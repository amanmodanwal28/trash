export const VideoStore = {
  videoList: [],
  currentIndex: "",
  currentVideoUrl: "",
  selectedCategory: "",
  VideoCategory: "",
  advertisementSeconds: "",
  adList: [],
  videoName: "",
  token: "",

  // 👇 NEW: Listeners array to notify components
  listeners: [],

  // 👇 NEW: Subscribe method for components
  subscribe(callback) {
    this.listeners.push(callback);
    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter(
        (listener) => listener !== callback
      );
    };
  },

  // 👇 NEW: Notify all listeners when video changes
  notifyListeners() {
    this.listeners.forEach((callback) => {
      callback({
        videoName: this.videoName,
        currentIndex: this.currentIndex,
        videoUrl: this.currentVideoUrl,
      });
    });
  },
  // 👇 UPDATED: Now notifies listeners after state change
  setVideoState(
    videoList,
    currentIndex,
    url,
    selectedCategory,
    VideoCategory,
    advertisementSeconds,
    adList,
    videoName,
    token
  ) {
    this.videoList = videoList;
    this.currentIndex = currentIndex;
    this.currentVideoUrl = url;
    this.selectedCategory = selectedCategory;
    this.VideoCategory = VideoCategory;
    this.advertisementSeconds = advertisementSeconds;
    this.adList = adList;
    this.videoName = videoName;
    this.token = token;
    // 👇 Notify all subscribed components
    this.notifyListeners();
  },
  // 👇 NEW: Helper method to update just the video
  updateCurrentVideo(videoName, index, videoUrl) {
    this.videoName = videoName;
    this.currentIndex = index;
    this.currentVideoUrl = videoUrl;

    // Notify all listeners
    this.notifyListeners();
  },
};