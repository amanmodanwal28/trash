// src/components/ProtectedRoute.jsx
import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children }) => {
  const isLoggedIn = sessionStorage.getItem('isLoggedIn') === 'true';
  const expirationTime = sessionStorage.getItem('expirationTime');
  const currentTime = new Date().getTime();

  useEffect(() => {
    if (!isLoggedIn || !expirationTime || currentTime > expirationTime) {
      // console.log('Redirecting to login due to unauthorized access or expired session.');
      sessionStorage.removeItem('isLoggedIn');
      sessionStorage.removeItem('expirationTime');
    }
  }, [isLoggedIn, expirationTime, currentTime]);

  if (!isLoggedIn || !expirationTime || currentTime > expirationTime) {
    return <Navigate to="/Attendent-Login" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
