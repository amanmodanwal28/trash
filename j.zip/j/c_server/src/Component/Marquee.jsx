/* eslint-disable no-unused-vars */
import React from 'react';
import '../Css/Marquee.css'; // Make sure to create this CSS file

const Marquee = () => {
  return (
    <div className="marquee"
    onContextMenu={(e) => e.preventDefault()}>
       <div className="marquee-contentMain">
          Welcome to Indian Railway !!
        </div> 
        
     </div>
  );
};

export default Marquee;
