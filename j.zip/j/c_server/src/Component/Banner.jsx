/* eslint-disable react/no-unknown-property */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react'
import '../Css/Banner.css' // Adjust the path if needed
import useLogin from '@api/useLogin'
import { decryptData } from '@api/cryptoUtils'

const Banner = () => {
  const [mediaUrl, setMediaUrl] = useState('')
  const [randomcurrentIndex, setRandomcurrentIndex] = useState(
    () => Math.floor(Math.random() * 15) + 1
  )
  const [fileList, setFileList] = useState([]) // Media file list from API
  const [isVideo, setIsVideo] = useState(false) // To track if the current media is a video
  const [currentIndex, setCurrentIndex] = useState(
    () => Math.floor(Math.random() * randomcurrentIndex) + 1
  )
  const { token } = useLogin()
  // Fetch media list from the API
  useEffect(() => {
    fetch(`/api/add`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`)
        }
        return response.json() // Parse as JSON only if the response is OK
      })
      .then((mediaData) => {
        // Decrypt file names
        const decryptedData = mediaData.map((item) => ({
          ...item,
          name: decryptData(item.name), // Decrypt the file name
        }))
// console.log('Decrypted index 8:', decryptedData[8])
        // console.log('Decrypted media data:', decryptedData); // Verify decrypted data
        setFileList(decryptedData)
        // console.log(mediaData);  // Log the data to ensure it's correct
        // setFileList(mediaData);  // Assuming the API returns an array of media items
        setRandomcurrentIndex()
      })
      .catch((error) =>
        console.error('Error fetching media list:', error.message)
      )
  }, [token])

  // console.log(token)

  // Function to get a random index that is not the same as the current index
  const getRandomIndex = (length, currentIndex) => {
    if (length <= 1) return 0 // Handle edge case where only one media exists
    let randomIndex
    do {
      randomIndex = Math.floor(Math.random() * length)
    } while (randomIndex === currentIndex) // Ensure the random index is different
    return randomIndex
  }

  useEffect(() => {
    let previousMediaUrl = mediaUrl // Store the previous URL for revoking later

    const loadMedia = () => {
      if (fileList.length > 0) {
        const currentMedia = fileList[currentIndex] // Get the media object at the current index
        if (currentMedia && currentMedia.name) {
          let MediaPlay = `/api/add/${currentMedia.name}`
          fetch(MediaPlay, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          })
            .then((response) => {
              if (!response.ok) {
                throw new Error('Failed to fetch media')
              }
              return response.blob() // Get the media data as a Blob
            })
            .then((blob) => {
              const url = URL.createObjectURL(blob) // Create a URL for the Blob
              setMediaUrl(url) // Set the new media URL

              // Revoke the previous Blob URL
              if (previousMediaUrl) {
                URL.revokeObjectURL(previousMediaUrl)
              }

              // Check if the current media is a video
              const isVideoMedia =
                currentMedia.name.endsWith('.mp4') ||
                currentMedia.name.endsWith('.webm')
              setIsVideo(isVideoMedia)
            })
          .catch((error) => {
      console.error('Error fetching media:', error)
      // Try the next index
      setCurrentIndex((prev) => (prev + 1) % fileList.length)
    })
        }
      }
    }

    loadMedia() // Load the media for the current index
    let intervalId = null
    clearInterval(intervalId)

    if(!isVideo) {
      intervalId = setTimeout(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % fileList.length)
      }, 5000)
    }
    
    return () => {
      if (mediaUrl) {
        URL.revokeObjectURL(mediaUrl) // Revoke the current media URL on unmount
      }
      clearTimeout(intervalId)
    }
  }, [currentIndex, fileList, isVideo])

  // Handle the video end event to select the next media randomly
  const handleVideoEnd = () => {
    const nextIndex = getRandomIndex(fileList.length, currentIndex)
    setCurrentIndex(nextIndex) // Move to the next random media
  }

  const currentMedia = fileList[currentIndex] || {} // Current media object
  // console.log(currentMedia)

  useEffect(() => {
    const videoElement = document.querySelector('video')
    if (videoElement) {
      videoElement.setAttribute('playsinline', 'true')
      videoElement.setAttribute('webkit-playsinline', 'true')
    }
  }, [mediaUrl])


  // console.log("mediaurl update " , mediaUrl)
  //   console.log("CurrentINdex " , currentIndex)
  //     console.log("fileList length update " , fileList.length)
  //       console.log("Isvideo " , isVideo)

  return (
    <div className="banner" onContextMenu={(e) => e.preventDefault()}>
      <div
        className="media-container"
        onContextMenu={(e) => e.preventDefault()}
      >
        {mediaUrl &&
          (currentMedia.name?.endsWith('.mp4') ||
          currentMedia.name?.endsWith('.webm') ? (
            <video
              key={currentMedia.name}
              src={mediaUrl}
              autoPlay
              loop={false} // Video plays once
              muted
              playsInline
              webkit-playsinline="true"
              onEnded={handleVideoEnd} // Move to the next media after the video ends
              onContextMenu={(e) => e.preventDefault()}
            />
          ) : (
            <img
              key={currentMedia.name}
              src={mediaUrl}
              alt={currentMedia.name}
              onContextMenu={(e) => e.preventDefault()}
            />
          ))}
      </div>
    </div>
  )
}

export default Banner
