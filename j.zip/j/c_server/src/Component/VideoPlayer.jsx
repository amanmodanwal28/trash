/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable no-unused-vars */
/* eslint-disable no-empty */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react/prop-types */
import { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import "video.js/dist/video-js.css";
import "./VideoPlayer.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faPlay,
  faPause,
  faStepBackward,
  faStepForward,
  faRotateLeft,
  faRotateRight,
  faLock,
  faLockOpen,
  faSun,
  faVolumeHigh,
  faExpand,
  faCompress,
  faClone,
  faGaugeHigh,
  faAngleDown,
} from "@fortawesome/free-solid-svg-icons";
import { VideoStore } from "../Store/VideoStore";
const IMAGE_AD_DURATION = 5;
const AD_THRESHOLD = 0.5; // ✅ Only trigger ad within 0.5 seconds of scheduled time

const isImage = (u) => /\.(jpg|jpeg|png|gif|webp)$/i.test(u);
const isVideo = (u) => /\.(mp4|mov|webm|mkv)$/i.test(u);

// Format time in MM:SS (minutes:seconds)
const fmt = (s = 0) => {
  if (!isFinite(s)) return "00:00:00";

  const hours = Math.floor(s / 3600);
  const minutes = Math.floor((s % 3600) / 60);
  const seconds = Math.floor(s % 60);

  if (hours > 0) {
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(
      2,
      "0"
    )}:${String(seconds).padStart(2, "0")}`;
  }

  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(
    2,
    "0"
  )}`;
};


export default function VideoPlayer({
  videoList,
  currentIndex,
  videoUrl,
  selectedCategory,
  VideoCategory,
  advertisementSeconds,
  advertisementData,
  videoName,
  token,
  
}) {
  const container = useRef(null);
  const wrap = useRef(null);
  const main = useRef(null);
  const ad = useRef(null);
  const adContainer = useRef(null);

  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [paused, setPaused] = useState(true);
  const [rate, setRate] = useState(1);
  const [vol, setVol] = useState(1);
  const [visible, setVisible] = useState(true);
  const [locked, setLocked] = useState(false);
  const [bright, setBright] = useState(0.5);
  const [showSpeed, setShowSpeed] = useState(false);
  const [pip, setPip] = useState(false);
  const [adPlaying, setAdPlaying] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [error, setError] = useState(null);
  const hasResumed = useRef(false);
  const mainVideoNode = useRef(null); // 👈 ADD THIS
  const [edgeMsg, setEdgeMsg] = useState("");
  const hideT = useRef(null);
  const nextAdTime = useRef(null);
  const triggering = useRef(false);
  const imageAdTimer = useRef(null);
  const adShownCount = useRef(0);
  const lastAdTriggerTime = useRef(-999); // ✅ Prevent duplicate triggers
  const pipLocked = useRef(false);
  const wasFullscreen = useRef(false);

  const showControls = () => {
    if (locked) return;
    // clear old timer
    if (hideT.current) {
      clearTimeout(hideT.current);
      hideT.current = null;
    }

    setVisible(true);
    // if (!adPlaying && !paused) {
    //   hideT.current = setTimeout(() => {
    //     setVisible(false);
    //   }, 3000);
    // }
  };

  const changeRate = (r) => {
    if (!main.current) return;
    main.current.playbackRate(r);
    setRate(r);
    setShowSpeed(false);
  };

  const enterFullscreen = async () => {
    const el = container.current;
    if (!el || document.fullscreenElement) return;

    try {
      await el.requestFullscreen();
      setIsFullscreen(true);

      if (screen.orientation?.lock) {
        try {
          await screen.orientation.lock("landscape");
        } catch {}
      }
    } catch (err) {
      console.warn("Enter fullscreen failed:", err);
    }
  };

  const exitFullscreen = async () => {
    if (!document.fullscreenElement) return;

    try {
      await document.exitFullscreen();
      setIsFullscreen(false);

      if (screen.orientation?.unlock) {
        try {
          screen.orientation.unlock();
        } catch {}
      }
    } catch (err) {
      console.warn("Exit fullscreen failed:", err);
    }
  };



  const toggleFullScreen = () => {
    if (document.fullscreenElement) {
      exitFullscreen();
    } else {
      enterFullscreen();
    }
  };


  const resumeData = useRef({});

  const saveResume = (src, time) => {
    resumeData.current[src] = time;
  };

  const getResume = (src) => {
    return resumeData.current[src] || 0;
  };

  const clearResume = (src) => {
    delete resumeData.current[src];
  };

  const togglePiP = async () => {
    const v = main.current?.tech()?.el();
    if (!v) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setPip(false);
      } else {
        await v.requestPictureInPicture();
        setPip(true);
      }
    } catch (err) {
      console.warn("PiP failed:", err);
    }
  };

  useEffect(() => {
    const onEnter = () => setPip(true);
    const onLeave = () => setPip(false);

    document.addEventListener("enterpictureinpicture", onEnter);
    document.addEventListener("leavepictureinpicture", onLeave);

    return () => {
      document.removeEventListener("enterpictureinpicture", onEnter);
      document.removeEventListener("leavepictureinpicture", onLeave);
    };
  }, []);

  const closePiPIfOpen = async () => {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      }
    } catch (e) {}
    setPip(false);
  };

  const canGoNext = videoList.length > 1;
  const canGoPrevious = videoList.length > 1;

  const goToNext = async () => {
    if (adPlaying || !videoList.length) return;

    // ✅ Force close ad if playing

    if (adPlaying) {
      forceCloseAd();
    }

    if (VideoStore.currentIndex === videoList.length - 1) {
      showEdgeMsg("No next video available");
      return;
    }

    await closePiPIfOpen();
    const nextIndex = VideoStore.currentIndex + 1;
    const nextVideo = videoList[nextIndex];
    if (!nextVideo?.name) return;

    const nextUrl = `/api/${VideoCategory}/${selectedCategory}/${nextVideo.name}`;
    // this is very importNT LINE FOR UPDATE NAME
    VideoStore.updateCurrentVideo(nextVideo.name, nextIndex, nextUrl);
    // ✅ Reset ad tracking
    adShownCount.current = 0;
    nextAdTime.current = advertisementSeconds;
    lastAdTriggerTime.current = -999;

    const player = main.current;
    if (player && !player.isDisposed()) {
      player.src({ src: nextUrl, type: getVideoType(nextUrl) });
      player.play();
    }
  };

  const handleVideoDoubleClick = () => {
    if (!adPlaying) {
      // toggleFullScreen();
      togglePlay();
    }
  };

  const goToPrevious = async () => {
    if (adPlaying || !videoList.length) return;

    const currentIndex = VideoStore.currentIndex;

    if (currentIndex === 0) {
      showEdgeMsg("No previous video available");
      return;
    }

    await closePiPIfOpen();
    const prevIndex = currentIndex - 1;
    const prevVideo = videoList[prevIndex];
    if (!prevVideo?.name) return;

    const prevUrl = `/api/${VideoCategory}/${selectedCategory}/${prevVideo.name}`;

    // ✅ Reset ad tracking
    adShownCount.current = 0;
    nextAdTime.current = advertisementSeconds;
    lastAdTriggerTime.current = -999;

    VideoStore.updateCurrentVideo(prevVideo.name, prevIndex, prevUrl);
    const player = main.current;
    if (player && !player.isDisposed()) {
      player.src({ src: prevUrl, type: getVideoType(prevUrl) });
      player.play();
    }
  };

  const showEdgeMsg = (msg) => {
    setEdgeMsg(msg);
    setTimeout(() => setEdgeMsg(""), 2000);
  };



  const startAd = async () => {
    if (!advertisementData.length || adPlaying || triggering.current) return;

    const p = main.current;
    if (!p) return;

    // 🔒 HARD PiP SECURITY LOCK (must be FIRST)
    pipLocked.current = true;

    triggering.current = true;
    setAdPlaying(true);
    setPaused(true);
    p.pause();


    // ---------- FETCH AD ----------
    const adObj =
      advertisementData[Math.floor(Math.random() * advertisementData.length)];

    if (!adObj?.name) return;

    const apiUrl = `/api/advertisment/${adObj.name}`;

    const headers = {
      Authorization: `Bearer ${token}`,
    };
    try {
      const response = await fetch(apiUrl, { headers });
      if (!response.ok) {
        console.error("Failed to fetch advertisement:", response.status);
        return;
      }
      const blob = await response.blob();
      const adUrl = URL.createObjectURL(blob);

      const resumeTime = p.currentTime();

      p.pause();
      triggering.current = true;
      setAdPlaying(true);
      setPaused(true);

      if (wrap.current) wrap.current.style.visibility = "hidden";

      const adDiv = document.createElement("div");
      adDiv.className = "ad-overlay";
      adDiv.style.cssText =
        "position:absolute;top:0;left:0;width:100%;height:100%;z-index:9999;background:#000;display:flex;align-items:center;justify-content:center;";
      container.current.appendChild(adDiv);
      adContainer.current = adDiv;

      const endAd = () => {
        pipLocked.current = false; // 🔓 UNLOCK

        if (imageAdTimer.current) {
          clearTimeout(imageAdTimer.current);
          imageAdTimer.current = null;
        }

        if (ad.current) {
          ad.current.dispose();
          ad.current = null;
        }

        if (adContainer.current) {
          adContainer.current.remove();
          adContainer.current = null;
        }

        if (wrap.current) {
          wrap.current.style.visibility = "visible";
        }

        p.currentTime(resumeTime);

        setTimeout(() => {
          p.play();
          setAdPlaying(false);
          setPaused(false);
          triggering.current = false;

          // ✅ FIX: Use advertisementSeconds directly (already in seconds)
          adShownCount.current += 1;
          nextAdTime.current += advertisementSeconds;

          console.log(`✅ Ad completed. Next ad at: ${nextAdTime.current}s`);
        }, 100);
      };

      // ---------- PLAY AD ----------
      if (isImage(adObj.name)) {
        const img = document.createElement("img");
        img.className = "ad-image";
        img.src = adUrl;
        img.style.cssText = "max-width:90%;max-height:90%;object-fit:contain;";
        img.onload = () => {
          // console.log("🖼 Image ad loaded")
        };
        img.onerror = () => {
          console.error("Image ad failed to load");
          endAd();
        };
        adDiv.appendChild(img);
        imageAdTimer.current = setTimeout(endAd, IMAGE_AD_DURATION * 1000);
        return;
      }

      if (isVideo(adObj.name)) {
        const vid = document.createElement("video");
        vid.className = "video-js vjs-default-skin ad-video";
        vid.setAttribute("playsinline", "true");
        vid.setAttribute("webkit-playsinline", "true");
        adDiv.appendChild(vid);

        const adPlayer = videojs(vid, {
          controls: false,
          autoplay: true,
          preload: "metadata",
          muted: false,
          sources: [{ src: adUrl, type: "video/mp4" }],
        });

        ad.current = adPlayer;
        adPlayer.ready(() => {
          const playPromise = adPlayer.play();
          if (playPromise) {
            playPromise
              .then(() => console.log("▶️ Ad play started"))
              .catch((err) => console.error("⛔ Ad play blocked", err));
          }
        });

        adPlayer.on("error", (err) => {
          console.error("❌ Ad error:", err);
          endAd();
        });
        adPlayer.on("ended", endAd);
      }
    } catch (error) {
      console.error("Error fetching advertisement:", error);
      triggering.current = false;
    }
  };

  // ✅ NEW: Function to forcefully close any running ad
  const forceCloseAd = () => {
    if (imageAdTimer.current) {
      clearTimeout(imageAdTimer.current);
      imageAdTimer.current = null;
    }

    if (ad.current) {
      ad.current.dispose();
      ad.current = null;
    }

    if (adContainer.current) {
      adContainer.current.remove();
      adContainer.current = null;
    }

    if (wrap.current) {
      wrap.current.style.visibility = "visible";
    }

    pipLocked.current = false;

    setAdPlaying(false);
    triggering.current = false;
  };

  useEffect(() => {
    const onFsChange = () => {
      const fs = !!document.fullscreenElement;
      setIsFullscreen(fs);

      if (!fs && screen.orientation?.unlock) {
        try {
          screen.orientation.unlock();
        } catch {}
      }
    };

    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  useEffect(() => {
    if (!videoUrl) return;

    // ✅ Force close ad when video changes
    if (adPlaying) {
      forceCloseAd();
    }

    if (isImage(videoUrl)) {
      if (wrap.current) {
        wrap.current.innerHTML = "";
        const img = document.createElement("img");
        img.src = videoUrl;
        img.style.cssText = "width:100%;height:100%;object-fit:contain;";
        wrap.current.appendChild(img);
      }
      return;
    }

    // create permanent video node
    if (!mainVideoNode.current) {
      const el = document.createElement("video");
      el.className = "video-js vjs-default-skin";
      el.setAttribute("playsinline", "");
      el.setAttribute("webkit-playsinline", "");
      el.style.cssText = "width:100%;height:100%;object-fit:contain;";
      wrap.current.appendChild(el);
      mainVideoNode.current = el;
    }

    // create VideoJS once
    if (!main.current) {
      main.current = videojs(mainVideoNode.current, {
        controls: false,
        preload: "auto",
        autoplay: true,
        playbackRates: [0.5, 1, 1.25, 1.5, 2],
        html5: {
          vhs: { overrideNative: true },
          nativeVideoTracks: false,
          nativeAudioTracks: false,
          nativeTextTracks: false,
        },
      });

      // register events ONCE
      const p = main.current;

      p.on("loadedmetadata", () => {
        setDuration(p.duration());
        adShownCount.current = 0;
        nextAdTime.current = advertisementSeconds;
        lastAdTriggerTime.current = -999;
        console.log(`✅ Video loaded. First ad at: ${advertisementSeconds}s`);
      });

      p.on("timeupdate", () => {
        if (adPlaying || triggering.current) return;
        const t = p.currentTime();
        setCurrent(t);
        saveResume(videoUrl, t);
        // ✅ FIX: Check ad trigger correctly
        if (
          advertisementData.length &&
          t >= nextAdTime.current &&
          t < nextAdTime.current + AD_THRESHOLD &&
          Math.abs(t - lastAdTriggerTime.current) > 2 // ✅ 2 second cooldown
        ) {
          // console.log(`🎬 Triggering ad at ${t.toFixed(1)}s (scheduled: ${nextAdTime.current}s)`);
          lastAdTriggerTime.current = t;
          startAd();
        }
      });

      p.on("play", () => {
        if (pipLocked.current || adPlaying) {
          p.pause();
          return;
        }

        // ✅ AUTO FULLSCREEN on play
        enterFullscreen();


        // ✅ FIX: Resume logic without * 60
        if (!hasResumed.current) {
          const resumeTime = getResume(videoUrl);
          const dur = p.duration();

          if (resumeTime > 2 && resumeTime < dur - 2) {
            p.currentTime(resumeTime);

            // Calculate next ad based on resume time
            const intervalSec = advertisementSeconds; // ✅ Already in seconds!
            nextAdTime.current =
              Math.ceil(resumeTime / intervalSec) * intervalSec;
            console.log(
              `▶️ Resumed at ${resumeTime}s. Next ad at: ${nextAdTime.current}s`
            );
          }
          hasResumed.current = true;
        }
        setPaused(false);
      });

      p.on("pause", () => !adPlaying && setPaused(true));
      p.on("volumechange", () => setVol(p.volume()));

      p.on("ended", () => {
        clearResume(videoUrl);

        if (document.fullscreenElement) {
          toggleFullScreen();
        }

        goToNext();
      });

      p.on("error", () => {
        const err = p.error();
        setError(err ? `Error ${err.code}: ${err.message}` : "Video error");
      });
    }

    // HARD PiP kill (this is what finally fixes your bug)
    (async () => {
      try {
        if (document.pictureInPictureElement) {
          await document.exitPictureInPicture();
        }
      } catch {}

      const p = main.current;
      p.pause();
      p.src({ src: videoUrl, type: getVideoType(videoUrl) });
      p.load();
      // ✅ Reset tracking for new video
      hasResumed.current = false;
      adShownCount.current = 0;
      nextAdTime.current = advertisementSeconds;
      lastAdTriggerTime.current = -999;

      p.play();
    })();
  }, [videoUrl]);

  const togglePlay = async () => {
    if (locked || adPlaying) return;
    const p = main.current;
    if (!p) {
      console.warn("No player instance");
      return;
    }
    if (p.paused()) {
      try {
        await p.play();
      } catch (err) {
        console.error("❌ Play failed:", err);
        setError(`Play failed: ${err.message}`);
      }
    } else {
      p.pause();
    }
    showControls();
  };

  const seek = (v) => {
    if (locked || adPlaying || !main.current) return;

    setCurrent(v);
    main.current.currentTime(v);
  };

  const getVideoType = (url) => {
    if (url.endsWith(".webm")) return "video/webm";
    if (url.endsWith(".mp4")) return "video/mp4";
    if (url.endsWith(".mov")) return "video/quicktime";
    if (url.endsWith(".mkv")) return "video/x-matroska";
    return "video/mp4";
  };

  const handleVolumeChange = (e) => {
    if (!main.current) return;
    const newVol = parseFloat(e.target.value);
    main.current.volume(newVol);
    setVol(newVol);
  };

  return (
    <div
      className={`vp-container ${locked ? "locked" : ""}${
        isFullscreen ? "is-fullscreen" : ""
      }`}
      ref={container}
      onClick={showControls}
      onTouchStart={showControls} // 👈 MOBILE FIX
      onMouseMove={showControls}
      onDoubleClick={handleVideoDoubleClick}
    >
      <div
        ref={wrap}
        className="video-wrapper"
        style={{
          filter: `brightness(${0.5 + Number(bright)})`,
        }}
      />

      {/* {error && <div className="error-overlay">{error}</div>} */}
      {error && (
        <div className="error-overlay">
          {
            "The media could not be loaded, either because the server or the format is not supported"
          }
        </div>
      )}
      {videoUrl && (
        <>
          <div
            onClick={() => setLocked((x) => !x)}
            className={`lock-btn ${visible ? "show" : ""}`}
          >
            <FontAwesomeIcon icon={locked ? faLock : faLockOpen} />
          </div>
          {/* SPEED CONTROL - Top Left */}
          {!locked && !adPlaying && (
            <div className="top-left-controls">
              <div className="speed-menu">
                <div
                  onClick={() => setShowSpeed(!showSpeed)}
                  className=" speed-btn"
                  title="Speed"
                >
                  <FontAwesomeIcon icon={faGaugeHigh} /> {rate}x
                </div>

                {showSpeed && (
                  <div className="speed-dropdown">
                    {[0.5, 1, 1.25, 1.5, 2].map((r) => (
                      <div
                        key={r}
                        onClick={() => changeRate(r)}
                        className={`speed-option ${rate === r ? "active" : ""}`}
                      >
                        <FontAwesomeIcon icon={faGaugeHigh} /> {r}x
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* BRIGHTNESS SLIDER - Right Side */}
          {!locked && !adPlaying && (
            <div
              className={`right-vertical-brightness ${visible ? "show" : ""}`}
            >
              <FontAwesomeIcon icon={faSun} />
              <input
                type="range"
                className="mobile-vertical-slider brightness-slider"
                min="0"
                max="1"
                step="0.01"
                value={bright}
                onChange={(e) => setBright(e.target.value)}
              />
            </div>
          )}
          {/* VOLUME SLIDER - Left Side */}
          {!locked && !adPlaying && (
            <div className={`left-vertical-volume ${visible ? "show" : ""}`}>
              <FontAwesomeIcon icon={faVolumeHigh} />
              <input
                type="range"
                className="mobile-vertical-slider volume-slider"
                min="0"
                max="1"
                step="0.01"
                value={vol}
                onChange={handleVolumeChange}
              />
            </div>
          )}
          {/* JUMP ZONES - Left & Right */}
          {!locked && !adPlaying && (
            <>
              {/* LEFT BACKWARD ZONE */}
              <div className={`jump-zone left ${visible ? "show" : ""}`}>
                <div onClick={() => seek(Math.max(0, current - 10))}>
                  <div className="jump-icon">
                    <FontAwesomeIcon icon={faRotateLeft} />
                  </div>
                </div>
              </div>

              {/* RIGHT FORWARD ZONE */}
              <div className={`jump-zone right ${visible ? "show" : ""}`}>
                <div onClick={() => seek(Math.min(duration, current + 10))}>
                  <div className="jump-icon">
                    <FontAwesomeIcon icon={faRotateRight} />
                  </div>
                </div>
              </div>
            </>
          )}
          {/* BOTTOM CONTROLS */}
          {!locked && !adPlaying && (
            <div className={`bottom-controls ${visible ? "show" : ""}`}>
              <div className="time-and-seekbar">
                <span className="time-display left-time">{fmt(current)}</span>
                <input
                  type="range"
                  className="seekbar-full"
                  min={0}
                  max={duration || 100}
                  step="0.1"
                  value={current}
                  onChange={(e) => seek(Number(e.target.value))}
                  style={{
                    "--seek-progress": `${(current / duration) * 100}%`,
                  }}
                />
                <span className="time-display right-time">{fmt(duration)}</span>
              </div>

              <div className="controls-row">
                <div className="controls-spacer" />
                <div className="controls-center">
                  <div className="controls-left">
                    <button
                      onClick={goToPrevious}
                      disabled={!canGoPrevious}
                      className="control-btn"
                    >
                      <FontAwesomeIcon icon={faStepBackward} />
                    </button>
                    <button onClick={togglePlay} className="control-btn">
                      <FontAwesomeIcon icon={paused ? faPlay : faPause} />
                    </button>
                    <button
                      onClick={goToNext}
                      disabled={!canGoNext}
                      className="control-btn"
                    >
                      <FontAwesomeIcon icon={faStepForward} />
                    </button>
                  </div>
                </div>

                <div className="controls-right">
                  <button
                    onClick={togglePiP}
                    className="control-btn"
                    title="Picture-in-Picture"
                  >
                    <FontAwesomeIcon icon={faClone} />
                  </button>
                  <button
                    onClick={toggleFullScreen}
                    className="control-btn"
                    title="Fullscreen"
                  >
                    <FontAwesomeIcon
                      icon={isFullscreen ? faCompress : faExpand}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}
          {/* TOAST MESSAGE */}
          {edgeMsg && <div className="edge-toast">{edgeMsg}</div>}
        </>
      )}
    </div>
  );
}
