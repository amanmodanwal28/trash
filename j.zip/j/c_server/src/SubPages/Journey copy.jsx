/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react'
import MarqueeWithBack from '../Component/MarqueeWithBack'
import Banner from '../Component/Banner'
import Footer from '../Component/Footer'
import '../Css/Journey.css'
import { io } from 'socket.io-client'

const Journey = () => {
  const SERVER_PORT = import.meta.env.VITE_SERVER_PORT || 5000
  const SERVER_HOST = import.meta.env.VITE_SERVER_HOST || '192.168.0.243' // Replace with actual IP
  let serverUrl = `http://${SERVER_HOST}:${SERVER_PORT}`

  const [journeyData, setJourneyData] = useState({
    adtns: null, // Approx distance to next station
    ss: null, // Source station
    ns: null, // Next station
    ds: null, // Destination station
    trainName: null, // Train name
    trainNumber: null,
    trainSpeed: null,
  })

  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Browser environment
      serverUrl = `${window.location.protocol}//${window.location.hostname}:${
        import.meta.env.VITE_SERVER_PORT
      }`
    }

    const socket = io(serverUrl, {
      transports: ['websocket'], // Ensure compatibility with mobile devices
    })

    socket.on('connect', () => {
      console.log('WebSocket Connected:', socket.id)
    })

    // Listen for UDP data and update state
    socket.on('udpData', (message) => {
      console.log('Received UDP data:', message) // Debug log
      if (message) {
       setJourneyData({
         adtns: message.distanceTonextStationName ?? null,
         ss: message.sourceStationName ?? null,
         ns: message.nextStationName ?? null,
         ds: message.destinationStationName ?? null,
         trainName: message.trainName ?? null,
         trainNumber: message.routeNumber ?? null, // backend sends routeNumber
         trainSpeed: message.trainSpeed ?? null,
       })

      }
    })

    return () => {
      socket.disconnect() // Clean up WebSocket connection on unmount
    }
  }, [])
  const MAX_DISTANCE = 50000 // 50 km
  const loadingText = 'Updating information, please wait...'
const distanceKm =
  journeyData.adtns !== null ? (journeyData.adtns / 1000).toFixed(1) : null

const distancePercent =
  journeyData.adtns !== null
    ? Math.min((journeyData.adtns / MAX_DISTANCE) * 100, 100)
    : 0

  return (
    <div onContextMenu={(e) => e.preventDefault()}>
      <MarqueeWithBack />
      <Banner />
      <div className="journey-timeline">
        <div className="timeline-header">
          <h2>🚆 Journey Status</h2>
          <div className="train-meta">
            <div className="train-title">
              {journeyData.trainName || loadingText}
            </div>

            <div className="train-submeta">
              <span>
                <strong>Train Number:</strong> {journeyData.trainNumber || '--'}
              </span>
              <span>
                <strong>Speed:</strong>{' '}
                {journeyData.trainSpeed
                  ? `${journeyData.trainSpeed} km/h`
                  : '--'}
              </span>
            </div>
          </div>
        </div>
        <div className="timeline">
          {/* Source Station */}
          <div className="timeline-item">
            <div className="timeline-icon">🚉</div>
            <div className="timeline-content">
              <h4>Source Station</h4>
              <p>
                <strong>{journeyData.ss || loadingText}</strong>
              </p>
            </div>
          </div>

          {/* Next Station */}
          <div className="timeline-item">
            <div className="timeline-icon">⏩</div>
            <div className="timeline-content">
              <h4>Next Station</h4>
              <p>
                <strong>{journeyData.ns || loadingText}</strong>
                <span className="status-badge upcoming">Upcoming</span>
              </p>

              <p
                style={{ marginTop: '6px', fontSize: '14px', color: '#cfd8dc' }}
              >
                Distance to next station:{' '}
                <strong>
                  {distanceKm !== null ? `${distanceKm} km` : loadingText}
                </strong>
              </p>

              <div className="distance-progress"></div>
            </div>
          </div>

          {/* Destination */}
          <div className="timeline-item">
            <div className="timeline-icon">🏁</div>
            <div className="timeline-content">
              <h4>Destination</h4>
              <p>
                <strong>{journeyData.ds || loadingText}</strong>
              </p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}

export default Journey
