import React, { useEffect, useState, useRef } from 'react';
import MarqueeWithBack from "../Component/MarqueeWithBack";
import Banner from "../Component/Banner";
import Footer from "../Component/Footer";
import useLogin from "@api/useLogin";
import Popup2 from "../Component/Popup2";
import '../Css/Music.css';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBackward, faForward, faPause, faPlay } from "@fortawesome/free-solid-svg-icons";

import { decryptData } from '@api/cryptoUtils'

const Music = () => {
  const [fileList, setFileList] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [currentSong, setCurrentSong] = useState(null);
  const [currentSongIndex, setCurrentSongIndex] = useState(0);
  const audioRef = useRef(null);
  const { token } = useLogin();
  const [isUserPaused, setIsUserPaused] = useState(false);
  const [seekValue, setSeekValue] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);

    useEffect(() => {
        Promise.all([
          fetch(`/api/music`, {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          }),
        ])
        .then(([AudioCategory,]) => {
          return Promise.all([
            AudioCategory.json(),
          ]);
        })
        .then(([AudioData,]) => {
          const decryptedData = AudioData.map(item => ({
                          ...item,
                          name: decryptData(item.name), // Decrypt the file name
                        }));
          // console.log(decryptedData)
          setFileList(decryptedData);
          
        })
        .catch((error) => console.error('Error fetching files:', error));
      
    }, [ token]);

  const pauseMedia = () => {
    if (audioRef.current && !audioRef.current.paused) {
      audioRef.current.pause(); // Pause the audio
      setIsUserPaused(true); 
    }

  };
  
  const resumeMedia = () => {
    if (audioRef.current && audioRef.current.paused) {
      audioRef.current.play(); // Resume the audio
      setIsUserPaused(false);
      
    }
  };

  const handlePlayPauseClick = () => {
    // Toggle between play and pause on button click
    if (audioRef.current && audioRef.current.paused) {
      resumeMedia()
    } else {
      pauseMedia()
    }
  };

  useEffect(() => {
    if (fileList.length > 0 && !selectedCategory) {
      const firstCategory = fileList.find(file => file.type === 'directory');
      if (firstCategory) setSelectedCategory(firstCategory.name);
    }
  }, [fileList, selectedCategory]);

  const categories = fileList.filter((file) => file.type === 'directory');

  const capitalizeFirstLetter = (string) => {
    if (!string) return '';
    return string.charAt(0).toUpperCase() + string.slice(1);
  };
  
  const renderCategory = (category) => (
    <div
      key={category.name}
      className={`category-box ${selectedCategory === category.name ? 'selected' : ''}`}
      onClick={() => setSelectedCategory(category.name)}
    >
      <strong>{capitalizeFirstLetter(category.name)}</strong>
    </div>
  );


  const renderSongs = (category) => {
    const songs = fileList.find(file => file.name === category)?.children || [];
    return songs.map((song, index) => {
      const isPlaying = currentSong === song.name;
      return (
        <li
          key={song.name || `${category}-${index}`}
          className={isPlaying ? 'highlight' : ''}
          style={isPlaying ? { backgroundColor: '#f0f8ff', fontWeight: 'bold' } : {}}
          onClick={() => handleSongClick(song.name, index)} // Move click handler here
        >
          <span>
            {index + 1}. {capitalizeFirstLetter(song.name)}
          </span>
        </li>
      );
    });
  };


  const handleSongClick = async (songName, index) => {
    if (currentSong === songName) return;

    setCurrentSong(songName);
    setCurrentSongIndex(index);

    if (audioRef.current) {
      audioRef.current.pause(); // Pause if playing
      audioRef.current.src = "";

      try {
        // Send an authenticated request to fetch the song
        const response = await fetch(`/api/music/${selectedCategory}/${songName}`, {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${token}`, // Include the token in the request
          },
        });

        if (!response.ok) {
          if (response.status === 403) {
            console.warn(
              `Song "${songName}" cannot be played (missing PPS header/footer)`
            );
          } else {
            console.error(`Failed to fetch song: ${response.status}`);
          }
          return; // Exit without updating audio
        }
          const blob = await response.blob(); // Get the audio file as a Blob
          const url = URL.createObjectURL(blob); // Create a URL from the Blob
          audioRef.current.src = url; // Set the audio source to the fetched Blob URL
          await audioRef.current.play();
      setIsUserPaused(false); 
      // Wait until audio metadata is loaded before playing and updating seekbar
        audioRef.current.onloadedmetadata = () => {
          audioRef.current
            .play()
            .catch((err) => console.error("Audio play error:", err));
          setDuration(audioRef.current.duration || 0);
          setSeekValue(0);
        };

        // Reset seekbar as audio plays
        audioRef.current.ontimeupdate = () => {
          if (audioRef.current.duration > 0) {
            setSeekValue(
              (audioRef.current.currentTime / audioRef.current.duration) * 100
            );
          }
        };
          
          
      } catch (error) {
        console.error("Error playing audio:", error);
      }
    }
  };

  const handleNextSong = () => {
    const songs = fileList.find(file => file.name === selectedCategory)?.children || [];
    const nextIndex = (currentSongIndex + 1) % songs.length;
    // console.log('Next song index:', nextIndex);
    handleSongClick(songs[nextIndex].name, nextIndex);
  };
  
  const handlePreviousSong = () => {
    const songs = fileList.find(file => file.name === selectedCategory)?.children || [];
    const prevIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    // console.log('Previous song index:', prevIndex);
    handleSongClick(songs[prevIndex].name, prevIndex);
  };
  


  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.addEventListener('ended', handleNextSong);
  
      const handleKeyDown = (e) => {
        if (e.key === 'ArrowRight') {
          // Increment current time by 5 seconds and round to avoid floating-point issues
          audioRef.current.currentTime = Math.min(
            Math.floor(audioRef.current.currentTime + 5),
            Math.floor(audioRef.current.duration)
          );
        }
        if (e.key === 'ArrowLeft') {
          // Decrement current time by 5 seconds and round to avoid floating-point issues
          audioRef.current.currentTime = Math.max(
            Math.floor(audioRef.current.currentTime - 5),
            0
          );
        }
        if (e.code === 'Space') {
          audioRef.current.paused ? resumeMedia() : pauseMedia();
        }

        // Adjust volume on ArrowUp or ArrowDown relative to current volume
        if (e.key === 'ArrowUp') {
          // Increase volume by 5% of the current volume
          audioRef.current.volume = Math.min(audioRef.current.volume + 0.05, 1);
        }
        if (e.key === 'ArrowDown') {
          // Decrease volume by 5% of the current volume
          audioRef.current.volume = Math.max(audioRef.current.volume - 0.05, 0);
        }
      };
  
      window.addEventListener('keydown', handleKeyDown);
  
      return () => {
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [ fileList, selectedCategory]);
  
  useEffect(() => {
    // Media Session API integration for earbud play/pause control
    if ('mediaSession' in navigator) {
      navigator.mediaSession.setActionHandler('play', resumeMedia);
      navigator.mediaSession.setActionHandler('pause', pauseMedia);
      navigator.mediaSession.setActionHandler('seekbackward', () => {
        if (audioRef.current) audioRef.current.currentTime -= 5;
      });
      navigator.mediaSession.setActionHandler('seekforward', () => {
        if (audioRef.current) audioRef.current.currentTime += 5;
      });
          // Next and Previous track actions
    navigator.mediaSession.setActionHandler('nexttrack', handleNextSong);
    navigator.mediaSession.setActionHandler('previoustrack', handlePreviousSong);

    }else {
      console.warn('Media Session API not supported');
      // Handle fallback for unsupported environments
    }
  }, [currentSongIndex,isUserPaused]);

  const updateTime = () => {
    let initialTime = Math.floor(audioRef.current.currentTime)
    let totalTime = (Math.floor(audioRef.current.duration) || 0)
    if (audioRef.current) {
      setCurrentTime(initialTime);
      setSeekValue(((initialTime / totalTime) * 100) || 0);
    }
  };

  // // Set an interval to update current time every 500 milliseconds
  const interval = setInterval(updateTime, 1000);

  const formatTime = (time) => {
    if (isNaN(time) || time < 0) return "0:00"; // Handle NaN or negative values gracefully
    const hours = Math.floor(time / 3600); // Calculate total hours
    const minutes = Math.floor((time % 3600) / 60); // Calculate remaining minutes
    const seconds = Math.floor(time % 60); // Calculate remaining seconds
    if (hours > 0) {
      return `${hours}:${minutes < 10 ? "0" : ""}${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
    }
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  };
  
  const handleSeekChange = (e) => {
    const newSeekValue = e.target.value;
    
    setSeekValue(newSeekValue);
    if (audioRef.current) {
    let totalTime = Math.floor(audioRef.current.duration)
    
      audioRef.current.currentTime = (newSeekValue / 100) * totalTime;
    }
  };



  return (
    <>
     {/* <Popup2 pauseMedia={pauseMedia}
          resumeMedia={resumeMedia}
          isUserPaused={isUserPaused}/> */}
      <MarqueeWithBack />
      <Banner />
      <div className="music-container" >
          <div className="categories-heading">
            <h2>Music Categories</h2>
          </div>
          <div className="category-container" onContextMenu={(e) => e.preventDefault()}>
            {categories.map(renderCategory)}
          </div>
          {selectedCategory && (
              <ul className="file-list" onContextMenu={(e) => e.preventDefault()}>
                {renderSongs(selectedCategory)}
              </ul>
          )}
        <div
          className="audio-controls">
          <span className="current-song">
            {currentSong ? `Now Playing: ${currentSong}` : 'Select a song to play'}
          </span>
          <div className="time-container">
            <span className="time-text">
              {formatTime(currentTime)}
            </span>
            <input
              type="range"
              min="0"
              max="100"
              value={seekValue}
              className="seekbar"
              onChange={handleSeekChange} // Use the new handler
            />
            <span className="time-text">
              {duration ? formatTime(duration) : "0:00"}
            </span>
          </div>
          <div className="audio-player-controls">
          <FontAwesomeIcon icon={faBackward} onClick={handlePreviousSong} />
          <FontAwesomeIcon
            icon={!currentSong ||isUserPaused ? faPlay : faPause}
            onClick={handlePlayPauseClick} // Use the new handler for play/pause
          />
          <FontAwesomeIcon icon={faForward} onClick={handleNextSong} />
        </div>
        <audio
          ref={audioRef}
          controls={false}
          preload="none"
          onLoadedMetadata={() => setDuration(audioRef.current.duration)}
          onContextMenu={(e) => e.preventDefault()}
          style={{ display: 'none' }}
        />
        </div>
      </div>
      <Footer />
    </>
  )
};
export default Music;