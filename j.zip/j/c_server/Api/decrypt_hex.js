import { promises as fs } from 'fs'

async function removeHeaderFooter(inputFile, outputFile) {
  try {
    const stats = await fs.stat(inputFile)
    if (stats.size <= 256) {
      console.log('⚠️ File too small to contain header/footer')
      return
    }

    // Read whole file
    const fileBuffer = await fs.readFile(inputFile)

    // Extract header and footer
    const headerBuf = fileBuffer.slice(0, 128)
    const footerBuf = fileBuffer.slice(stats.size - 128)

    const header = headerBuf.slice(0, 35).toString('utf8').replace(/\0/g, '')
    const footer = footerBuf.slice(0, 35).toString('utf8').replace(/\0/g, '')

    if (header === 'PPS INTERNATIONAL' && footer === 'PPS INTERNATIONAL') {
      // Slice out the middle part (remove 128 bytes from start and end)
      const middle = fileBuffer.slice(128, stats.size - 128)

      // If input and output are the same, overwrite directly
      await fs.writeFile(outputFile, middle)

      if (inputFile === outputFile) {
        console.log(`✅ Header/Footer removed & overwritten: ${outputFile}`)
      } else {
        console.log(
          `✅ Header/Footer removed. Restored file saved as ${outputFile}`
        )
      }
    } else {
      console.log('\n❌ No valid header/footer found. File not modified.')
    }
  } catch (err) {
    console.error('❌ Error:', err.message)
  }
}

// === Example usage ===
const inputFile = './Annapoorani_encrypt.mp4'
const outputFile = './Annapoorani_encrypt.mp4' // same name works now

removeHeaderFooter(inputFile, outputFile)
