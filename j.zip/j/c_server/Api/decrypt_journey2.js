// Convert hex string to ASCII
function hexToAscii(hex) {
  let str = "";
  for (let i = 0; i < hex.length; i += 2) {
    str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
  }
  return str;
}

// Read length-prefixed string
function readString(hexArray, index) {
  const length = hexArray[index];
  index += 1;

  const hex = hexArray
    .slice(index, index + length)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  return {
    value: hexToAscii(hex),
    newIndex: index + length,
  };
}
export function decodeHexData(hexData) {
  const hexArray = hexData.split(" ").map((b) => parseInt(b, 16));
  let i = 0;

  /* 0️⃣ Backend Message Number */
  const messageNumber = hexArray[i++];
  if (messageNumber !== 1) {
    throw new Error("Invalid Backend Message Number");
  }

  /* 1️⃣ Media Mute / Unmute */
  const media = hexArray[i++];
  const muteStatus = media === 1 ? "Mute" : "Unmute";

  /* 2️⃣ Train Speed (2 bytes) */
  const trainSpeed = parseInt(
    hexArray
      .slice(i, i + 2)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join(""),
    16
  );
  i += 2;

  /* 3️⃣ Date (3 bytes) */
  const date = parseInt(
    hexArray
      .slice(i, i + 3)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join(""),
    16
  );
  i += 3;

  /* 4️⃣ Time (3 bytes) */
  const time = parseInt(
    hexArray
      .slice(i, i + 3)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join(""),
    16
  );
  i += 3;

  // /* 5️⃣ Distance To Next Station (4 bytes) */
  // const distanceToNextStation = parseInt(
  //   hexArray
  //     .slice(i, i + 4)
  //     .map((b) => b.toString(16).padStart(2, "0"))
  //     .join(""),
  //   16
  // );
  // i += 4;
  /* 5️⃣ Distance To Next Station (4 bytes – ROTATE RIGHT 2 BITS PER BYTE) */
  const d0 = rotateRight2(hexArray[i]);
  const d1 = rotateRight2(hexArray[i + 1]);
  const d2 = rotateRight2(hexArray[i + 2]);
  const d3 = rotateRight2(hexArray[i + 3]);

  // keep HEX integrity first
  const distanceHex =
    d0.toString(16).padStart(2, "0") +
    d1.toString(16).padStart(2, "0") +
    d2.toString(16).padStart(2, "0") +
    d3.toString(16).padStart(2, "0");

  // OPTIONAL: only if you finally need decimal
  const distanceToNextStation = parseInt(distanceHex, 16);

  i += 4;

  /* 6️⃣ Route Number */
  let res = readString(hexArray, i);
  const routeNumber = res.value;
  i = res.newIndex;

  /* 8️⃣ Train Name */
  res = readString(hexArray, i);
  const trainName = res.value;
  i = res.newIndex;

  /* 🔟 Source Station */
  res = readString(hexArray, i);
  const sourceStationName = res.value;
  i = res.newIndex;

  /* 1️⃣2️⃣ Destination Station */
  res = readString(hexArray, i);
  const destinationStationName = res.value;
  i = res.newIndex;

  /* 1️⃣4️⃣ Next Station */
  res = readString(hexArray, i);
  const nextStationName = res.value;
  i = res.newIndex;

  /* 1️⃣6️⃣ Present Station */
  res = readString(hexArray, i);
  const presentStationName = res.value;
  i = res.newIndex;

  return {
    messageNumber,
    muteStatus,
    trainSpeed,
    date,
    time,
    distanceToNextStation,
    routeNumber,
    trainName,
    sourceStationName,
    destinationStationName,
    nextStationName,
    presentStationName,
  };
}
