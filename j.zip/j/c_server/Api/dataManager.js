import  DetectContentPath  from './DetectContentPath.js'

import fs from 'fs'
import path from 'path'
import { authenticateJWT} from './Authentication.js'
import { encryptData } from './cryptoUtils.js';
export const dataManager = (app) => {

    const { activePath} = DetectContentPath(app)
    const jsonFilePath = path.join(activePath,'database/registersr.json')
    let count = 0
    
    // Check and create the CSV file if it doesn't exist
    const checkAndCreateFile = async (filePath) => {
        try {
            await fs.promises.access(filePath)
            // console.log('File already exists:');
        } catch (err) {
            await fs.promises.writeFile(filePath, JSON.stringify([]))
            console.log('File created successfully:')
        }
    }
    
    // Call the function to ensure the file exists
    
    checkAndCreateFile(jsonFilePath)
    .then(() => {
        // console.log('Check and create file operation completed.');
    })
    .catch((error) => {
        console.error('Error:', error)
    })
    
    // Function to read data from the CSV file
    const readJsonFile = async (filePath) => {
        try {
            const data = await fs.promises.readFile(filePath, 'utf8')
            return JSON.parse(data)
        } catch (error) {
            throw new Error('File is busy or cannot be opened: ' + error.message)
        }
    }
    
    // Function to write data to the JSON file
    const writeJsonFile = async (filePath, data) => {
        try {
            await fs.promises.writeFile(filePath, JSON.stringify(data, null, 2))
        } catch (err) {
            throw new Error('Error writing data: ' + err.message)
        }
    }
    
    // Function to initialize the ID counter
    const initializeIdCounter = async () => {
        try {
            const data = await readJsonFile(jsonFilePath)
            // count = data.length > 0 ? parseInt(data[data.length - 1].id, 10) : 0
            count = data.length > 0 ? parseInt(data[0].id, 10) : 0
            // console.log(`ID counter initialized to ${count}`);
        } catch (error) {
            console.error('Error initializing ID counter:', error)
        }
    }
    // Call the function to initialize the ID counter
    initializeIdCounter()
    
    // Function to get the next unique ID based on existing data
    const getNextId = async (data) => {
      // If count exceeds 10, reset to 1
        if (count >= 1000) {
            // Remove all entries with ID 1
            data = data.filter((entry) => parseInt(entry.id, 10) !== 1)
            await writeJsonFile(jsonFilePath, data) // Update the file after removing
            count = 1 // Reset count to 1
        } else {
            count += 1 // Increment the count for each new entry
        }
        // Write back the updated data to the file
        await writeJsonFile(jsonFilePath, data) // Update the file after removing duplicates
        
        // console.log(`Current ID: ${count}`);
        return count // Return the new unique ID
    }
    
    // Endpoint to get data
    app.get('/data',authenticateJWT, async (req, res) => {
        try {
            const data = await readJsonFile(jsonFilePath)
            // Sort the data in descending order based on the id
            // Reverse the data array
            // const reversedData = data.reverse()
            // res.json(reversedData)
        // console.log(data)
        // Encrypt the relevant fields in the data
        const encryptedData = data.map(item => ({
            ...item,
            pnr: encryptData(item.pnr),
            passengerName: encryptData(item.passengerName),
            contactNumber: encryptData(item.contactNumber),
            seatNumber: encryptData(item.seatNumber),
        }));
        // console.log(encryptedData)

            res.json(encryptedData)
        } catch (error) {
            console.error(error)
            res
            .status(500)
            .json({ message: 'Error reading the JSON file: ' + error.message })
        }
    })
    
    // Endpoint to save new data
    app.post('/data', async (req, res) => {
        const {
            pnr,
            passengerName,
            contactNumber,
            seatNumber,
            serviceType,
            complaint,
            date,
            time,
            status,
            actionTaken,
        } = req.body
    
        if (
            !pnr ||
            !passengerName ||
            !contactNumber ||
            !seatNumber ||
            !serviceType ||
            !complaint ||
            !date ||
            !date ||
            !status ||
            !actionTaken
        ) {
            return res.status(400).json({ error: 'All fields are required.' })
        }
    
        try {
            let data = await readJsonFile(jsonFilePath)
            const newEntryId = await getNextId(data) // Get the next unique ID
            // Remove existing entries with the same ID before adding the new one
            data = data.filter((entry) => parseInt(entry.id, 10) !== newEntryId)
        
            const newEntry = {
            id: newEntryId,
            pnr,
            passengerName,
            contactNumber,
            seatNumber,
            serviceType,
            complaint,
            date,
            time,
            status,
            actionTaken,
            }
        
            // data.push(newEntry)
            data.unshift(newEntry);
            await writeJsonFile(jsonFilePath, data)
            res
            .status(201)
            .json({ message: 'Data saved successfully!', entry: newEntry })
        } catch (error) {
            console.error(error)
            res
            .status(500)
            .json({ error: 'Error saving data to the JSON file: ' + error.message })
        }
    })
    
    // Endpoint to update existing data
    app.put('/data/:pnr/:index', async (req, res) => {
        const { pnr, index } = req.params
        const {
            passengerName,
            contactNumber,
            seatNumber,
            serviceType,
            complaint,
            date,
            time,
            status,
            actionTaken,
        } = req.body
    
        if (
            !passengerName ||
            !contactNumber ||
            !seatNumber ||
            !serviceType ||
            !complaint ||
            !date ||
            !time ||
            !status ||
            !actionTaken
        ) {
            return res.status(400).json({ error: 'All fields are required.' })
        }
    
        try {
            const data = await readJsonFile(jsonFilePath)
            if (index < 0 || index >= data.length) {
            return res.status(400).json({ error: 'Invalid index.' })
            }
        
            data[index] = {
            ...data[index],
            pnr,
            passengerName,
            contactNumber,
            seatNumber,
            serviceType,
            complaint,
            date,
            time,
            status,
            actionTaken,
            }
        
            await writeJsonFile(jsonFilePath, data)
            res.json({ message: 'Data updated successfully!' })
        } catch (error) {
            console.error(error)
            res
            .status(500)
            .json({ error: 'Error updating data in the JSON file: ' + error.message })
        }
    })
}