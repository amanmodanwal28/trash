import fs from 'fs'
import path from 'path'
import dotenv from 'dotenv'
import { fileURLToPath } from 'url'

// Get the directory name from the module's URL
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)


const loadEnv = (envPaths = ['./.env', '../.env']) => {
  // Iterate through the paths and find the first one that exists
  const envPath = envPaths
    .map((p) => path.resolve(__dirname, p)) // Resolve relative paths to absolute paths
    .find((p) => fs.existsSync(p)); // Check if the path exists

  if (envPath) {
    const result = dotenv.config({ path: envPath }); // Load .env file
    // console.log(`Loaded .env from: ${envPath}`);
    return result; // Return the result of dotenv.config()
  } else {
    console.warn('No .env file found in the specified paths.');
    return null; // If no .env file is found, return null
  }
};


 // Function to check if a file exists and create it with default content if not
const createEnvFileIfNotExist = (envPath) => {
    // Define the default content for the .env file
    const defaultEnvContent = `
  # Default .env file
  # Add your environment variables here
  
  SECRET_KEY=YoursTr0ngSecreT!Key12345
  VITE_PORT=80
  VITE_SERVER_PORT=5000
  VITE_SERVER_HOST=192.168.0.243
  `;
  
    // Check if the file exists
    if (!fs.existsSync(envPath)) {
      // If the .env file doesn't exist, create it with default content
      fs.writeFileSync(envPath, defaultEnvContent, 'utf8');
    //   console.log(`.env file not found, created new .env at: ${envPath}`);
    } else {
    //   console.log(`Found .env at: ${envPath}`);
    //   console.log(`Found .env at:`);
    }
  };
let envfile = path.join(__dirname,'./.env')
  createEnvFileIfNotExist(envfile)

export default loadEnv;
