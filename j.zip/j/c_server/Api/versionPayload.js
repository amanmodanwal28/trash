// versionPayload.js
import fs from 'fs'
import path from 'path'

// Read package.json once
const packageJsonPath = path.join(process.cwd(), 'package.json')
const packageData = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'))
const version = packageData.version || '1.0'
const [majorStr, minorStr] = version.split('.')
const major = parseInt(majorStr) & 0xff
const minor = parseInt(minorStr) & 0xff

// Static payload info
const FRONTEND_MSG = 2
const HDD_STATE = 1

// Function to get UDP payload buffer
export function getVersionBuffer() {
  return Buffer.from([FRONTEND_MSG, HDD_STATE, major, minor])
}
