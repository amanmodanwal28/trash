// Hex → ASCII
function hexToAscii(hex) {
  let str = ''
  for (let i = 0; i < hex.length; i += 2) {
    str += String.fromCharCode(parseInt(hex.substr(i, 2), 16))
  }
  return str.trim()
}


let hexData =
  '01 01 55 00 03 01 26 2E 22 19 60 09 00 00 05 31 32 35 36 30 12 41 68 6D 65 64 61 62 61 64 20 4A 75 6E 63 74 69 6F 6E 12 41 68 6D 65 64 61 62 61 64 20 4A 75 6E 63 74 69 6F 6E 0E 4D 75 6D 62 61 69 20 43 65 6E 74 72 61 6C 05 53 75 72 61 74 04 61 6D 61 6E'

export function decodeHexData(hexData) {
  // console.log('================ RAW HEX DATA ================')
  // console.log(hexData)

  // const hexArray = hexData.split(' ').map((b) => parseInt(b, 16))
  // Remove any non-hex characters (spaces, newlines, etc.)
  const cleanedHex = hexData.replace(/[^a-fA-F0-9]/g, '')

  // Convert every 2 hex chars to a byte
  const hexArray = []
  for (let i = 0; i < cleanedHex.length; i += 2) {
    hexArray.push(parseInt(cleanedHex.substr(i, 2), 16))
  }
  let dataIndex = 0

  // console.log('\n============= PROTOCOL DECODE START =============')

  // [0] Backend msg number (skip)
  const backendMsg = hexArray[dataIndex]
  dataIndex += 1
  // console.log('[0] Backend Msg Number (Skipped):', backendMsg)

  // [1] Media flag
  const mediaFlag = hexArray[dataIndex]
  dataIndex += 1
  const mediaStatus = mediaFlag === 1 ? 'Unmute' : 'Mute'
  // console.log('[1] Media Flag:', mediaFlag, mediaStatus)

  // [2] Train speed (2 bytes – HEX based)
  const speedHex = hexArray
    .slice(dataIndex, dataIndex + 2)
    .reverse()
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')

  // const trainSpeed = parseInt(speedHex, 16)

  // // [2] Train speed (2 bytes – Little Endian)
  const trainSpeed = (hexArray[dataIndex + 1] << 8) | hexArray[dataIndex]
  // const trainSpeed = (hexArray[dataIndex] << 8) | hexArray[dataIndex + 1]

  dataIndex += 2

  // console.log('Train Speed:', trainSpeed)

  // console.log('[2] Train Speed:', trainSpeed, 'km/h')

  // [3] Date (3 bytes)
  const dateBytes = hexArray.slice(dataIndex, dataIndex + 3)
  dataIndex += 3
  // console.log('[3] Date RAW:', dateBytes)

  // [4] Time (3 bytes)
  const timeBytes = hexArray.slice(dataIndex, dataIndex + 3)
  dataIndex += 3
  // console.log('[4] Time RAW:', timeBytes)

  // //[5] Distance to next station (4 bytes – HEX based)
  const distanceHex = hexArray
    .slice(dataIndex, dataIndex + 4)
    .reverse() // 👈 KEY FIX (right-shift / endian swap)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')

  // // console.log(distanceHex, distanceHex)
  // const distanceTonextStationName = parseInt(distanceHex, 16)
  const distanceTonextStationName =
    (hexArray[dataIndex + 3] << 24) |
    (hexArray[dataIndex + 2] << 16) |
    (hexArray[dataIndex + 1] << 8) |
    hexArray[dataIndex]

  dataIndex += 4

  // // console.log('Distance (m):', distanceTonextStationName)

  // console.log('[5] Distance to Next Station (m):', distanceTonextStationName)

  // Helper for variable-length ASCII strings
  function readString(label) {
    const len = hexArray[dataIndex]
    dataIndex += 1

    const hexStr = hexArray
      .slice(dataIndex, dataIndex + len)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('')
    dataIndex += len

    const value = hexToAscii(hexStr)
    // console.log(`${label} Length:`, len)
    // console.log(`${label} Value:`, value)
    return value
  }

  // [6–7] Route number
  const routeNumber = readString('[6–7] Route Number')

  // [8–9] Train name
  const trainName = readString('[8–9] Train Name')

  // [10–11] Source station
  const sourceStationName = readString('[10–11] Source Station')

  // [12–13] Destination station
  const destinationStationName = readString('[12–13] Destination Station')

  // [14–15] Next station
  const nextStationName = readString('[14–15] Next Station')

  // [16–17] Present station
  const presentStationName = readString('[16–17] Present Station')

  // console.log('============= PROTOCOL DECODE END =============\n')

  return {
    backendMsg,
    mediaFlag,
    mediaStatus,
    trainSpeed,
    dateBytes,
    timeBytes,
    distanceTonextStationName,
    routeNumber,
    trainName,
    sourceStationName,
    destinationStationName,
    nextStationName,
    presentStationName,
  }
}


decodeHexData(hexData)