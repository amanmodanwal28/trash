/* eslint-disable no-undef */
/* eslint-disable no-constant-binary-expression */
/* eslint-disable no-unused-vars */
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'
// import loadEnv from './Api/loadEnv'
// import loadEnv from './Api/loadEnv'

// Custom paths to search for .env file
// const envPath = [ './.env','./dist/Api/.env'] // Define your custom search paths

// Call the loadEnv function with custom paths
// const result = loadEnv(envPath);

// Ensure proper port setting and environment usage
const isProduction = process.env.NODE_ENV === 'production'
let loadEnvPath

// Custom paths to search for .env file
const envPath = ['./.env', './dist/Api/.env'] // Define your custom search paths

// Dynamically import the correct loadEnv based on NODE_ENV
if (isProduction) {
  console.log('Running in production mode')
  loadEnvPath = await import('./dist/Api/loadEnv')
} else {
  console.log('Running in development mode')
  loadEnvPath = await import('./Api/loadEnv')
}

// console.log(loadEnvPath.default)
loadEnvPath.default(envPath)

// console.log(process.env.VITE_SERVER_PORT)
// https://vitejs.dev/config/
export default defineConfig({
  server: {
    host: true,
    open: true,
    port: process.env.VITE_PORT || 80 || 5179 || 5174, // Fallback to 3000 if not defined
    proxy: {
      '/api': {
        target: `http://localhost:${process.env.VITE_SERVER_PORT}`,
        changeOrigin: true,
        secure: false,
        credentials: true,
        rewrite: (path) => path.replace(/^\/api/, ''), // Remove `/api` prefix
      },
    },
  },
  plugins: [react()],
  resolve: {
    alias: {
      '@api': path.resolve(__dirname, isProduction ? './dist/Api/' : './Api'), // Alias to the Api folder
    },
  },

  preview: {
    host: true,
    port: process.env.PORT || 4173, // Port for preview server
    allowedHosts: ['vb-wifi.in', 'ptwifibox.in'],
  },
})
