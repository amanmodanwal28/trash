#!/bin/bash
# =========================================
# Bridge auto-enable/disable based on UDP broadcast
# =========================================

BRIDGE_SCRIPT="/path/to/bridgeControl.sh"   # <-- update path to your bridgeControl.sh
UDP_PORT=8002
TIMEOUT=60      # 60 seconds timeout
LAST_TIME=$(date +%s)

log() {
  echo "[bridgeMonitor] $1"
}

require_root() {
  [[ $EUID -eq 0 ]] || { echo "[bridgeMonitor] Run as root (sudo)"; exit 1; }
}

require_root

log "Starting UDP monitor on port $UDP_PORT..."

while true; do
  # Listen for UDP messages with a 1-second timeout
  MESSAGE=$(timeout 1 nc -u -l -p $UDP_PORT 2>/dev/null || true)

  CURRENT_TIME=$(date +%s)

  if [[ "$MESSAGE" == "MESSAGE_FROM_SPUT_TOOL" ]]; then
    log "Received trigger message. Enabling bridge..."
    sudo "$BRIDGE_SCRIPT" enable
    LAST_TIME=$CURRENT_TIME
  fi

  # Check if timeout exceeded
  ELAPSED=$(( CURRENT_TIME - LAST_TIME ))
  if (( ELAPSED >= TIMEOUT )); then
    log "No message received in last $TIMEOUT seconds. Disabling bridge..."
    sudo "$BRIDGE_SCRIPT" disable
    # Reset last time so it won't repeatedly disable
    LAST_TIME=$CURRENT_TIME
  fi

  sleep 1
done
