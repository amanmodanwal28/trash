#!/bin/bash
# =========================================
# Netplan Bridge Enable / Disable (INLINE)
# =========================================

set -e

ACTIVE_FILE="/etc/netplan/01-network-manager-all.yaml"
LOCKFILE="/tmp/bridgeControl.lock"

log() {
  echo "[bridgeControl] $1"
}

require_root() {
  [[ $EUID -eq 0 ]] || { echo "[bridgeControl] Run as root (sudo)"; exit 1; }
}

lock() {
  exec 9>"$LOCKFILE"
  flock -n 9 || { echo "[bridgeControl] Another operation running"; exit 1; }
}

apply_netplan() {
  log "Generating netplan config"
  #netplan generate

  log "Applying netplan"
  netplan apply
  
   # log "Applying netplan"
  netplan apply

  log "Restarting NetworkManager"
  systemctl restart NetworkManager
}

# ---------- BRIDGE ENABLE ----------
enable_bridge() {
  lock
  log "Enabling bridge using netplan"

  cat > "$ACTIVE_FILE" <<'EOF'
network:
  version: 2
  renderer: networkd
  ethernets:
    enp2s0: {}
    enp3s0: {}
  bridges:
    br0:
      interfaces: [enp2s0, enp3s0]
      addresses: [192.168.0.243/16]
      parameters:
        stp: true
        forward-delay: 4
EOF

  chmod 600 "$ACTIVE_FILE"
  apply_netplan

  log "✅ Bridge ENABLED successfully"
}

# ---------- BRIDGE DISABLE ----------
disable_bridge() {
  lock
  log "Disabling bridge (normal network)"

  cat > "$ACTIVE_FILE" <<'EOF'
network:
  version: 2
  renderer: NetworkManager
EOF

  chmod 600 "$ACTIVE_FILE"
  apply_netplan
  sudo ip link set br0 down
  sudo ip link set enp2s0 up
  sudo ip link set enp3s0 up
  sudo ip link delete br0 type bridge
  

  log "✅ Bridge DISABLED successfully"
}

# ---------- STATUS ----------
status_bridge() {
  if ip link show br0 &>/dev/null; then
    echo "Bridge: ENABLED"
    ip a show br0
    bridge link
  else
    echo "Bridge: DISABLED"
    ip a
  fi
}

require_root

case "${1:-}" in
  enable)
    enable_bridge
    ;;
  disable)
    disable_bridge
    ;;
  status)
    status_bridge
    ;;
  *)
    echo "Usage: sudo ./bridgeControl.sh enable|disable|status"
    exit 1
    ;;
esac

