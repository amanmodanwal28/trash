import dgram from 'dgram'

// UDP server to listen on port 8000
const UDP_PORT = 8000
const HOST = '0.0.0.0' // listen on all interfaces

const udpServer = dgram.createSocket('udp4')

udpServer.on('listening', () => {
  const address = udpServer.address()
  console.log(`UDP server listening on ${address.address}:${address.port}`)
})

udpServer.on('message', (msg, rinfo) => {
  console.log(`Received message from ${rinfo.address}:${rinfo.port}`)
  console.log(`Data (hex): ${msg.toString('hex')}`)
  console.log(`Data (bytes): [${msg.join(', ')}]`)
})

udpServer.bind(UDP_PORT, HOST)

// Graceful shutdown
process.on('SIGINT', () => {
  udpServer.close(() => {
    console.log('UDP server on 8000 closed')
    process.exit()
  })
})
