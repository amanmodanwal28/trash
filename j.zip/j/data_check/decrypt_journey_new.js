// Hex → ASCII
function hexToAscii(hex) {
  let str = ''
  for (let i = 0; i < hex.length; i += 2) {
    str += String.fromCharCode(parseInt(hex.substr(i, 2), 16))
  }
  return str.trim()
}

// Decode function

let hexData =
  '01 01 00 00 03 01 1A 11 2E 22 19 2F 00 00 09 31 39 30 31 30 20 20 20 7F 12 41 68 6D 65 64 61 62 61 64 20 4A 75 6E 63 74 69 6F 6E 12 41 68 6D 65 64 61 62 61 64 20 4A 75 6E 63 74 69 6F 6E 0E 4D 75 6D 62 61 69 20 43 65 6E 74 72 61 6C 06 53 75 72 61 74 20 00 00'
export function decodeHexData(hexData) {
  console.log('================ RAW HEX DATA ================')
  console.log(hexData)

  const hexArray = hexData.split(' ').map((byte) => parseInt(byte, 16))

  let i = 0
console.log(hexArray)
  console.log('\n============= PROTOCOL DECODE START =============')

  // [0] Backend msg number (fixed = 1)
  const backendMsg = hexArray[i]
  i++
  console.log('[0] Backend Msg Number:', backendMsg, '(Skipped)')

  // [1] Media flag
  const mediaFlag = hexArray[i]
  i++
  console.log('[1] Media Flag:', mediaFlag)

  // [2] Train speed (2 bytes)
  const trainSpeed = (hexArray[i]) | hexArray[i + 1]
  i += 2
  console.log('[2] Train Speed:', trainSpeed, (hexArray[i]), hexArray[i + 1])

  // [3] Date (3 bytes)
  const dateBytes = hexArray.slice(i, i + 3)
  i += 3
  console.log('[3] Date (RAW):', dateBytes)

  // [4] Time (3 bytes)
  const timeBytes = hexArray.slice(i, i + 3)
  i += 3
  console.log('[4] Time (RAW):', timeBytes)

  // [5] Distance (4 bytes)
  const distance =
    (hexArray[i] << 24) |
    (hexArray[i + 1] << 16) |
    (hexArray[i + 2] << 8) |
    hexArray[i + 3]
  i += 4
  console.log('[5] Distance to Next Station (meters):', distance)

  // Helper for variable strings
  function readString(label) {
    const len = hexArray[i++]
    const hex = hexArray
      .slice(i, i + len)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('')
    i += len
    const value = hexToAscii(hex)
    console.log(`${label} Length:`, len)
    console.log(`${label} Value:`, value)
    return value
  }

  // [6–7] Route number
  const routeNumber = readString('[6–7] Route Number')

  // [8–9] Train name
  const trainName = readString('[8–9] Train Name')

  // [10–11] Source station
  const sourceStation = readString('[10–11] Source Station')

  // [12–13] Destination station
  const destinationStation = readString('[12–13] Destination Station')

  // [14–15] Next station
  const nextStation = readString('[14–15] Next Station')

  // [16–17] Present station
  const presentStation = readString('[16–17] Present Station')

  console.log('============= PROTOCOL DECODE END =============\n')

  return {
    backendMsg,
    mediaFlag,
    trainSpeed,
    dateBytes,
    timeBytes,
    distance,
    routeNumber,
    trainName,
    sourceStation,
    destinationStation,
    nextStation,
    presentStation,
  }
}

decodeHexData(hexData)
