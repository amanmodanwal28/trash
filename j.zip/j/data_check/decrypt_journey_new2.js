// Hex → ASCII
function hexToAscii(hex) {
  let str = ''
  for (let i = 0; i < hex.length; i += 2) {
    str += String.fromCharCode(parseInt(hex.substr(i, 2), 16))
  }
  return str.trim()
}


let hexData =
  '01 01 00 00 03 01 1A 11 2E 22 19 2F 00 00 09 31 39 30 31 30 20 20 20 7F 12 41 68 6D 65 64 61 62 61 64 20 4A 75 6E 63 74 69 6F 6E 12 41 68 6D 65 64 61 62 61 64 20 4A 75 6E 63 74 69 6F 6E 0E 4D 75 6D 62 61 69 20 43 65 6E 74 72 61 6C 06 53 75 72 61 74 20 00 00'



export function decodeHexData(hexData) {
  console.log('================ RAW HEX DATA ================')
  console.log(hexData)

  const hexArray = hexData.split(' ').map((b) => parseInt(b, 16))
  let dataIndex = 0

  console.log('\n============= PROTOCOL DECODE START =============')

  // [0] Backend msg number (skip)
  const backendMsg = hexArray[dataIndex]
  dataIndex += 1
  console.log('[0] Backend Msg Number (Skipped):', backendMsg)

  // [1] Media flag
  const mediaFlag = hexArray[dataIndex]
  dataIndex += 1
  const mediaStatus = mediaFlag === 1 ? 'ON' : 'OFF'
  console.log('[1] Media Flag:', mediaFlag, mediaStatus)

  // [2] Train speed (2 bytes – HEX based)
  const speedHex = hexArray
    .slice(dataIndex, dataIndex + 2)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')


  // const trainSpeed = parseInt(speedHex, 16)

  // // [2] Train speed (2 bytes – Little Endian)
  const trainSpeed = (hexArray[dataIndex ] << 8) | hexArray[dataIndex+1]
console.log(trainSpeed)
  dataIndex += 2

  console.log('Train Speed:', trainSpeed)

  console.log('[2] Train Speed:', trainSpeed, 'km/h')

  // [3] Date (3 bytes)
  const dateBytes = hexArray.slice(dataIndex, dataIndex + 3)
  dataIndex += 3
  console.log('[3] Date RAW:', dateBytes)

  // [4] Time (3 bytes)
  const timeBytes = hexArray.slice(dataIndex, dataIndex + 3)
  dataIndex += 3
  console.log('[4] Time RAW:', timeBytes)

  // //[5] Distance to next station (4 bytes – HEX based)
  const distanceHex = hexArray
    .slice(dataIndex, dataIndex + 4)
    .reverse() // 👈 KEY FIX (right-shift / endian swap)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')

  // console.log(distanceHex, distanceHex)
  // const distanceToNext = parseInt(distanceHex, 16)
  const distanceToNext =
    (hexArray[dataIndex + 3] << 24) |
    (hexArray[dataIndex + 2] << 16) |
    (hexArray[dataIndex + 1] << 8) |
    hexArray[dataIndex]

  dataIndex += 4

  // console.log('Distance (m):', distanceToNext)

  console.log('[5] Distance to Next Station (m):', distanceToNext)

  // Helper for variable-length ASCII strings
  function readString(label) {
    const len = hexArray[dataIndex]
    dataIndex += 1

    const hexStr = hexArray
      .slice(dataIndex, dataIndex + len)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('')
    dataIndex += len

    const value = hexToAscii(hexStr)
    console.log(`${label} Length:`, len)
    console.log(`${label} Value:`, value)
    return value
  }

  // [6–7] Route number
  const routeNumber = readString('[6–7] Route Number')

  // [8–9] Train name
  const trainName = readString('[8–9] Train Name')

  // [10–11] Source station
  const sourceStation = readString('[10–11] Source Station')

  // [12–13] Destination station
  const destinationStation = readString('[12–13] Destination Station')

  // [14–15] Next station
  const nextStation = readString('[14–15] Next Station')

  // [16–17] Present station
  const presentStation = readString('[16–17] Present Station')

  console.log('============= PROTOCOL DECODE END =============\n')

  return {
    backendMsg,
    mediaFlag,
    mediaStatus,
    trainSpeed,
    dateBytes,
    timeBytes,
    distanceToNext,
    routeNumber,
    trainName,
    sourceStation,
    destinationStation,
    nextStation,
    presentStation,
  }
}


decodeHexData(hexData)