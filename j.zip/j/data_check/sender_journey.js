import dgram from 'dgram'

const socket = dgram.createSocket('udp4')



function getCurrentTimeBytes() {
  const now = new Date()

  const hours = now.getHours() // 0–23
  const minutes = now.getMinutes() // 0–59
  const seconds = now.getSeconds() // 0–59

  return [hours, minutes, seconds]
}

function getCurrentDateBytes() {
  const now = new Date()

  const day = now.getDate() // 1–31
  const month = now.getMonth() + 1 // 1–12
  const year = now.getFullYear() % 100 // last 2 digits

  return [day, month, year]
}


// ===== CONFIG =====
const TARGET_IP = '127.0.0.1'
const TARGET_PORT = 8001
const SEND_INTERVAL_MS = 3000

// ===== STRING → HEX BUFFER =====
function stringToBytes(str) {
  return Buffer.from(str, 'ascii')
}

// ===== ENCODER =====
function encodeJourneyPacket(data) {
  const bufferArray = []

  console.log('\n=========== ENCODING PACKET ===========')

  // [0] Backend msg number (FIXED = 1)
  bufferArray.push(Buffer.from([0x01]))
  console.log('[0] Backend Msg: 1')

  // [1] Media flag
  bufferArray.push(Buffer.from([data.mediaFlag]))
  console.log('[1] Media Flag:', data.mediaFlag)

  //// [2] Train speed (2 bytes)
  // const speedBuf = Buffer.alloc(2)
  // speedBuf.writeUInt16LE(data.trainSpeed)
  // bufferArray.push(speedBuf)
  // console.log('[2] Train Speed:', data.trainSpeed)

  // [2] Train speed (2 bytes – MANUAL LITTLE ENDIAN)
  const speedBuf = Buffer.alloc(2)
  speedBuf[0] = data.trainSpeed & 0xff // LSB
  speedBuf[1] = (data.trainSpeed >> 8) & 0xff // MSB
  bufferArray.push(speedBuf)
  console.log('[2] Train Speed (LE):', speedBuf)

  // // [3] Date (3 bytes)
  // bufferArray.push(Buffer.from(data.date))
  // console.log('[3] Date Bytes:', data.date)

  // [3] Date (3 bytes – CURRENT DATE)
  const dateBytes = getCurrentDateBytes()
  bufferArray.push(Buffer.from(dateBytes))
  console.log('[3] Date Bytes (DD MM YY):', dateBytes)

  // // [4] Time (3 bytes)
  // bufferArray.push(Buffer.from(data.time))
  // console.log('[4] Time Bytes:', data.time)
  // [4] Time (3 bytes – CURRENT TIME)

  const timeBytes = getCurrentTimeBytes()
  bufferArray.push(Buffer.from(timeBytes))
  console.log('[4] Time Bytes (HH MM SS):', timeBytes)

  // [5] Distance (4 bytes – MANUAL LITTLE ENDIAN)
  const dist = data.distance

  const distBuf = Buffer.from([
    dist & 0xff, // LSB
    (dist >> 8) & 0xff,
    (dist >> 16) & 0xff,
    (dist >> 24) & 0xff, // MSB
  ])

  bufferArray.push(distBuf)
  console.log('[5] Distance (LE):', distBuf)

  // Helper for variable strings
  function pushString(label, value) {
    const strBuf = stringToBytes(value)
    bufferArray.push(Buffer.from([strBuf.length]))
    bufferArray.push(strBuf)
    console.log(`${label} Length:`, strBuf.length)
    console.log(`${label} Value:`, value)
  }

  // [6–7] Route number
  pushString('[6–7] Route Number', data.routeNumber)

  // [8–9] Train name
  pushString('[8–9] Train Name', data.trainName)

  // [10–11] Source station
  pushString('[10–11] Source Station', data.sourceStation)

  // [12–13] Destination station
  pushString('[12–13] Destination Station', data.destinationStation)

  // [14–15] Next station
  pushString('[14–15] Next Station', data.nextStation)

  // [16–17] Present station
  pushString('[16–17] Present Station', data.presentStation)

  const finalBuffer = Buffer.concat(bufferArray)

  console.log('=========== PACKET HEX ===========')
  // console.log(finalBuffer.toString('hex').toUpperCase())
  const hexWithSpaces = finalBuffer
    .toString('hex')
    .toUpperCase()
    .match(/.{1,2}/g)
    .join(' ')

  console.log(hexWithSpaces)

  console.log('=================================\n')

  return finalBuffer
}

// ===== SAMPLE DATA =====
const journeyData = {
  mediaFlag: 1,
  trainSpeed: 85,
  date: [0x03,0x01,0x26], // example
  time: [0x2e, 0x22, 0x19], // example
  distance: 2400,
  routeNumber: '12560',
  trainName: 'Ahmedabad Junction',
  sourceStation: 'Ahmedabad Junction',
  destinationStation: 'Mumbai Central',
  nextStation: 'Sura',
  presentStation: 'aman',
}

// ===== SEND EVERY 3 SECONDS =====
setInterval(() => {
  const packet = encodeJourneyPacket(journeyData)

  socket.send(packet, TARGET_PORT, TARGET_IP, (err) => {
    if (err) {
      console.error('UDP Send Error:', err)
    } else {
      console.log('✅ Packet sent successfully')
    }
  })
}, SEND_INTERVAL_MS)
