from django.urls import path
from .views import index, latest_status, get_detail,login_view,signup_view,get_detail_lcd

urlpatterns = [
    path('home/', index, name='index'),
    path('', login_view, name='login'),
    path('signup/', signup_view, name='signup'),
    path('latest_status/', latest_status, name='latest_status'), ##ajax
    path('detail/', get_detail, name='detail'),
    path('get_detail_lcd/',get_detail_lcd,name='get_detail_lcd'),
]
