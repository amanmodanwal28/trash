from django.contrib import admin

# Register your models here.
from .models import Status,UploadedFile,Signup

admin.site.register(Status)
admin.site.register(UploadedFile)
admin.site.register(Signup)
# admin.site.register(file)
