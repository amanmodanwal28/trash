
from django.shortcuts import render
from django.http import JsonResponse,HttpResponseRedirect
from .models import Status
import os
from django.conf import settings
from .forms import UploadFileForm
import socket
import time
from django.db.models import OuterRef, Subquery
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from datetime import datetime , timedelta
from django.utils.timezone import now , make_aware
from django.views.decorators.csrf import csrf_exempt
from django.core.exceptions import ObjectDoesNotExist
import json

previous_data = None
check_ip_list=None
# Get absolute path to the current file (ui.py)
current_dir = os.path.dirname(os.path.abspath(__file__))

server_storage = os.path.abspath(os.path.join(current_dir, '..','server_storage'))
selected_file_name =os.path.abspath(os.path.join(current_dir, '..', 'server_storage', 'selected_file_name.txt'))

selected_ips = os.path.abspath(os.path.join(current_dir, '..', 'server_storage', 'selected_ips.txt'))


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home/')  # Replace 'home' with your homepage URL name
        else:
            # Return an 'invalid login' error message.
            return render(request, 'login.html', {'error': 'Invalid login credentials'})
    return render(request, 'login.html')

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('home')  # Replace 'home' with your homepage URL name
    else:
        form = UserCreationForm()
    return render(request, 'sign.html', {'form': form})

def redirect_view(request):
    if request.user.is_authenticated:
        return redirect('home/')  # Replace 'home' with your homepage URL name
    else:
        return redirect('signup')


def index(request):
    global check_ip_list, client_socket

    if request.method == 'POST':
        checked_ips = request.POST.get('checked_ips', '')
        checked_ips_list = checked_ips.split(',') if checked_ips else []
        form = UploadFileForm(request.POST, request.FILES)

        print('checked_ips_list',checked_ips_list)
        if not checked_ips_list and not request.FILES.get('file'):
            messages.error(request, 'Please select an IP and upload a file.')
            return redirect('/home')

        elif not checked_ips_list:
            messages.error(request, 'Please select at least one IP.')
            return redirect('/home')

        elif not request.FILES.get('file'):
            messages.error(request, 'Please upload a file.')
            return redirect('/home')


        # Store selected IP
        check_ip_list = checked_ips_list[0]
        print('check_ip_list====', check_ip_list)
        with open(selected_ips, 'wb') as file:
            file.write(check_ip_list.encode())

        if form.is_valid():
            uploaded_file = request.FILES['file']
            file_path = os.path.join(settings.MEDIA_ROOT, 'uploaded_files', uploaded_file.name)
            print('file_path:', file_path)

            # Save selected file name
            with open(selected_file_name, 'wb') as file:
                file.write(uploaded_file.name.encode())

            os.makedirs(os.path.dirname(file_path), exist_ok=True)

            # Save uploaded file to disk
            with open(file_path, 'wb+') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)

            # Send file via TCP socket
            try:
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                # client_socket.connect(('103.76.138.125', 8010))
                client_socket.connect(('127.0.0.1', 8010))
                with open(file_path, 'rb') as file:
                    while True:
                        chunk = file.read(1024)
                        if not chunk:
                            break
                        header = bytes([0])
                        client_socket.sendall(header + chunk)
                client_socket.close()
                print("File sent successfully.")
                messages.success(request, 'File sent successfully.')
            except Exception as e:
                print("Socket error:", str(e))
                messages.error(request, f'Error sending file: {str(e)}')
                messages.error(request, f'Error sending file')

        else:
            messages.error(request, 'Invalid form or file.')

        return redirect(request.path_info)

    return render(request, 'index.html')

def get_detail(request):
    checked_ips = request.POST.get('checked_ips', '')
    checked_ips_list = checked_ips.split(',') if checked_ips else []
    detail = {}

    print(checked_ips)
    if checked_ips_list:
        ip_to_check = checked_ips_list[0]

        # Save selected IP
        with open(selected_ips, 'wb') as file:
            file.write(ip_to_check.encode())

        try:
            # Fetch latest status for this IP
            latest_device = Status.objects.filter(
                ip=ip_to_check,
                status_date__isnull=False
            ).latest('status_date')

            connected_devices = latest_device.connected_devices or ""

            print('connected_devices ================= ', connected_devices)

            # Map of device codes and names
            device_map = {
                '06': 'LED',
                '07': 'LCD',
                '08': 'ETBU',
                '09': 'EBU',
            }

            for code, name in device_map.items():
                detail[name] = 'Healthy' if code in connected_devices else 'Unhealthy'

        except ObjectDoesNotExist:
            messages.error(request, 'No device data found for the selected IP.')
            return redirect('/home')
        print(detail)
        return render(request, 'detail.html', {'detail': detail})
        # return JsonResponse({'detail': detail})
    else:
        messages.warning(request, 'Please select an IP address first.')
        return redirect('/home')


# @csrf_exempt  # Optional if CSRF token is properly handled in frontend
def get_detail_lcd(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            selected_ips = data.get('selected_ips', '')
            print("selected_ips",selected_ips)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)

        if not selected_ips:
            return JsonResponse({'error': 'No IP provided'}, status=400)

        ip_to_check = selected_ips.strip()
        try:
            latest_device = Status.objects.filter(
                ip=ip_to_check,
                status_date__isnull=False
            ).latest('status_date')

            connected_devices = latest_device.connected_devices or ""

            device_map = {
                '06': 'LED',
                '07': 'LCD',
                '08': 'ETBU',
                '09': 'EBU',
            }

            detail = {
                name: 'Healthy' if code in connected_devices else 'Unhealthy'
                for code, name in device_map.items()
            }

            print("LCD detail ",detail)
            return JsonResponse({'ip': ip_to_check, 'detail': detail})

        except ObjectDoesNotExist:
            return JsonResponse({'error': 'Device status not found for given IP'}, status=404)

    return HttpResponseBadRequest("Invalid request method") # type: ignore



def latest_status(request):
    latest_status_date = Status.objects.filter(
        ip=OuterRef('ip')
    ).order_by('-status_date').values('status_date')[:1]

    statuses = Status.objects.filter(
        status_date=Subquery(latest_status_date)
    ).order_by('ip')

    data = []
    current_time = datetime.now().replace(microsecond=0)

    for status in statuses:
        status_time = datetime.combine(current_time.date(), status.status_date)
        time_diff = current_time - status_time
        # print(f"IP: {status.ip}, Diff: {time_diff}")

        if time_diff <= timedelta(seconds=4):
            data.append({
                'ip': status.ip,
                'status': status.status,
                'status_date': str(status.status_date)
            })

    # data =[{'ip': '192.168.0.1', 'status': 'Healthy', 'status_date': '14:19:41'},
    #        {'ip': '192.168.0.1', 'status': 'Healthy', 'status_date': '14:19:41'},
    #              {'ip': '192.168.0.9', 'status': 'Unhealthy', 'status_date': '14:19:40'}]
    print("ip data  packet => ",data)
    # ✅ Only check after loop is complete
    if not data:
        return JsonResponse({"message": "No active IP"}, status=200)

    return JsonResponse(data, safe=False)
