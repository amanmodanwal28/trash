let selectedIPs = []



function fetchLatestStatus() {
  fetch('/latest_status')
    .then((response) => response.json())
    .then((data) => {
      const statusContainer = document.getElementById('status-container')
      statusContainer.innerHTML = '' // Clear previous content

      if (Array.isArray(data) && data.length > 0) {
        data.forEach((status, index) => {
          const ip = status.ip
          const state = status.status || 'Unknown'
          const statusLower = state.toLowerCase()

          // Create card div
          const ipDiv = document.createElement('div')
          ipDiv.className = `ip-card ${statusLower}` // .ip-card.healthy etc.
          ipDiv.id = `ipCard${index}`

          // Create checkbox
          const checkbox = document.createElement('input')
          checkbox.type = 'checkbox'
          checkbox.id = `checkbox${index}`
          checkbox.className = 'status-checkbox'
          checkbox.setAttribute('data-ip', ip)
          checkbox.checked = selectedIPs.includes(ip)

          // Create status label
          const label = document.createElement('span')
          label.className = 'ip-label'
          label.innerHTML = `${ip}`

          // Append elements
          ipDiv.appendChild(checkbox)
          ipDiv.appendChild(label)
          statusContainer.appendChild(ipDiv)

          // Click behavior on card
          ipDiv.addEventListener('click', function (e) {
            if (e.target !== checkbox) {
              checkbox.checked = !checkbox.checked
              checkbox.dispatchEvent(new Event('change'))
            }
          })

          // Track selected IPs
          checkbox.addEventListener('change', function () {
            const ip = this.getAttribute('data-ip')
            if (this.checked) {
              if (!selectedIPs.includes(ip)) selectedIPs.push(ip)
            } else {
              selectedIPs = selectedIPs.filter(
                (selectedIp) => selectedIp !== ip
              )
            }
          })
        })
      } else {
        const noData = document.createElement('p')
        noData.id = 'no-data-message'
        noData.textContent = 'No data available'
        statusContainer.appendChild(noData)
      }
    })
    .catch((error) => {
      document.getElementById('status-container').innerHTML =
        '<p>Error fetching data</p>'
      console.error('Fetch error:', error)
    })
}


function collectCheckedIPs() {
  const checkedIPs = Array.from(
    document.querySelectorAll('.status-checkbox:checked')
  ).map((cb) => cb.getAttribute('data-ip'))

  const checkedInput = document.getElementById('checked_ips')
  const detailInput = document.getElementById('details_checked_ips')
  const lcdDetailInput = document.getElementById('lcd_details_checked_ips')

  if (checkedInput) checkedInput.value = checkedIPs.join(',')
  if (detailInput) detailInput.value = checkedIPs.join(',')
  if (lcdDetailInput) lcdDetailInput.value = checkedIPs.join(',')
}


// ######################################################################
// ######################################################################
// event ensures that your JavaScript runs only after the full HTML has been parsed#
// ######################################################################
// ######################################################################

document.addEventListener('DOMContentLoaded', function () {
  fetchLatestStatus()
  setInterval(fetchLatestStatus, 5000)

  const uploadForm = document.getElementById('uploadForm')
  const detailsForm = document.getElementById('detailsForm')
  const lcdDetailsForm = document.getElementById('lcdDetailsForm')

  if (uploadForm) uploadForm.addEventListener('submit', collectCheckedIPs)
  if (detailsForm) detailsForm.addEventListener('submit', collectCheckedIPs)
  if (lcdDetailsForm) lcdDetailsForm.addEventListener('submit', collectCheckedIPs)


  fIleInput();

  lcdDetailsData()
})
// ######################################################################
// ######################################################################




// ######################################################################
// ######################################################################
//  ############  Message Section Data ################################
// ######################################################################
// ######################################################################
function showMessage(type, text) {
  const messagesBox = document.querySelector('.messages')
  if (!messagesBox) return

  const iconMap = {
    success: '✅',
    warning: '⚠️',
    error: '❌',
  }

  messagesBox.innerHTML = `
    <div class="alert ${type}">${iconMap[type] || ''} ${text}</div>
  `

  // Hide alerts after 5s
  setTimeout(() => {
    const alerts = document.querySelectorAll('.alert')
    alerts.forEach((alert) => {
      alert.style.transition = 'opacity 1s ease'
      alert.style.opacity = '0'
      setTimeout(() => alert.remove(), 1000)
    })
  }, 5000)
}
// ######################################################################
// ######################################################################




// ######################################################################
// ######################################################################
//  ############  Healthy Unhealthy Data ################################
// ######################################################################
// ######################################################################
function lcdDetailsData() {

    const LCD_Form = document.getElementById('lcdDetailsForm')

    LCD_Form.addEventListener('submit', function (e) {
      e.preventDefault() // Stop form from reloading the page

      const selectedIps = document.getElementById(
        'lcd_details_checked_ips'
      ).value

      fetch('/get_detail_lcd/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': getCSRFToken(), // CSRF must exist in your page
        },
        body: JSON.stringify({ selected_ips: selectedIps }),
      })
        .then((response) => response.json())
        .then((data) => {
          // console.log('Response:', data);
          showPopupWithData(data, LCD_Form)
        })
        .catch((error) => console.error('Error:', error))
    })

    function getCSRFToken() {
      return document.querySelector('[name=csrfmiddlewaretoken]').value
    }
}

function showPopupWithData(data, formElement) {
  const popup = document.getElementById('popupBox')
  const detailsList = document.getElementById('popupDetailsList')

  detailsList.innerHTML = '' // Clear previous

  if (data.detail) {
    const container = document.createElement('div')
    container.className = 'device-status-grid'

    for (const [device, status] of Object.entries(data.detail)) {
      const statusLower = status.toLowerCase()
      const cssClass = statusLower === 'healthy' ? 'healthy' : 'unhealthy'
      const icon = statusLower === 'healthy' ? '✅' : '❌'
      const color = statusLower === 'healthy' ? '#2ecc71' : '#e74c3c'

      const card = document.createElement('div')
      card.className = `status-card ${cssClass}`
      card.innerHTML = `
        <div class="status-badge">${icon}</div>
        <div class="status-text">
          <div class="device-name">${device}</div>
          <div class="device-status">${status}</div>
        </div>
      `
      container.appendChild(card)
    }

    detailsList.appendChild(container)
  } else {
    detailsList.innerHTML = `<p class="no-status-text">No details available.</p>`
  }

  popup.style.display = 'flex'

  const closeBtn = document.getElementById('closePopupBtn')
  if (closeBtn) {
    closeBtn.onclick = () => {
      popup.style.display = 'none'
    }
  }

  const refreshBtn = document.getElementById('refreshPopupBtn')
  if (refreshBtn && formElement) {
    refreshBtn.onclick = () => {
      formElement.dispatchEvent(new Event('submit', { cancelable: true }))
    }
  }
}

// ######################################################################
// ######################################################################




// ######################################################################
// ######################################################################
//  ############  Input Type file  Data ################################
// ######################################################################
// ######################################################################

function fIleInput() {

    const dropArea = document.getElementById('dropArea')
    const fileInput = document.getElementById('formFile')
    const dropAreaText = document.getElementById('dropAreaText')
    const form = document.getElementById('uploadForm')
    const progressBar = document.getElementById('uploadProgress')
    const progressContainer = document.querySelector('.progress-bar-container')

    // Click anywhere on drop area to open file dialog
    dropArea.addEventListener('click', () => {
      fileInput.click()
    })

    // Show file name on file select
    fileInput.addEventListener('change', () => {
      if (fileInput.files.length > 0) {
        dropAreaText.textContent = `📄 ${fileInput.files[0].name}`
      } else {
        dropAreaText.textContent = '📁 No file selected'
      }
    })

    // Drag-and-drop
    dropArea.addEventListener('dragover', (e) => {
      e.preventDefault()
      dropArea.classList.add('dragover')
    })

    dropArea.addEventListener('dragleave', () => {
      dropArea.classList.remove('dragover')
    })

    dropArea.addEventListener('drop', (e) => {
      e.preventDefault()
      dropArea.classList.remove('dragover')

      const file = e.dataTransfer.files[0]
      if (file) {
        fileInput.files = e.dataTransfer.files
        dropAreaText.textContent = `📄 ${file.name}`
      }
    })

    // Upload with progress
    form.addEventListener('submit', function (e) {
      e.preventDefault()

      const messagesBox = document.querySelector('.messages')
      messagesBox.innerHTML = '' // Clear previous messages

      const selectedIPs = Array.from(
        document.querySelectorAll('.status-checkbox:checked')
      ).map((cb) => cb.getAttribute('data-ip'))

      const fileSelected = fileInput.files.length > 0

      if (!fileSelected && selectedIPs.length === 0) {
        showMessage('warning', 'Please select a file and at least one IP.')

        return
      }

      if (!fileSelected) {
        showMessage('warning', 'Please select a file to upload.')

        return
      }

      if (selectedIPs.length === 0) {

        showMessage('warning', ' Please select at least one IP address.')
        return
      }

      // Set the hidden IP input
      document.getElementById('checked_ips').value = selectedIPs.join(',')

      const formData = new FormData(form)
      const xhr = new XMLHttpRequest()
      xhr.open('POST', form.getAttribute('action') || window.location.href)

      progressContainer.style.display = 'block'
      progressBar.style.width = '0%'

      xhr.upload.onprogress = function (e) {
        if (e.lengthComputable) {
          const percent = (e.loaded / e.total) * 100
          progressBar.style.width = `${percent}%`
        }
      }

      xhr.onload = function () {
        if (xhr.status === 200) {
          progressBar.style.backgroundColor = '#2ecc71'
          messagesBox.innerHTML = `<div class="alert success">✅ Upload successful!</div>`
          showMessage('success', 'Upload successful!')
          form.reset()
          dropAreaText.textContent = '📁 No file selected'
          progressBar.style.width = '0%'
          progressContainer.style.display = 'none'
        } else {
          progressBar.style.backgroundColor = '#e74c3c'
          showMessage('error', 'Upload failed. Try again.')
        }
      }

      xhr.onerror = function () {
        progressBar.style.backgroundColor = '#e74c3c'
        messagesBox.innerHTML = `<div class="alert error">❌ Error during upload.</div>`
        showMessage('error', 'Error during upload.')
      }

      xhr.send(formData)
    })


}



