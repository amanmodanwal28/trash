#!/bin/bash

# Change directory to the script location
cd "$(dirname "$0")"

# Activate the virtual environment
source venv/bin/activate

# Run Django server (will also launch GUI from manage.py)
python manage.py runserver
