import os
import sqlite3
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtCore import Qt

# ---- Constants ----
WINDOW_WIDTH = 280
WINDOW_HEIGHT = 300
INPUT_WIDTH = 300
INPUT_HEIGHT = 40
BUTTON_STYLE = "font:14px; background-color:#0095ff; color:white;border-radius: 10px;"
INPUT_STYLE = "border-radius:10px; padding:8px; font:16px"
LABEL_STYLE = "color: blue; font: 25px"

# ---- Paths ----
current_dir = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.abspath(os.path.join(current_dir, '..', 'iot_enable.sqlite3'))
logo_path = os.path.abspath(os.path.join(current_dir, '..', 'iot_ftp', 'static', 'logo.jpg'))

# ---- Import your Ui_MainWindow ----
from server_ui import Ui_MainWindow  # 🔁 Update this with actual path


# ---- Shared Helpers ----
def connect_to_database():
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        return conn, cursor
    except Exception as e:
        QtWidgets.QMessageBox.critical(None, "Database Error", f"Failed to connect to database:\n{e}")
        return None, None


def switch_to_login(current_widget):
    current_widget.close()
    login_window = SignInWindow()
    login_window.setWindowTitle("Log In")
    login_window.show()


# ---- SignUpWindow ----
class SignUpWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.conn, self.cursor = connect_to_database()

        self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
        screen_geometry = QtWidgets.QDesktopWidget().screenGeometry()
        x = int(screen_geometry.width() / 2 - WINDOW_WIDTH)
        self.setGeometry(x, 120, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setWindowTitle("PT Communication")
        self.setWindowIcon(QtGui.QIcon(logo_path))

        self.setup_ui()

    def setup_ui(self):
        self.setContentsMargins(20, 0, 20, 20)
        layout = QtWidgets.QVBoxLayout()

        label = QtWidgets.QLabel("Create Account")
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet(LABEL_STYLE)

        self.username_line_edit = QtWidgets.QLineEdit()
        self.username_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.username_line_edit.setStyleSheet(INPUT_STYLE)
        self.username_line_edit.setPlaceholderText("Enter Username")

        self.password_line_edit = QtWidgets.QLineEdit()
        self.password_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.password_line_edit.setStyleSheet(INPUT_STYLE)
        self.password_line_edit.setPlaceholderText("Enter Password")
        self.password_line_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password_line_edit.returnPressed.connect(self.register_user)

        self.signup_button = QtWidgets.QPushButton("Sign Up")
        self.signup_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.signup_button.setStyleSheet(BUTTON_STYLE)

        self.back_to_login_button = QtWidgets.QPushButton("Back to Login")
        self.back_to_login_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.back_to_login_button.setStyleSheet(BUTTON_STYLE)

        layout.addWidget(label)
        layout.addSpacing(10)
        layout.addWidget(self.username_line_edit)
        layout.addWidget(self.password_line_edit)
        layout.addSpacing(20)
        layout.addWidget(self.signup_button)
        layout.addWidget(self.back_to_login_button)
        layout.addStretch()

        self.setLayout(layout)

        self.signup_button.clicked.connect(self.register_user)
        self.back_to_login_button.clicked.connect(lambda: switch_to_login(self))

    def register_user(self):
        username = self.username_line_edit.text().strip()
        password = self.password_line_edit.text().strip()

        if not username or not password:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Both fields are required.")
            return

        try:
            self.cursor.execute("SELECT username FROM iot_ftp_signup WHERE username=?", (username,))
            if self.cursor.fetchone():
                QtWidgets.QMessageBox.warning(self, "Duplicate", "Username already exists.")
                return

            self.cursor.execute("INSERT INTO iot_ftp_signup (username, password) VALUES (?, ?)", (username, password))
            self.conn.commit()
            QtWidgets.QMessageBox.information(self, "Success", "Account created successfully!")
            switch_to_login(self)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Database Error", f"Error occurred:\n{e}")


# ---- SignInWindow ----
class SignInWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.conn, self.cursor = connect_to_database()

        self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
        screen_geometry = QtWidgets.QDesktopWidget().screenGeometry()
        x = int(screen_geometry.width() / 2 - WINDOW_WIDTH)
        self.setGeometry(x, 120, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setWindowTitle("PT Communication")
        self.setWindowIcon(QtGui.QIcon(logo_path))

        self.setup_ui()

    def setup_ui(self):
        self.setContentsMargins(20, 0, 20, 20)
        layout = QtWidgets.QVBoxLayout()

        label = QtWidgets.QLabel("Log In")
        label.setStyleSheet(LABEL_STYLE)
        label.setAlignment(Qt.AlignCenter)

        self.username_line_edit = QtWidgets.QLineEdit()
        self.username_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.username_line_edit.setStyleSheet(INPUT_STYLE)
        self.username_line_edit.setPlaceholderText("Enter Username")

        self.password_line_edit = QtWidgets.QLineEdit()
        self.password_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.password_line_edit.setStyleSheet(INPUT_STYLE)
        self.password_line_edit.setPlaceholderText("Enter Password")
        self.password_line_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password_line_edit.returnPressed.connect(self.handle_login)

        self.login_button = QtWidgets.QPushButton("Log In")
        self.login_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.login_button.setStyleSheet(BUTTON_STYLE)

        self.create_account_button = QtWidgets.QPushButton("Sign Up")
        self.create_account_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.create_account_button.setStyleSheet(BUTTON_STYLE)

        layout.addWidget(label)
        layout.addSpacing(10)
        layout.addWidget(self.username_line_edit)
        layout.addWidget(self.password_line_edit)
        layout.addSpacing(20)
        layout.addWidget(self.login_button)
        layout.addWidget(self.create_account_button)
        layout.addStretch()

        self.setLayout(layout)
        self.login_button.clicked.connect(self.handle_login)
        self.create_account_button.clicked.connect(self.open_sign_up)

    def handle_login(self):
        username = self.username_line_edit.text().strip()
        password = self.password_line_edit.text().strip()

        if not username or not password:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Username and password cannot be empty.")
            return

        try:
            self.cursor.execute("SELECT username, password FROM iot_ftp_signup")
            records = self.cursor.fetchall()

            if (username, password) in records:
                self.open_main_window()
            else:
                QtWidgets.QMessageBox.warning(self, "Login Failed", "Incorrect username or password.")
                self.username_line_edit.clear()
                self.password_line_edit.clear()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Query Error", f"Failed to validate login:\n{e}")

    def open_main_window(self):
        self.close()
        self.main_window = Ui_MainWindow()
        self.main_window.setWindowTitle("Main Window")
        self.main_window.show()

    def open_sign_up(self):
        self.close()
        self.sign_up_window = SignUpWindow()
        self.sign_up_window.setWindowTitle("Sign Up")
        self.sign_up_window.show()
