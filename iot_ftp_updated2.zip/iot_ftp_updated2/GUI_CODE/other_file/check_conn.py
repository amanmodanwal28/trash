import os
import sqlite3

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
db_path = os.path.join(base_dir,  'iot_enable.sqlite3')
class DatabaseChecker:
    def __init__(self):
        # Get base path (one level up from GUI_CODE)

        self.conn = None
        self.cursor_ = None

    def connect(self):
        # Step 1: Check if DB file exists
        if not os.path.isfile(db_path):
            print(f"❌ Database file not found at: {db_path}")
            return False

        # Step 2: Attempt connection
        try:
            self.conn = sqlite3.connect(db_path)
            self.cursor_ = self.conn.cursor()

            # Test query
            self.cursor_.execute("SELECT 1")
            print("✅ Connection to database successful.")

            # Show tables (optional)
            self.cursor_.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [table[0] for table in self.cursor_.fetchall()]
            print(f"📋 Tables in DB: {tables}")

            return True
        except sqlite3.Error as e:
            print(f"❌ SQLite error occurred: {e}")
            return False
        except Exception as e:
            print(f"❌ General error occurred: {e}")
            return False

    def close(self):
        if self.cursor_:
            self.cursor_.close()
        if self.conn:
            self.conn.close()
            print("🔒 Connection closed safely.")

# Example usage
if __name__ == "__main__":
    db_checker = DatabaseChecker()
    if db_checker.connect():
        db_checker.close()
