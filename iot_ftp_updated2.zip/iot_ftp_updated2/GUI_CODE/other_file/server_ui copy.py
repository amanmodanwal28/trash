
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import pyqtSignal, QObject,QTimer,QThread
import threading
import socket
import os
import sqlite3
import sys
from datetime import datetime, timedelta
import struct
import time
import subprocess
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QMovie, QKeySequence
# from PyQt5.QtGui import QMovie
import paramiko as pm
import re
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtGui import QColor
from GUI_CODE.other_file.user_auth_ui import SignInWindow


# Constants
WINDOW_WIDTH = 280
WINDOW_HEIGHT = 300
INPUT_WIDTH = 300
INPUT_HEIGHT = 40
BUTTON_STYLE = "font:14px; background-color:#0095ff; color:white;border-radius: 10px;"
INPUT_STYLE = "border-radius:10px; padding:8px; font:16px"
LABEL_STYLE = "color: blue; font: 25px"

# Paths
# Get absolute path to the current file (ui.py)
current_dir = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.abspath(os.path.join(current_dir, '..', 'iot_enable.sqlite3'))

# Move two directories up, then into iot_ftp/static/logo.jpg
logo_path = os.path.abspath(os.path.join(current_dir, '..', 'iot_ftp', 'static', 'logo.jpg'))



class CommandThread(QThread):
    # Signal to send data back to the main thread
    new_line = pyqtSignal(int, str)
    # getKeyBoardCommand = pyqtSignal(int)
    def __init__(self, command,ssh_client, parent=None):
        super().__init__(parent)
        self.command = command
        self.ssh_client = ssh_client

    def run(self):
        # Simulate executing the command and emitting the output line by line
        for index, line in enumerate(self.execute_command(self.command)):
            self.new_line.emit(index, line)  # Emit line to the main thread
        # self.getKeyBoardCommand.connect(self.command)

    def close_command(self):
        self.shell.close()

    def execute_command(self, command):
        self.shell = self.ssh_client.invoke_shell()
        # Send the command to the shell
        self.shell.send(command + "\n")
        # Buffer for incomplete lines
        buffer = ""
        # Read and yield the output in real-time
        while True:
            time.sleep(1)  # Sleep briefly to avoid excessive CPU usage
            # If there's data available, read it
            if self.shell.recv_ready():
                output = self.shell.recv(4096).decode('utf-8')
                # Add output to buffer and split by lines
                buffer += output
                lines = buffer.splitlines(keepends=True)
                # Yield each complete line
                for line in lines[:-1]:
                    yield line.strip()  # Yield line without newline
                    QThread.msleep(100)

                # Keep the last incomplete line in the buffer
                buffer = lines[-1]

            # Break condition (you can use any custom condition to stop the loop)
            # For example, if you expect a shell prompt after the command completes
            if buffer.endswith("$ ") or buffer.endswith("# "):  # Typical shell prompt endings
                break

    # def stop(self):
    #     print("hello00000000000000000====")
    #     self.ssh_client.close()

class AllowAllKeys(pm.MissingHostKeyPolicy):
    def missing_host_key(self, client, hostname, key):
        return

class CommandWorker(QObject):
    command_finished = pyqtSignal(str, int)
    # output_received = pyqtSignal(str)

    def __init__(self, ssh_client, dir_output, command):
        super().__init__()
        self.ssh_client = ssh_client
        self.dir_output = dir_output
        self.command = command

    def run(self):
        try:
            if self.ssh_client.get_transport().is_active():
                stdin, stdout, stderr = self.ssh_client.exec_command(f"cd {self.dir_output} {self.command}")
                exit_status = stdout.channel.recv_exit_status()
                result = stdout.read().decode('utf-8')
                # for line in self.stream_output(stdout):
                #     self.output_received.emit(line)
                self.command_finished.emit(result, exit_status)
            else:
                print("SSH session is not active")
        except Exception as e:
            print("error==========",e)


    # def stream_output(self, stdout):
    #     """
    #     A generator that reads the stdout line by line and yields each line.
    #     """
    #     for line in stdout:
    #         print('line======================',line)
    #         yield line

class Working(QObject):
    # command_finished = pyqtSignal(str)
    # data_msg = pyqtSignal(tuple)
    # subprocess_command=pyqtSignal(object)
    def __init__(self,conn,cursor):
        super().__init__()
        self.connection=conn
        self.cursor=cursor
        # self.SERVER_HOST = '103.76.138.125' # Accept connections on any interface
        self.SERVER_HOST = '192.168.0.206'
        self.SERVER_PORT = 8010      # Port to listen on
        self.BUFFER_SIZE = 1024      # Buffer size for receiving data

        self.clients = {}
        self.client_id_counter = 0
        self.lock = threading.Lock()
        self.checked_ip=None
        self.ip=[]
        # self.run_django_server()

    def run(self):
        # Create a TCP/IP socket
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # Bind the socket to the address and port
        server_socket.bind((self.SERVER_HOST, self.SERVER_PORT))
        # Enable listening mode
        server_socket.listen(5)
        # global client_id_counter
        print(f"Server listening on {self.SERVER_HOST}:{self.SERVER_PORT}")
        try:
            while True:
                # Wait for incoming connections
                client_socket, client_address = server_socket.accept()
                print(client_socket,client_address)
                with self.lock:
                    self.client_id_counter += 1
                    client_id = self.client_id_counter
                # Create a new thread to handle the client
                client_thread = threading.Thread(target=self.handle_client, args=(client_socket, client_address,client_id))
                client_thread.start()
                # self.run_django_server()

        except KeyboardInterrupt:
            print("Server shutting down")

        except Exception as e:
            print(f"An error occurred: {e}")

    def send_file_from_web(self):
        self.header = bytes([0])
        # Read the file name and IP address
        with open('server_storage/selected_ips.txt', 'r') as file:
            self.selected_ip = file.read().strip()  # Ensure there are no extra spaces/newlines

        with open('server_storage/selected_file_name.txt', 'r') as file:
            self.file_name = file.read().strip()  # Ensure there are no extra spaces/newlines

        # Path to the file to be sent
        file_path = os.path.join('server_storage', self.file_name)

        with open(file_path, 'wb') as file:
                while True:
                    # data = self.clients['103.76.138.125'].recv(self.BUFFER_SIZE)
                    data = self.clients['192.168.0.206'].recv(self.BUFFER_SIZE)
                    # print(data)
                    if not data:
                        break
                    file.write(data)

        if not os.path.isfile(file_path):
            print(f"File {file_path} does not exist.")
            return

        # Open the file and prepare to send
        with open(file_path, 'rb') as file:
            file_data = file.read()
            file_size = len(file_data)

            # clients[selected_ip].sendall(header)

            # Send the file name length first
            self.clients[self.selected_ip].sendall(self.header)
            file_name_encoded = self.file_name.encode('utf-8')
            file_name_length = len(file_name_encoded)
            self.clients[self.selected_ip].sendall(struct.pack('!I', file_name_length))
            print(f"File name length ({file_name_length} bytes) sent successfully")

            # Send the file name
            self.clients[self.selected_ip].sendall(file_name_encoded)
            print(f"File name ({self.file_name}) sent successfully")

            # Send the file size
            self.clients[self.selected_ip].sendall(struct.pack('!Q', file_size))
            print("File size sent successfully")
            # Send the file data in chunks
            chunk_size = 64
            for i in range(0, file_size, chunk_size):
                # print('file_data[i:i+chunk_size]=====',len(file_data[i:i+chunk_size]))
                self.clients[self.selected_ip].sendall(file_data[i:i+chunk_size])
            print("File data sent successfully")


    def send_file_from_ui(self,selected_ip,file_path,file_name):
        # Check if the file exists
        self.header = bytes([0])
        # print("hellololoolo=====================================",file_path)
        # if not os.path.isfile(file_path):
        #     print(f"File {file_path} does not exist.")
        #     return

        # Open the file and prepare to send
        with open(file_path, 'rb') as file:
            file_data = file.read()
            file_size = len(file_data)
            # Send the file name length first
            self.clients[selected_ip].sendall(self.header)
            file_name_encoded = file_name.encode('utf-8')
            file_name_length = len(file_name_encoded)
            self.clients[selected_ip].sendall(struct.pack('!I', file_name_length))
            print(f"File name length ({file_name_length} bytes) sent successfully")

            # Send the file name
            self.clients[selected_ip].sendall(file_name_encoded)
            print(f"File name ({file_name}) sent successfully")

            # Send the file size
            self.clients[selected_ip].sendall(struct.pack('!Q', file_size))
            print("File size sent successfully")

            # Send the file data in chunks
            chunk_size = 64
            for i in range(0, file_size, chunk_size):
                # print('file_data[i:i+chunk_size]=====',len(file_data[i:i+chunk_size]))
                self.clients[selected_ip].sendall(file_data[i:i+chunk_size])
            header = self.clients[selected_ip].recv(1)
            print("File data recieved successfully ========== ",header)

    def handle_client(self,client_socket, client_address, client_id):
        client_ip=client_address[0]
        with self.lock:
            self.clients[client_ip] = client_socket
        print(f"Accepted connection from {client_address}")

        header = client_socket.recv(1)   ##xx00
        # if len(header)>=1:
        data_type = int(header[0])  ###0
        self.connection.execute('PRAGMA busy_timeout = 3000')  # Wait for up to 3000 milliseconds (3 seconds)
        # cursor = connection.cursor()

        if data_type == 0:
            self.send_file_from_web()

        elif data_type == 3:
            with open('server_storage/selected_ips.txt', 'r') as file:
                selected_ip = file.read().strip()
            header = bytes([3])
            print(selected_ip)
            self.clients[selected_ip].sendall(header)

        elif data_type == 4:
            print("Waiting for file confirmation message...")

            # Read the next part of the message after the header
            confirmation_data = client_socket.recv(1024)  # Adjust buffer size if needed

            if confirmation_data:
                confirmation_message = confirmation_data.decode('utf-8')
                print(f"Confirmation received from client: {confirmation_message}")
            else:
                print("No confirmation message received or client disconnected")

        elif data_type == 2:
            # print("connection are ready")
            id = client_id
            while True:
                # print("connection are start")
                # Receive data from the client
                data = client_socket.recv(1024).decode()
                # print("data=====",data)
                if not data:
                    break
                device_type = 'None'
                if len(data)>=43:
                    # print("hellololooooooooooooooooooooooooooo===")
                    if data[1:3]=='01':   #2bytes
                        print('data[-8:-2]===========',data[0:].strip())
                        device_type='MPU'
                        # data =data[-6:]
                    elif data[1:3]=='02':
                        # print('data[-8:-2]===========',data[0:].strip())
                        device_type='ICOME'
                        # data =data[-6:]
                    elif data[1:3]=='03':
                        # data =data[-6:]
                        device_type='EBTU'

                    serial_number=data[3:11]   #8bytes
                    software_version=data[11:15] #4bytes
                    connected_device=data[15:23]  #8bytes
                    train_id = data[22:30]
                    coach_id = data[30:38]
                    train_number = data[38:46]
                    # print("train_number============",train_id,coach_id,train_number)
                    if connected_device.count('0') > 4 and connected_device.count('0') < 8:
                        stataus = 'Unhealthy'   #8bytes
                    else:
                        stataus = 'Healthy'

                    now = datetime.now()
                    formatted_time = now.strftime('%H:%M:%S')

                    insert_query = '''
                        INSERT INTO iot_ftp_status (ip, port, status, client_id, status_date,type,serial_number,version,connected_devices,train_id,coach_id,train_number) VALUES (?, ?, ?, ?, ?,?,?,?,?,?,?,?)
                    '''
                    data1 = (client_address[0], client_address[1], stataus, id, formatted_time,device_type,serial_number,software_version,connected_device,train_id,coach_id,train_number)
                    self.execute_query_with_retry(self.cursor, insert_query, data1)
                    self.connection.commit()
                    time.sleep(1)
                    try:
                        delete_query = 'DELETE FROM iot_ftp_status WHERE id NOT IN (SELECT id FROM iot_ftp_status ORDER BY id DESC LIMIT 50);'
                        self.execute_query_with_retry(self.cursor, delete_query)
                        self.connection.commit()
                    except sqlite3.OperationalError as e:
                        print(f"Error executing delete query: {e}")

    def execute_query_with_retry(self,cursor, query, data=None, max_retries=5, base_delay=0.1):
        retries = 0
        while retries < max_retries:
            try:
                if data:
                    cursor.execute(query, data)
                else:
                    cursor.execute(query)
                return
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e):
                    time.sleep(base_delay * (2 ** retries))  # Exponential backoff
                    retries += 1
                else:
                    raise
        raise sqlite3.OperationalError("Max retries exceeded for query: {}".format(query))

class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        # self.close()
        self.setupUi(self)

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        # MainWindow.resize(1366, 768)
        # self.setWindowTitle("PT Communication")
        self.setWindowIcon(QtGui.QIcon(logo_path))

        self.setGeometry(100, 100, 800, 600)  # Initial size and position
        self.showMaximized()

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.centralwidget.setStyleSheet("background-color: black;")

        self.main_ver_Layout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.main_ver_Layout.setContentsMargins(20, 20, 20, 20)
        self.main_ver_Layout.setObjectName("main_ver_Layout")

        # self.main_ver_Layout_QtWidgets = QtWidgets.QWidget()
        # self.main_ver_Layout_QtWidgets.setLayout(self.main_ver_Layout)
        # self.main_ver_Layout_QtWidgets.setStyleSheet("background-color: lightblue;")

        self.main_hori_Layout = QtWidgets.QHBoxLayout()
        self.main_hori_Layout.setObjectName("main_hori_Layout")



        self.horizontalLayout_header = QtWidgets.QHBoxLayout()   #header
        self.horizontalLayout_header.setContentsMargins(20, 20, 20, 20)
        self.horizontalLayout_header.setObjectName("horizontalLayout_header")
        self.container_widget_horizontalLayout_header = QtWidgets.QWidget(self.centralwidget)
        self.container_widget_horizontalLayout_header.setLayout(self.horizontalLayout_header)
        self.container_widget_horizontalLayout_header.setStyleSheet("background-color: lightgrey;")

        self.connected_devices_num = QtWidgets.QLabel()
        self.connected_devices_num.setStyleSheet("font-weight: bold; font: 16px; color: green")
        self.Connected_devices = QtWidgets.QLabel("Active Devices :")
        self.Connected_devices.setStyleSheet("font-weight: bold; font: 16px; color: green")
        self.button_lineedit_layout = QtWidgets.QHBoxLayout()
        self.button_lineedit_layout.setObjectName("button_lineedit_layout")

        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 20, 251, 31))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.horizontalLayout_header.addWidget(self.label)
        spacer1 = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_header.addItem(spacer1)
        spacer2 = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_header.addItem(spacer2)

        self.dropdown = QtWidgets.QComboBox(self)
        self.dropdown.setCurrentIndex(0)
        self.dropdown.setFixedSize(150, 24)
        self.dropdown.addItems(["Filter", "Healthy", "Unhealthy"])
        self.dropdown.setStyleSheet("font-weight: bold;")
        self.dropdown.currentIndexChanged.connect(self.on_selection_change)
        self.horizontalLayout_header.addWidget(self.dropdown)
        self.horizontalLayout_header.addWidget(self.dropdown,alignment=QtCore.Qt.AlignRight)

        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        # self.tableWidget.cellClicked.connect(self.get_row_data)
        self.tableWidget.setStyleSheet("""
        QTableWidget {
            background-color: lightgrey;
            gridline-color: black;
        }

       QHeaderView::section {
        background-color: rgb(175, 175, 0) ;
        font-weight: bold;
        color: white;

     }
        QTableWidget::item {
            text-align: center;
            font: 12px;
        }
    """)
        # self.tableWidget.setGeometry(QtCore.QRect(30, 70, 200, 100))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(10)
        self.tableWidget.setRowCount(1)

        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, item)

        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(6, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(7, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(8, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(9, item)
        # item = QtWidgets.QTableWidgetItem()
        self.tableWidget.verticalHeader().setVisible(True)
        self.tableWidget.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        MainWindow.setCentralWidget(self.centralwidget)

        self.main_hori_Layout.addWidget(self.tableWidget)
        self.main_ver_Layout.addWidget(self.container_widget_horizontalLayout_header)
        self.main_ver_Layout.addLayout(self.main_hori_Layout)

        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        #self.db_path = r"C:\Users\AMAN-RND\Desktop\iot_enable_remote_control\iot_enable_ftp\iot_enable.sqlite3"
        self.connection = sqlite3.connect(db_path, check_same_thread=False)
        self.cursor = self.connection.cursor()

        self.cursor2=None
        self.previous_time = {}

        self.start_server()  #

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.show_data)
        self.timer.start(1000)


        self.console_lineEdit = None
        self.consol_dir_label = None
        self.consol_label_output = None
        self.execute_button = None
        self.container_widget_consol_Layout = None
        self.dir_output=None
        self.main_dir_list=[]
        self.selected_option = None
        self.commands = ("cd", "ls", "mkdir","pwd","cat","rm", "cp","mv","touch","chmod","nano","head","tail")

        self.auth_flag=True

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        bold_font = QFont()
        bold_font.setBold(True)

        MainWindow.setWindowTitle(_translate("MainWindow", "jjjjjj"))
        self.label.setText(_translate("MainWindow", "Devices Information"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Train ID"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Coach ID"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Train Number"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "Device Serial Number"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "Main Device"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "Status"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "Time"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "Detail"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "Upload File"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(9)
        item.setText(_translate("MainWindow", "Console"))
        item.setFont(bold_font)

        # item = self.tableWidget.horizontalHeaderItem(4)
        # item.setText(_translate("MainWindow", "detail"))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Control:
            self.console_lineEdit.clearFocus()
        if event.key() ==  Qt.Key_Return:
            self.execute_command_line()
        elif event.key() == Qt.Key_C and event.modifiers() == Qt.ControlModifier:
            if self.thread3:
                self.thread3.close_command()
        super(Ui_MainWindow, self).keyPressEvent(event)

    def start_server(self):
        self.worker1 = Working(self.connection,self.cursor)
        self.thread1 = threading.Thread(target=self.worker1.run)
        # self.worker.data_msg.connect(self.show_data)
        self.thread1.start()

    def show_data(self):
        if self.cursor2:
            self.cursor2.close()

        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.cursor2 = self.conn.cursor()
        if self.selected_option == None:
            query='select train_id,coach_id, train_number,serial_number, type, status, status_date,connected_devices from iot_ftp_status where status_date=(select max(status_date) from iot_ftp_status) and client_id in (select distinct(client_id) from iot_ftp_status)'
            self.cursor2.execute(query)
            self.data = self.cursor2.fetchall()
        else:
            # query=f'select serial_number, type, status, status_date,connected_devices,ip from iot_ftp_status where status_date=(select max(status_date) from iot_ftp_status) and client_id in (select distinct(client_id) from iot_ftp_status) and status = ?'
            query=f'select train_id,coach_id, train_number,serial_number, type, status, status_date,connected_devices from iot_ftp_status where status_date=(select max(status_date) from iot_ftp_status) and client_id in (select distinct(client_id) from iot_ftp_status) and status = ?'
            self.cursor2.execute(query,(self.selected_option,))
            self.data = self.cursor2.fetchall()
        print('self.data====================',self.data)

        self.tableWidget.setRowCount(0)  # Clear existing data
        # self.tableWidget.setHorizontalHeaderLabels(['Client ID', 'Latest Date'])
        if self.previous_time != {}:
            # print('self.previous_time==========',self.previous_time)
            for row_num, row_data in enumerate(self.data):
                self.tableWidget.insertRow(row_num)
                for col_num, col_data in enumerate(row_data):
                    # print("col_data=====",col_data,self.previous_time)
                    # if self.previous_time[row_data[3]] == row_data[6]:
                    if row_data[3] in self.previous_time and self.previous_time[row_data[3]] == row_data[6]:
                        self.tableWidget.removeRow(row_num)
                    else:
                        # print("helloloooooooooo==============")
                        self.tableWidget.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))
                        item = self.tableWidget.item(row_num, col_num)
                        if item is not None:
                            item.setTextAlignment(Qt.AlignCenter)
                self.previous_time[row_data[3]] = row_data[6]
                row_count = self.tableWidget.rowCount()
                # print("row_count=============",row_count)
                row_count = f"{row_count}"
                self.connected_devices_num.setText(row_count)
                self.horizontalLayout_header.insertWidget(2,self.Connected_devices)
                self.horizontalLayout_header.insertWidget(3,self.connected_devices_num)
                self.button = QtWidgets.QPushButton("Detail")
                self.button.setStyleSheet('background-color:lightgrey;font-weight: bold;')

                upload = QtWidgets.QPushButton("Upload")
                upload.setStyleSheet('background-color:lightgrey;font-weight: bold;')

                self.console_button=QtWidgets.QPushButton("Console")
                self.console_button.setStyleSheet("background-color: lightgrey; font-weight: bold;")

                self.button.clicked.connect(self.detail_view)
                upload.clicked.connect(self.upload_file)
                self.console_button.clicked.connect(self.authentication)

                self.button.setProperty("row", row_num)
                upload.setProperty("row", row_num)
                self.console_button.setProperty("row", row_num)

                self.tableWidget.setCellWidget(row_num, 7, self.button)
                self.tableWidget.setCellWidget(row_num, 8, upload)
                self.tableWidget.setCellWidget(row_num, 9, self.console_button)
        else:
            for row_num, row_data in enumerate(self.data):
                self.tableWidget.insertRow(row_num)
                for col_num, col_data in enumerate(row_data):
                    self.tableWidget.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))
                    item = self.tableWidget.item(row_num, col_num)
                    if item is not None:
                        item.setTextAlignment(Qt.AlignCenter)

                self.button = QtWidgets.QPushButton("Detail")
                self.button.setStyleSheet('background-color:lightgrey;font-weight: bold;')

                upload = QtWidgets.QPushButton("Upload")
                upload.setStyleSheet('background-color:lightgrey;font-weight: bold;')

                self.console_button=QtWidgets.QPushButton("Console")
                self.console_button.setStyleSheet("background-color: lightgrey; font-weight: bold;")

                self.previous_time[row_data[3]]=row_data[6]

                self.button.clicked.connect(self.detail_view)
                upload.clicked.connect(self.upload_file)

                self.button.setProperty("row", row_num)
                upload.setProperty("row", row_num)
                self.console_button.setProperty("row", row_num)

                self.tableWidget.setCellWidget(row_num, 4, self.button)
                self.tableWidget.setCellWidget(row_num, 5, upload)
                self.tableWidget.setCellWidget(row_num, 6, self.console_button)

    def on_selection_change(self):
        self.selected_option = self.dropdown.currentText()
        if self.selected_option == "Filter":
            self.selected_option = None

    def detail_view(self):
        # Create the dialog
        detail_dialog = QtWidgets.QDialog(self)
        detail_dialog.setStyleSheet("background-color:lightgrey;")
        detail_dialog.setWindowTitle("Detail View")
        detail_dialog.setGeometry(100, 250, 200, 230)  # Adjusted size for better fit
        detail_dialog.setWindowFlags(detail_dialog.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)
        qr = detail_dialog.frameGeometry()
        cp = QtWidgets.QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        detail_dialog.move(qr.topLeft())
        # Create a vertical layout
        layout = QtWidgets.QVBoxLayout()
        # Create and set a label for the title
        title_label = QtWidgets.QLabel("Detail View")
        title_label.setAlignment(QtCore.Qt.AlignLeft)
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
        layout.addWidget(title_label)

        button = self.sender()
        if button:
            row = button.property("row")
            row_data = self.data[row]
        # print("raw_data====",row_data)
        data = row_data[-1]
        # print("show data=========",data)
        data = [data[i:i+2] for i in range(0, len(data), 2)]
        print("=============================",data)

        # Initialize status variables
        LED  =  'Unhealthy'
        LCD  =  'Unhealthy'
        ETBU =  'Unhealthy'
        EPB  =  'Unhealthy'

        # Set status based on data
        if data:
            if '06' in data:
                LED = 'Healthy'
            if '07' in data:
                LCD = 'Healthy'
            if '08' in data:
                ETBU = 'Healthy'
            if '09' in data:
                EPB = 'Healthy'

        # Create and set labels for each status
        led_label = QtWidgets.QLabel(f"<b>LED:</b> {LED}")
        lcd_label = QtWidgets.QLabel(f"<b>LCD:</b> {LCD}")
        etbu_label = QtWidgets.QLabel(f"<b>ETBU:</b> {ETBU}")
        epb_label = QtWidgets.QLabel(f"<b>EPB:</b> {EPB}")

        # Style each label
        status_style = "font-size: 14px; color: #34495e; margin: 10px;"
        healthy_style = "color: green;"  # Green
        unhealthy_style = "color: #e74c3c;"  # Red

        led_label.setStyleSheet(status_style + (healthy_style if LED == 'Healthy' else unhealthy_style))
        lcd_label.setStyleSheet(status_style + (healthy_style if LCD == 'Healthy' else unhealthy_style))
        etbu_label.setStyleSheet(status_style + (healthy_style if ETBU == 'Healthy' else unhealthy_style))
        epb_label.setStyleSheet(status_style + (healthy_style if EPB == 'Healthy' else unhealthy_style))

        # Add status labels to the layout
        layout.addWidget(led_label)
        layout.addWidget(lcd_label)
        layout.addWidget(etbu_label)
        layout.addWidget(epb_label)
        # Add spacing and adjust layout
        layout.addStretch()
        # Set the layout for the dialog
        detail_dialog.setLayout(layout)

        # Show the dialog
        detail_dialog.exec_()

    def upload_file(self):
        button = self.sender()
        if button:
            row = button.property("row")
            row_data = self.data[row]
            # print('row_data=====================',row_data,row_data[-1])

        options = QtWidgets.QFileDialog.Options()
        options |= QtWidgets.QFileDialog.ReadOnly
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "", "All Files (*);;Text Files (*.txt)", options=options)
        # print(file_path)
        if not os.path.isfile(file_path):
            print(f"File {file_path} does not exist.")
        else:
            file_name = file_path.split("/")[-1]
            # print("file_name=============",file_name)
            self.worker1.send_file_from_ui(row_data[-1],file_path,file_name)
            # label=QtWidgets.QLabel("File send Successfully")
            # self.horizontalLayout_header.insertWidget(3,label)
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Information)
            msg.setWindowTitle("File Status")
            msg.setText("File send Successfully")
            msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
            msg.exec_()

    def execute_command(self,command):
        if command == 'cd ..':
            if self.dir_output == "/home\n":
                command=f"{command} && {command}"
                # print("change direcotry command",f"{command} && pwd")
                stdin, stdout, stderr = self.ssh_client.exec_command(f"{command} && pwd")
                self.dir_output=stdout.read().decode('utf-8')
                self.consol_dir_label.setText(self.dir_output)
                # print("===1==current direcotry===== ",self.dir_output)
            elif self.dir_output == "/home/root\n":
                # print("change direcotry command",f"{command} && pwd")
                stdin, stdout, stderr = self.ssh_client.exec_command(f"{command} && pwd")
                self.dir_output=stdout.read().decode('utf-8')
                self.consol_dir_label.setText(self.dir_output)
            else:

                stdin, stdout, stderr = self.ssh_client.exec_command(f"cd {self.dir_output} {command} && pwd")
                self.dir_output=stdout.read().decode('utf-8')
                self.consol_dir_label.setText(self.dir_output)

            # stdin, stdout, stderr = self.ssh_client.exec_command(f"pwd")
            # print("=====direcotry===== ",stdout.read().decode('utf-8'))

        elif command =="cd /":
            stdin, stdout, stderr = self.ssh_client.exec_command(f"{command} && pwd")
            self.dir_output=stdout.read().decode('utf-8')
            self.consol_dir_label.setText(self.dir_output)
            # print("==elif===current direcotry===== ",self.dir_output)

        else:
            # print("command===")
            # input_string = command
            pattern = r"^cd .+\/$"
            match = re.match(pattern, command)
            if match:
                stdin, stdout, stderr = self.ssh_client.exec_command(f"cd  {self.dir_output} {command} && pwd")
                self.dir_output=stdout.read().decode('utf-8')
                self.consol_dir_label.setText(self.dir_output)
                return stdout.read().decode('utf-8')
            elif self.consol_dir_label != None:
                # self.movie.start()
                self.worker = CommandWorker(self.ssh_client, self.dir_output, command)
                self.thread2 = QThread()
                self.worker.moveToThread(self.thread2)
                # self.worker.output_received.connect(self.on_output_received)
                self.worker.command_finished.connect(self.on_command_finished)
                self.thread2.started.connect(self.worker.run)
                self.thread2.start()
            else:
                stdin, stdout, stderr = self.ssh_client.exec_command(command)
                return stdout.read().decode('utf-8')

    def on_command_finished(self, result, exit_status):

        self.consol_label_output.setText(result)
        if exit_status == 0:
            print(f"Command executed successfully:{exit_status}")
        else:
            print("Command failed with error")

        # Clean up the worker and thread
        self.worker2 = None
        self.thread2.quit()
        self.thread2.wait()
        self.thread2 = None

        # Update UI or return the result
        # print('result==================',result)
        # return result

    def execute_command_line(self):
        self.flag= False
        command= self.console_lineEdit.text()
        # Connect to the SSH server
        try:
            if command.startswith(self.commands):
                self.consol_label_output.clear()
                # print("if condition===================")
                self.execute_command(command)
            else:
                # print("hellololol==============")
                self.consol_label_output.clear()
                self.run_command(f"{command}")


        except Exception as e:
            print(f"Failed to connect or execute commands: {e}")

        # Close the connection
        finally:
            self.console_lineEdit.clear()

    def run_command(self, command):
        # Create the worker thread
        self.thread3 = CommandThread(command,self.ssh_client)
        self.thread3.new_line.connect(self.update_output)  # Connect signal to update function
        self.thread3.start()

    def update_output(self, index, line):
        # print(f"Received line {index}: {line}")
        if index == 0:
            pass
        elif index == 1:
            pass
        elif self.flag is not True:
            current_text = self.consol_label_output.text() + line + '\n'
            self.consol_label_output.setText(current_text)

    def authentication(self):
        if self.auth_flag:
            self.auth_dialog = QtWidgets.QDialog(self)
            self.auth_dialog.setStyleSheet("background-color:lightgrey;margin:3px;")
            self.auth_dialog.setWindowTitle("Authentication")
            self.auth_dialog.setGeometry(100, 250, 300, 420)  # Adjusted size for better fit
            self.auth_dialog.setWindowFlags(self.auth_dialog.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)

            qr = self.auth_dialog.frameGeometry()
            cp = QtWidgets.QDesktopWidget().availableGeometry().center()
            qr.moveCenter(cp)
            self.auth_dialog.move(qr.topLeft())

            # Create a vertical layout
            layout = QtWidgets.QVBoxLayout()
            # Create and set a label for the title
            title_label = QtWidgets.QLabel("Fill information")
            title_label.setAlignment(QtCore.Qt.AlignCenter)
            title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
            hostname_label= QtWidgets.QLabel("Host name : ")
            hostname_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
            self.hostname_lineedit = QtWidgets.QLineEdit()
            self.hostname_lineedit.setPlaceholderText("192.168.0.206")
            self.hostname_lineedit.setStyleSheet("background-color:white; border-radius:10px; padding:8px;font:16px")
            user_label= QtWidgets.QLabel("User name : ")
            user_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
            self.user_lineedit = QtWidgets.QLineEdit()
            self.user_lineedit.setPlaceholderText("root")
            self.user_lineedit.setStyleSheet("background-color:white; border-radius:10px; padding:8px;font:16px")
            password_label= QtWidgets.QLabel("Password : ")
            password_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
            self.password_lineedit = QtWidgets.QLineEdit()
            self.password_lineedit.setPlaceholderText("xyz123")
            self.password_lineedit.setStyleSheet("background-color:white; border-radius:10px; padding:8px;font:16px")

            submit_button = QtWidgets.QPushButton("Submit")
            submit_button.setFixedSize(300,40)
            submit_button.setStyleSheet("font:14px; background-color:#0095ff; color:white;border-radius: 10px; ")

            layout.addWidget(title_label)
            label_spacer = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
            layout.addItem(label_spacer)
            layout.addWidget(hostname_label)
            layout.addWidget(self.hostname_lineedit)
            layout.addWidget(user_label)
            layout.addWidget(self.user_lineedit)
            layout.addWidget(password_label)
            layout.addWidget(self.password_lineedit)
            auth_spacer = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
            layout.addItem(auth_spacer)
            layout.addWidget(submit_button)
            submit_button.clicked.connect(self.console)
            # Add spacing and adjust layout
            layout.addStretch()
            # Set the layout for the dialog
            self.auth_dialog.setLayout(layout)
            # Show the dialog
            self.auth_dialog.exec_()
        else:
            self.console()

    def console(self):
        self.hostname= self.hostname_lineedit.text()
        self.username= self.user_lineedit.text()
        self.password= self.password_lineedit.text()
        self.auth_dialog.close()
        self.flag = True

        self.ssh_client = pm.SSHClient()
        self.ssh_client.load_system_host_keys()
        self.ssh_client.set_missing_host_key_policy(AllowAllKeys())
        if self.hostname.strip() != '' and self.username.strip() != '':
            print("hello")
            if self.consol_dir_label is None:
                self.auth_flag=False
                # print("consol======",self.consol_dir_label)
                try:
                    # self.gif_label = QtWidgets.QLabel(self)  # Example QLabel widget
                    # self.gif_label.setGeometry(100, 100, 200, 200)
                    # self.gif_label.setMovie(self.movie)
                    # self.movie.start()
                    # self.ssh_client.connect(hostname='192.168.11.200', username='root', password='')
                    self.ssh_client.connect(hostname=self.hostname, username= self.username, password=self.password)
                    self.dir_output = self.execute_command('pwd')
                except Exception as e:
                    print(f"Failed to connect or execute commands: {e}")
                self.console_button.setText("Back")
                # Create the main vertical layout
                self.consol_Layout = QtWidgets.QVBoxLayout(self.centralwidget)
                self.consol_Layout.setObjectName("consol_Layout")

                # Create a container widget for the layout
                self.container_widget_consol_Layout = QtWidgets.QWidget()
                self.container_widget_consol_Layout.setLayout(self.consol_Layout)
                self.container_widget_consol_Layout.setStyleSheet("""
                    QWidget {
                        background-color: grey;
                    }
                """)
                # Add the console_dir_label
                self.consol_dir_label = QtWidgets.QLabel(self.centralwidget)
                self.consol_dir_label.setText(self.dir_output) ####set directory
                self.consol_dir_label.setStyleSheet('background-color:black; color:white; font-size: 14px;')
                self.consol_dir_label.setContentsMargins(10, 12, 0, 0)
                self.consol_dir_label.setFixedSize(640, 50)
                self.consol_Layout.addWidget(self.consol_dir_label)

                # Add the console_label_output
                self.consol_label_output = QtWidgets.QLabel(self.centralwidget)
                self.consol_label_output.setWordWrap(True)
                self.consol_label_output.setStyleSheet('background-color:black; color:white; font-size: 12px;')
                self.consol_label_output.setContentsMargins(10, 10, 10, 10)
                self.consol_label_output.setAlignment(Qt.AlignTop)

                # Create a QScrollArea and set the QLabel as its widget
                self.scroll_area = QtWidgets.QScrollArea(self.centralwidget)
                self.scroll_area.setWidget(self.consol_label_output)
                self.scroll_area.setWidgetResizable(True)
                self.scroll_area.setFixedSize(640, 400)
                self.scroll_area.setStyleSheet('background-color:black;')

                # Add the scroll area to the layout
                self.consol_Layout.addWidget(self.scroll_area)

                # Add console_lineEdit and execute_button
                self.console_lineEdit = QtWidgets.QLineEdit(self.centralwidget)
                self.console_lineEdit.setFixedSize(560, 50)
                self.console_lineEdit.setStyleSheet("background-color: black;color: white; font-size: 12px;")
                self.console_lineEdit.setTextMargins(10, 0, 0, 0)

                self.execute_button = QtWidgets.QPushButton("Execute")
                self.execute_button.setFixedSize(75, 50)
                self.execute_button.setStyleSheet("background-color: lightgrey;color: black; font-weight: bold;")
                self.execute_button.clicked.connect(self.execute_command_line)

                # Create a horizontal layout for the line edit and button
                self.button_lineedit_layout = QtWidgets.QHBoxLayout()
                self.button_lineedit_layout.addWidget(self.console_lineEdit)
                self.button_lineedit_layout.addWidget(self.execute_button)

                # Add the line edit and button layout to the main console layout
                self.consol_Layout.addLayout(self.button_lineedit_layout)

                # Add the consol_Layout to the main layout
                self.main_hori_Layout.addWidget(self.container_widget_consol_Layout)
            else:
                self.auth_flag=True
                # Clean up the worker and thread
                self.worker2 = None
                # Remove console_dir_label
                self.console_button.setText("Console")
                self.consol_Layout.removeWidget(self.consol_dir_label)
                self.consol_dir_label.deleteLater()  # Properly delete the widget
                self.consol_dir_label = None

                # Remove console_label_output
                self.consol_Layout.removeWidget(self.consol_label_output)
                self.consol_label_output.deleteLater()  # Properly delete the widget
                self.consol_label_output = None

                # Remove console_lineEdit
                self.button_lineedit_layout.removeWidget(self.console_lineEdit)
                self.console_lineEdit.deleteLater()  # Properly delete the widget
                self.console_lineEdit = None

                # Remove execute_button
                self.button_lineedit_layout.removeWidget(self.execute_button)
                self.execute_button.deleteLater()  # Properly delete the button
                self.execute_button = None

                # Remove button_lineedit_layout layout from consol_Layout
                self.consol_Layout.removeItem(self.button_lineedit_layout)
                # self.consol_Layout.removeWidget(self.container_widget_consol_Layout)

                # Remove the container widget from the main layout
                self.main_hori_Layout.removeWidget(self.container_widget_consol_Layout)
                self.container_widget_consol_Layout.deleteLater()
                self.container_widget_consol_Layout = None
        else:
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Information)
            msg.setWindowTitle("Informartion")
            msg.setText("Fill the credential")
            msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
            msg.exec_()

# class SignUpWindow(QtWidgets.QWidget):
#     def __init__(self):
#         super().__init__()
#         self.conn = None
#         self.cursor = None

#         self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
#         screen_geometry = QtWidgets.QDesktopWidget().screenGeometry()
#         x = int(screen_geometry.width() / 2 - 200)
#         self.setGeometry(x, 120, 280, 300)
#         self.setWindowTitle("PT Communication")
#         self.setWindowIcon(QtGui.QIcon(logo_path))

#         self.setup_ui()

#     def setup_ui(self):
#         self.setContentsMargins(20, 0, 20, 20)
#         layout = QtWidgets.QVBoxLayout()

#         self.label = QtWidgets.QLabel("Create Account")
#         self.label.setAlignment(Qt.AlignCenter)
#         self.label.setStyleSheet(LABEL_STYLE)

#         self.username_line_edit = QtWidgets.QLineEdit()
#         self.username_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
#         self.username_line_edit.setStyleSheet(INPUT_STYLE)
#         self.username_line_edit.setPlaceholderText("Enter Username")

#         self.password_line_edit = QtWidgets.QLineEdit()
#         self.password_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
#         self.password_line_edit.setStyleSheet(INPUT_STYLE)
#         self.password_line_edit.setPlaceholderText("Enter Password")
#         self.password_line_edit.setEchoMode(QtWidgets.QLineEdit.Password)
#         self.password_line_edit.returnPressed.connect(self.register_user)

#         self.signup_button = QtWidgets.QPushButton("Sign Up")
#         self.signup_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
#         self.signup_button.setStyleSheet(BUTTON_STYLE)

#         self.back_to_login_button = QtWidgets.QPushButton("Back to Login")
#         self.back_to_login_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
#         self.back_to_login_button.setStyleSheet(BUTTON_STYLE)

#         layout.addWidget(self.label)
#         layout.addSpacing(10)
#         layout.addWidget(self.username_line_edit)
#         layout.addWidget(self.password_line_edit)
#         layout.addSpacing(20)
#         layout.addWidget(self.signup_button)
#         layout.addWidget(self.back_to_login_button)
#         layout.addStretch()

#         self.setLayout(layout)
#         self.connect_to_database()

#        # self.db_path = r"C:\Users\AMAN-RND\Desktop\iot_enable_remote_control\iot_enable_ftp\iot_enable.sqlite3"
#         #self.conn = sqlite3.connect(db_path)
#         #self.cursor_ = self.conn.cursor()

#         self.signup_button.clicked.connect(self.register_user)
#         self.back_to_login_button.clicked.connect(self.back_to_login)

#     def connect_to_database(self):
#             try:
#                 self.conn = sqlite3.connect(db_path)
#                 self.cursor = self.conn.cursor()
#             except Exception as e:
#                 QtWidgets.QMessageBox.critical(self, "Database Error", f"Failed to connect to database:\n{e}")
#                 self.close()

#     def register_user(self):
#         username = self.username_line_edit.text().strip()
#         password = self.password_line_edit.text().strip()

#         if not username or not password:
#                     QtWidgets.QMessageBox.warning(self, "Input Error", "Both fields are required.")
#                     return

#         try:
#             # Optional: check if username already exists
#             self.cursor.execute("SELECT username FROM iot_ftp_signup WHERE username=?", (username,))
#             if self.cursor.fetchone():
#                 QtWidgets.QMessageBox.warning(self, "Error", "Username already exists. Choose another.")
#                 return

#             query = "INSERT INTO iot_ftp_signup (username, password) VALUES (?, ?)"
#             self.cursor.execute(query, (username, password))
#             self.conn.commit()

#             QtWidgets.QMessageBox.information(self, "Success", "Account created successfully!")
#             self.back_to_login()

#         except Exception as e:
#             QtWidgets.QMessageBox.critical(self, "Database Error", f"Error occurred:\n{e}")


#     def back_to_login(self):
#         self.close()
#         self.sign_in_window = SignInWindow()
#         self.sign_in_window.setWindowTitle("Log In")
#         self.sign_in_window.show()

# class SignInWindow(QtWidgets.QWidget):
#     def __init__(self):
#         super().__init__()
#         self.conn = None
#         self.cursor = None
#         self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)

#         # Center window
#         screen_geometry = QtWidgets.QDesktopWidget().screenGeometry()
#         x = int(screen_geometry.width() / 2 - WINDOW_WIDTH)
#         self.setGeometry(x, 120, WINDOW_WIDTH, WINDOW_HEIGHT)
#         self.setWindowTitle("PT Communication")
#         self.setWindowIcon(QtGui.QIcon(logo_path))

#         self.setup_ui()
#         self.connect_to_database()


#     def setup_ui(self):
#         self.setContentsMargins(20,0,20,20)
#         layout = QtWidgets.QVBoxLayout()

#         self.label = QtWidgets.QLabel("Log In")
#         self.label.setStyleSheet(LABEL_STYLE)
#         self.label.setAlignment(Qt.AlignCenter)

#         self.username_line_edit = QtWidgets.QLineEdit()
#         self.username_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
#         self.username_line_edit.setStyleSheet(INPUT_STYLE)
#         self.username_line_edit.setPlaceholderText("Enter Username")

#         self.password_line_edit = QtWidgets.QLineEdit()
#         self.password_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
#         self.password_line_edit.setStyleSheet(INPUT_STYLE)
#         self.password_line_edit.setPlaceholderText("Enter Password")
#         self.password_line_edit.setEchoMode(QtWidgets.QLineEdit.Password)

#         self.password_line_edit.returnPressed.connect(self.handle_login)

#         self.login_button = QtWidgets.QPushButton("Log In")
#         self.login_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
#         self.login_button.setStyleSheet(BUTTON_STYLE)

#         self.create_account_button = QtWidgets.QPushButton("Sign Up")
#         self.create_account_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
#         self.create_account_button.setStyleSheet(BUTTON_STYLE)
#         #self.create_account_button.setDisabled(True)
#         self.create_account_button.setToolTip("Sign-up will be available soon.")




#         # Add widgets
#         layout.addWidget(self.label)
#         layout.addSpacing(10)
#         layout.addWidget(self.username_line_edit)
#         layout.addWidget(self.password_line_edit)
#         layout.addSpacing(20)
#         layout.addWidget(self.login_button)
#         layout.addWidget(self.create_account_button)
#         layout.addStretch()

#         self.setLayout(layout)

#         #self.db_path =r"C:\Users\AMAN-RND\Desktop\iot_enable_remote_control\iot_enable_ftp\iot_enable.sqlite3"
#         #self.conn = sqlite3.connect(db_path)
#         #self.cursor_ = self.conn.cursor()

#         # Connect signals
#         self.login_button.clicked.connect(self.handle_login)
#         self.create_account_button.clicked.connect(self.open_sign_up)

#     def connect_to_database(self):
#         try:
#             self.conn = sqlite3.connect(db_path)
#             self.cursor = self.conn.cursor()
#         except Exception as e:
#             QtWidgets.QMessageBox.critical(self, "Database Error", f"Failed to connect to database:\n{e}")
#             self.close()

#     def handle_login(self):
#         username = self.username_line_edit.text().strip()
#         password = self.password_line_edit.text().strip()

#         if not username or not password:
#             QtWidgets.QMessageBox.warning(self, "Input Error", "Username and password cannot be empty.")
#             return

#         query = "SELECT username, password FROM iot_ftp_signup"
#         try:
#             self.cursor.execute(query)
#             records = self.cursor.fetchall()

#             if (username, password) in records:
#                 self.open_main_window()
#             else:
#                 QtWidgets.QMessageBox.warning(self, "Login Failed", "Incorrect username or password.")
#                 self.username_line_edit.clear()
#                 self.password_line_edit.clear()
#         except Exception as e:
#             QtWidgets.QMessageBox.critical(self, "Query Error", f"Failed to validate login:\n{e}")

#     def open_main_window(self):
#             self.close()
#             self.main_window = Ui_MainWindow()
#             self.main_window.setWindowTitle("Main Window")
#             self.main_window.show()


#     def open_sign_up(self):
#         self.close()
#         self.sign_up_window = SignUpWindow()
#         self.sign_up_window.setWindowTitle("Sign Up")
#         self.sign_up_window.show()

if __name__ == "__main__":

    app = QtWidgets.QApplication(sys.argv)
    window = SignInWindow()
    window.show()
    sys.exit(app.exec_())