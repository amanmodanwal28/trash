import sys
import paramiko
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QMessageBox
)
from PyQt5.QtCore import Qt

class SSHLineEdit(QLineEdit):
    def __init__(self, parent=None, ssh_terminal=None):
        super().__init__(parent)
        self.terminal = ssh_terminal

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Tab:
            self.terminal.handle_tab_autocomplete()
        else:
            super().keyPressEvent(event)

class SSHTerminal(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SSH Terminal - 192.168.0.8 (root)")
        self.setGeometry(100, 100, 700, 500)

        self.init_ui()
        self.connect_ssh()

    def init_ui(self):
        layout = QVBoxLayout()

        self.output_area = QTextEdit()
        self.output_area.setReadOnly(True)
        layout.addWidget(self.output_area)

        self.command_input = SSHLineEdit(ssh_terminal=self)
        self.command_input.setPlaceholderText("Enter command...")
        self.command_input.returnPressed.connect(self.execute_command)
        layout.addWidget(self.command_input)

        self.send_button = QPushButton("Send")
        self.send_button.clicked.connect(self.execute_command)
        layout.addWidget(self.send_button)

        self.setLayout(layout)

    def connect_ssh(self):
        try:
            self.ssh = paramiko.SSHClient()
            self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh.connect("192.168.0.8", username="root", password="", look_for_keys=False, allow_agent=False)
            self.current_dir = self.get_remote_pwd()
            self.append_output(f"[Connected to 192.168.0.8 as root]\nCurrent Dir: {self.current_dir}")
        except Exception as e:
            QMessageBox.critical(self, "SSH Connection Failed", str(e))
            sys.exit()

    def get_remote_pwd(self):
        stdin, stdout, stderr = self.ssh.exec_command("pwd")
        return stdout.read().decode().strip()

    def append_output(self, text):
        self.output_area.append(text)

    def execute_command(self):
        user_cmd = self.command_input.text().strip()
        if not user_cmd:
            return

        self.append_output(f"> {user_cmd}")

        if user_cmd.startswith("cd "):
            new_cmd = f"{user_cmd} && pwd"
            stdin, stdout, stderr = self.ssh.exec_command(f"cd {self.current_dir} && {new_cmd}")
            result = stdout.read().decode().strip()
            error = stderr.read().decode().strip()
            if result:
                self.current_dir = result
                self.append_output(f"Changed dir to: {self.current_dir}")
            elif error:
                self.append_output(error)
        else:
            full_cmd = f"cd {self.current_dir} && {user_cmd}"
            stdin, stdout, stderr = self.ssh.exec_command(full_cmd)
            output = stdout.read().decode()
            error = stderr.read().decode()
            self.append_output(output if output else error)

        self.command_input.clear()

    def handle_tab_autocomplete(self):
        current_text = self.command_input.text().strip()
        if not current_text:
            return

        parts = current_text.split()
        last_part = parts[-1] if parts else ""
        prefix = last_part

        stdin, stdout, stderr = self.ssh.exec_command(f"cd {self.current_dir} && ls")
        files = stdout.read().decode().split()
        matches = [f for f in files if f.startswith(prefix)]

        if len(matches) == 1:
            parts[-1] = matches[0]
            self.command_input.setText(" ".join(parts))
        elif len(matches) > 1:
            self.append_output(" ".join(matches))

    def closeEvent(self, event):
        try:
            self.ssh.close()
        except:
            pass
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SSHTerminal()
    window.show()
    sys.exit(app.exec_())
