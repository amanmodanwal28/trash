from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import pyqtSignal, QObject,QTimer,QThread
import threading
import socket
import os
import sqlite3
import sys
from datetime import datetime, timedelta
import struct
import time
import subprocess
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QMovie, QKeySequence
# from PyQt5.QtGui import QMovie
import paramiko as pm
import re
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtGui import QColor


# Constants
WINDOW_WIDTH = 280
WINDOW_HEIGHT = 300
INPUT_WIDTH = 300
INPUT_HEIGHT = 40
BUTTON_STYLE = "font:14px; background-color:#0095ff; color:white;border-radius: 10px;"
INPUT_STYLE = "border-radius:10px; padding:8px; font:16px"
LABEL_STYLE = "color: blue; font: 25px"
# Global variable


# Paths
# Get absolute path to the current file (ui.py)
current_dir = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.abspath(os.path.join(current_dir, '..', 'iot_enable.sqlite3'))

# Move two directories up, then into iot_ftp/static/logo.jpg
logo_path = os.path.abspath(os.path.join(current_dir, '..', 'iot_ftp', 'static', 'PPS_logo.png'))
server_storage = os.path.abspath(os.path.join(current_dir, '..','server_storage'))
selected_file_name =os.path.abspath(os.path.join(current_dir, '..', 'server_storage', 'selected_file_name.txt'))
uploading_folder = os.path.abspath(os.path.join(current_dir, '..', 'iot_ftp', 'media', 'uploaded_files'))
selected_ips = os.path.abspath(os.path.join(current_dir, '..', 'server_storage', 'selected_ips.txt'))


class CommandThread(QThread):
    # Signal to send data back to the main thread
    new_line = pyqtSignal(int, str)
    # getKeyBoardCommand = pyqtSignal(int)
    def __init__(self, command,ssh_client, parent=None):
        super().__init__(parent)
        self.command = command
        self.ssh_client = ssh_client

    def run(self):
        # Simulate executing the command and emitting the output line by line
        for index, line in enumerate(self.execute_command(self.command)):
            self.new_line.emit(index, line)  # Emit line to the main thread
        # self.getKeyBoardCommand.connect(self.command)

    def close_command(self):
        self.shell.close()



class AllowAllKeys(pm.MissingHostKeyPolicy):
    def missing_host_key(self, client, hostname, key):
        return

class CommandWorker(QObject):
    command_finished = pyqtSignal(str, int)
    # output_received = pyqtSignal(str)

    def __init__(self, ssh_client, dir_output, command):
        super().__init__()
        self.ssh_client = ssh_client
        self.dir_output = dir_output
        self.command = command

    def run(self):
        try:
            if self.ssh_client.get_transport().is_active():
                stdin, stdout, stderr = self.ssh_client.exec_command(f"cd {self.dir_output} {self.command}")
                exit_status = stdout.channel.recv_exit_status()
                result = stdout.read().decode('utf-8')
                # for line in self.stream_output(stdout):
                #     self.output_received.emit(line)
                self.command_finished.emit(result, exit_status)
            else:
                print("SSH session is not active")
        except Exception as e:
            print("error==========",e)


    # def stream_output(self, stdout):
    #     """
    #     A generator that reads the stdout line by line and yields each line.
    #     """
    #     for line in stdout:
    #         print('line======================',line)
    #         yield line

class Config:
    SERVER_HOST = '0.0.0.0'
    SERVER_PORT = 8010
    BUFFER_SIZE = 1024




class Working(QObject):
    # command_finished = pyqtSignal(str)
    # data_msg = pyqtSignal(tuple)
    # subprocess_command=pyqtSignal(object)
    def __init__(self,conn,cursor):
        super().__init__()
        self.connection=conn
        self.cursor=cursor
        # self.SERVER_HOST = '103.76.138.125' # Accept connections on any interface
        # self.SERVER_HOST = '192.168.0.206'
        self.SERVER_HOST = Config.SERVER_HOST
        self.SERVER_PORT = Config.SERVER_PORT
        self.BUFFER_SIZE = Config.BUFFER_SIZE
        


        self.clients = {}
        self.client_id_counter = 0
        self.lock = threading.Lock()
        self.checked_ip=None
        self.ip=[]
        self.last_insert_time = {}
        # self.run_django_server()

    def run(self):
        # Create a TCP/IP socket
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # Bind the socket to the address and port
        server_socket.bind((self.SERVER_HOST, self.SERVER_PORT))
        # Enable listening mode
        server_socket.listen(5)
        # global client_id_counter
        print(f"Server listening on {self.SERVER_HOST}:{self.SERVER_PORT}")
        try:
            while True:
                # Wait for incoming connections
                client_socket, client_address = server_socket.accept()
                # print(client_socket,client_address,"aaaaaaaaaaaaaaaaa")
                with self.lock:
                    self.client_id_counter += 1
                    client_id = self.client_id_counter
                # Create a new thread to handle the client
                client_thread = threading.Thread(target=self.handle_client, args=(client_socket, client_address,client_id))
                client_thread.start()
                # self.run_django_server()

        except KeyboardInterrupt:
            print("Server shutting down")

        except Exception as e:
            print(f"An error occurred: {e}")

    def send_file_from_web(self):
        self.header = bytes([0])
        # Read the file name and IP address
        with open(selected_ips, 'r') as file:
            self.selected_ip = file.read().strip()  # Ensure there are no extra spaces/newlines
            print("self.selected_ip===========", self.selected_ip)

        with open(selected_file_name, 'r') as file:
            self.file_name = file.read().strip()  # Ensure there are no extra spaces/newlines
            print("self.file_name===========", self.file_name)

        # Path to the file to be sent
        file_path = os.path.join(uploading_folder, self.file_name)
        print('serverui upload file_path',file_path)
        # Open the file and prepare to send
        with open(file_path, 'rb') as file:
            file_data = file.read()
            file_size = len(file_data)

            # clients[selected_ip].sendall(header)

            # Send the file name length first
            self.clients[self.selected_ip].sendall(self.header)
            file_name_encoded = self.file_name.encode('utf-8')
            file_name_length = len(file_name_encoded)
            self.clients[self.selected_ip].sendall(struct.pack('!I', file_name_length))
            print(f"File name length ({file_name_length} bytes) sent successfully")

            # Send the file name
            self.clients[self.selected_ip].sendall(file_name_encoded)
            print(f"File name ({self.file_name}) sent successfully")

            # Send the file size
            self.clients[self.selected_ip].sendall(struct.pack('!Q', file_size))
            print("File size sent successfully")
            # Send the file data in chunks
            chunk_size = 1048576
            for i in range(0, file_size, chunk_size):
                # print('file_data[i:i+chunk_size]=====',len(file_data[i:i+chunk_size]))
                self.clients[self.selected_ip].sendall(file_data[i:i+chunk_size])
            print("File data sent successfully")


    def send_file_from_ui(self,selected_ip,file_path,file_name):
        # Check if the file exists
        print("📡 Available clients:", self.clients.keys())      # ✅ Line 1
        print("🎯 Trying to access client:", selected_ip)         # ✅ Line 2
        self.header = bytes([0])
        # print("hellololoolo=====================================",file_path)
        # if not os.path.isfile(file_path):
        #     print(f"File {file_path} does not exist.")
        #     return

        # Open the file and prepare to send
        with open(file_path, 'rb') as file:
            file_data = file.read()
            print("file_data===",  file_data)
            file_size = len(file_data)
            # Send the file name length first
            print("selected_ip======228", selected_ip)
            self.clients[selected_ip].sendall(self.header)
            file_name_encoded = file_name.encode('utf-8')
            print("file_name_encoded========", file_name_encoded)
            file_name_length = len(file_name_encoded)
            self.clients[selected_ip].sendall(struct.pack('!I', file_name_length))
            print(f"File name length ({file_name_length} bytes) sent successfully")

            # Send the file name
            self.clients[selected_ip].sendall(file_name_encoded)
            print(f"File name ({file_name}) sent successfully")

            # Send the file size
            self.clients[selected_ip].sendall(struct.pack('!Q', file_size))
            print("File size sent successfully")

            # Send the file data in chunks
            chunk_size = 1048576
            for i in range(0, file_size, chunk_size):
                # print('file_data[i:i+chunk_size]=====',len(file_data[i:i+chunk_size]))
                self.clients[selected_ip].sendall(file_data[i:i+chunk_size])
            header = self.clients[selected_ip].recv(1)
            print("File data recieved successfully ========== ",header)



    def handle_client(self, client_socket, client_address, client_id):
        client_ip = client_address[0]
        with self.lock:
            self.clients[client_ip] = client_socket
        # print(f"[+] Accepted connection from {client_address}")

        try:
            header = client_socket.recv(1)
            print("header===================",header)
            if not header:
                print("[!] Client disconnected before sending data_type.")
                return

            data_type = int(header[0])
            self.connection.execute('PRAGMA busy_timeout = 3000')

            if data_type == 0:
                self.send_file_from_web()

            elif data_type == 3:
                try:
                    with open(selected_ips, 'r') as file:
                        selected_ip = file.read().strip()
                    if selected_ip in self.clients:
                        self.clients[selected_ip].sendall(bytes([3]))
                        print(f"[→] Trigger sent to selected IP: {selected_ip}")
                    else:
                        print(f"[!] Selected IP {selected_ip} not connected.")
                except FileNotFoundError:
                    print("[!] File selected_ips.txt not found.")

            elif data_type == 4:
                confirmation_data = client_socket.recv(1024)
                if confirmation_data:
                    print(f"[✔] Confirmation received: {confirmation_data.decode('utf-8')}")
                else:
                    print("[!] No confirmation received or client disconnected.")

            elif data_type == 2:
                buffer = ""
                while True:
                    try:
                        data = client_socket.recv(1024).decode()
                        if not data:
                            print("[x] Client disconnected during data transmission.")
                            break

                        if len(data) < 43:
                            print(f"[!] Invalid data received: {data}")
                            continue

                        # Parse device type
                        device_type = {
                            '01': 'MPU',
                            '02': 'ICOME',
                            '03': 'EBTU'
                        }.get(data[1:3], 'None')

                        serial_number = data[3:11]
                        software_version = data[11:15]
                        connected_device = data[15:23]
                        train_id = data[22:30]
                        coach_id = data[30:38]
                        train_number = data[38:46]

                        # Health status
                        zero_count = connected_device.count('0')
                        status = 'Unhealthy' if 4 < zero_count < 8 else 'Healthy'
                        formatted_time = datetime.now().strftime('%H:%M:%S')

                        insert_query = '''
                            INSERT INTO iot_ftp_status
                            (ip, port, status, client_id, status_date, type, serial_number, version, connected_devices, train_id, coach_id, train_number)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        '''
                        data_tuple = (
                            client_ip, client_address[1], status, client_id, formatted_time,
                            device_type, serial_number, software_version,
                            connected_device, train_id, coach_id, train_number
                        )

                        # print("[→] Inserting data:", data_tuple)
                        self.execute_query_with_retry(insert_query, data_tuple)

                        # Keep only last 50 entries
                        delete_query = '''
                            DELETE FROM iot_ftp_status
                            WHERE id NOT IN (SELECT id FROM iot_ftp_status ORDER BY id DESC LIMIT 50)
                        '''
                        self.execute_query_with_retry(delete_query)

                    except UnicodeDecodeError:
                        print("[!] Error decoding received data.")
                    except Exception as e:
                        print(f"[!] Error processing data: {e}")
                        break

        except Exception as e:
            print(f"[!!] Error in handle_client: {e}")

        finally:
            with self.lock:
                if client_ip in self.clients:
                    del self.clients[client_ip]
            client_socket.close()
            print(f"[-] Connection closed: {client_ip}")



    def execute_query_with_retry(self, query, data=None, max_retries=5, base_delay=0.1):
        retries = 0
        while retries < max_retries:
            try:
                cursor = self.connection.cursor()
                if data:
                    cursor.execute(query, data)
                else:
                    cursor.execute(query)
                self.connection.commit()  # Explicit commit here
                cursor.close()
                return
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e):
                    time.sleep(base_delay * (2 ** retries))
                    retries += 1
                else:
                    raise
            except Exception as e:
                print(f"[!!] Query failed: {e}")
                raise
        raise sqlite3.OperationalError(f"Max retries exceeded for query: {query}")




class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        # self.close()
        self.setupUi(self)

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        # MainWindow.resize(1366, 768)
        # self.setWindowTitle("PT Communication")
        self.setWindowIcon(QtGui.QIcon(logo_path))
        self.setGeometry(100, 100, 800, 600)  # Initial size and position
        self.showMaximized()

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.centralwidget.setStyleSheet("background-color: black;")

        self.main_ver_Layout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.main_ver_Layout.setContentsMargins(20, 20, 20, 20)
        self.main_ver_Layout.setObjectName("main_ver_Layout")

        # self.main_ver_Layout_QtWidgets = QtWidgets.QWidget()
        # self.main_ver_Layout_QtWidgets.setLayout(self.main_ver_Layout)
        # self.main_ver_Layout_QtWidgets.setStyleSheet("background-color: lightblue;")

        self.main_hori_Layout = QtWidgets.QHBoxLayout()
        # self.main_hori_Layout.setContentsMargins(20, 20, 20, 20)
        self.main_hori_Layout.setObjectName("main_hori_Layout")

        # self.container_widget_main_hori_Layout = QtWidgets.QWidget()
        # self.container_widget_main_hori_Layout.setLayout(self.main_hori_Layout)
        # self.container_widget_main_hori_Layout.setStyleSheet("background-color: grey;")


        self.horizontalLayout_header = QtWidgets.QHBoxLayout()   #header
        self.horizontalLayout_header.setContentsMargins(20, 20, 20, 20)
        self.horizontalLayout_header.setObjectName("horizontalLayout_header")
        self.container_widget_horizontalLayout_header = QtWidgets.QWidget(self.centralwidget)
        self.container_widget_horizontalLayout_header.setLayout(self.horizontalLayout_header)
        self.container_widget_horizontalLayout_header.setStyleSheet("background-color: lightgrey;")
        # self.container_widget_horizontalLayout_header.setStyleSheet(
        #     """
        #     QWidget {
        #         border: 2px solid black;
        #         border-radius: 5px;
        #         background-color: lightblue;
        #     }
        #     """
        # )
        self.connected_devices_num = QtWidgets.QLabel()
        self.connected_devices_num.setStyleSheet("font-weight: bold; font: 16px; color: green")
        self.Connected_devices = QtWidgets.QLabel("Active Devices :")
        self.Connected_devices.setStyleSheet("font-weight: bold; font: 16px; color: green")



        self.button_lineedit_layout = QtWidgets.QHBoxLayout()
        self.button_lineedit_layout.setObjectName("button_lineedit_layout")


        # self.horizontalLayout_header.addWidget(self.execute_button,alignment=QtCore.Qt.AlignRight)

        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 20, 251, 31))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.horizontalLayout_header.addWidget(self.label)
        spacer1 = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_header.addItem(spacer1)
        spacer2 = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_header.addItem(spacer2)

        self.dropdown = QtWidgets.QComboBox(self)
        self.dropdown.setCurrentIndex(0)
        self.dropdown.setFixedSize(150, 24)
        self.dropdown.addItems(["Filter", "Healthy", "Unhealthy"])
        self.dropdown.setStyleSheet("font-weight: bold;")
        self.dropdown.currentIndexChanged.connect(self.on_selection_change)
        self.horizontalLayout_header.addWidget(self.dropdown)
        self.horizontalLayout_header.addWidget(self.dropdown,alignment=QtCore.Qt.AlignRight)
        # self.console_button=QtWidgets.QPushButton("Console")
        # # self.console_button.setGeometry(10,10,10,10)
        # self.console_button.setStyleSheet("background-color: lightgrey; font-weight: bold;")
        # self.horizontalLayout_header.addWidget(self.console_button,alignment=QtCore.Qt.AlignRight)

        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        # self.tableWidget.cellClicked.connect(self.get_row_data)
        self.tableWidget.setStyleSheet("""
        QTableWidget {
            background-color: lightgrey;
            gridline-color: black;
        }

       QHeaderView::section {
        background-color: rgb(175, 175, 0) ;
        font-weight: bold;
        color: white;

     }
        QTableWidget::item {
            text-align: center;
            font: 12px;
        }
    """)
        # self.tableWidget.setGeometry(QtCore.QRect(30, 70, 200, 100))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(10)
        self.tableWidget.setRowCount(1)

        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, item)

        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(6, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(7, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(8, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(9, item)
        # item = QtWidgets.QTableWidgetItem()
        self.tableWidget.verticalHeader().setVisible(True)
        self.tableWidget.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        MainWindow.setCentralWidget(self.centralwidget)

        self.main_hori_Layout.addWidget(self.tableWidget)
        self.main_ver_Layout.addWidget(self.container_widget_horizontalLayout_header)
        self.main_ver_Layout.addLayout(self.main_hori_Layout)

        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)


        # self.db_path = os.path.join(os.getcwd(), "iot_enable.sqlite3")

        self.db_path = db_path
        self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cursor = self.connection.cursor()

        self.cursor2=None
        self.previous_time = {}

        self.start_server()  #
        # self.get_total_devices()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.show_data)
        self.timer.start(1000)

        # self.get_active_devices_timer = QTimer(self)
        # self.get_active_devices_timer.timeout.connect(self.get_total_devices)
        # self.get_active_devices_timer.start(1000)


        self.terminalInputLine = None
        self.consol_dir_label = None
        self.consol_label_output = None
        self.execute_button = None
        self.container_widget_consol_Layout = None
        self.dir_output=None
        self.main_dir_list=[]
        # self.console_button.clicked.connect(self.console)
        self.selected_option = None
        self.commands = ("cd", "ls", "mkdir","pwd","cat","rm", "cp","mv","touch","chmod","nano")
        # self.movie = QMovie("D:\\machine_learning\\iot_enable_remote_control\\iot_enable_ftp\\g0R5.gif")
        # self.tableWidget.cellClicked.connect(self.upload_file)
        # self.setFocusPolicy(Qt.StrongFocus)
        self.auth_flag=True

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        bold_font = QFont()
        bold_font.setBold(True)

        MainWindow.setWindowTitle(_translate("MainWindow", "jjjjjj"))
        self.label.setText(_translate("MainWindow", "Devices Information"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Train ID"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Coach ID"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Train Number"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "Device Serial Number"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "Main Device"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "Status"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "Time"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "Detail"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "Upload File"))
        item.setFont(bold_font)
        item = self.tableWidget.horizontalHeaderItem(9)
        item.setText(_translate("MainWindow", "Console"))
        item.setFont(bold_font)

        # item = self.tableWidget.horizontalHeaderItem(4)
        # item.setText(_translate("MainWindow", "detail"))

    '''def keyPressEvent(self, event):
        if event.key() == Qt.Key_Control:
            self.terminalInputLine.clearFocus()
        if event.key() ==  Qt.Key_Return:
            self.execute_command_line()
        elif event.key() == Qt.Key_C and event.modifiers() == Qt.ControlModifier:
            if self.thread3:
                self.thread3.close_command()
        super(Ui_MainWindow, self).keyPressEvent(event)'''

    def keyPressEvent(self, event):
            # Only act if return or Ctrl+C is pressed
        if event.key() == Qt.Key_Return:
            self.execute_command_line()
            return

        elif event.key() == Qt.Key_C and event.modifiers() == Qt.ControlModifier:
            if self.thread3:
                self.thread3.close_command()
            return

        # Let all other keys (like Ctrl+V, Ctrl+X, Ctrl+A) go to the focused widget
        super(Ui_MainWindow, self).keyPressEvent(event)


    def start_server(self):
        self.worker1 = Working(self.connection,self.cursor)
        self.thread1 = threading.Thread(target=self.worker1.run)
        # self.worker.data_msg.connect(self.show_data)
        self.thread1.start()

    # def get_total_devices(self):
    #     query='select count(distinct(ip)) from iot_ftp_status'
    #     self.cursor.execute(query)
    #     self.data = self.cursor.fetchall()[0][0]
    #     text = f"{self.data}"
    #     self.connected_devices_num.setText(text)
    #     self.horizontalLayout_header.insertWidget(2,self.Connected_devices)
    #     self.horizontalLayout_header.insertWidget(3,self.connected_devices_num)

    def show_data(self):
        if self.cursor2:
            self.cursor2.close()

        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cursor2 = self.conn.cursor()

        # 🔁 Group by IP instead of serial_number
        query = '''
            SELECT train_id, coach_id, train_number, serial_number, type, status, status_date, connected_devices, ip
            FROM iot_ftp_status
            WHERE id IN (
                SELECT MAX(id)
                FROM iot_ftp_status
                GROUP BY ip
            )
        '''
        params = ()
        if self.selected_option is not None:
            query += ' AND status = ?'
            params = (self.selected_option,)

        # Retry logic for SELECT query
        retries = 5
        base_delay = 0.1
        while retries > 0:
            try:
                if params:
                    self.cursor2.execute(query, params)
                else:
                    self.cursor2.execute(query)
                self.data = self.cursor2.fetchall()
                # print('self.data====================', self.data)
                break
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e):
                    time.sleep(base_delay * (2 ** (5 - retries)))
                    retries -= 1
                else:
                    raise
            except Exception as e:
                print(f"[!] Error fetching data: {e}")
                retries -= 1
                time.sleep(0.5)

        self.tableWidget.setRowCount(0)  # Clear table

        if self.previous_time != {}:
            for row_num, row_data in enumerate(self.data):
                self.tableWidget.insertRow(row_num)
                for col_num, col_data in enumerate(row_data):
                    if row_data[8] in self.previous_time and self.previous_time[row_data[8]] == row_data[6]:  # ⬅ based on IP now
                        self.tableWidget.removeRow(row_num)
                        break
                    else:
                        self.tableWidget.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))
                        item = self.tableWidget.item(row_num, col_num)
                        if item is not None:
                            item.setTextAlignment(Qt.AlignCenter)

                self.previous_time[row_data[8]] = row_data[6]  # based on IP
                row_count = self.tableWidget.rowCount()
                self.connected_devices_num.setText(str(row_count))
                self.horizontalLayout_header.insertWidget(2, self.Connected_devices)
                self.horizontalLayout_header.insertWidget(3, self.connected_devices_num)

                self.button = QtWidgets.QPushButton("Detail")
                self.button.setStyleSheet('background-color:lightgrey;font-weight: bold;')

                upload = QtWidgets.QPushButton("Upload")
                upload.setStyleSheet('background-color:lightgrey;font-weight: bold;')

                self.console_button = QtWidgets.QPushButton("Console")
                self.console_button.setStyleSheet("background-color: lightgrey; font-weight: bold;")

                self.button.clicked.connect(self.detail_view)
                upload.clicked.connect(self.upload_file)
                self.console_button.clicked.connect(self.authentication)

                self.button.setProperty("row", row_num)
                upload.setProperty("row", row_num)
                self.console_button.setProperty("row", row_num)

                self.tableWidget.setCellWidget(row_num, 7, self.button)
                self.tableWidget.setCellWidget(row_num, 8, upload)
                self.tableWidget.setCellWidget(row_num, 9, self.console_button)

        else:
            for row_num, row_data in enumerate(self.data):
                self.tableWidget.insertRow(row_num)
                for col_num, col_data in enumerate(row_data):
                    self.tableWidget.setItem(row_num, col_num, QtWidgets.QTableWidgetItem(str(col_data)))
                    item = self.tableWidget.item(row_num, col_num)
                    if item is not None:
                        item.setTextAlignment(Qt.AlignCenter)

                self.previous_time[row_data[8]] = row_data[6]  # based on IP

                self.button = QtWidgets.QPushButton("Detail")
                self.button.setStyleSheet('background-color:lightgrey;font-weight: bold;')

                upload = QtWidgets.QPushButton("Upload")
                upload.setStyleSheet('background-color:lightgrey;font-weight: bold;')

                self.console_button = QtWidgets.QPushButton("Console")
                self.console_button.setStyleSheet("background-color: lightgrey; font-weight: bold;")

                self.button.clicked.connect(self.detail_view)
                upload.clicked.connect(self.upload_file)
                self.console_button.clicked.connect(self.authentication)

                self.button.setProperty("row", row_num)
                upload.setProperty("row", row_num)
                self.console_button.setProperty("row", row_num)

                self.tableWidget.setCellWidget(row_num, 4, self.button)
                self.tableWidget.setCellWidget(row_num, 5, upload)
                self.tableWidget.setCellWidget(row_num, 6, self.console_button)



    def on_selection_change(self):
        self.selected_option = self.dropdown.currentText()
        if self.selected_option == "Filter":
            self.selected_option = None

    def detail_view(self):
        # Create the dialog
        detail_dialog = QtWidgets.QDialog(self)
        detail_dialog.setStyleSheet("background-color:lightgrey;")
        detail_dialog.setWindowTitle("Detail View")
        detail_dialog.setGeometry(100, 250, 200, 230)  # Adjusted size for better fit
        detail_dialog.setWindowFlags(detail_dialog.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)
        qr = detail_dialog.frameGeometry()
        cp = QtWidgets.QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        detail_dialog.move(qr.topLeft())
        # Create a vertical layout
        layout = QtWidgets.QVBoxLayout()
        # Create and set a label for the title
        title_label = QtWidgets.QLabel("Detail View")
        title_label.setAlignment(QtCore.Qt.AlignLeft)
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
        layout.addWidget(title_label)
        # print("==================",self.button.pos())
        # print("=====================================",self.button.rect())
        # button_pos = self.button.mapToGlobal(self.button.rect().topRight())
        # button_pos = self.button.rect()
        # detail_dialog.move(button_pos.x(), button_pos.y() + 50)

        # Set dialog's position based on the button's position
        # detail_dialog.move(button_pos)

        button = self.sender()
        if button:
            row = button.property("row")
            row_data = self.data[row]
        # print("raw_data====",row_data)
        data = row_data[-2]
        print("show data@@@@@@@@@@@@@@@@@@@@@@@@=========",data)
        data = [data[i:i+2] for i in range(0, len(data), 2)]
        print("=============================",data)

        # Initialize status variables
        LED  =  'Unhealthy'
        LCD  =  'Unhealthy'
        ETBU =  'Unhealthy'
        EPB  =  'Unhealthy'

        # Set status based on data
        if data:
            if '06' in data:
                LED = 'Healthy'
            if '07' in data:
                LCD = 'Healthy'
            if '08' in data:
                ETBU = 'Healthy'
            if '09' in data:
                EPB = 'Healthy'

        # Create and set labels for each status
        led_label = QtWidgets.QLabel(f"<b>LED:</b> {LED}")
        lcd_label = QtWidgets.QLabel(f"<b>LCD:</b> {LCD}")
        etbu_label = QtWidgets.QLabel(f"<b>ETBU:</b> {ETBU}")
        epb_label = QtWidgets.QLabel(f"<b>EPB:</b> {EPB}")

        # Style each label
        status_style = "font-size: 14px; color: #34495e; margin: 10px;"
        healthy_style = "color: green;"  # Green
        unhealthy_style = "color: #e74c3c;"  # Red

        led_label.setStyleSheet(status_style + (healthy_style if LED == 'Healthy' else unhealthy_style))
        lcd_label.setStyleSheet(status_style + (healthy_style if LCD == 'Healthy' else unhealthy_style))
        etbu_label.setStyleSheet(status_style + (healthy_style if ETBU == 'Healthy' else unhealthy_style))
        epb_label.setStyleSheet(status_style + (healthy_style if EPB == 'Healthy' else unhealthy_style))

        # Add status labels to the layout
        layout.addWidget(led_label)
        layout.addWidget(lcd_label)
        layout.addWidget(etbu_label)
        layout.addWidget(epb_label)
        # Add spacing and adjust layout
        layout.addStretch()
        # Set the layout for the dialog
        detail_dialog.setLayout(layout)

        # Show the dialog
        detail_dialog.exec_()

    def upload_file(self):
        button = self.sender()
        if button:
            row = button.property("row")
            row_data = self.data[row]

            print('row_data=====================',row_data)
            # print('row_data=====================',row_data,row_data[-1])

        options = QtWidgets.QFileDialog.Options()
        options |= QtWidgets.QFileDialog.ReadOnly
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "", "All Files (*);;Text Files (*.txt)", options=options)
        # print(file_path)
        if not os.path.isfile(file_path):
            print(f"File {file_path} does not exist.")
        else:
            file_name = file_path.split("/")[-1]
            print('row_data811=====================',row_data[-1])
            print("file_path======812", file_path)
            print("file_name813=============",file_name)
            self.worker1.send_file_from_ui(row_data[-1],file_path,file_name)
            # label=QtWidgets.QLabel("File send Successfully")
            # self.horizontalLayout_header.insertWidget(3,label)
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Information)
            msg.setWindowTitle("File Status")
            msg.setText("File send Successfully")
            msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
            msg.exec_()


    def on_command_finished(self, result, exit_status):
        # print(result)
        # Stop the GIF
        # self.movie.stop()
        # self.consol_label_output.setMovie(None)
        # self.consol_label_output.clear()
        self.consol_label_output.setText(result)
        if exit_status == 0:
            print(f"Command executed successfully:{exit_status}")
        else:
            print("Command failed with error")

        # Clean up the worker and thread
        self.worker2 = None
        self.thread2.quit()
        self.thread2.wait()
        self.thread2 = None

        # Update UI or return the result
        # print('result==================',result)
        # return result

    def execute_command_line(self):

        """Triggered when Execute button is clicked or Enter pressed"""
        command = self.terminalInputLine.text().strip()
        if not command:
            return

        # Store command so handle_shell can use it
        self.lastCommand = command

        # Clear input box
        self.terminalInputLine.clear()
        
        
        self.flag= False
        # Connect to the SSH server
        try:
            if command.startswith(self.commands):
                print(f"[DEBUG] Command matched from list: {command}")
                self.consol_label_output.clear()
                # print("if condition===================")
                # self.execute_command(command)
            else:
                print(f"[DEBUG] Running general command: {command}")
                # print("hellololol==============")
                self.consol_label_output.clear()
                self.run_command(f"{command}")


        except Exception as e:
            print(f"Failed to connect or execute commands: {e}")

        # Close the connection
        finally:
            self.terminalInputLine.clear()

    def run_command(self, command):
        # Create the worker thread
        self.thread3 = CommandThread(command,self.ssh_client)
        self.thread3.new_line.connect(self.update_output)  # Connect signal to update function
        self.thread3.start()

    def update_output(self, index, line):
        # print(f"Received line {index}: {line}")
        if index == 0:
            pass
        elif index == 1:
            pass
        elif self.flag is not True:
            current_text = self.consol_label_output.text() + line + '\n'
            self.consol_label_output.setText(current_text)

    def authentication(self):
        # print("auth_flag==================")
        if self.auth_flag:
            # Get the sender button and row data
            button = self.sender()
            ip_placeholder = "8000"  # Default fallback
            if button:
                row = button.property("row")
                if self.data and row is not None:
                    try:
                        ip_placeholder = self.data[row][-1]  # IP is the last column
                    except IndexError:
                        pass

            self.auth_dialog = QtWidgets.QDialog(self)
            self.auth_dialog.setStyleSheet("background-color:lightgrey;margin:3px;")
            self.auth_dialog.setWindowTitle("Authentication")
            self.auth_dialog.setGeometry(100, 250, 300, 150)
            self.auth_dialog.setWindowFlags(self.auth_dialog.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)

            qr = self.auth_dialog.frameGeometry()
            cp = QtWidgets.QDesktopWidget().availableGeometry().center()
            qr.moveCenter(cp)
            self.auth_dialog.move(qr.topLeft())

            layout = QtWidgets.QVBoxLayout()
            title_label = QtWidgets.QLabel("Fill information")
            title_label.setAlignment(QtCore.Qt.AlignCenter)
            title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")

            terminal_port_label = QtWidgets.QLabel("Port : ")
            terminal_port_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
            self.terminal_port_input = QtWidgets.QLineEdit()
            self.terminal_port_input.setPlaceholderText(ip_placeholder)
            self.terminal_port_input.setStyleSheet("background-color:white; border-radius:10px; padding:8px;font:16px")


            submit_button = QtWidgets.QPushButton("Submit")
            submit_button.setFixedSize(300, 40)
            submit_button.setStyleSheet("font:14px; background-color:#0095ff; color:white;border-radius: 10px;")

            layout.addWidget(title_label)
            layout.addSpacing(10)
            layout.addWidget(terminal_port_label)
            layout.addWidget(self.terminal_port_input)

            layout.addSpacing(10)
            layout.addWidget(submit_button)

            submit_button.clicked.connect(self.console)
            layout.addStretch()

            self.auth_dialog.setLayout(layout)
            self.auth_dialog.exec_()
        else:
            self.console()




    def console(self):
        self.port_name_input= self.terminal_port_input.text()
        self.auth_dialog.close()
        self.flag = True
        
        # print("Host:", Config.SERVER_HOST)
        # print("Buffer Size:", Config.BUFFER_SIZE)
        # print("self.hostname Size:", self.port_name_input)

        if self.port_name_input.strip() != '' :
            # print("hello")
            # Start server thread only if port_name_input is filled
            
            if self.consol_dir_label is None:
                self.auth_flag=False
                try:
                    # self.dir_output = self.execute_command('pwd')
                    self.dir_output = 'Running please wait...'
                except Exception as e:
                    print(f"Failed to connect or execute commands: {e}")
                self.console_button.setText("Back")
                # Create the main vertical layout
                self.consol_Layout = QtWidgets.QVBoxLayout(self.centralwidget)
                self.consol_Layout.setObjectName("consol_Layout")

                # Create a container widget for the layout
                self.container_widget_consol_Layout = QtWidgets.QWidget()
                self.container_widget_consol_Layout.setLayout(self.consol_Layout)
                self.container_widget_consol_Layout.setStyleSheet("""
                    QWidget {
                        background-color: grey;
                    }
                """)
                # Add the console_dir_label
                self.consol_dir_label = QtWidgets.QLabel(self.centralwidget)
                self.consol_dir_label.setText(self.dir_output) ####set directory
                self.consol_dir_label.setStyleSheet('background-color:black; color:white; font-size: 14px;')
                self.consol_dir_label.setContentsMargins(10, 12, 0, 0)
                self.consol_dir_label.setFixedSize(640, 50)
                self.consol_Layout.addWidget(self.consol_dir_label)

                # Add the console_label_output
                self.consol_label_output = QtWidgets.QLabel(self.centralwidget)
                self.consol_label_output.setWordWrap(True)
                self.consol_label_output.setStyleSheet('background-color:black; color:white; font-size: 12px;')
                self.consol_label_output.setContentsMargins(10, 10, 10, 10)
                self.consol_label_output.setAlignment(Qt.AlignTop)

                # Create a QScrollArea and set the QLabel as its widget
                self.scroll_area = QtWidgets.QScrollArea(self.centralwidget)
                self.scroll_area.setWidget(self.consol_label_output)
                self.scroll_area.setWidgetResizable(True)
                self.scroll_area.setFixedSize(640, 400)
                self.scroll_area.setStyleSheet('background-color:black;')

                # Add the scroll area to the layout
                self.consol_Layout.addWidget(self.scroll_area)

                # Add terminalInputLine and execute_button
                self.terminalInputLine = QtWidgets.QLineEdit(self.centralwidget)
                self.terminalInputLine.setFixedSize(560, 50)
                self.terminalInputLine.setStyleSheet("background-color: black;color: white; font-size: 12px;")
                self.terminalInputLine.setTextMargins(10, 0, 0, 0)
                

                self.execute_button = QtWidgets.QPushButton("Execute")
                self.execute_button.setFixedSize(75, 50)
                self.execute_button.setStyleSheet("background-color: lightgrey;color: black; font-weight: bold;")
                self.execute_button.clicked.connect(self.execute_command_line)

                # Create a horizontal layout for the line edit and button
                self.button_lineedit_layout = QtWidgets.QHBoxLayout()
                self.button_lineedit_layout.addWidget(self.terminalInputLine)
                self.button_lineedit_layout.addWidget(self.execute_button)

                # Add the line edit and button layout to the main console layout
                self.consol_Layout.addLayout(self.button_lineedit_layout)

                # Add the consol_Layout to the main layout
                self.main_hori_Layout.addWidget(self.container_widget_consol_Layout)
            else:
                self.auth_flag=True
                # Clean up the worker and thread
                self.worker2 = None
                # Remove console_dir_label
                self.console_button.setText("Console")
                self.consol_Layout.removeWidget(self.consol_dir_label)
                self.consol_dir_label.deleteLater()  # Properly delete the widget
                self.consol_dir_label = None

                # Remove console_label_output
                self.consol_Layout.removeWidget(self.consol_label_output)
                self.consol_label_output.deleteLater()  # Properly delete the widget
                self.consol_label_output = None

                # Remove terminalInputLine
                self.button_lineedit_layout.removeWidget(self.terminalInputLine)
                self.terminalInputLine.deleteLater()  # Properly delete the widget
                self.terminalInputLine = None

                # Remove execute_button
                self.button_lineedit_layout.removeWidget(self.execute_button)
                self.execute_button.deleteLater()  # Properly delete the button
                self.execute_button = None

                # Remove button_lineedit_layout layout from consol_Layout
                self.consol_Layout.removeItem(self.button_lineedit_layout)
                # self.consol_Layout.removeWidget(self.container_widget_consol_Layout)

                # Remove the container widget from the main layout
                self.main_hori_Layout.removeWidget(self.container_widget_consol_Layout)
                self.container_widget_consol_Layout.deleteLater()
                self.container_widget_consol_Layout = None
       
            threading.Thread(target=self.terminal_start_server, args=(self.port_name_input, self.handle_shell, "Shell"), daemon=True).start()

       
        else:
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Information)
            msg.setWindowTitle("Informartion")
            msg.setText("Fill the credential")
            msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
            msg.exec_()
            


    def handle_shell(self, conn, addr):
        """Handle shell commands from operator on port 8020"""
        self.conn = conn
        print(f"[+] Shell connected from {addr}")

        try:
            
            # --- ✅ Step 1: get initial working directory ---
            conn.send(bytes([5]) + b"pwd")
            data = conn.recv(4096)
            if data:
                header = data[0]
                payload = data[1:]
                if header == 6:
                    self.dir_output = payload.decode(errors="ignore").strip()
                    self.consol_dir_label.setText(self.dir_output)
                    print(f"[Init PWD] {self.dir_output}")
            
            
            
            # --- ✅ Step 2: normal shell loop ---
            while True:
                # Don't use input() – wait for GUI commands
                if hasattr(self, "lastCommand") and self.lastCommand:
                    cmd = self.lastCommand.strip()
                    self.lastCommand = None  # reset after using
                    print(f"[Shell] Got from GUI: {cmd}")

                    # --- ✅ Check against allowed commands ---
                    base_cmd = cmd.split()[0]  # check only first word (ls -l → ls)
                    if base_cmd not in self.commands:
                        formatted_output = "Command not found . Please enter a valid command."
                        print(formatted_output)
                        self.consol_label_output.setText(
                            self.consol_label_output.text() + "\n" + formatted_output
                        )
                        continue  # skip sending to client
                    
                    
                        # --- ✅ Special handling for cd ---
                    if cmd.startswith("cd "):
                        conn.send(bytes([5]) + cmd.encode()  + b" && pwd")

                        data = conn.recv(4096)
                        if data:
                            header = data[0]
                            payload = data[1:]
                            if header == 6:
                                shell_output = payload.decode(errors="ignore").strip()

                                # check  "No such file" error found or not 
                                if "No such file" in shell_output or "not found" in shell_output:
                                    # Filter clean error message only show path part
                                    clean_error = shell_output.split("cd:")[-1].strip()
                                    error_msg = f"{clean_error}"
                                    # print(error_msg)
                                    self.consol_label_output.setText(
                                        self.consol_label_output.text() + "\n" + error_msg
                                    )

                                    # --- ✅ 2 sec delay ke baad redirect to /home/ptcs ---
                                    def delayed_redirect():
                                        time.sleep(1)
                                        self.consol_label_output.setText( "")
                                        conn.send(bytes([5]) + b"pwd")
                                        new_data = conn.recv(4096)
                                        if new_data:
                                            header2 = new_data[0]
                                            payload2 = new_data[1:]
                                            if header2 == 6:
                                                safe_path = payload2.decode(errors="ignore").strip()
                                                self.dir_output = safe_path
                                                self.consol_dir_label.setText(self.dir_output)
                                                print(f"[Redirected Dir] {self.dir_output}")

                                    threading.Thread(target=delayed_redirect, daemon=True).start()

                                else:
                                    # directory change successful
                                    self.dir_output = shell_output
                                    self.consol_dir_label.setText(self.dir_output)
                        continue


                    # --- ✅ Send allowed command to client ---
                    conn.send(bytes([5])+ f"cd {self.dir_output} && {cmd}".encode())

                    if cmd.lower() in ["exit", "quit"]:
                        conn.close()
                        break

                    # Read response
                    data = conn.recv(4096)
                    if not data:
                        break

                    header = data[0]
                    payload = data[1:]

                    if header == 6:  # Shell output
                        output = payload.decode(errors="ignore").strip()
                        print(output)  # also print in terminal
                        print(f"[Updated Dir2] {self.dir_output}")
                        if output:  # only append if non-empty
                            self.consol_label_output.setText(
                                self.consol_label_output.text() + "\n" + output
                            )
                    else:
                        print(f"[UNKNOWN SHELL {addr}] {payload}")

        except Exception as e:
            print(f"[-] Shell error: {e}")
        finally:
            conn.close()
            self.conn = None
            print("[-] Connection closed")




    def terminal_start_server(self,port, handler, name):
        """Start a server on given port with given handler"""
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("0.0.0.0", int(port)))
        # print(f"[*] Binding to port {port}")
        server.listen(5)
        print(f"[*] {name} listening on 0.0.0.0:{port}...")

        while True:
            conn, addr = server.accept()
            thread = threading.Thread(target=handler, args=(conn, addr), daemon=True)
            thread.start()






# ---- Shared Helpers ----
def connect_to_database():
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        return conn, cursor
    except Exception as e:
        QtWidgets.QMessageBox.critical(None, "Database Error", f"Failed to connect to database:\n{e}")
        return None, None


def switch_to_login(current_widget):
    current_widget.close()
    login_window = SignInWindow()
    login_window.setWindowTitle("Log In")
    login_window.show()


# ---- SignUpWindow ----
class SignUpWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.conn, self.cursor = connect_to_database()

        self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
        screen_geometry = QtWidgets.QDesktopWidget().screenGeometry()
        x = int(screen_geometry.width() / 2 - WINDOW_WIDTH)
        self.setGeometry(x, 120, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setWindowTitle("PT Communication")
        self.setWindowIcon(QtGui.QIcon(logo_path))

        self.setup_ui()

    def setup_ui(self):
        self.setContentsMargins(20, 0, 20, 20)
        layout = QtWidgets.QVBoxLayout()

        label = QtWidgets.QLabel("Create Account")
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet(LABEL_STYLE)

        self.username_line_edit = QtWidgets.QLineEdit()
        self.username_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.username_line_edit.setStyleSheet(INPUT_STYLE)
        self.username_line_edit.setPlaceholderText("Enter Username")

        self.password_line_edit = QtWidgets.QLineEdit()
        self.password_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.password_line_edit.setStyleSheet(INPUT_STYLE)
        self.password_line_edit.setPlaceholderText("Enter Password")
        self.password_line_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password_line_edit.returnPressed.connect(self.register_user)

        self.signup_button = QtWidgets.QPushButton("Sign Up")
        self.signup_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.signup_button.setStyleSheet(BUTTON_STYLE)

        self.back_to_login_button = QtWidgets.QPushButton("Back to Login")
        self.back_to_login_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.back_to_login_button.setStyleSheet(BUTTON_STYLE)

        layout.addWidget(label)
        layout.addSpacing(10)
        layout.addWidget(self.username_line_edit)
        layout.addWidget(self.password_line_edit)
        layout.addSpacing(20)
        layout.addWidget(self.signup_button)
        layout.addWidget(self.back_to_login_button)
        layout.addStretch()

        self.setLayout(layout)

        self.signup_button.clicked.connect(self.register_user)
        self.back_to_login_button.clicked.connect(lambda: switch_to_login(self))

    def register_user(self):
        username = self.username_line_edit.text().strip()
        password = self.password_line_edit.text().strip()

        if not username or not password:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Both fields are required.")
            return

        try:
            self.cursor.execute("SELECT username FROM iot_ftp_signup WHERE username=?", (username,))
            if self.cursor.fetchone():
                QtWidgets.QMessageBox.warning(self, "Duplicate", "Username already exists.")
                return

            self.cursor.execute("INSERT INTO iot_ftp_signup (username, password) VALUES (?, ?)", (username, password))
            self.conn.commit()
            QtWidgets.QMessageBox.information(self, "Success", "Account created successfully!")
            switch_to_login(self)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Database Error", f"Error occurred:\n{e}")


# ---- SignInWindow ----
class SignInWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.conn, self.cursor = connect_to_database()

        self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
        screen_geometry = QtWidgets.QDesktopWidget().screenGeometry()
        x = int(screen_geometry.width() / 2 - WINDOW_WIDTH)
        self.setGeometry(x, 120, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setWindowTitle("PT Communication")
        self.setWindowIcon(QtGui.QIcon(logo_path))

        self.setup_ui()

    def setup_ui(self):
        self.setContentsMargins(20, 0, 20, 20)
        layout = QtWidgets.QVBoxLayout()

        label = QtWidgets.QLabel("Log In")
        label.setStyleSheet(LABEL_STYLE)
        label.setAlignment(Qt.AlignCenter)

        self.username_line_edit = QtWidgets.QLineEdit()
        self.username_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.username_line_edit.setStyleSheet(INPUT_STYLE)
        self.username_line_edit.setPlaceholderText("Enter Username")

        self.password_line_edit = QtWidgets.QLineEdit()
        self.password_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.password_line_edit.setStyleSheet(INPUT_STYLE)
        self.password_line_edit.setPlaceholderText("Enter Password")
        self.password_line_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password_line_edit.returnPressed.connect(self.handle_login)

        self.login_button = QtWidgets.QPushButton("Log In")
        self.login_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.login_button.setStyleSheet(BUTTON_STYLE)

        self.create_account_button = QtWidgets.QPushButton("Sign Up")
        self.create_account_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.create_account_button.setStyleSheet(BUTTON_STYLE)

        layout.addWidget(label)
        layout.addSpacing(10)
        layout.addWidget(self.username_line_edit)
        layout.addWidget(self.password_line_edit)
        layout.addSpacing(20)
        layout.addWidget(self.login_button)
        layout.addWidget(self.create_account_button)
        layout.addStretch()

        self.setLayout(layout)
        self.login_button.clicked.connect(self.handle_login)
        self.create_account_button.clicked.connect(self.open_sign_up)

    def handle_login(self):
        username = self.username_line_edit.text().strip()
        password = self.password_line_edit.text().strip()

        if not username or not password:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Username and password cannot be empty.")
            return

        try:
            self.cursor.execute("SELECT username, password FROM iot_ftp_signup")
            records = self.cursor.fetchall()

            if (username, password) in records:
                self.open_main_window()
            else:
                QtWidgets.QMessageBox.warning(self, "Login Failed", "Incorrect username or password.")
                self.username_line_edit.clear()
                self.password_line_edit.clear()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Query Error", f"Failed to validate login:\n{e}")

    def open_main_window(self):
        self.close()
        self.main_window = Ui_MainWindow()
        self.main_window.setWindowTitle("Main Window")
        self.main_window.show()

    def open_sign_up(self):
        self.close()
        self.sign_up_window = SignUpWindow()
        self.sign_up_window.setWindowTitle("Sign Up")
        self.sign_up_window.show()


if __name__ == "__main__":

    app = QtWidgets.QApplication(sys.argv)
    window = SignInWindow()
    window.show()
    sys.exit(app.exec_())