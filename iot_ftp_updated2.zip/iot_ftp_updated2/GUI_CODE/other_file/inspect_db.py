import os
import sqlite3
import sys

def find_sqlite_file(root_dir):
    # Look for a .sqlite3 file in the root directory
    files = [f for f in os.listdir(root_dir) if f.endswith('.sqlite3')]
    if not files:
        print(f"No .sqlite3 file found in {root_dir}")
        return None
    elif len(files) > 1:
        print(f"Multiple .sqlite3 files found in {root_dir}: {files}")
        print("Using the first one found.")
    return os.path.join(root_dir, files[0])

def print_tables(cursor):
    print("=== TABLES IN DATABASE ===")
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [row[0] for row in cursor.fetchall()]
    for table in tables:
        print(f"- {table}")
    print()
    return tables

def print_table_schema_and_preview(cursor, table):
    print(f"=== SCHEMA FOR TABLE: {table} ===")
    cursor.execute(f"PRAGMA table_info('{table}');")
    columns = cursor.fetchall()
    if not columns:
        print("  [No columns found]")
    for col in columns:
        print(f"  {col[1]} ({col[2]})")  # col[1]=name, col[2]=type
    print("  -- Top 5 rows --")
    try:
        cursor.execute(f"SELECT * FROM '{table}' LIMIT 5;")
        rows = cursor.fetchall()
        if not rows:
            print("   [No rows found]")
        for row in rows:
            print("  ", row)
    except Exception as e:
        print("  [Error reading data:]", e)
    print("\n-----------------------------\n")

def main():
    # Get the directory where this script is located (root directory)
    root_dir = os.path.dirname(os.path.abspath(__file__))
    print(f"Looking for .sqlite3 file in {root_dir}")
    db_path = find_sqlite_file(root_dir)
    if not db_path:
        print("No SQLite file found in the root directory. Please add a .sqlite3 file and try again.")
        return

    print(f"\nInspecting database at: {db_path}\n")

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
    except Exception as e:
        print("Could not open database:", e)
        return

    try:
        tables = print_tables(cursor)
        if not tables:
            print("No tables found in this database.")
            return
        for table in tables:
            print_table_schema_and_preview(cursor, table)
    except Exception as e:
        print("Error while inspecting database:", e)
    finally:
        conn.close()

if __name__ == "__main__":
    main()
