#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys
import subprocess
import psutil  # Make sure you've run: pip install psutil


def run_gui_once():


    base_dir = os.path.dirname(os.path.abspath(__file__))

    gui_path = os.path.abspath(os.path.join(base_dir, 'GUI_CODE', 'server_ui.py'))
    # gui_path = os.path.join(os.path.dirname(__file__), 'GUI_CODE', 'server_ui.py')

    # Check if GUI is already running
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            cmdline_list = proc.info.get('cmdline')
            if not cmdline_list:
                continue
            cmdline = ' '.join(cmdline_list).lower()
            if 'server_ui.py' in cmdline:
                print("⚠️ GUI already running.")
                return
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, TypeError):
            continue


    if getattr(sys, 'frozen', False):
    # If bundled by cx_Freeze or PyInstaller
      exe = sys.executable
    else:
        exe = sys.executable
    print("✅ Launching GUI...")
    subprocess.Popen([exe, gui_path], shell=True)



def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'iot_enable_ftp.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc

    # ✅ Run GUI only in main process (not during Django reloads)
    if os.environ.get('DJANGO_RUN_MAIN') != 'true':
        run_gui_once()

    # 👇 Automatically append 0.0.0.0:80 if user runs only "runserver"
    if len(sys.argv) == 2 and sys.argv[1] == "runserver":
        sys.argv.append("0.0.0.0:80")

    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
