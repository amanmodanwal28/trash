def hex_to_big_decimal(hex_string):
    # Remove spaces
    hex_string = hex_string.replace(" ", "")
    
    # Convert whole hex string to decimal
    decimal_value = int(hex_string, 16)
    
    return decimal_value


# Example
hex_data = "000000024CB016EA"
decimal_value = hex_to_big_decimal(hex_data)

print("Decimal Value:", decimal_value)
# 2528395061930