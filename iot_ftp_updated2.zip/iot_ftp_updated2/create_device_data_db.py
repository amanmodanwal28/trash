import os
import sqlite3
from datetime import datetime

# Get the script's current directory
base_dir = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(base_dir, 'device_data.sqlite3')  # <-- change file name here

# 1. Connect to SQLite DB (creates file if not exists)
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# 2. Create the table (if it doesn't exist already)
cursor.execute('''
    CREATE TABLE IF NOT EXISTS devices2 (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip TEXT NOT NULL,
        lcd TEXT,
        hmi TEXT,
        tft TEXT,
        port INTEGER,
        connection TEXT,
        version TEXT,
        status TEXT,
        created_at TEXT
    )
''')


# 3. Insert sample data with current time
now = datetime.now().isoformat(' ', 'seconds')  # e.g. '2024-08-01 13:22:48'
# 3. Insert sample data


devices_data = [
    ('192.168.1.10', 'LCD-001', 'HMI-A', 'TFT-X', 8080, 'Ethernet', 'v1.0', 'Online', now),
    ('192.168.1.11', 'LCD-002', 'HMI-B', 'TFT-Y', 8081, 'WiFi', 'v1.2', 'Offline', now),
    ('192.168.1.12', 'LCD-003', 'HMI-C', 'TFT-Z', 8082, 'Ethernet', 'v2.0', 'Online', now),
]

cursor.executemany('''
    INSERT INTO devices2 (ip, lcd, hmi, tft, port, connection, version, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
''', devices_data)

conn.commit()  # Save changes

# 4. Fetch and display all rows
cursor.execute('SELECT * FROM devices2')
rows = cursor.fetchall()

print(f"All Devices in Table ({db_path}):")
for row in rows:
    print(row)



def drop_table(conn, table_name):
    cursor = conn.cursor()
    try:
        cursor.execute(f'DROP TABLE IF EXISTS {table_name}')
        conn.commit()
        print(f"Table '{table_name}' has been deleted (dropped) from the database.")
    except Exception as e:
        print(f"Error dropping table {table_name}: {e}")



def delete_all_data(conn, table_name):
    cursor = conn.cursor()
    try:
        cursor.execute(f'DELETE FROM {table_name}')
        conn.commit()
        print(f"All data has been deleted from table '{table_name}'.")
    except Exception as e:
        print(f"Error deleting data from {table_name}: {e}")


def delete_row_by_id(conn, table_name, row_id):
    cursor = conn.cursor()
    try:
        cursor.execute(f'DELETE FROM {table_name} WHERE id = ?', (row_id,))
        conn.commit()
        print(f"Row with id={row_id} deleted from '{table_name}'.")
    except Exception as e:
        print(f"Error deleting row: {e}")


# delete_row_by_id(conn, 'devices2',5)
# delete_all_data(conn, 'devices2')
# drop_table(conn, 'devices2')


conn.close()
