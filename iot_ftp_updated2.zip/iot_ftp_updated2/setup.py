from cx_Freeze import setup, Executable
import sys

# Dependencies are automatically detected, but some modules need manual listing
build_exe_options = {
    "packages": ["os", "sys", "sqlite3", "PyQt5", "django", "threading", "socket", "paramiko", "re","psutil"],
    "include_files": [
        ("GUI_CODE", "GUI_CODE"),
        ("iot_ftp", "iot_ftp"),
        ("iot_enable_ftp", "iot_enable_ftp"),
        ("server_storage", "server_storage"),
    ],
    "excludes": ["tkinter"],  # Exclude if not needed
}

base = None
if sys.platform == "win32":
    base = "Console"  # Use "Win32GUI" if your main file is a pure GUI (no console)

setup(
    name="MyDjangoGuiApp",
    version="1.0",
    description="Django + PyQt5 Project",
    options={"build_exe": build_exe_options},
    executables=[Executable("manage.py", base=base)],
)
