import socket

HOST = '0.0.0.0'  # Listen on all interfaces
PORT = 8010       # Port to bind
BUFFER_SIZE = 1024

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(5)
    print(f"[Server] Listening on {HOST}:{PORT}...")

    try:
        while True:
            client_socket, client_address = server_socket.accept()
            print(f"[Server] Connection from {client_address}")
            try:
                while True:
                    data = client_socket.recv(BUFFER_SIZE)
                    if not data:
                        break
                    print(f"[Server] Received: {data.decode(errors='ignore')}")
                    # Echo back the message (optional)
                    client_socket.sendall(b"Message received")
            except ConnectionResetError:
                print(f"[Server] Connection lost with {client_address}")
            finally:
                client_socket.close()
                print(f"[Server] Connection closed: {client_address}")
            
            
    except KeyboardInterrupt:
        print("\n[Server] Shutting down...")
    finally:
        server_socket.close()

if __name__ == "__main__":
    main()
