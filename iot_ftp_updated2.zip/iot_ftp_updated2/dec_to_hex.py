def dec_to_hex_8bytes(decimal_value):
    # Convert decimal to hex (without "0x")
    hex_string = hex(decimal_value)[2:].upper()
    
    # Pad with leading zeros to make 16 hex digits (8 bytes)
    hex_string = hex_string.zfill(16)
    
    # Split into pairs
    pairs = [hex_string[i:i+2] for i in range(0, 16, 2)]
    
    return hex_string, pairs


# Example
decimal_value = 9876543210
hex_string, pairs = dec_to_hex_8bytes(decimal_value)

print("Full 8-byte Hex:", hex_string)
print("Hex Pairs:", pairs)
