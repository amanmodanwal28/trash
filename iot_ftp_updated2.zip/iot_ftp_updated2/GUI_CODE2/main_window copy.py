from PyQt5 import QtWidgets, QtCore, QtGui
from socket_client import SocketServer  # use your SocketServer class
from resources import  PPS_LOGO


class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self, username=None):
        super().__init__()
        
        # ---------------- Window Properties ----------------
        self.setWindowTitle("Main Window")
        self.setWindowIcon(QtGui.QIcon(PPS_LOGO))
        self.showMaximized() 
        
        # ---------------- Central Widget ----------------
        self.central_widget = QtWidgets.QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Layout
        self.layout = QtWidgets.QVBoxLayout(self.central_widget)
        
        # Welcome Label
        self.label = QtWidgets.QLabel(f"Welcome {username}!")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setStyleSheet("font-size: 24px; font-weight: bold;")
        self.layout.addWidget(self.label)
        
        # Text area to display received messages
        self.text_area = QtWidgets.QTextEdit()
        self.text_area.setReadOnly(True)
        self.layout.addWidget(self.text_area)

        # ---------------- Start Socket Server ----------------
        self.server = SocketServer()
        self.server.data_received.connect(self.display_data)
        self.server.connection_status.connect(self.update_status)
        self.server.start()

    # ---------------- Display messages in text area ----------------
    def display_data(self, msg):
        self.text_area.append(msg)

    # ---------------- Update server status ----------------
    def update_status(self, connected):
        if connected:
            self.text_area.append("Socket server started ✅")
        else:
            self.text_area.append("Socket server failed ❌")

    # ---------------- Cleanly stop server when GUI closes ----------------
    def closeEvent(self, event):
        if hasattr(self, "server"):
            self.server.stop()
        event.accept()
