import os
import sys
import sqlite3
from PyQt5 import QtCore, QtWidgets
from resources import DB_PATH

def connect_to_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS iot_ftp_signup (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        )
    """)
    conn.commit()
    return conn, cursor

# ---------------- Common Styles ----------------
WINDOW_WIDTH, WINDOW_HEIGHT = 400, 300
INPUT_WIDTH, INPUT_HEIGHT = 280, 35
LABEL_STYLE = "font-size: 18px; font-weight: bold; margin-bottom: 10px;"
INPUT_STYLE = "padding: 5px; font-size: 14px;"
BUTTON_STYLE = "padding: 5px; font-size: 14px; background-color: #0078d7; color: white;"


# ---- SignUpWindow ----
class SignUpWindow(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.conn, self.cursor = connect_to_database()
        self.setGeometry(600, 200, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setup_ui()

    def setup_ui(self):
        layout = QtWidgets.QVBoxLayout()
        label = QtWidgets.QLabel("Create Account")
        label.setAlignment(QtCore.Qt.AlignCenter)
        label.setStyleSheet(LABEL_STYLE)

        self.username_line_edit = QtWidgets.QLineEdit()
        self.username_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.username_line_edit.setStyleSheet(INPUT_STYLE)
        self.username_line_edit.setPlaceholderText("Enter Username")

        self.password_line_edit = QtWidgets.QLineEdit()
        self.password_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.password_line_edit.setStyleSheet(INPUT_STYLE)
        self.password_line_edit.setPlaceholderText("Enter Password")
        self.password_line_edit.setEchoMode(QtWidgets.QLineEdit.Password)

        self.signup_button = QtWidgets.QPushButton("Sign Up")
        self.signup_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.signup_button.setStyleSheet(BUTTON_STYLE)
        self.signup_button.clicked.connect(self.register_user)

        self.password_line_edit.returnPressed.connect(self.register_user)
        self.username_line_edit.returnPressed.connect(self.register_user)

        self.back_to_login_button = QtWidgets.QPushButton("Back to Login")
        self.back_to_login_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.back_to_login_button.setStyleSheet(BUTTON_STYLE)
        self.back_to_login_button.clicked.connect(self.back_to_login)

        layout.addWidget(label)
        layout.addSpacing(10)
        layout.addWidget(self.username_line_edit)
        layout.addWidget(self.password_line_edit)
        layout.addSpacing(20)
        layout.addWidget(self.signup_button)
        layout.addWidget(self.back_to_login_button)
        layout.addStretch()
        self.setLayout(layout)

    def register_user(self):
        username = self.username_line_edit.text().strip()
        password = self.password_line_edit.text().strip()

        if not username or not password:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Both fields are required.")
            return

        try:
            self.cursor.execute("SELECT username FROM iot_ftp_signup WHERE username=?", (username,))
            if self.cursor.fetchone():
                QtWidgets.QMessageBox.warning(self, "Duplicate", "Username already exists.")
                return

            self.cursor.execute("INSERT INTO iot_ftp_signup (username, password) VALUES (?, ?)", (username, password))
            self.conn.commit()
            QtWidgets.QMessageBox.information(self, "Success", "Account created successfully!")
            self.back_to_login()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Database Error", f"Error occurred:\n{e}")

    def back_to_login(self):
        self.parent().setCurrentWidget(self.parent().sign_in)


# ---- SignInWindow ----
class SignInWindow(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.conn, self.cursor = connect_to_database()
        self.setGeometry(600, 200, WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setup_ui()

    def setup_ui(self):
        layout = QtWidgets.QVBoxLayout()
        label = QtWidgets.QLabel("Log In")
        label.setStyleSheet(LABEL_STYLE)
        label.setAlignment(QtCore.Qt.AlignCenter)

        self.username_line_edit = QtWidgets.QLineEdit()
        self.username_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.username_line_edit.setStyleSheet(INPUT_STYLE)
        self.username_line_edit.setPlaceholderText("Enter Username")

        self.password_line_edit = QtWidgets.QLineEdit()
        self.password_line_edit.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.password_line_edit.setStyleSheet(INPUT_STYLE)
        self.password_line_edit.setPlaceholderText("Enter Password")
        self.password_line_edit.setEchoMode(QtWidgets.QLineEdit.Password)

        self.login_button = QtWidgets.QPushButton("Log In")
        self.login_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.login_button.setStyleSheet(BUTTON_STYLE)
        self.login_button.clicked.connect(self.handle_login)

        self.password_line_edit.returnPressed.connect(self.handle_login)
        self.username_line_edit.returnPressed.connect(self.handle_login)

        self.create_account_button = QtWidgets.QPushButton("Sign Up")
        self.create_account_button.setFixedSize(INPUT_WIDTH, INPUT_HEIGHT)
        self.create_account_button.setStyleSheet(BUTTON_STYLE)
        self.create_account_button.clicked.connect(self.open_sign_up)

        layout.addWidget(label)
        layout.addSpacing(10)
        layout.addWidget(self.username_line_edit)
        layout.addWidget(self.password_line_edit)
        layout.addSpacing(20)
        layout.addWidget(self.login_button)
        layout.addWidget(self.create_account_button)
        layout.addStretch()
        self.setLayout(layout)

    def handle_login(self):
        username = self.username_line_edit.text().strip()
        password = self.password_line_edit.text().strip()

        if not username or not password:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Username and password cannot be empty.")
            return

        try:
            self.cursor.execute("SELECT username FROM iot_ftp_signup WHERE username=? AND password=?", (username, password))
            record = self.cursor.fetchone()
            if record:
                self.parent().open_main_window(username)
            else:
                QtWidgets.QMessageBox.warning(self, "Login Failed", "Incorrect username or password.")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Query Error", f"Failed to validate login:\n{e}")

    def open_sign_up(self):
        self.parent().setCurrentWidget(self.parent().sign_up)
