import socket
import sqlite3
import threading
import time
from datetime import datetime
from PyQt5.QtCore import QObject, pyqtSignal
from resources import DB_PATH  # make sure this points to your sqlite file

class Config:
    SERVER_HOST = '0.0.0.0'  # bind on all interfaces
    SERVER_PORT = 8010
    BUFFER_SIZE = 1024
    DB_PATH = DB_PATH


# ---------------- Database Handler ----------------
class DatabaseHandler:
    def __init__(self, db_path=Config.DB_PATH):
        # allow access from multiple threads
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.lock = threading.Lock()

    def execute_query_with_retry(self, query, data=None, max_retries=5, base_delay=0.1):
        retries = 0
        while retries < max_retries:
            try:
                # with self.lock:
                with self.lock:  # <--- IMPORTANT
                    cursor = self.conn.cursor()
                    if data:
                        cursor.execute(query, data)
                    else:
                        cursor.execute(query)
                    self.conn.commit()
                    cursor.close()
                return
            except sqlite3.OperationalError as e:
                # be permissive about case
                if "database is locked" in str(e).lower():
                    time.sleep(base_delay * (2 ** retries))
                    retries += 1
                else:
                    raise
            except Exception as e:
                print(f"[!!] Query failed: {e}")
                raise
        raise sqlite3.OperationalError(f"Max retries exceeded for query: {query}")

    def close(self):
        try:
            with self.lock:
                self.conn.close()
        except Exception:
            pass


# ---------------- Data Processor ----------------
class DataProcessor:
    def __init__(self, db_handler):
        # expects an instance of DatabaseHandler
        self.db = db_handler

    def process_and_store_data(self, raw_data: bytes, client_ip: str, client_port: int, client_id="Unknown"):
        if not raw_data:
            print("[x] Client disconnected during data transmission.")
            return

        try:
            # print(f"[Debug] Raw data received: {raw_data}")
            hex_data = raw_data

            # Extract fields (indexes kept as in your code)
            device_type_hex   = hex_data[1:5]
            serial_number_hex = hex_data[5:21]
            version_hex       = hex_data[21:29]
            connected_hex     = hex_data[29:45]
            train_id_hex      = hex_data[45:61]
            coach_id_hex      = hex_data[61:77]
            train_number_hex  = hex_data[77:93]

            device_type = {
                '0001': 'MPU',
                '0002': 'ICOME',
                '0003': 'EBTU'
            }.get(device_type_hex, 'None')

            # Convert numeric fields
            try:
                serial_number = int(serial_number_hex, 16)
            except Exception:
                print(f"[!] Invalid hex for serial_number: {serial_number_hex}")
                serial_number = 0

            try:
                software_version = int(version_hex, 16)
            except Exception:
                software_version = 0

            connected_devices = connected_hex  # stored as hex string (you can parse into bytes if you prefer)

            try:
                train_id = int(train_id_hex, 16)
            except Exception:
                train_id = 0

            try:
                coach_id = int(coach_id_hex, 16)
            except Exception:
                coach_id = 0

            # Train number → ASCII (strip leading zeros first)
            tn = train_number_hex.lstrip("0")
            if len(tn) % 2 != 0:
                tn = "0" + tn
            if tn:
                try:
                    train_number = bytes.fromhex(tn).decode(errors="ignore").strip()
                except Exception:
                    try:
                        train_number = str(int(train_number_hex, 16))
                    except Exception:
                        train_number = ""
            else:
                train_number = ""

            # Health status heuristic (keep your original logic)
            zero_count = connected_devices.count('0')
            status = 'Unhealthy' if 4 < zero_count < 8 else 'Healthy'
            formatted_time = datetime.now().strftime('%H:%M:%S')
            
            print('device_type_hex==================',device_type)
            print('serial_number_hex==================',serial_number)
            print('version_hex==================',software_version)
            print('connected_hex==================',connected_devices)
            print('train_id_hex==================',train_id)
            print('coach_id_hex==================',coach_id)
            print('train_number_hex==================',train_number)
            print('zero_count==================',zero_count)
            print('status==================',status)
            print('formatted_time==================',formatted_time)

            # Insert row
            insert_query = '''
                INSERT INTO iot_ftp_status
                (ip, port, status, client_id, status_date, type, serial_number, version, connected_devices, train_id, coach_id, train_number)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            '''
            data_tuple = (
                client_ip, client_port, status, client_id, formatted_time,
                device_type, serial_number, software_version,
                connected_devices, train_id, coach_id, train_number
            )
            self.db.execute_query_with_retry(insert_query, data_tuple)

            # Keep only last 50 entries (safe delete)
            delete_query = '''
                DELETE FROM iot_ftp_status
                WHERE id NOT IN (SELECT id FROM iot_ftp_status ORDER BY id DESC LIMIT 50)
            '''
            self.db.execute_query_with_retry(delete_query)

            print("[✓] Data inserted:", data_tuple)

        except Exception as e:
            print(f"[!!] Processing failed: {e}")


# ---------------- Socket Server ----------------
class SocketServer(QObject):
    data_received = pyqtSignal(str)
    connection_status = pyqtSignal(bool)

    def __init__(self, db_handler: DatabaseHandler = None, host=None, port=None, buffer_size=None):
        super().__init__()
        self.host = host or Config.SERVER_HOST
        self.port = port or Config.SERVER_PORT
        self.buffer_size = buffer_size or Config.BUFFER_SIZE
        self.sock = None
        self.clients = {}
        self._stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)

        # DB handler: accept external or create internal
        if db_handler is None:
            self.db_handler = DatabaseHandler(Config.DB_PATH)
        else:
            self.db_handler = db_handler

        self.processor = DataProcessor(self.db_handler)

    def start(self):
        self.thread.start()

    def stop(self):
        self._stop_event.set()
        try:
            if self.sock:
                self.sock.close()
        except Exception:
            pass

        for c in list(self.clients.values()):
            try:
                c.close()
            except Exception:
                pass

        # close DB connection if it was created internally
        try:
            self.db_handler.close()
        except Exception:
            pass

    def _run(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind((self.host, self.port))
            self.sock.listen(5)
            print(f"[SocketServer] Listening on {self.host}:{self.port}...")
            self.connection_status.emit(True)

            while not self._stop_event.is_set():
                try:
                    client_sock, client_addr = self.sock.accept()
                    print(f"[SocketServer] Client connected: {client_addr}")
                    self.clients[client_addr] = client_sock
                    threading.Thread(
                        target=self.handle_client,
                        args=(client_sock, client_addr),
                        daemon=True
                    ).start()
                except Exception as e:
                    print(f"[SocketServer] Accept error: {e}")
        except Exception as e:
            print(f"[SocketServer] Socket bind/listen failed: {e}")
            self.connection_status.emit(False)

    def handle_client(self, client_sock, client_addr):
        client_ip, client_port = client_addr
        try:
            while True:
                data = client_sock.recv(self.buffer_size)
                if not data:
                    print("[x] Client disconnected.")
                    break

                # human-friendly message for GUI/debug
                try:
                    msg = data.decode(errors="ignore").strip().replace(" ", "")
                    # print(f"[SocketServer] Received from {client_addr}:msg : {msg}")
                except Exception:
                    msg = "<binary data>"

                # print(f"[SocketServer] Received from {client_addr}: {msg}")
                self.data_received.emit(f"{client_addr}: {msg}")

                # Process + Insert into DB (raw bytes)
                self.processor.process_and_store_data(msg, client_ip, client_port, client_id=str(client_ip))

        except Exception as e:
            print(f"[SocketServer] Client error: {e}")
        finally:
            try:
                client_sock.close()
            except Exception:
                pass
            if client_addr in self.clients:
                del self.clients[client_addr]
            print(f"[SocketServer] Client disconnected: {client_addr}")
