# resources.py
import os
import sys

def resource_path(relative_path):
    """Get absolute path to resource (works for dev and PyInstaller)"""
    base_path = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

# ---------------- Database ----------------
DB_PATH = resource_path(os.path.join("..", "iot_enable.sqlite3"))

# ---------------- Logos / Icons ----------------
PPS_LOGO = resource_path(os.path.join("..", "iot_ftp", "static", "PPS_logo.png"))

# ---------------- Other Images ----------------
server_storage = resource_path(os.path.join('..', 'server_storage'))
selected_file_name = resource_path(os.path.join('..', 'server_storage', 'selected_file_name.txt'))
uploading_folder = resource_path(os.path.join('..', 'iot_ftp', 'media', 'uploaded_files'))
selected_ips = resource_path(os.path.join('..', 'server_storage', 'selected_ips.txt'))

