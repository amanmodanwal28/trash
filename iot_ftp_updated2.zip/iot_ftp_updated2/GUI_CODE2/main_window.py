from PyQt5 import QtWidgets, QtCore, QtGui
from socket_client import SocketServer
from resources import PPS_LOGO


class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self, username=None):
        super().__init__()
        
        # ---------------- Window Properties ----------------
        self.setWindowTitle("Main Window")
        self.setWindowIcon(QtGui.QIcon(PPS_LOGO))
        self.showMaximized() 
        
        # ---------------- Central Widget ----------------
        self.central_widget = QtWidgets.QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Layout
        self.layout = QtWidgets.QVBoxLayout(self.central_widget)
        
        # ---------------- Heading Section ----------------
        heading_layout = QtWidgets.QHBoxLayout()
        
        # Left heading
        self.left_heading = QtWidgets.QLabel("Devices Information")
        self.left_heading.setStyleSheet("font-size: 20px; font-weight: bold; padding: 8px;")
        heading_layout.addWidget(self.left_heading, alignment=QtCore.Qt.AlignLeft)
        
        # Center heading
        self.center_heading = QtWidgets.QLabel("Active Devices : 1")
        self.center_heading.setStyleSheet("font-size: 16px; font-weight: bold; color: green; padding: 8px;")
        heading_layout.addWidget(self.center_heading, alignment=QtCore.Qt.AlignCenter)
        
        # Right filter dropdown
        self.filter_combo = QtWidgets.QComboBox()
        self.filter_combo.addItems(["Filter", "Healthy", "Unhealthy"])
        heading_layout.addWidget(self.filter_combo, alignment=QtCore.Qt.AlignRight)
        
        # Add heading layout to main layout
        self.layout.addLayout(heading_layout)
        
        # ---------------- Table Section ----------------
        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(10)  # 10 columns
        self.table.setHorizontalHeaderLabels([
            "Train ID", "Coach ID", "Train Number", "Device Serial Number",
            "Main Device", "Status", "Time", "Detail", "Upload File", "Console"
        ])
        
        # Example: add 1 row for testing
        self.table.setRowCount(1)
        self.table.setItem(0, 0, QtWidgets.QTableWidgetItem("9001"))
        self.table.setItem(0, 1, QtWidgets.QTableWidgetItem("6001"))
        self.table.setItem(0, 2, QtWidgets.QTableWidgetItem("12560"))
        self.table.setItem(0, 3, QtWidgets.QTableWidgetItem("9876543210"))
        self.table.setItem(0, 4, QtWidgets.QTableWidgetItem("ICOME"))
        self.table.setItem(0, 5, QtWidgets.QTableWidgetItem("Healthy"))
        self.table.setItem(0, 6, QtWidgets.QTableWidgetItem("14:58:15"))

        # Add clickable buttons in last 3 columns
        detail_btn = QtWidgets.QPushButton("Detail")
        upload_btn = QtWidgets.QPushButton("Upload")
        console_btn = QtWidgets.QPushButton("Console")
        
        self.table.setCellWidget(0, 7, detail_btn)
        self.table.setCellWidget(0, 8, upload_btn)
        self.table.setCellWidget(0, 9, console_btn)
        
        self.layout.addWidget(self.table)
        
        # ---------------- Start Socket Server ----------------
        self.server = SocketServer()
        self.server.data_received.connect(self.display_data)
        self.server.connection_status.connect(self.update_status)
        self.server.start()

    # ---------------- Display messages in table ----------------
    def display_data(self, msg):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QtWidgets.QTableWidgetItem(msg))  # Just putting raw msg in Train ID for now

    # ---------------- Update server status ----------------
    def update_status(self, connected):
        if connected:
            self.center_heading.setText("Socket server started ✅")
        else:
            self.center_heading.setText("Socket server failed ❌")

    # ---------------- Cleanly stop server when GUI closes ----------------
    def closeEvent(self, event):
        if hasattr(self, "server"):
            self.server.stop()
        event.accept()
