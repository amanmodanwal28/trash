import os
import sys
import signal
from PyQt5 import QtWidgets, QtGui
from auth import SignInWindow, SignUpWindow
from main_window import Ui_MainWindow
from resources import DB_PATH, PPS_LOGO

class Application(QtWidgets.QStackedWidget):
    def __init__(self):
        super().__init__()
        # Create pages
        self.sign_in = SignInWindow(parent=self)
        self.sign_up = SignUpWindow(parent=self)

        self.addWidget(self.sign_in)
        self.addWidget(self.sign_up)

        self.setCurrentWidget(self.sign_in)
        self.setWindowTitle("PPS Internation - Log In")   # default title
        self.setWindowIcon(QtGui.QIcon(PPS_LOGO))
        # 🔹 Whenever page changes, update window title
        self.currentChanged.connect(self.update_window_title)
        
    def update_window_title(self, index):
        current_widget = self.widget(index)
        if isinstance(current_widget, SignInWindow):
            self.setWindowTitle("PPS Internation - Log In")
        elif isinstance(current_widget, SignUpWindow):
            self.setWindowTitle("PPS Internation - Create Account")

    def open_main_window(self, username):
        self.main_window = Ui_MainWindow(username=username) 
        self.close() 
        

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    
     # ✅ Ensure Ctrl+C works
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    
    application = Application()
    application.show()
    sys.exit(app.exec_())
