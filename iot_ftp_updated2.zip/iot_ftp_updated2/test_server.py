import socket

HOST = '0.0.0.0'
PORT = 8010
BUFFER_SIZE = 1024

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen(5)
print(f"[Server] Listening on {HOST}:{PORT}...")

try:
    client_socket, client_addr = server_socket.accept()
    print(f"[Server] Connected: {client_addr}")
    while True:
        data = client_socket.recv(BUFFER_SIZE)
        if not data:
            break
        print(f"[Server] Received: {data.decode(errors='ignore')}")
        client_socket.sendall(b"Message received")
finally:
    client_socket.close()
    server_socket.close()
