
from PyQt5 import QtCore, QtGui, QtWidgets
import socket
import sqlite3
import threading
import time
import datetime
import os
import struct
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QFileDialog, QLabel

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setStyleSheet("background-color: rgb(85, 170, 255);")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(70, 40, 91, 31))
        self.label.setObjectName("label")
        self.radioButton = QtWidgets.QRadioButton(self.centralwidget)
        self.radioButton.setGeometry(QtCore.QRect(70, 80, 82, 17))
        self.radioButton.setObjectName("radioButton")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
         self.pushButton.setGeometry(QtCore.QRect(350, 50, 75, 23))
        self.pushButton.setObjectName("pushButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.SERVER_HOST = '0.0.0.0' # Accept connections on any interface
        self.SERVER_PORT = 8010      # Port to listen on
        
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.pushButton.clicked.connect(self.send_file)
        # Start the server in a new thread
        threading.Thread(target=self.start_server, daemon=True).start()

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "status"))
        self.radioButton.setTex t(_translate("MainWindow", "ip:"))
        self.pushButton.setText(_translate("MainWindow", "send file"))

    def start_server(self):
        # Create a TCP/IP socket
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Bind the socket to the address and port
        server_socket.bind((self.SERVER_HOST, self.SERVER_PORT))
        # Enable listening mode
        server_socket.listen(5)
        print(f"Server listening on {self.SERVER_HOST}:{self.SERVER_PORT}")
        count=0
        try:
            # Connect to the database
            while True:
                # Wait for incoming connections
                self.client_socket, self.client_address = server_socket.accept()
                print(f"Connection from {self.client_address}")
                threading.Thread(target=self.handle_client, args=(self.client_socket, self.client_address)).start()
                count=count+1
                print(count)
        except KeyboardInterrupt:
             print("Server shutting down")
        
        
    def handle_client(self, client_socket, client_address):
        db_path = 'D:\\machine_learning\\iot_enable_remote_control\\iot_enable_ftp\\iot_enable.sqlite3'
        connection = sqlite3.connect(db_path)
        cursor = connection.cursor()
        header = client_socket.recv(1)
        print('header=======================',header)
        data_type = int(header[0])
        if data_type==0:
            self.send_file()
        try:
            while True:
                data = client_socket.recv(1024).decode()[-6:]
                if not data:
                    break
                print(f"Received from {client_address}: {data}")
                
                insert_query = '''
                    INSERT INTO iot_ftp_status (ip, port, status) VALUES (?,?,?)
                '''
                data_tuple = (client_address[0], client_address[1], data)
                
                cursor.execute(insert_query, data_tuple)
                 connection.commit()
                
                self.radioButton.setText((client_address[0]))
                # self.radioButton.styleSheet('color')
                self.radioButton.setStyleSheet("color: green;")
                time.sleep(1)
        
        finally:
            client_socket.close()


    def send_file(self):
        BUFFER_SIZE = 1024  
        try:
            print("in if condition")
            header = bytes([1])
            try:
                file_path="D:\\machine_learning\\iot_enable_remote_control\\using_pyqt5\\main.ui"
                print("Starting file transmission")
                with open(file_path, 'rb') as file:
                    file_data = file.read()
                    file_size = len(file_data)
                    print(f"File size: {file_size} bytes")

                    # Send the file size to the client
                    self.client_socket.sendall(struct.pack('!Q', file_size))
                    print("File size  sent successfully")

                    # Send the file data to the client in chunks
                    chunk_size = 4096
                    for i in range(0, file_size, chunk_size):
                        self.client_socket.sendall(file_data[i:i+chunk_size])
                    print("File data sent successfully")
            except Exception as e:
                print(f"Error: {e}")
            # else: 
            #     pass

        except Exception as e:
            print(f"Error occurred with client {self.client_address}: {e}")      

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()  # Create a QMainWindow instance
    ui = Ui_MainWindow()  # Create an instance of your UI class
    ui.setupUi(MainWindow)  # Set up the UI on the QMainWindow instance
    MainWindow.show()  # Show the QMainWindow instance
    sys.exit(app.exec_())
