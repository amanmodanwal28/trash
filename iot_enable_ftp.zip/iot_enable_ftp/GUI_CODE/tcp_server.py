import socket
import sqlite3
import datetime

class tcp_host:
    def __init__(self):
        # Define self.HOST and self.PORT
        self.HOST = '103.76.138.125'  # Server's self.HOSTname or IP address
        self.PORT = 8010            # self.PORT to listen on
        # Define the database file path
        # self.db_path = 'D:\\machine_learning\\iot enable remote control\\iot_enable_ftp\\iot_enable.sqlite3'
        self.db_path='D:\\machine_learning\\iot_enable_remote_control\\iot_enable_ftp\\iot_enable.sqlite3'
        # Connect to the database
        self.connection = sqlite3.connect(self.db_path)
        # Create a cursor object to interact with the database
        self.cursor = self.connection.cursor()
        print(f"Connected to database at {self.db_path}")
        self.listen()
    # Create a TCP socket
    def listen(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
            # Bind the socket to the self.HOST and self.PORT
            server_socket.bind((self.HOST, self.PORT))
            print(f"Server is listening on {self.HOST}:{self.PORT}")
            # Listen for incoming connections (max queue size is 5)
            server_socket.listen(5)
            while True:
                # Accept a new connection
                client_socket, client_address = server_socket.accept()
                print(f"Connected to {client_address}")
                # Handle client communication
                while True:
                    # Receive data from the client
                    data = client_socket.recv(1024)
                    if not data:
                        break
                    print(f"Received from {client_address}: {data}")
                    now =datetime.datetime.now()
                    print(now)
                    insert_query = '''
                                    INSERT INTO iot_ftp_status (ip, self.PORT, status) VALUES (?,?,?)
                                    '''
                    # Data to be inserted
                    data = (client_address[0], client_address[1],data)
                    
    def send_file(self,filename):    
        try: 
            # Reading file and sending data to server 
            fi = open(filename, "r") 
            data = fi.read() 
            print("data======",data)
            self.client_socket.send(data.encode())
            # if not data:
        except IOError: 
            print('You entered an invalid filename!\ Please enter a valid name') 

if __name__=='__main__':
    tcp_host()        
            


