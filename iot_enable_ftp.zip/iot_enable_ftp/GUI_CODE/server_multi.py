import socket
import threading
import os
import sqlite3
from datetime import datetime
import struct
import time
import shutil

# SERVER_HOST = '103.76.138.125' # Accept connections on any interface
SERVER_HOST = '192.168.11.27'
SERVER_PORT = 8010      # Port to listen on
BUFFER_SIZE = 1024      # Buffer size for receiving data

clients = {}
client_id_counter = 0
lock = threading.Lock()
checked_ip=None
ip=[]
# file_name=None

def send_file():
    header = bytes([0])
    
    # Read the file name and IP address
    with open('server_storage/selected_ips.txt', 'r') as file:
        selected_ip = file.read().strip()  # Ensure there are no extra spaces/newlines

    with open('server_storage/selected_file_name.txt', 'r') as file:
        file_name = file.read().strip()  # Ensure there are no extra spaces/newlines
    
    # clients[selected_ip].sendall(header)    

    # print(f"Selected IP: {selected_ip}")
    # print(f"File name: {file_name}")

    # Path to the file to be sent
    file_path = os.path.join('server_storage', file_name)

    with open(file_path, 'wb') as file:
            while True:
                data = clients['103.76.138.125'].recv(BUFFER_SIZE)
                # print(data)
                if not data:
                    break
                file.write(data)

    # Check if the file exists
    if not os.path.isfile(file_path):
        print(f"File {file_path} does not exist.")
        return
    

    # Open the file and prepare to send
    with open(file_path, 'rb') as file:
        file_data = file.read()
        file_size = len(file_data)

        # clients[selected_ip].sendall(header)

        # Send the file name length first
        clients[selected_ip].sendall(header)
        file_name_encoded = file_name.encode('utf-8')
        file_name_length = len(file_name_encoded)
        clients[selected_ip].sendall(struct.pack('!I', file_name_length))
        print(f"File name length ({file_name_length} bytes) sent successfully")

        # Send the file name
        clients[selected_ip].sendall(file_name_encoded)
        print(f"File name ({file_name}) sent successfully")

        # Send the file size
        clients[selected_ip].sendall(struct.pack('!Q', file_size))
        print("File size sent successfully")

        # Send the file data in chunks
        chunk_size = 64
        for i in range(0, file_size, chunk_size):
            # print('file_data[i:i+chunk_size]=====',len(file_data[i:i+chunk_size]))
            clients[selected_ip].sendall(file_data[i:i+chunk_size])
        print("File data sent successfully")
           
def rename_file_name(file_path):
    global ip
    # if not os.path.exists(file_path):
    #     os.makedirs(file_path, exist_ok=True)

    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    if not lines:
        return None
    
    first_line = lines[0]
    # ip=lines[1] 
    # print('first_line===========',first_line)
    # print('ip===========',ip)
    # os.chdir('D:\\machine_learning\\iot_enable_remote_control\\iot_enable_ftp\\server_storage')
    new_file_path_ = os.path.join('server_storage', first_line.strip())
    if os.path.isfile(new_file_path_):
        os.remove(new_file_path_)
        # new_file_path = os.path.join('server_storage', first_line.strip())
    
    new_file_path = os.path.join('server_storage', first_line.strip())
    # print('new_file_path====',new_file_path)
   
    # Rename the file
    os.rename(file_path, new_file_path)  
    # if os.path.exists(file_path):
    #     os.remove(file_path)   
    # print("new_file_path================",new_file_path)
    return new_file_path
def delete_line(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    if not lines:
        return None
    
    with open(file_path, 'w') as file:
        file.writelines(lines[2:])

def handle_client(client_socket, client_address, client_id):
    # print("client_socket, client_address, client_id == ",client_socket, client_address, client_id)
    global clients,checked_ip
    # print('client_address=====',client_address)
    client_ip=client_address[0]
    with lock:
        clients[client_ip] = client_socket
    print(f"Accepted connection from {client_address}")

    header = client_socket.recv(1)
    # if len(header)>=1:
    data_type = int(header[0])
    print("header============",data_type)
    # else:
    #     data_type=0    
    db_path = 'D:\\machine_learning\\iot_enable_remote_control\\iot_enable_ftp\\iot_enable.sqlite3'

    # Connect to the database
    connection = sqlite3.connect(db_path, check_same_thread=False)
    connection.execute('PRAGMA busy_timeout = 3000')  # Wait for up to 3000 milliseconds (3 seconds)
    cursor = connection.cursor()

    if data_type == 0:
        # print("I am in file transfer condition")
        send_file() 
    elif data_type == 3:
        with open('server_storage/selected_ips.txt', 'r') as file:
            selected_ip = file.read().strip()
        header = bytes([3])
        print('header==================',selected_ip)
        clients[selected_ip].sendall(header)
        # while True:
        #     data=clients[selected_ip].recv(1024)
        #     print(data)
    elif data_type == 4:
        print("this is receiver")   
    elif data_type == 2:
        id = client_id
        while True:
            # Receive data from the client
            data = client_socket.recv(1024).decode()
            # device_conn=data[-4:]
            print('data[-8:-2]===========',len(data),data.strip(),type(data[0]))
            # print('data==============',data[-6:])
            if not data:
                break
            if len(data)>=23:
                if data[1:3]=='01':
                    # print('data[-8:-2]===========',data[0:].strip())
                    device_type='mpu'
                    # data =data[-6:]
                elif data[1:3]=='02':
                    # print('data[-8:-2]===========',data[0:].strip())
                    device_type='icome'
                    # data =data[-6:]
                elif data[1:3]=='03':
                    # data =data[-6:]
                    device_type='ebtu'  
                serial_number=data[3:11]
                software_version=data[11:15]
                connected_device=data[15:23]
                if connected_device.count('0') > 4 and connected_device.count('0')< 8:
                    stataus='Unhealthy'
                else:
                    stataus='Healthy'
                    
                # if data[14:16]=='06':
                #     connected_device='LED'
                # elif data[16:18]=='07':
                #     connected_device='LCD'
                # elif data[18:20]=='08':
                #     connected_device='EBTU' 
                # elif data[20:22]=='09':
                #     connected_device='EPU'      
                        

                    
                # if len(data)>7:
                #     # print('data==============',len(data))
                #     with open('server_storage/detail.txt', 'wb') as file:
                #         while True:
                #             data=data[8:]
                #             print(data)
                #             if not data:
                #                 break
                #             file.write(data.encode())
                #             break
                #     continue
                # now = datetime.now()

                now = datetime.now()
                formatted_time = now.strftime('%H:%M:%S')
            

                # Format the date and time
                # formatted_date_time = now.strftime("%d/%m/%y %H:%M:%S")
                insert_query = '''
                    INSERT INTO iot_ftp_status (ip, port, status, client_id, status_date,type,serial_number,version,connected_devices) VALUES (?, ?, ?, ?, ?,?,?,?,?)
                '''
                data1 = (client_address[0], client_address[1], stataus, id, formatted_time,device_type,serial_number,software_version,connected_device)
                # Execute the query with retry logic
                execute_query_with_retry(cursor, insert_query, data1)
                connection.commit()
                time.sleep(1)
                try:
                    delete_query = 'DELETE FROM iot_ftp_status WHERE id NOT IN (SELECT id FROM iot_ftp_status ORDER BY id DESC LIMIT 50);'
                    execute_query_with_retry(cursor, delete_query)
                    connection.commit()
                except sqlite3.OperationalError as e:
                    print(f"Error executing delete query: {e}")

    # connection.close()

def start_server():
    # Create a TCP/IP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # Bind the socket to the address and port
    server_socket.bind((SERVER_HOST, SERVER_PORT))
    # Enable listening mode
    server_socket.listen(5)
    global client_id_counter
    print(f"Server listening on {SERVER_HOST}:{SERVER_PORT}")

    try:
        while True:
            # Wait for incoming connections
            client_socket, client_address = server_socket.accept()

            with lock:
                client_id_counter += 1
                client_id = client_id_counter
            # Create a new thread to handle the client
            client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address,client_id))
            client_thread.start()

    except KeyboardInterrupt:
        print("Server shutting down")

def execute_query_with_retry(cursor, query, data=None, max_retries=5, base_delay=0.1):
    retries = 0
    while retries < max_retries:
        try:
            if data:
                cursor.execute(query, data)
            else:
                cursor.execute(query)
            return
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                time.sleep(base_delay * (2 ** retries))  # Exponential backoff
                retries += 1
            else:
                raise
    raise sqlite3.OperationalError("Max retries exceeded for query: {}".format(query))        
    
    # finally:
    #     server_socket.close()

if __name__ == "__main__":
    server_thread = threading.Thread(target=start_server)
    server_thread.start()



