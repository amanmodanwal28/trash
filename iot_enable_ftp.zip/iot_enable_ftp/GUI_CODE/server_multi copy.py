import socket
import threading
import os
import sqlite3
from datetime import datetime
import struct
import time
import shutil

SERVER_HOST = '0.0.0.0' # Accept connections on any interface
SERVER_PORT = 8010      # Port to listen on
BUFFER_SIZE = 1024      # Buffer size for receiving data

clients = {}
client_id_counter = 0
lock = threading.Lock()
checked_ip=None
ip=[]
# file_name=None

def send_file():
        with open('server_storage/selected_ips.txt', 'rb') as file:
                selected_ip = file.read().decode()
                print('file_data============',type(selected_ip))
                
        print("hellooooooooooooooooooooooo")
        BUFFER_SIZE = 1024  
        # try:
            # print("in if condition")
        header = bytes([1])
        # current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        directory = 'server_storage'
        if not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)
        
        temp_file_path='server_storage\\temp.txt'
        # last_item = list(clients.items())[-1]

        # Unpack the key and value
        # last_key, client_browser = last_item
        # Open a new file to write received data
        print("clients===============",clients)
        with open(temp_file_path, 'wb') as file:
            while True:
                data = clients['103.76.138.125'].recv(BUFFER_SIZE)
                print(data)
                if not data:
                    break
                file.write(data)  
        file_path=rename_file_name(temp_file_path)                  
        print(f"File received successfully: {file_path}")
        # file_path="D:\\machine_learning\\iot_enable_remote_control\\using_pyqt5\\main.ui"
        # print("Starting file transmission")
        with open(file_path, 'rb') as file:
            file_data = file.read()
            # print(file_data)
            file_size = len(file_data)
            # print(f"File size: {file_size} bytes")

            # Send the file size to the client
            clients[selected_ip].sendall(struct.pack('!Q', file_size))
            print("File size sent successfully")

            # Send the file data to the client in chunks
            chunk_size = 4096
            for i in range(0, file_size, chunk_size):
                clients[selected_ip].sendall(file_data[i:i+chunk_size])
            print("data sent successfully")
        delete_line(file_path)
               
        # except Exception as e:
        #     print(f"Error: {e}")
           
def rename_file_name(file_path):
    global ip
    # if not os.path.exists(file_path):
    #     os.makedirs(file_path, exist_ok=True)

    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    if not lines:
        return None
    
    first_line = lines[0]
    # ip=lines[1] 
    # print('first_line===========',first_line)
    # print('ip===========',ip)
    # os.chdir('D:\\machine_learning\\iot_enable_remote_control\\iot_enable_ftp\\server_storage')
    new_file_path_ = os.path.join('server_storage', first_line.strip())
    if os.path.isfile(new_file_path_):
        os.remove(new_file_path_)
        # new_file_path = os.path.join('server_storage', first_line.strip())
    
    new_file_path = os.path.join('server_storage', first_line.strip())
    # print('new_file_path====',new_file_path)
   
    # Rename the file
    os.rename(file_path, new_file_path)  
    # if os.path.exists(file_path):
    #     os.remove(file_path)   
    print("new_file_path================",new_file_path)
    return new_file_path
def delete_line(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    if not lines:
        return None
    
    with open(file_path, 'w') as file:
        file.writelines(lines[2:])

def handle_client(client_socket, client_address, client_id):
    print("client_socket, client_address, client_id == ",client_socket, client_address, client_id)
    global clients,checked_ip
    print('client_address=====',client_address)
    client_ip=client_address[0]
    with lock:
        clients[client_ip] = client_socket
    print(f"Accepted connection from {client_address}")

    header = client_socket.recv(1)
    # if len(header)>=1:
    data_type = int(header[0])
    # else:
    #     data_type=0    
    db_path = 'D:\\machine_learning\\iot_enable_remote_control\\iot_enable_ftp\\iot_enable.sqlite3'

    # Connect to the database
    connection = sqlite3.connect(db_path, check_same_thread=False)
    connection.execute('PRAGMA busy_timeout = 3000')  # Wait for up to 3000 milliseconds (3 seconds)
    cursor = connection.cursor()

    if data_type == 0:
        print("I am in file transfer condition")
        send_file() 
    elif data_type == 2:
        id = client_id
        while True:
            # Receive data from the client
            data = client_socket.recv(1024).decode()[-6:]
            if not data:
                break
            now = datetime.now()

            # Format the date and time
            formatted_date_time = now.strftime("%d/%m/%y %H:%M:%S")
            insert_query = '''
                INSERT INTO iot_ftp_status (ip, port, status, client_id, status_date) VALUES (?, ?, ?, ?, ?)
            '''
            data1 = (client_address[0], client_address[1], data, id, formatted_date_time)
            # Execute the query with retry logic
            execute_query_with_retry(cursor, insert_query, data1)
            connection.commit()
            time.sleep(1)
            try:
                delete_query = 'DELETE FROM iot_ftp_status WHERE id NOT IN (SELECT id FROM iot_ftp_status ORDER BY id DESC LIMIT 50);'
                execute_query_with_retry(cursor, delete_query)
                connection.commit()
            except sqlite3.OperationalError as e:
                print(f"Error executing delete query: {e}")

    # connection.close()

def start_server():
    # Create a TCP/IP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Bind the socket to the address and port
    server_socket.bind((SERVER_HOST, SERVER_PORT))
    # Enable listening mode
    server_socket.listen(5)
    global client_id_counter
    print(f"Server listening on {SERVER_HOST}:{SERVER_PORT}")

    try:
        while True:
            # Wait for incoming connections
            client_socket, client_address = server_socket.accept()

            with lock:
                client_id_counter += 1
                client_id = client_id_counter
            # Create a new thread to handle the client
            client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address,client_id))
            client_thread.start()

    except KeyboardInterrupt:
        print("Server shutting down")

def execute_query_with_retry(cursor, query, data=None, max_retries=5, base_delay=0.1):
    retries = 0
    while retries < max_retries:
        try:
            if data:
                cursor.execute(query, data)
            else:
                cursor.execute(query)
            return
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                time.sleep(base_delay * (2 ** retries))  # Exponential backoff
                retries += 1
            else:
                raise
    raise sqlite3.OperationalError("Max retries exceeded for query: {}".format(query))        
    
    # finally:
    #     server_socket.close()

if __name__ == "__main__":
    server_thread = threading.Thread(target=start_server)
    server_thread.start()
