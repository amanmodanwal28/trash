import streamlit as st
import pandas as pd
import numpy as np

st.title("Interactive Data App This is My First Page")

# # Data input
num_rows = st.slider("Number of rows:", 1, 100, 10)
data = pd.DataFrame(np.random.randn(num_rows, 3), columns=["A", "B", "C"])
st.write("Generated Data", data)

# # Display graph
st.line_chart(data)
# print("fininshed")

