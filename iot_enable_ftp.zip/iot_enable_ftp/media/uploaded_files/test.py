# from PyQt5 import QtWidgets
# from PyQt5.QtWidgets import QPushButton, QTableWidgetItem

# class MyWindow(QtWidgets.QMainWindow):
#     def __init__(self):
#         super().__init__()

#         self.centralwidget = QtWidgets.QWidget(self)
#         self.setCentralWidget(self.centralwidget)

#         # Create table widget
#         self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
#         self.tableWidget.setGeometry(50, 50, 400, 300)

#         # Set table size (5 rows and 3 columns: serial number, data, and button)
#         self.tableWidget.setRowCount(5)
#         self.tableWidget.setColumnCount(3)

#         # Populate table with serial numbers, data, and buttons
#         for row in range(5):
#             # Add serial number to the first column
#             serial_number_item = QTableWidgetItem(str(row + 1))  # Serial starts from 1
#             self.tableWidget.setItem(row, 0, serial_number_item)

#             # Add some dummy data to the second column
#             data_item = QTableWidgetItem(f"Item {row}")
#             self.tableWidget.setItem(row, 1, data_item)

#             # Create a QPushButton for the last column
#             btn = QPushButton("Click Me")
#             btn.clicked.connect(self.on_button_clicked)  # Connect to slot
#             # Store the row number in the button using setProperty
#             btn.setProperty("row", row)
            
#             # Add the button to the last column of the table
#             self.tableWidget.setCellWidget(row, 2, btn)

#     def on_button_clicked(self):
#         # Get the button that was clicked
#         button = self.sender()

#         if button:
#             # Retrieve the row number stored in the button
#             row = button.property("row")
#             print(f"Button clicked in row {row}")

# if __name__ == "__main__":
#     import sys
#     app = QtWidgets.QApplication(sys.argv)
#     window = MyWindow()
#     window.show()
#     sys.exit(app.exec_())

def welcome(func):
    def wrapper():
        print("welcome")
        func()
    return wrapper 
 
@welcome
def hello():
    print("laxman")   
hello() 

# l1=[1,3,2,4,5]
# k=l1.index(4)
# print(k)




