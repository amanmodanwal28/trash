

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox,QFileDialog,QMenu,QTableWidget, QTableWidgetItem, QMenu,QDialog
import paramiko as pm
import os
import fnmatch
from PyQt5.QtCore import Qt
from rename import Ui_Dialog

class AllowAllKeys(pm.MissingHostKeyPolicy):
    def missing_host_key(self, client, hostname, key):
        return
    
class MainWindow(QtWidgets.QMainWindow,Ui_Dialog):
    def __init__(self):
        super().__init__()        
        self.setupUi(self)

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)  # Slightly larger initial size
        # MainWindow.setWindowOpacity(1.0)
        MainWindow.setToolTipDuration(-1)
        MainWindow.setStyleSheet("background-color: #e0f7fa;;")
        MainWindow.setTabShape(QtWidgets.QTabWidget.Rounded)
        
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout.setContentsMargins(20, 20, 20, 20)
        self.verticalLayout.setObjectName("verticalLayout")
        
        ###horizontal widget
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")

        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setStyleSheet("background-color: lightblue;")
        self.pushButton_2.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("icon/upload.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_2.setIcon(icon)
        self.pushButton_2.setObjectName("pushButton_2")
        self.horizontalLayout.addWidget(self.pushButton_2)
        self.pushButton_6 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_6.setStyleSheet("background-color: lightblue;\n""")
        self.pushButton_6.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("icon/console.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_6.setIcon(icon1)
        self.pushButton_6.setObjectName("pushButton_6")
        self.horizontalLayout.addWidget(self.pushButton_6)

        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)

        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setStyleSheet("background-color: lightblue;")
        self.pushButton.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("icon/back.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton.setIcon(icon1)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton)

        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setStyleSheet("background-color: lightblue;")
        self.pushButton_3.setText("")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("icon/refresh.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_3.setIcon(icon2)
        self.pushButton_3.setObjectName("pushButton_3")
        self.horizontalLayout.addWidget(self.pushButton_3)

        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setStyleSheet("background-color: lightblue;")
        self.pushButton_4.setText("")
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("icon/trash.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_4.setIcon(icon3)
        self.pushButton_4.setObjectName("pushButton_4")
        self.horizontalLayout.addWidget(self.pushButton_4)

        ################end of horizontal widget

        self.verticalLayout.addLayout(self.horizontalLayout)

        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setStyleSheet("background-color: lightblue; color: black; border: 1px solid black; padding-top: 10px;")
        self.label.setFrameShadow(QtWidgets.QFrame.Raised)
        self.label.setText("")
        self.label.setIndent(5)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)

        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setMinimumSize(QtCore.QSize(0, 400))
        style_sheet = """
                    QTableWidget {
                        color: rgb(0, 0, 0);
                        border-color: rgb(255, 255, 255);
                        gridline-color: rgb(255, 255, 255);
                        selection-background-color: rgb(255, 255, 255);
                        selection-color: rgb(0, 0, 0);
                    }
                    QHeaderView::section {
                        background-color: lightblue;
                        color: black;
                    }"""
        self.tableWidget.setStyleSheet(style_sheet)
        self.tableWidget.setTabKeyNavigation(False)
        self.tableWidget.setProperty("showDropIndicator", False)
        self.tableWidget.setDragDropOverwriteMode(False)
        self.tableWidget.setShowGrid(False)
        self.tableWidget.setGridStyle(QtCore.Qt.NoPen)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(3)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(2, 0, item)
        self.tableWidget.horizontalHeader().setVisible(True)
        self.tableWidget.horizontalHeader().setHighlightSections(False)
        self.tableWidget.horizontalHeader().setMinimumSectionSize(53)
        self.tableWidget.horizontalHeader().setSortIndicatorShown(False)
        self.tableWidget.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.tableWidget.verticalHeader().setVisible(False)
        self.tableWidget.verticalHeader().setHighlightSections(True)
        self.tableWidget.verticalHeader().setMinimumSectionSize(0)
        self.tableWidget.verticalHeader().setStretchLastSection(False)
        self.verticalLayout.addWidget(self.tableWidget)
        
        MainWindow.setCentralWidget(self.centralwidget)

        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        ##########################################################
        # Define the file patterns for text, music, video, and image files
        self.python_file=['*.py']
        self.text_patterns = ['*.txt', '*.md', '*.docx', '*.pdf', '*.markdown', '*.tex', '*.rtf', '*.html', '*.htm', '*.xml', '*.csv', '*.json']
        self.music_patterns = ['*.mp3', '*.wav', '*.aac', '*.flac', '*.aiff', '*.ogg', '*.wma', '*.m4a', '*.mid', '*.midi']
        self.video_patterns = ['*.mp4', '*.avi', '*.mov', '*.mkv', '*.mpg', '*.mpeg', '*.wmv', '*.flv', '*.webm', '*.3gp', '*.m4v', '*.asf']
        self.image_patterns = ['*.jpg', '*.jpeg', '*.png', '*.gif', '*.bmp', '*.tiff', '*.webp', '*.svg', '*.raw', '*.arw', '*.cr2', '*.nef', '*.orf', '*.sr2']
        self.main() 
        self.tableWidget.cellClicked.connect(self.update_row_column)
        self.tableWidget.cellPressed.connect(self.update_row_column)
        self.tableWidget.cellDoubleClicked.connect(self.connect_to_selected_host)
        self.pushButton.clicked.connect(self.back_dir)
        self.pushButton_2.clicked.connect(self.send_file)
        self.pushButton_3.clicked.connect(self.refresh)
        self.pushButton_4.clicked.connect(self.delete)
        self.previous_dir = None
        self.del_flag = False
        self.refresh_flag=False

        # Set context menu policy
        self.tableWidget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tableWidget.customContextMenuRequested.connect(self.show_context_menu)
        # self.tableWidget.setEditTriggers(QTableWidget.DoubleClicked | QTableWidget.EditKeyPressed)
        # self.tableWidget.itemChanged.connect(self.on_item_changed)
        

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "FTP"))
        item = self.tableWidget.verticalHeaderItem(0)
        item.setText(_translate("MainWindow", "New Row"))
        item = self.tableWidget.verticalHeaderItem(1)
        item.setText(_translate("MainWindow", "New Row"))
        item = self.tableWidget.verticalHeaderItem(2)
        item.setText(_translate("MainWindow", "New Row"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Name"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Size"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Changed"))

    # def on_item_changed(self, item):
    #     # This slot is called when an item in the table is edited
    #     if item.column() == 0:  # Check if the edited item is in a specific column (e.g., Column 1)
    #         self.content = self.tableWidget.item(item.row(), item.column()).text()  # Get the text from the edited item
    #         # print(f'Edited content at row {item.row()}, column {item.column()}: {content}')
                

    def show_context_menu(self, pos):
        context_menu = QMenu(self)
        context_menu.setStyleSheet("""
            QMenu {
                color: black; /* Set the text color for all items */
            }
            QMenu::item:selected {
                background-color: lightgray; /* Optional: Set a different background color for selected items */
            }
        """)

        action1 = context_menu.addAction("Open")
        action2 = context_menu.addAction("Extract")
        action3 = context_menu.addAction("Copy")
        action4 = context_menu.addAction("Rename")
        action5 = context_menu.addAction("Delete")

        action = context_menu.exec_(self.tableWidget.mapToGlobal(pos))

        if action:
            item = self.tableWidget.itemAt(pos)
            if item:
                if action == action1:
                    print(list(self.current_dir))
                    command = f'ls {self.current_dir.strip()}/{item.text()}/ -l'
                    output=self.execute_command(self.client, command)
                    self.current_dir=f'{self.current_dir.strip()}/{item.text()}'
                    self.label.setText(self.current_dir)
                    output=[[i.split(" ")[-1],"",""] for i in output.split("\n")[:-1]][2:]
                    self.tableWidget.clearContents()
                    self.table_view(output)
                elif action == action2:
                    self.extract_zip()
                elif action == action3:
                    item.setText("Action 3 triggered") 
                elif action == action4:
                    self.rename()
                elif action == action5:
                    self.delete() 
                     
    def extract_zip(self):
        item = self.tableWidget.item(self.row, self.column)
        item=item.text()
        extract_dir = self.current_dir.strip()+"/"+item
        command = f'unzip {item} -d {self.current_dir}'
        output=self.execute_command(self.client, command)
        # print('output=====',output)

    def rename(self):
        item = self.tableWidget.item(self.row, self.column)
        old_dir = self.current_dir+"/"+item.text()
        dialog = QDialog(self)
        dialog_ui = Ui_Dialog()
        dialog_ui.setupUi(dialog)
        result = dialog.exec_()
        
        cancel_button = dialog_ui.getCancelButton()
        ok_button = dialog_ui.getOkButton()

        cancel_button.clicked.connect(dialog.reject)  # Close dialog without accepting
        ok_button.clicked.connect(self.close_pop_ui) 
       
        if result == QDialog.Accepted:
            print("Dialog was accepted")
        else:
            print("Dialog was rejected or closed")

        text=dialog_ui.get_text()
        new_dir= self.current_dir+"/"+text
        print('new_dir====',new_dir)
        command=f'mv {old_dir} {new_dir}'
        self.execute_command(self.client, command) 

    def close_pop_ui(self):
        print("hellooooooo")

   
    def update_row_column(self,row,column):
        self.row=row
        self.column=column 
        self.del_flag=True    

    def delete(self):
        if self.del_flag:
            self.show_message_box("Information", "Are you sure! you want to delete file")
            if self.result == QMessageBox.Ok:
                item = self.tableWidget.item(self.row, self.column)
                delete_dir = self.current_dir+"/"+item.text()
                if "." not in item.text():
                    command = f'rm -r {self.current_dir}'
                    self.execute_command(self.client, command)
                else:
                    command = f'rm {delete_dir}'
                    self.execute_command(self.client, command)  
            else:
                pass        
        else:
            pass             

    def refresh(self):
        try:
            command = f'cd {self.current_dir[0:]}/ && pwd && ls -l'
            output = self.execute_command(self.client, command)
            self.label.setText(self.current_dir)
            output=[[i.split(" ")[-1],"",""] for i in output.split("\n")[:-1]][2:]
            self.tableWidget.clearContents()
            self.table_view(output)
        except Exception as e:
            print(f"Failed to connect or execute commands: {e}")       
         
    def back_dir(self):
        dir="/".join(self.current_dir.split("/")[:-1])
        # print("dir========",dir)
        self.current_dir=dir
        # print("dir========",self.current_dir)
        if dir !="":
            # print("dir=======ififi=======",dir)
            command = f'cd "{dir}" && pwd && ls -l'
            output = self.execute_command(self.client, command) 
            # print("=====output=========",output)
            output=[[i.split(" ")[-1],"",""] for i in output.split("\n")[:-1]][2:]
            self.label.setText(dir)
            self.tableWidget.clearContents()
            self.table_view(output)
            self.previous_dir=dir
        else:
            # print("dir=======eleeleelfi=======",dir)
            command = f'cd / && pwd && ls -l'
            output = self.execute_command(self.client, command) 
            # print("=====output=========",output)
            output=[[i.split(" ")[-1],"",""] for i in output.split("\n")[:-1]][2:]
            self.label.setText("/")
            self.tableWidget.clearContents()
            self.table_view(output)
            self.previous_dir=""
            self.label.setText(self.previous_dir)  


    def connect_to_selected_host(self,row,column):
        item = self.tableWidget.item(row, column)
        folder = item.text()
        if "." not in folder:
            if self.previous_dir==None:
                self.previous_dir=folder
            else:    
                folder=self.previous_dir+"/"+folder
                self.previous_dir=folder 
            command = f'cd {folder}/ && pwd && ls -l'
            output = self.execute_command(self.client, command) 
            self.current_dir= output.split("\n")[0]
            # print("self.current_dir====connect",self.current_dir)
            self.label.setText(output.split(" ")[0].split("\n")[0])
            output=[[i.split(" ")[-1],"",""] for i in output.split("\n")[:-1]][2:]
            self.tableWidget.clearContents()
            self.table_view(output)
        else:
            pass

    def show_message_box(self, title, message):
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        self.result=msg_box.exec_()            

    def execute_command(self,ssh_client, command):
        stdin, stdout, stderr = ssh_client.exec_command(command)
        return stdout.read().decode('utf-8')

    def main(self):
        # print("hello")
        HOST = '192.168.11.200'
        USER = 'root '
        PASSWORD = ''
        # Create an SSH client instance
        self.client = pm.SSHClient()
        self.client.load_system_host_keys()
        self.client.set_missing_host_key_policy(AllowAllKeys())
        
        # Connect to the SSH server 
        try:
            self.client.connect(hostname=HOST, username=USER, password=PASSWORD)
            print(f"Connected to {HOST}")
            command = 'ls -l'
            output = self.execute_command(self.client, command)
            print(output)
            command = 'pwd'
            self.current_dir = self.execute_command(self.client, command)
            # print("main==",self.current_dir)
            self.label.setText(self.current_dir)
            output=[[i.split(" ")[-1],"",""] for i in output.split("\n")[:-1]][1:]
            self.tableWidget.clearContents()
            self.table_view(output)
            self.refresh_flag=True
        except Exception as e:
            print(f"Failed to connect or execute commands: {e}")    


    def table_view(self,output):        
            # print(output)
            for row_idx, row_data in enumerate(output):
                for col_idx, item_data in enumerate(row_data):
                    self.tableWidget.setRowCount(row_idx + 1)

                    if col_idx == 0:
                        # print(item_data)
                        # Create a QTableWidgetItem with both text and icon for column 0
                        if any(fnmatch.fnmatch(item_data, pattern) for pattern in self.text_patterns):
                            smiley_pixmap = QtGui.QPixmap("icon/txt.png")
                        elif any(fnmatch.fnmatch(item_data, pattern) for pattern in self.music_patterns):
                            smiley_pixmap = QtGui.QPixmap("icon/music.png")
                        elif any(fnmatch.fnmatch(item_data, pattern) for pattern in self.video_patterns):
                            smiley_pixmap = QtGui.QPixmap("icon/video.png")
                        elif any(fnmatch.fnmatch(item_data, pattern) for pattern in self.image_patterns):
                            smiley_pixmap = QtGui.QPixmap("icon/image.png")   
                        elif any(fnmatch.fnmatch(item_data, pattern) for pattern in self.python_file):
                            smiley_pixmap = QtGui.QPixmap("icon/python.png")
                        else:
                            # print(item_data)
                            smiley_pixmap = QtGui.QPixmap("icon/folder.png")
                        smiley_item = QtWidgets.QTableWidgetItem(item_data)
                        smiley_item.setIcon(QtGui.QIcon(smiley_pixmap))
                        self.tableWidget.setItem(row_idx, col_idx, smiley_item)
                    else:
                        # Create a QTableWidgetItem for other columns
                        item = QtWidgets.QTableWidgetItem(item_data)
                        self.tableWidget.setItem(row_idx, col_idx, item)  

    def send_file(self):
        options = QFileDialog.Options()
        options |= QFileDialog.ReadOnly
        self.file_name, _ = QFileDialog.getOpenFileName(self, "Select File", "", "All Files (*);;Text Files (*.txt)", options=options)
        if self.file_name:
            file_or_folder=self.file_name.split("/")[-1]
            sftp = self.client.open_sftp()
            sftp.put(self.file_name, "/tmp/"+file_or_folder)
            print(f"File {self.file_name} successfully uploaded to {'/tmp/{file_or_folder}}'}")                           
               

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = MainWindow()
    MainWindow.show()
    sys.exit(app.exec_())