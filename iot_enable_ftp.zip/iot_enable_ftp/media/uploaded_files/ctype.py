import ctypes
 
libObject = ctypes.CDLL('D:/machine_learning/socket_connection/clibrary.so')

# # libObject = ctypes.CDLL(clibrary.so')
libObject.hello()

# gcc -shared -o clibrary.dll hello.c
