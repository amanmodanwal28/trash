import socket
import sqlite3
import datetime

# Define host and port
HOST = '103.76.138.125'  # Server's hostname or IP address
PORT = 8010            # Port to listen on
# Define the database file path
db_path = 'D:\\machine_learning\\iot enable remote control\\iot_enable_ftp\\iot_enable.sqlite3'
# Connect to the database
connection = sqlite3.connect(db_path)
# Create a cursor object to interact with the database
cursor = connection.cursor()
print(f"Connected to database at {db_path}")
# Create a TCP socket
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
    # Bind the socket to the host and port
    server_socket.bind((HOST, PORT))
    print(f"Server is listening on {HOST}:{PORT}")
    # Listen for incoming connections (max queue size is 5)
    server_socket.listen(5)
    while True:
        # Accept a new connection
        client_socket, client_address = server_socket.accept()
        print(f"Connected to {client_address}")
        # Handle client communication
        while True:
            # Receive data from the client
            data = client_socket.recv(1024)
            if not data:
                break
            print(f"Received from {client_address}: {data}")
            now =datetime.datetime.now()
            print(now)
            insert_query = '''
                            INSERT INTO iot_ftp_status (ip, port, status) VALUES (?,?,?)
                            '''
            # Data to be inserted
            data = (client_address[0], client_address[1],data)
            # Execute the query with data
            cursor.execute(insert_query, data)
            # Commit the changes
            connection.commit()

            # Receive message from the server
            # received_message = client_socket.recv(1024).decode()

            filename = 'output.txt'
            print("filename====",filename)
            fo = open(filename, "w")
            fo.write(data.decode())
            print("Message from server")
            


