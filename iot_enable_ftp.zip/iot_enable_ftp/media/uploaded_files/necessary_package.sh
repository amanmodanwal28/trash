#!/bin/bash
# Autorun Script for Node.js, SSH, and DNSMasq Setup
# Author: Your Name
# Description: Automates Node.js installation, SSH setup, DNSMasq configuration, and other dependencies.

# Enable strict error handling
set -e

# Log file
LOGFILE="/var/log/autorun.log"
echo "Starting installation..." | tee -a "$LOGFILE"

# Allow password-less sudo for the current user
USER="${SUDO_USER:-$(whoami)}"
#USER=$(who | awk '{print $1}' | head -n 1)
SUDOERS_FILE="/etc/sudoers.d/$USER-no-passwd"
echo "username $USER" | tee -a "$LOGFILE"
# Add NOPASSWD entry for the current user
echo "$USER ALL=(ALL) NOPASSWD:ALL" > "$SUDOERS_FILE"
chmod 0440 "$SUDOERS_FILE"
echo "Password-less sudo enabled for user $USER" | tee -a "$LOGFILE"

echo "Installation completed." | tee -a "$LOGFILE"


# Update package list
echo "Updating package list..." | tee -a $LOGFILE
sudo apt update

# Function to check installation status
check_installation() {
  if dpkg -l | grep -q "$1"; then
    echo "$1 is installed." | tee -a $LOGFILE
  else
    echo "$1 is NOT installed." | tee -a $LOGFILE
  fi
}

# Install required dependencies
echo "Installing dependencies..." | tee -a $LOGFILE
sudo apt install -y curl software-properties-common ubuntu-restricted-extras net-tools
check_installation "curl"
check_installation "software-properties-common"
check_installation "ubuntu-restricted-extras"

# Install GStreamer
echo "Installing GStreamer..." | tee -a $LOGFILE
sudo apt install -y gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly gstreamer1.0-libav gstreamer1.0-tools
check_installation "gstreamer1.0-plugins-base"
check_installation "gstreamer1.0-plugins-good"
check_installation "gstreamer1.0-plugins-bad"
check_installation "gstreamer1.0-plugins-ugly"
check_installation "gstreamer1.0-libav"
check_installation "gstreamer1.0-tools"


# Install Google Chrome
echo "Downloading Google Chrome..." | tee -a "$LOGFILE"
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb

echo "Installing Google Chrome..." | tee -a "$LOGFILE"
sudo dpkg -i google-chrome-stable_current_amd64.deb || sudo apt --fix-broken install -y
check_installation "google-chrome-stable"

# Verify Installation
echo "Verifying Google Chrome installation..." | tee -a "$LOGFILE"
google-chrome --version | tee -a "$LOGFILE"

# Remove downloaded file
rm -f google-chrome.deb

# Add NodeSource repository and install Node.js
echo "Adding Node.js 22 repository..." | tee -a $LOGFILE
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

# Install NVM
echo "Installing NVM..." | tee -a $LOGFILE
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.3/install.sh | bash

source ~/.bashrc

# Verify Node.js and NPM installation
echo "Verifying Node.js and NPM installation..." | tee -a $LOGFILE
node -v | tee -a $LOGFILE
npm -v | tee -a $LOGFILE
npx -v | tee -a $LOGFILE
nvm -v | tee -a $LOGFILE

# Install and enable OpenSSH
echo "Installing OpenSSH server..." | tee -a $LOGFILE
sudo apt install -y openssh-server
sudo systemctl enable ssh
sudo systemctl start ssh

# Check SSH status
echo "Checking SSH status..." | tee -a $LOGFILE
sudo systemctl status ssh | tee -a $LOGFILE

# Disable systemd-resolved to free port 53
echo "Disabling systemd-resolved..." | tee -a $LOGFILE
sudo systemctl stop systemd-resolved | tee -a $LOGFILE
sudo systemctl disable systemd-resolved | tee -a $LOGFILE
sudo systemctl mask systemd-resolved | tee -a $LOGFILE

# Disable NetworkManager DNS management
echo "Configuring NetworkManager to stop DNS handling..." | tee -a $LOGFILE
sudo bash -c 'cat <<EOF >> /etc/NetworkManager/NetworkManager.conf

dns=none
EOF'

# Restart NetworkManager
echo "Restarting NetworkManager..." | tee -a $LOGFILE
sudo systemctl restart NetworkManager | tee -a $LOGFILE

# Make it immutable
sudo chattr -i /etc/resolv.conf

# Remove resolve.conf
sudo rm /etc/resolv.conf

# Remove existing resolv.conf and create a new one
echo "Configuring resolv.conf..." | tee -a $LOGFILE
sudo bash -c 'cat <<EOF > /etc/resolv.conf
nameserver 127.0.0.53
nameserver 8.8.8.8
nameserver 1.1.1.1
nameserver 127.0.0.1
EOF'

# set read-only permissions
sudo chmod 444 /etc/resolv.conf

# Make it immutable
sudo chattr +i /etc/resolv.conf

# Install and configure DNSMasq
echo "Installing DNSMasq..." | tee -a $LOGFILE
sudo apt install -y dnsmasq

# Find the correct network interface
INTERFACE=$(ip route | grep default | awk '{print $5}')
echo "Detected network interface: $INTERFACE" | tee -a $LOGFILE

# Append to dnsmasq.conf
echo "Configuring DNSMasq..." | tee -a $LOGFILE
sudo bash -c "cat <<EOF >> /etc/dnsmasq.conf

# Custom DNSMasq Config
# Listen on all interfaces
#interface=\$INTERFACE
bind-dynamic

# Assign DNS server to all devices
dhcp-option=option:dns-server,192.168.0.243

# Redirect vb-wifi.in to 192.168.0.243
address=/vb-wifi.in/192.168.0.243

# Optional: Forward other DNS requests to public DNS
server=8.8.8.8
server=1.1.1.1
EOF"



# Add hostname to /etc/hosts
echo "Adding hostname to /etc/hosts..." | tee -a $LOGFILE
sudo bash -c 'echo "192.168.0.243 vb-wifi.in" >> /etc/hosts'

# Restart and enable dnsmasq
echo "Restarting and enabling DNSMasq..." | tee -a $LOGFILE
sudo systemctl restart dnsmasq | tee -a $LOGFILE
sudo systemctl enable dnsmasq | tee -a $LOGFILE
sudo systemctl status dnsmasq | tee -a $LOGFILE

# Start, enable, and restart DNSMasq
echo "Starting and enabling DNSMasq..." | tee -a $LOGFILE
sudo systemctl start dnsmasq
sudo systemctl enable dnsmasq
sudo systemctl restart dnsmasq


# Create systemd service file for autorun
echo "Creating systemd service for autorun..." | tee -a $LOGFILE
sudo bash -c 'cat <<EOF > /etc/systemd/system/autorun.service
[Unit]
Description=Autorun Script
After=network.target multi-user.target
Wants=network-online.target

[Service]
ExecStart=/bin/bash /usr/local/bin/autorun.sh
Restart=always
User=root
StandardOutput=journal
StandardError=journal
Environment="HOME=/home/%u" "USER=%u"
ExecStartPre=/bin/sleep 10

[Install]
WantedBy=multi-user.target
EOF'

# Reload systemd and enable the service
echo "Enabling autorun service..." | tee -a $LOGFILE
sudo systemctl daemon-reload
sudo systemctl enable autorun.service
sudo systemctl start autorun.service


# Find IOB_Server directory
IOB_DIR=$(find /home/$USER -type d -name "IOB_Server" 2>/dev/null)

if [ -n "$IOB_DIR" ]; then
  echo "IOB_Server directory found at: $IOB_DIR" | tee -a "$LOGFILE"

  # Navigate to IOB_Server directory and run the command
  cd "$IOB_DIR" || exit
  echo "Running 'sudo npm run serve_linux' in $IOB_DIR" | tee -a "$LOGFILE"
  #sudo npm run serve_linux | tee -a "$LOGFILE"
  #npm install | tee -a "$LOGFILE"
  # Run npm command as the correct user
  sudo -u "$USER" bash -c "cd '$IOB_DIR' && npm install" | tee -a "$LOGFILE"
else
  echo "IOB_Server directory not found." | tee -a "$LOGFILE"
fi

# Install http-server globally
echo "Installing http-server globally..." | tee -a $LOGFILE
sudo npm install -g http-server
echo "http-server installed successfully." | tee -a $LOGFILE


# Reboot system
echo "Rebooting system..." | tee -a $LOGFILE
#sudo reboot

# End of script
echo "Installation complete. System rebooting..." | tee -a $LOGFILE

