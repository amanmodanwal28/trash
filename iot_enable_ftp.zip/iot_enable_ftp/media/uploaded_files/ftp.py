from ftplib import FTP, error_perm
import socket

def list_files(ftp, path):
    """
    List files and directories in a given path on the FTP server.
    """
    file_list = []
    
    try:
        file_list = ftp.nlst(path)
    except error_perm as e:
        if str(e) == "550 No files found":
            print(f"No files in directory: {path}")
        else:
            raise
    
    return file_list

def download_file(ftp, remote_file_path, local_file_path):
    """
    Download a file from the FTP server.
    """
    with open(local_file_path, 'wb') as local_file:
        ftp.retrbinary(f"RETR {remote_file_path}", local_file.write)

def main():
    ftp_host = '192.168.11.200'
    ftp_user = 'root'  # Assuming 'root' user
    ftp_pass = ''  # No password for root user
    ftp_port = 22  # Default FTP port
    remote_dir = '/home/'
    
    # Connect to the FTP server
    try:
        ftp = FTP()
        print(f"Connecting to FTP server: {ftp_host}:{ftp_port}")
        ftp.connect(ftp_host, ftp_port)
        print("Connected to the FTP server. Logging in...")
        ftp.login(user=ftp_user, passwd=ftp_pass)
        print("Logged in to the FTP server.")
    except (socket.error, socket.gaierror) as e:
        print(f"Error connecting to FTP server: {e}")
        return
    except error_perm as e:
        print(f"Login failed: {e}")
        return
    except EOFError as e:
        print(f"Connection closed unexpectedly: {e}")
        return
    
    # List directories and files in the remote directory
    print(f"Listing files in directory: {remote_dir}")
    try:
        files = list_files(ftp, remote_dir)
        for file in files:
            print(file)
    except error_perm as e:
        print(f"Failed to list files: {e}")
    
    # Example: Download a specific file
    remote_file_path = f"{remote_dir}/example.txt"
    local_file_path = "example.txt"
    try:
        download_file(ftp, remote_file_path, local_file_path)
        print(f"Downloaded {remote_file_path} to {local_file_path}")
    except error_perm as e:
        print(f"Failed to download file: {e}")
    
    # Quit the FTP session
    ftp.quit()
    print("FTP session closed.")

if __name__ == "__main__":
    main()
