import socket
import subprocess



# Define host and port
HOST = '192.168.11.200'  # The server's hostname or IP address
PORT = 65432        # The port used by the server

# Create a socket object
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
    # Connect to the server
    client_socket.connect((HOST, PORT))
    # message = input("Enter message to send (type 'exit' to quit): ")
    message = "Hi everyone: "
    
    # while True:
        # Send data to the server
        
    # if message.lower() == 'exit':
    #     break
    client_socket.sendall(message.encode())
    
    # Receive data from the server
    data = client_socket.recv(1024)
    print("Received:", data.decode())
