import socket
import threading
import time

def receive_messages(client_socket):
    while True:
        try:
            response = client_socket.recv(1024)
            if not response:
                print("Server closed the connection.")
                break
            print(f"Received: {response.decode()}")
        except Exception as e:
            print(f"An error occurred while receiving a message: {e}")
            break

def send_messages(client_socket):
    header = bytes([2])
    while True:
        try:
            message = 'active'
            # print(header+message.encode())
            client_socket.sendall(header + message.encode())
            time.sleep(1)
        except Exception as e:
            print(f"An error occurred while sending a message: {e}")
            break

def create_client(host='103.76.138.125', port=8010):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect((host, port))
        print(f"Connected to server {host}:{port}")

        receive_thread = threading.Thread(target=receive_messages, args=(client_socket,))
        send_thread = threading.Thread(target=send_messages, args=(client_socket,))
        
        receive_thread.start()
        send_thread.start()
        
        receive_thread.join()
        send_thread.join()

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        client_socket.close()
        print("Connection closed")

if __name__ == "__main__":
    create_client()
