from django.shortcuts import render
from django.http import HttpResponse
from .models import images
from django.db.models import Q

# Create your views here.
def signup(request):
    return render(request, 'signup.html')

def responsive(request):
    if request.method == "POST":
        # image_data2 = images.objects.values_list('name')
        # image_data2 = images.objects.filter(name='laptop').values()
        # image_data2 = images.objects.filter(Q(name='laptop') | Q(name='com') ).values()
        image_data2 = images.objects.filter(name__startswith='k').values()
        image_data = images.objects.all()
        print('image_data2===========',image_data2)
        # print(image_data)
        # data={
        #     'name':image_data.name,
        #     'image_path': image_data.
        # }
        # for img in image_data:
        #     image_path= img.image.url
        # print(image_path)
        # username = request.POST.get('123')
        # email = request.POST.get('1234')
        # data= {"name": username,
        #        "email":email,
        #        'image': image_path}
        return render(request, "display.html", {'data':image_data})
        # return HttpResponse(f'Received username: {username} {email}')
