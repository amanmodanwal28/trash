import socket
import subprocess
# subprocess.Popen(["./abcd"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)

def run_c_file():
    # import subprocess

    # Command to execute
    command = "gcc -fPIC -shared -o clibrary.so hello.c"

    # Execute the command
    try:
        subprocess.run(command, shell=True, check=True)
        print("Compilation successful.")
    except subprocess.CalledProcessError as e:
        print("Compilation failed:", e)

run_c_file()

# # Define host and port
# HOST = '192.168.11.200'  # Standard loopback interface address (localhost)
# PORT = 65432        # Port to listen on (non-privileged ports are > 1023)

# # Create a socket object
# with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
#     # Bind the socket to the address and port
#     server_socket.bind((HOST, PORT))
    
#     # Listen for incoming connections
#     server_socket.listen()

#     print("Server is listening for incoming connections...")

#     # Accept a connection
#     conn, addr = server_socket.accept()
#     with conn:
#         print('Connected by', addr)
        
#         while True:
#             # Receive data from the client
#             data = conn.recv(1024)
#             if not data:
#                 break
#             print("Received:", data.decode())
            
#             # Echo the received data back to the client
#             conn.sendall(data)

