import paramiko as pm

class AllowAllKeys(pm.MissingHostKeyPolicy):
    def missing_host_key(self, client, hostname, key):
        return

HOST = '192.168.11.200'
USER = 'root'
PASSWORD = ''

def execute_command(ssh_client, command):
    stdin, stdout, stderr = ssh_client.exec_command(command)
    return stdout.read().decode('utf-8')

def main():
    # Create an SSH client instance
    client = pm.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(AllowAllKeys())
    
    # Connect to the SSH server 
    try:
        client.connect(hostname=HOST, username=USER, password=PASSWORD)
        print(f"Connected to {HOST}")

        command = 'ls'
        output = execute_command(client, command)
        print("Directory listing:")
        print(output)
        
        # # List directories and files in the root directory
        # command = 'ls -la /'
        # output = execute_command(client, command)
        # print("Directory listing:")
        # print(output)
        
        # # Example: Create a new directory
        # command = 'mkdir /home/root/new_directory'
        # execute_command(client, command)
        # print("Created directory '/home/root/new_directory'")
        
        # # Example: Remove the created directory
        # command = 'rm -r /home/root/new_directory'
        # execute_command(client, command)
        # print("Removed directory '/home/root/new_directory'")
        
    except Exception as e:
        print(f"Failed to connect or execute commands: {e}")
    
    # Close the connection
    finally:
        client.close()
        print("SSH connection closed")

if __name__ == "__main__":
    main()

