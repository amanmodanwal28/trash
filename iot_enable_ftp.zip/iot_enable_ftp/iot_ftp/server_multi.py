import socket
import threading
import os
import sqlite3
import datetime
import struct
import time

SERVER_HOST = '0.0.0.0' # Accept connections on any interface
SERVER_PORT = 8010      # Port to listen on
BUFFER_SIZE = 1024      # Buffer size for receiving data

def handle_client(client_socket, client_address):
    print(f"Accepted connection from {client_address}")
    header = client_socket.recv(1)
    print('header===',header)
    data_type = int(header[0])
    db_path='D:\\machine_learning\\iot_enable_remote_control\\iot_enable_ftp\\iot_enable.sqlite3'
    # Connect to the database
    connection = sqlite3.connect(db_path)
    # Create a cursor object to interact with the database
    cursor = connection.cursor()
    # print(header)
    # print(data_type)
    if data_type==0:
            print("i am in file transfer condition")
        # # data = client_socket.recv(BUFFER_SIZE)
        # # print(data)
        # try:
            # Receive file name first
            # file_path = client_socket.recv(1024).decode('utf-8')
            # print("file_path===",file_path)
            current_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            directory = 'received_files'
            os.makedirs(directory, exist_ok=True)

            file_name = f'received_{current_time}.py'
            file_path = os.path.join(directory, file_name)
            print(file_path)

            # Open a new file to write received data
            with open(file_path, 'wb') as file:
                while True:
                    data = client_socket.recv(BUFFER_SIZE)
                    if not data:
                        break
                    file.write(data)            
            print(f"File received successfully: {file_name}")
        #     print('file_name====',file_name)
        #     # if file_name!=None:
        #     print("in if condition")
        #     header = bytes([1])
            # try:
            # file_path="D:\\machine_learning\\iot_enable_remote_control\\using_pyqt5\\main.ui"
            print("Starting file transmission")
            with open(file_path, 'rb') as file:
                file_data = file.read()
                file_size = len(file_data)
                print(f"File size: {file_size} bytes")
                # Send the file size to the client
                client_socket.sendall(struct.pack('!Q', file_size))
                print("File size sent successfully")
                # Send the file data to the client in chunks
                # chunk_size = 4096
                # for i in range(0, file_size, chunk_size):
                #     client_socket.sendall(file_data[i:i+chunk_size])
                # print("File data sent successfully")
            # except Exception as e:
            #     print(f"Error: {e}")
            # else: 
            #     pass

        # except Exception as e:
        #     print(f"Error occurred with client {client_address}: {e}")

        # finally:
        #     # client_socket.close()
        #     print(f"Connection with {client_address} closed")

    elif int(data_type)==2:
        while True:
            # Receive data from the client
            data = client_socket.recv(1024).decode()[-6:]
            # print(data)
            if not data:
                break
            # print(f"Received from {client_address}: {data}")
            # now =datetime.datetime.now()
            # print(now)
            insert_query = '''
                            INSERT INTO iot_ftp_status (ip, port, status) VALUES (?,?,?)
                            '''
            # Data to be inserted
            data1 = (client_address[0], client_address[1],data)
            # Execute the query with data
            cursor.execute(insert_query, data1)
            # Commit the changes
            connection.commit()     

def start_server():
    # Create a TCP/IP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Bind the socket to the address and port
    server_socket.bind((SERVER_HOST, SERVER_PORT))

    # Enable listening mode
    server_socket.listen(5)
    print(f"Server listening on {SERVER_HOST}:{SERVER_PORT}")

    try:
        while True:
            # Wait for incoming connections
            client_socket, client_address = server_socket.accept()

            # Create a new thread to handle the client
            client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
            client_thread.start()

    except KeyboardInterrupt:
        print("Server shutting down")
    
    # finally:
    #     server_socket.close()

if __name__ == "__main__":
    start_server()
