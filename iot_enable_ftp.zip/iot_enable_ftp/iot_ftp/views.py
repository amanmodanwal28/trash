
from django.shortcuts import render
from django.http import JsonResponse
from .models import Status
import os
from django.conf import settings
from .forms import UploadFileForm
import socket
import time
from django.db.models import OuterRef, Subquery
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from datetime import datetime , timedelta

previous_data = None
check_ip_list=None

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home/')  # Replace 'home' with your homepage URL name
        else:
            # Return an 'invalid login' error message.
            return render(request, 'login.html', {'error': 'Invalid login credentials'})
    return render(request, 'login.html')

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('home')  # Replace 'home' with your homepage URL name
    else:
        form = UserCreationForm()
    return render(request, 'sign.html', {'form': form})

def redirect_view(request):
    if request.user.is_authenticated:
        return redirect('home/')  # Replace 'home' with your homepage URL name
    else:
        return redirect('signup')

def index(request):
    global check_ip_list,client_socket
    checked_ips = request.POST.get('checked_ips', '')
    checked_ips_list = checked_ips.split(',') if checked_ips else []


    if request.method == 'POST':
        if checked_ips_list!=[]:
            check_ip_list=checked_ips_list[0]
            print('check_ip_list====',check_ip_list)
            with open('server_storage/selected_ips.txt', 'wb') as file:
                    file.write(check_ip_list.encode())
            form = UploadFileForm(request.POST, request.FILES)
            if form.is_valid():
                print("open file")
                uploaded_file = request.FILES['file']
                # Construct the file path using MEDIA_ROOT
                file_path = os.path.join(settings.MEDIA_ROOT, 'uploaded_files', uploaded_file.name)
                # print("file_path=======", file_path)
                with open('server_storage/selected_file_name.txt', 'wb') as file:
                    file.write((uploaded_file.name).encode())

                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                # Save the file
                with open(file_path, 'wb+') as destination:
                    for chunk in uploaded_file.chunks():
                        destination.write(chunk)
                # tcp_host.send_file(file_path)
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                # client_socket.connect(('103.76.138.125', 8010))
                client_socket.connect(('192.168.0.206', 8010))
                with open(file_path, 'rb') as file:
                    # Read and send the file in chunks
                    while True:
                        # print("hellololooooooooooooooo")
                        chunk = file.read(1024)  # Read 1024 bytes from the file
                        if not chunk:
                            break  # End of file
                        header = bytes([0])
                        client_socket.sendall(header + chunk)  # Send the chunk over the socket
                        # print('sended==============')
                    client_socket.close()
            print(f"File sent successfully.")
            messages.success(request, 'File sent successfully.')
            return redirect(request.path_info)
        else:
            messages.success(request, 'First select IP then choose file.')
            return redirect('/home')
    return render(request, 'index.html')

def get_detail(request):   ####for getting details module
    global check_ip_list,client_socket
    checked_ips = request.POST.get('checked_ips', '')
    checked_ips_list = checked_ips.split(',') if checked_ips else []
    detail ={}
    # if checked_ips_list==[]:
    #     return

    if checked_ips_list!=[]:
        check_ip_list=checked_ips_list[0]
        # print('check_ip_list====',check_ip_list)
        with open('server_storage/selected_ips.txt', 'wb') as file:
                file.write(check_ip_list.encode())
        latest_device = Status.objects.filter(ip=check_ip_list, status_date__isnull=False).latest('status_date')
        connected_devices = latest_device.connected_devices
        print('connected_devices ================= ',connected_devices)
        if connected_devices:
            if '06' in connected_devices:
                detail['LED'] = 'Healthy'
            else:
                detail['LED'] = 'Unhealthy'
            if '07' in connected_devices:
                detail['LCD'] = 'Healthy'
            else:
                detail['LCD'] = 'Unhealthy'
            if '08' in connected_devices:
                detail['ETBU'] = 'Healthy'
            else:
                detail['ETBU'] = 'Unhealthy'
            if '09' in connected_devices:
                detail['EBU'] = 'Healthy'
            else:
                detail['EBU'] = 'Unhealthy'
        return render(request, 'detail.html', {'detail': detail})
    else:
        # return render(request, 'detail.html', {'detail': 'Please fresh the page'})
        messages.success(request, 'Please select IP.')
        # return render(request, 'index.html')
        return redirect('/home')


def latest_status(request):
    # global previous_data

    # statuses__ = Status.objects.all()
    # print(statuses__)

    # for status in statuses__:
    #     print(f'id: {status.id}, ip: {status.ip}, port: {status.port}, status: {status.status}, client_id: {status.client_id}, status_date: {status.status_date}, device_conn: {status.device_conn}')
    # Subquery to get the latest status_date for each ip
    latest_status_date = Status.objects.filter(
        ip=OuterRef('ip')
    ).order_by('-status_date').values('status_date')[:1]

    # print('Subquery SQL:', latest_status_date.query)
    # Query to get the distinct statuses with the latest status_date
    statuses = Status.objects.filter(
        status_date=Subquery(latest_status_date)
    ).order_by('ip')


    # print('Subquery SQL:', latest_status_date.query)
    # print('Main Query SQL:', statuses.query)
    # Prepare data for the response
    data = []
    for status in statuses:
        # print('status====',status.status_date)
        status_data = {
            'id': status.id,
            'ip': status.ip,
            # 'port': status.port,
            'status': status.status,
            # 'client_id': status.client_id,
            'status_date': status.status_date,
        }
        data.append(status_data)
    # print(data)
    now = datetime.now()
    formatted_time = now.strftime('%H:%M:%S')
    # for p_data in previous_data:
    for index, status_data in enumerate(data):
        status_date = status_data['status_date']  # Assuming this is a datetime.time object

        # Convert status_date to a datetime object with the current date
        status_datetime = datetime.combine(now.date(), status_date)

        # Calculate the difference between now and status_datetime
        time_diff = now - status_datetime
        # print("time_diff========",time_diff)
        # print( timedelta(seconds=1))
        # Check if the difference is less than 4 seconds
        print(data)
        if abs(time_diff) > timedelta(seconds=2):
            print("data[index]['status']====",data[index]['status'])
            data[index]['status'] = 'Unhealthy'
            # print(data)
            return JsonResponse(data, safe=False)
        else:
            # print("dataelse,",data)
            return JsonResponse(data, safe=False)


    # if (formatted_time-status_data['status_date'])>4:
    #     # print("datat===",data[index]['id'],data[index]['ip'])
    #     data[index]['status']='xx0003'   #for active
    #     return JsonResponse(data, safe=False)
    # elif (formatted_time-status_data['status_date'])<4:
    #     return JsonResponse(data, safe=False)

    # # # Check if the data has changed
    # if previous_data!=None:
    #     # for p_data in previous_data:
    #     #     for index, status_data in enumerate(data):
    #     #         if p_data['id']!=status_data['id'] and p_data['ip'] == status_data['ip']:
    #     #             # print("datat===",data[index]['id'],data[index]['ip'])
    #     #             data[index]['status']='xx0001'   #for active
    #     #         elif p_data['id']==status_data['id'] and p_data['ip']== status_data['ip']:
    #     #             data[index]['status']='xx0002'   #for inactive
    #     # previous_data=data
    #     return JsonResponse(data, safe=False)
    # else:
    #     # previous_data=data
    #     # print("data=(((*)))==",data)
    #     return JsonResponse(data, safe=False)


