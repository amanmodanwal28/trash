from django.db import models
from django.utils import timezone

class Status(models.Model):
    ip = models.CharField(max_length=15)
    port = models.IntegerField()
    status = models.CharField(max_length=15)
    train_id = models.CharField(max_length=15,default='null')
    coach_id = models.CharField(max_length=15,default='null')
    train_number = models.CharField(max_length=15,default='null')
    client_id=models.IntegerField(default=0)
    status_date=models.TimeField(default=timezone.now)
    type=models.CharField(max_length=15,default='null')
    serial_number=models.CharField(max_length=15,default='null')
    version=models.CharField(max_length=15,default='null')
    connected_devices=models.CharField(max_length=15,default='null')

    def __str__(self):
        return f"{self.ip}:{self.port} - {self.status}"

# class ips(models.Modal):
#     ip=models.CharField(max_length=200)   

# class file(models.Modal):
#     file_name=models.CharField(max_length=200)       
    
    
class UploadedFile(models.Model):
    file = models.FileField(upload_to='uploads/')
    uploaded_at = models.DateTimeField(auto_now_add=True) 

class Signup(models.Model):   
    username = models.CharField(max_length=15)
    password = models.CharField(max_length=15) 
    
  
