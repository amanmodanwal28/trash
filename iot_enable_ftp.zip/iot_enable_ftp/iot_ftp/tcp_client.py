import socket
import time
import struct
import threading
import os


# Define host and port
HOST = '103.76.138.125' # The server's hostname or IP address
#HOST = '192.168.11.27'
PORT = 8010             # The port used by the server

def details_file(client_socket):
    while True:
        print("hello")
        head= client_socket.recv(1)
        print('head======================',head)
        data_type = int(head[0])
        if data_type!=3:
            continue

def recv_all(sock, size):
    data = b''
    while len(data) < size:
        packet = sock.recv(size - len(data))
        if not packet:
            return None
        data += packet
    return data

def receive_file(client_socket):
    directory = 'tmp'
    os.makedirs(directory, exist_ok=True)
    
    # Set a timeout for the socket
    client_socket.settimeout(20)  # Increased timeout to 20 seconds
    
    while True:
        try:
            #print("Waiting to receive header...")
            head = client_socket.recv(1)
            if not head:
                print("Connection closed by the server")
                break
            
            #print('head======================', head)
            header = int(head[0])
            
            if header == 0:
                while True:
                    try:
                        # Receive the file name size first
                        raw_file_name_size = client_socket.recv(4)
                        
                        if len(raw_file_name_size) < 4:
                            print("Failed to receive the complete file name size")
                            continue
                        print("len(raw_file_name_size)======", len(raw_file_name_size))
                        file_name_size = struct.unpack('!I', raw_file_name_size)[0]
                        print(f"File name size: {file_name_size} bytes")
                        
                        # Receive the file name
                        file_name = recv_all(client_socket, file_name_size).decode('utf-8').strip()
                        print(f"Receiving file: {file_name}")

                        # Receive the file size
                        raw_file_size = client_socket.recv(8)
                        if len(raw_file_size) < 8:
                            print("Failed to receive the complete file size")
                            continue

                        file_size = struct.unpack('!Q', raw_file_size)[0]
                        print(f"File size: {file_size} bytes")

                        # Receive the file data
                        file_data = b''
                        bytes_received = 0
                        while bytes_received < file_size:
                            chunk = client_socket.recv(min(file_size - bytes_received, 64))
                            if not chunk:
                                print("Connection closed prematurely")
                                break
                            file_data += chunk
                            bytes_received += len(chunk)

                        if bytes_received == file_size:
                            with open(os.path.join(directory, file_name), 'wb') as f:
                                f.write(file_data)
                            header = int(head[6])
                            client_socket.sendall(header)
                            print("File received successfully")
                        else:
                            print("File reception incomplete")
			
                    except socket.timeout:
                        print("Timeout occurred while receiving data")
                        time.sleep(5)  # Wait before trying again
                    except Exception as e:
                        print(f"An error occurred while receiving the file: {e}")
                        time.sleep(5)  # Wait before trying again
                    # print("helololololololololololololo========================================")
                    break
            elif header == 3:
                print("I am able to send file back")
                with open('detail.txt', 'rb') as file:
                    chunk = file.read()  # Read 1024 bytes from the file
                    if not chunk:
                        break  # End of file
                    header = bytes([2])
                    client_socket.sendall(header + chunk) 

        except socket.timeout:
            print("Timeout occurred while waiting for header")
        except Exception as e:
            print(f"An error occurred: {e}")
            break  # Exit the loop if any other exception occurs
            # with open('detail.txt', 'rb') as file:
            #     chunk = file.read()  # Read 1024 bytes from the file
            #     if not chunk:
            #         break  # End of file
            #     header = bytes([4])
                # client_socket.sendall(header + chunk)           

def rename_delete_line(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    if not lines:
        return None
    
    first_line = lines[0]
    
    with open(file_path, 'w') as file:
        file.writelines(lines[1:])  
    
    new_file_path = os.path.join('tmp', first_line.strip())
    
    # Rename the file
    os.rename(file_path, new_file_path)            

def connect_and_send_messages():
    header = bytes([2])
    while True:
        try:
            # Create a TCP socket object
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
                # Connect to the server
                client_socket.connect((HOST, PORT))
                print(f"Connected to {HOST}:{PORT}")
                client_socket.settimeout(10)
                
                # Start the receive file thread
                # head= client_socket.recv(1)
                # print('head======================',head)
                # data_type = int(head[0])
                receive_thread = threading.Thread(target=receive_file, args=(client_socket,))
                receive_thread.daemon = True  # Daemonize thread to exit when main program exits
                receive_thread.start()
                # receive_thread.join()

                # details_thread = threading.Thread(target=details_file, args=(client_socket,))
                # details_thread.daemon = True  # Daemonize thread to exit when main program exits
                # details_thread.start()
                # details_thread.join()
                
                while True:
                    message = "0104040404050506070809"
                    # print(header+message.encode())
                    client_socket.sendall(header + message.encode())
                    # print("Message sent, waiting for file...")
                    time.sleep(1)
                    
        except (ConnectionRefusedError, ConnectionResetError, BrokenPipeError) as e:
            print(f"Connection error: {e}. Reconnecting in 5 seconds...")
            time.sleep(5)
        except Exception as e:
            print(f"An unexpected error occurred: {e}. Reconnecting in 5 seconds...")
            time.sleep(5)

if __name__ == "__main__":
    connect_and_send_messages()







# file_header = client_socket.recv(1)
# if file_header == bytes([1]):  # Example file header indicator
#     # Receive file size
#     file_size_bytes = client_socket.recv(4)
#     file_size = int.from_bytes(file_size_bytes, byteorder='big')
    
#     # Receive file content
#     received_bytes = b''
#     while len(received_bytes) < file_size:
#         chunk = client_socket.recv(min(file_size - len(received_bytes), 4096))
#         if not chunk:
#             raise RuntimeError("File transfer interrupted.")
#         received_bytes += chunk
    
#     # Save or process received file (replace with your handling logic)
#     with open('received_file.txt', 'wb') as f:
#         f.write(received_bytes)
#         print("File received successfully.")