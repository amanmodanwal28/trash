$(document).ready(function(){
    $('#myButton').click(function(){
        $.ajax({
            url: '/your-django-url/',
            method: 'GET',
            success: function(response) {
                alert('Request was successful!');
                // Handle the response from the server here
                console.log(response);
            },
            error: function(error) {
                alert('An error occurred.');
                // Handle any errors that occurred during the request
                console.log(error);
            }
        });
    });
});
