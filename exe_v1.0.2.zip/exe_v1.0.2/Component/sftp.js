const fs = require('fs')
const { Client } = require('ssh2')
const ping = require('ping')
const path = require('path')
const logger = require('./logger') // Import your logger
let mainWindow
let results = [] // Define results array globally to store data for all IPs

const mainWindowfn = (window) => {
  mainWindow = window
}
// SFTP connection details
const privateKeyPath = path.join(__dirname, '../auth/PTCS_key11.ppk') // Adjust the private key path as necessary

async function connection(ipAddress) {
  return new Promise((resolve, reject) => {
    const conn = new Client()

    // Try to connect with private key
    const tryPrivateKey = () => {
      const privateKey = fs.readFileSync(privateKeyPath)
      conn.connect({
        host: ipAddress,
        username: 'root',
        privateKey: privateKey,
      })
    }

    // Try to connect with alternative username and password
    const tryUsernamePassword = () => {
      conn.connect({
        host: ipAddress,
        username: 'ptcs',
        password: 'ptcs', // Replace 'ptcs' with the actual password if necessary
      })
    }

    conn
      .on('ready', () => {
        logger.info(`connection: Connected successfully to ${ipAddress}`)
        resolve(conn)
      })
      .on('error', (err) => {
        if (err.level === 'client-authentication') {
          // Retry with username 'ptcs' and password if private key fails
          // logger.warn(
          //   `connection: Private key authentication failed for ${ipAddress}, retrying with username 'ptcs' and password`
          // )
          tryUsernamePassword()
        } else {
          logger.error(
            `connection: SFTP connection error to ${ipAddress}: ${err.message}`
          )
          console.log(err)
          reject(err)
        }
      })

    // Start by trying the private key
    tryPrivateKey()
  })
}

async function uploadFile(sftp, localPath, remotePath) {
  return new Promise((resolve, reject) => {
    sftp.fastPut(localPath, remotePath, (err) => {
      if (err) {
        logger.error(
          `uploadFile: Error uploading file from ${localPath} to ${remotePath}: ${err.message}`
        )
        reject(err)
      } else {
        logger.info(
          `uploadFile: File successfully uploaded from ${localPath} to ${remotePath}`
        )
        resolve()
      }
    })
  })
}

async function checkRemoteFileExists(sftp, remotePath) {
  return new Promise((resolve, reject) => {
    sftp.stat(remotePath, (err, stats) => {
      if (err) {
        if (err.code === 2) {
          // No such file or directory
          logger.info(
            `checkRemoteFileExists: Remote file does not exist: ${remotePath}`
          )
          resolve(false)
        } else {
          logger.error(
            `checkRemoteFileExists: Error checking remote file existence for ${remotePath}: ${err.message}`
          )
          reject(err)
        }
      } else {
        logger.info(`checkRemoteFileExists: Remote file exists: ${remotePath}`)
        resolve(true)
      }
    })
  })
}

function checkIP(ip, aliance_name) {
  return new Promise((resolve) => {
    ping.sys.probe(ip, function (isAlive) {
      const status = isAlive ? 'active' : 'inactive'
      resolve({ ip, aliance_name, status })
    })
  })
}

async function findContentFolder(conn) {
  return new Promise((resolve, reject) => {
    const command = `
      find / -type d -name "content" -exec sh -c '
        for dir; do
          if [ -d "$dir/movies" ] && [ -d "$dir/poster" ] && [ -d "$dir/music" ]; then
            echo "$dir"
          fi
        done
      ' sh {} + || echo "No matching folders found"
    `

    conn.exec(command, (err, stream) => {
      if (err) {
        logger.error('findContentFolder: Error executing SSH command')
        return reject(err)
      }

      let output = ''

      stream
        .on('close', (code, signal) => {
          if (code === 0) {
            logger.info('findContentFolder: Command executed successfully')
          } else {
            logger.warn(`findContentFolder: Command failed with code ${code}`)
          }

          // Filter and extract valid folder paths
          const lines = output.split('\n').filter((line) => {
            const trimmedLine = line.trim()
            return (
              trimmedLine.startsWith('/') &&
              trimmedLine.includes('/src/content') &&
              !trimmedLine.includes('logout')
            )
          })

          const cleanedPaths = lines.map((line) => line.replace(/\r/g, ''))
          // resolve(cleanedPaths)

          // Set ServerContentPath to the first valid folder with /src/content
          if (cleanedPaths.length > 0) {
            const ServerContentPath = cleanedPaths[0] // Use the first valid path
            logger.info(
              `findContentFolder: ServerContentPath set to ${ServerContentPath}`
            )
            resolve(ServerContentPath)
          } else {
            logger.warn(
              'findContentFolder: No valid folder containing /src/content found'
            )
            resolve(null) // Return null if no valid folder is found
          }
        })
        .on('data', (data) => {
          output += data.toString()
        })
        .on('error', (err) => {
          logger.error('findContentFolder: Error during stream processing')
          reject(err)
        })
    })
  })
}

async function checkVersionAndConnect(ipList) {
  // Store successfully connected IPs to avoid reconnecting
  const connectedIps = new Set()

  for (const { ip, aliance_name, status } of ipList) {
    // Skip inactive IPs and the one already connected
    if (status === 'active' && ip !== '192.168.0.3' && !connectedIps.has(ip)) {
      try {
        // logger.info(
        //   `checkVersionAndConnect: Attempting to connect to active IP - ${ip} (${aliance_name})`
        // )

        // Attempt to establish an SFTP connection
        const conn = await connection(ip)

        // logger.info(
        //   `checkVersionAndConnect: Successfully connected to ${ip} (${aliance_name})`
        // )

        // Mark the IP as connected
        connectedIps.add(ip)

        // Call findContentFolder after connection is established
        let contentFolderPath = await findContentFolder(conn)

        // If no content folder is found, use the default folder
        if (!contentFolderPath) {
          contentFolderPath = '/home/ptcs/Desktop/ppsWebsite/src/content'
          logger.warn(
            `checkVersionAndConnect: No content folder found on ${ip} (${aliance_name}), using default path: ${contentFolderPath}`
          )
        } else {
          logger.info(
            `checkVersionAndConnect: Found content folder at ${contentFolderPath}`
          )
        }

        // Now, check for the INDEX.SYS file in /database folder
        const databasePath = contentFolderPath + '/database/INDEX.SYS'


        try {
          await readFileWithCat(conn, databasePath,ip)
        } catch (err) {
          logger.error(
            `checkVersionAndConnect: Failed to read INDEX.SYS from ${databasePath}: ${err.message}`
          )
        }


        // Close the connection after use
        conn.end()
      } catch (error) {
        logger.error(
          `checkVersionAndConnect: Failed to connect to ${ip} (${aliance_name}): ${error.message}`
        )
      }
    } else {
      // logger.info(
      //   `checkVersionAndConnect: Skipping IP - ${ip} (${aliance_name}) because it's either inactive or already connected`
      // )
    }
  }
}


// Function to read the content of a file using 'cat' command
async function readFileWithCat(conn, filePath,ip) {
  return new Promise((resolve, reject) => {
    conn.exec(`cat ${filePath}`, (err, stream) => {
      if (err) {
        reject(new Error(`Failed to execute 'cat' command: ${err.message}`))
        return
      }

      let fileData = ''
      stream.on('data', (data) => {
        fileData += data.toString()
      })

      stream.on('end', () => {
        if (fileData) {
          // logger.info(`File contents of ${filePath}:\n${fileData}`)
           parseIndexSysData(fileData, ip)
          resolve(fileData)
        } else {
          reject(new Error(`No data received for file ${filePath}`))
        }
      })

      stream.on('error', (err) => {
        reject(new Error(`Stream error: ${err.message}`))
      })
    })
  })
}

const parseIndexSysData = (data, ip) => {
  const rows = data.split('\n')

  rows.forEach((row) => {
    row = row.trim()
    if (row === '') return

    const parts = row.split(/\s+/)

    if (parts.length >= 3) {
      const size = parts[1]
      const filename = parts.slice(2).join(' ')

      if (size === '00000000') {
        const version_name = filename

        // Create a JSON object for the current data
        const newData = {
          ip,
          version_name,
        }

        // Filter out existing data with the same ip
        results = results.filter((item) => item.ip !== newData.ip)

        // Add the new data to results
        results.push(newData) // Add the new data to the results array
logFinalResults()
        console.log("Updated results:", results);
      }
    }
  })
}

// Deduplicate the results array and log the final output
const logFinalResults = () => {

  // Send the unique results to the main window (for Electron)
  if (mainWindow && mainWindow.webContents) {
    mainWindow.webContents.send("Database_version_name_module", results);
     console.log('Updated results2:', results)
  }

}



module.exports = {
  mainWindowfn,
  connection,
  checkIP,
  uploadFile,
  checkRemoteFileExists,
  findContentFolder,
  checkVersionAndConnect,
}
