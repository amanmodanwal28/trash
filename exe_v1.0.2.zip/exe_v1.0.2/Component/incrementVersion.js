function incrementVersion(line) {
  console.log(line, ' vvvvvvvvvvvvvvvv')

  // Match the line format with 'DB Ver: 1.0.0'
  const versionMatch = line.match(/^(.*?)(DB Ver:\s*(\d+)\.(\d+)\.(\d+))(.*)$/)

  if (versionMatch) {
    let beforeVersion = versionMatch[1] // The part before 'DB Ver'
    let versionPart = versionMatch[2] // The part with 'DB Ver: 1.0.0'
    let major = parseInt(versionMatch[3])
    let minor = parseInt(versionMatch[4])
    let patch = parseInt(versionMatch[5])
    let afterVersion = versionMatch[6] // The part after 'DB Ver: 1.0.0'

    // Increment the patch version
    patch++

    // Check if patch has reached 99
    if (patch > 99) {
      patch = 0 // Reset patch to 0
      minor++ // Increment minor version
    }

    // Check if minor has reached 99
    if (minor > 99) {
      minor = 0 // Reset minor to 0
      major++ // Increment major version
    }

    // Construct the updated version line
    const updatedVersion = `DB Ver: ${major}.${minor}.${patch}`

    // Return the complete line with the updated version
    return `${beforeVersion}${updatedVersion}${afterVersion}`
  }

  return line // Return the original line if it doesn't match the expected format
}

module.exports = { incrementVersion }
