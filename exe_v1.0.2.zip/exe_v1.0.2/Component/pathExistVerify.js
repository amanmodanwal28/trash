const path = require('path')
const fs = require('fs')
const logger = require('./logger')
const os = require('os')

function pathExistsSync(p) {
  try {
    fs.accessSync(p, fs.constants.F_OK)
    return true
  } catch (err) {
    return false
  }
}

function checkPathsSync(xmlFilePath, sourceFfmpegDir) {
  // Check in installationPath
  if (pathExistsSync(xmlFilePath) && pathExistsSync(sourceFfmpegDir)) {
    logger.info(
      `checkPathsSync: Found XML file and FFmpeg directory in installationPath`
    )
    return { xmlFilePath, sourceFfmpegDir }
  }

  // Update paths to __dirname if not found in installationPath
  xmlFilePath = path.join(__dirname, '../resources/', 'Iot_Config.xml')
  sourceFfmpegDir = path.join(__dirname, '../resources/', 'ffmpeg')

  if (os.platform() === 'win32') {
    sourceFfmpegDir = path.join(__dirname, '../resources', 'ffmpeg')
  } else if (os.platform() === 'linux') {
    sourceFfmpegDir = path.join(__dirname, '../resources', 'ffmpeg_linux')
  } else {
    logger.error(`Unsupported platform: ${os.platform()}`)
  }
  // Check in __dirname
  if (pathExistsSync(xmlFilePath) && pathExistsSync(sourceFfmpegDir)) {
    logger.info(
      `checkPathsSync: Found XML file and FFmpeg directory in __dirname`
    )
    logger.info(
      `checkPathsSync: xml => ${xmlFilePath}, ffmpeg => ${sourceFfmpegDir}`
    )
    return { xmlFilePath, sourceFfmpegDir }
  }

  // If not found in both
  logger.error(
    `checkPathsSync: Files or directories not found in both installationPath and __dirname.`
  )

  return null // Return null or any appropriate value if paths are not found
}

module.exports = {
  checkPathsSync,
}
