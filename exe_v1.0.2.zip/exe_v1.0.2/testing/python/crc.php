<?php
function generateCRC32Table() {
    $table = [];
    $polynomial = 0xedb88320;
    for ($i = 0; $i < 256; $i++) {
        $crc = $i;
        for ($j = 8; $j > 0; $j--) {
            $crc = ($crc & 1) ? ($crc >> 1) ^ $polynomial : $crc >> 1;
        }
        $table[$i] = $crc;
    }
    return $table;
}

function calculateCRC32($filePath) {
    $crc = 0xffffffff;
    $chunkSize = 8192; // 8KB
    $table = generateCRC32Table();

    if (!file_exists($filePath)) throw new Exception("File not found: $filePath");
    $handle = fopen($filePath, 'rb') or throw new Exception("Unable to open file: $filePath");

    while (!feof($handle)) {
        $chunk = fread($handle, $chunkSize);
        foreach (str_split($chunk) as $byte) {
            $crc = ($crc >> 8) ^ $table[($crc ^ ord($byte)) & 0xff];
        }
    }

    fclose($handle);
    return sprintf('%08X', ($crc ^ 0xffffffff) & 0xffffffff);
}

function calculateFileCRC32($filePath) {
    $checksum = calculateCRC32($filePath);
    echo "CRC32 Checksum: $checksum\n";
    return ['checksum' => $checksum];
}

// Example usage
try {
    $filePath = 'Aur Kya Mujhe.mp4';
    calculateFileCRC32($filePath);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>