const fs = require('fs')

// CRC32 Lookup Table
const CRC32_TABLE = (() => {
  const table = []
  const polynomial = 0xedb88320

  for (let i = 0; i < 256; i++) {
    let crc = i
    for (let j = 8; j > 0; j--) {
      if (crc & 1) {
        crc = (crc >>> 1) ^ polynomial
      } else {
        crc = crc >>> 1
      }
    }
    table[i] = crc
  }
  return table
})()

const calculateCRC32 = (data) => {
  let crc = 0xffffffff
  for (let i = 0; i < data.length; i++) {
    const byte = data[i]
    crc = (crc >>> 8) ^ CRC32_TABLE[(crc ^ byte) & 0xff]
  }
  return (crc ^ 0xffffffff) >>> 0
}

const calculateFileCRC32 = (filePath) => {
  return new Promise((resolve, reject) => {
    // Get file stats to retrieve file size
    fs.stat(filePath, (err, stats) => {
      if (err) {
        return reject(`Error retrieving file stats: ${err.message}`)
      }

      const fileSize = stats.size
      // console.log(`File Size: ${fileSize} bytes`)

      const stream = fs.createReadStream(filePath)
      let dataChunks = []

      stream.on('data', (chunk) => {
        dataChunks.push(chunk)
      })

      stream.on('end', () => {
        const buffer = Buffer.concat(dataChunks)
        const crc32 = calculateCRC32(buffer)
        const checksum = crc32.toString(16).toUpperCase().padStart(8, '0')
        console.log(`CRC32 Checksum: ${checksum}`)
        resolve({ checksum, fileSize })
      })

      stream.on('error', (error) => {
        console.error(`Error calculating CRC32: ${error.message}`)
        reject(error)
      })
    })
  })
}

// Example usage
calculateFileCRC32('./Aur Kya Mujhe.mp4')
  .then(({ checksum, fileSize }) => {
  })
  .catch(console.error)
