function incrementVersion(version) {

  // Match the version pattern: DB Ver: 1:0:0
  const versionMatch = version.match(/DB Ver:\s*(\d+):(\d+):(\d+)/)
//  console.log(versionMatch)
  if (versionMatch) {
    let major = parseInt(versionMatch[1])
    let minor = parseInt(versionMatch[2])
    let patch = parseInt(versionMatch[3])

    // Increment the patch version
    patch++

    // Check if patch has reached 99
    if (patch > 99) {
      patch = 0 // Reset patch to 0
      minor++ // Increment minor version
    }

    // Check if minor has reached 99
    if (minor > 99) {
      minor = 0 // Reset minor to 0
      major++ // Increment major version
    }

    // Return the new version string
    return `DB Ver: ${major}:${minor}:${patch}`
  }

  return version // Return the original version if it doesn't match
}
console.log(incrementVersion('DB Ver: 1:0:1'))  // DB Ver: 1:0:2
console.log(incrementVersion('DB Ver: 1:0:99')) // DB Ver: 1:1:0
console.log(incrementVersion('DB Ver: 99:99:99')) // DB Ver: 1:2:0

