// const path = require('path')

// async function getPathAfterDirectory(filePath, dirToFind) {
//   const parts = filePath.split(path.sep)
//   const index = parts.indexOf(dirToFind)

//   if (index === -1 || index === parts.length - 1) {
//     return '' // Directory not found or it's the last segment
//   }

//   // Extract parts after the found directory
//   const slicedParts = parts.slice(index + 1)

//   // Convert each part to lowercase except the last element
//   const modifiedParts = slicedParts.map((part, i) =>
//     i === slicedParts.length - 1 ? part : part.toLowerCase()
//   )

//   // Join the modified parts to form the path
//   let resultPath = path.join(...modifiedParts)

//   console.log('Parts after split:', parts)
//   console.log('Slice starting after the found directory:', ...slicedParts)
//   console.log('Modified parts:', ...modifiedParts)
//   console.log('Joined path after modification:', resultPath)

//   // Convert backslashes to forward slashes (for consistent URL-like paths)
//   resultPath = resultPath.replace(/\\/g, '/')
//   console.log('Converted path:', resultPath)

//   return '/' + resultPath // Return the result with a leading slash
// }

// // Example usage:
// const filePath =
//   'C:\\Users\\PTCS\\Downloads\\1\\w\\Poster\\videos\\regional2\\VAideoAdvertismentTime.txt'
// const dirToFind = 'w'

// getPathAfterDirectory(filePath, dirToFind)
//   .then((result) => console.log('Resulting Path:', result))
//   .catch((err) => console.error('Error:', err))
