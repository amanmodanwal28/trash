const { ipcRenderer } = require('electron');


window.onload = async () => {
  try {
    // Get IP and alliance data from the main process
    const ipAddresses = await ipcRenderer.invoke('get-ip-addresses');
  
    if (ipAddresses.length === 0) {
      console.log('No IP addresses found.');
      return;
    }  

    // Create the list of IP addresses with checkboxes
    const ipListElement = document.getElementById('ip-list');
    const selectedIps = [];  // Store selected IPs

    ipAddresses.forEach((ipData) => {
      // Create a list item with checkbox and status
      const listItem = document.createElement('li');
      listItem.innerHTML = `
        <input type="checkbox" id="checkbox-${ipData.ip}" class="ip-checkbox">
        <label for="checkbox-${ipData.ip}" class="checkbox-label"></label>
        <span><strong>${ipData.alianceName}</strong></span>
        <span class="status-icon" id="status-${ipData.ip}"></span>
      `;

      // Append the list item to the list
      ipListElement.appendChild(listItem);

      // Set initial status
      const statusIcon = document.getElementById(`status-${ipData.ip}`);
      updateStatusIcon(statusIcon, ipData.status);

      // Checkbox click event
      const checkbox = document.getElementById(`checkbox-${ipData.ip}`);
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) {
          checkbox.classList.add('checked');
          selectedIps.push(ipData.ip); // Add IP to selected
        } else {
          checkbox.classList.remove('checked');
          const index = selectedIps.indexOf(ipData.ip);
          if (index > -1) selectedIps.splice(index, 1); // Remove IP from selected
        }
        ipcRenderer.send('selectedIps', selectedIps);
        console.log('Selected IPs:', selectedIps);
      });
    });

    // Listen for status updates from the main process
    ipcRenderer.on('ip-status-update', (event, updatedIpData) => {
      const statusIcon = document.getElementById(`status-${updatedIpData.ip}`);
      if (statusIcon) {
        updateStatusIcon(statusIcon, updatedIpData.status);
      }
    });

    // Listen for folder status message and update text on the page
    ipcRenderer.on('folder-status', (event, message) => {
      const folderStatusElement = document.getElementById('folder-status');
      if (folderStatusElement) {
        folderStatusElement.textContent = message; // Display folder status in normal text
      }
    });

  } catch (error) {
    console.error('Error loading IP addresses:', error);
  }
};

// Function to update the status icon 
function updateStatusIcon(statusIcon, status) {
  if (status === 'active') {
    statusIcon.innerHTML = '✔️'; // Green checkmark for active
    statusIcon.style.color = 'green';
  } else {
    statusIcon.innerHTML = '❌'; // Red cross for inactive
    statusIcon.style.color = 'red';
  }
}

const chooseDirButton = document.getElementById('chooseDirButton');
const submitButton = document.getElementById('submitButton');
const folderStatusElement = document.getElementById('folder-status');

// Open the directory dialog when "Choose Directory" button is clicked
chooseDirButton.addEventListener('click', () => {
  ipcRenderer.send('choose-directory'); // Send event to main process to open directory dialog
});

let selectedDirectory = ''; // Variable to store the selected directory

submitButton.addEventListener('click', () => {
  if (!selectedDirectory) {
    // Show "No directory selected" message if no directory is selected
    if (folderStatusElement) {
      folderStatusElement.textContent = 'No directory selected! Please choose a directory first.';
    }
    return;
  }
 
// Listen for the selected directory from the main process
ipcRenderer.on('selected-directory', (event, directory) => {
  selectedDirectory = directory; // Update the selected directory
  console.log('Selected directory:', selectedDirectory);

  // Update folder status message
  if (folderStatusElement) {
    folderStatusElement.textContent = `Selected Directory: ${selectedDirectory}`; // Display selected directory
  }
});
  // Send the directory to the main process and display success message
  ipcRenderer.send('submit-directory', selectedDirectory);
  console.log('Directory submitted:', selectedDirectory);

  if (folderStatusElement) {
    folderStatusElement.textContent = 'Folder submitted successfully!'; // Success message after submission
  }
 // Log the directory
});
 
// Listen for the selected directory from the main process
ipcRenderer.on('selected-directory', (event, directory) => {
  selectedDirectory = directory; // Set selected directory
  console.log('Selected directory:', selectedDirectory);
  const folderStatusElement = document.getElementById('folder-status');
  if (folderStatusElement) {
    folderStatusElement.textContent = `Selected Directory: ${selectedDirectory}`; // Update folder status text
  }
});
