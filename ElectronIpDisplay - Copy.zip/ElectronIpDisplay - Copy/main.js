const { app, BrowserWindow, ipcMain, Menu, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const ping = require('ping');

let mainWindow;
let selectedDirectory = null;  // Variable to store selected directory
let ipAddresses = [];  // Array to store the IP addresses

const requiredSubfolders = [
  'index.sys',
  'videoadvertisementtime.txt',
  'add',
  'add2',
  'poster',
  'videos',
  'kidszone',
  'img',
  'music',
  'movies',
  'advertisment',
];

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    resizable: false, // Disable resizing
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
  });

  mainWindow.loadFile('index.html');
  createMenu(); // Call custom menu function
}

function createMenu() {
  const menuTemplate = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Choose Directory',
          accelerator: 'Ctrl+D',
          click: async () => {
            const result = await dialog.showOpenDialog(mainWindow, {
              properties: ['openDirectory'],
            });
            if (!result.canceled) {
              const directoryPath = result.filePaths[0];
              console.log('Selected Directory:', directoryPath);
              mainWindow.webContents.send('directory-chosen', directoryPath); // Send to renderer
              checkSubfolders(directoryPath); // Check subfolders
            }
          },
        },
        { type: 'separator' },
        { role: 'quit' },
      ],
    },
    {
      label: 'Tools',
      submenu: [
        {
          label: 'Open Toggle Developer Tools',
          accelerator: 'CmdOrCtrl+I',
          click: () => {
            mainWindow.webContents.toggleDevTools();
          },
        },
        {
          label: 'Refresh',
          accelerator: 'CmdOrCtrl+R',
          click: () => {
            mainWindow.reload();
          },
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(() => {
  createWindow();

  ipcMain.handle('get-ip-addresses', async () => {
    try {
      const xmlPath = path.join(__dirname, 'resources', 'Iot_Config.xml');
      const xmlData = fs.readFileSync(xmlPath, 'utf-8');
      const ipAddresses = extractIpAddresses(xmlData);
      startMonitoring(ipAddresses);
      return ipAddresses;
    } catch (error) {
      console.error('Error reading XML:', error);
      return [];
    }
  });

  ipcMain.on('selectedIps', (event, selectedIps) => {
    console.log('Selected IPs:', selectedIps);
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

function extractIpAddresses(xmlData) {
  const ipAddresses = [];
  const regex = /<Ipaddress ip="([^"]+)" aliance_name="([^"]+)"/g;
  let match;

  while ((match = regex.exec(xmlData)) !== null) {
    ipAddresses.push({
      ip: match[1],
      alianceName: match[2],
      status: 'inactive',
    });
  }

  return ipAddresses;
}

function startMonitoring(ipAddresses) {
  console.log('Starting network monitoring');
  const hostStatus = {};

  ipAddresses.forEach((ipData) => {
    hostStatus[ipData.ip] = false;
  });

  setInterval(async () => {
    try {
      const pingPromises = ipAddresses.map((ipData) =>
        ping.promise.probe(ipData.ip)
      );

      const results = await Promise.all(pingPromises);

      results.forEach((res, index) => {
        const ipData = ipAddresses[index];
        const wasAlive = hostStatus[ipData.ip];
        hostStatus[ipData.ip] = res.alive;

        if (res.alive !== wasAlive) {
          ipData.status = res.alive ? 'active' : 'inactive';
          mainWindow.webContents.send('ip-status-update', ipData);
        }
      });
    } catch (error) {
      console.error(`Error in network monitoring: ${error.message}`);
    }
  }, 1000);
}

// Function to check if required subfolders exist
function checkSubfolders(directory) {
  const folderNames = fs.readdirSync(directory).map((name) => name.toLowerCase());
  const missingFolders = requiredSubfolders.filter((subfolder) => !folderNames.includes(subfolder));

  if (missingFolders.length === 0) {
    mainWindow.webContents.send('folder-status', 'Folder selected successfully');
    setTimeout(() => {
      mainWindow.webContents.send('folder-status', ''); // Clear status after 2-3 seconds
    }, 3000);
  } else {
    console.log('Missing subfolders:', missingFolders.join(', '));
    mainWindow.webContents.send('folder-status', `Missing subfolders: ${missingFolders.join(', ')}`);

  }
}

// Handle directory selection from renderer
ipcMain.on('choose-directory', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory'],
  });
  if (!result.canceled) {
    const directoryPath = result.filePaths[0];
    console.log('Selected Directory:', directoryPath);
    mainWindow.webContents.send('directory-chosen', directoryPath);
    checkSubfolders(directoryPath); // Check subfolders
  }
});
