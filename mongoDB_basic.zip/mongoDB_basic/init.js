const mongoose = require('mongoose')
const Chat = require('./models/chat')
main()
  .then((res) => {
    console.log('connection successfull')
  })
  .catch((err) => {
    console.log(err)
  })

  let chats = [
    {
      from: 'neha',
      to: 'garv',
      msg: 'this is my first testing',
      created_at: new Date('2024-12-17T10:00:00'),
    },
    {
      from: 'garv',
      to: 'neha',
      msg: 'Hello Neha, how are you?',
      created_at: new Date('2024-12-17T10:05:00'),
    },
    {
      from: 'neha',
      to: 'garv',
      msg: "I'm good, thanks! How about you?",
      created_at: new Date('2024-12-17T10:10:00'),
    },
    {
      from: 'garv',
      to: 'neha',
      msg: "I'm doing well, just a bit busy with work.",
      created_at: new Date('2024-12-17T10:15:00'),
    },
    {
      from: 'neha',
      to: 'garv',
      msg: 'That sounds exhausting! Take care of yourself.',
      created_at: new Date('2024-12-17T10:20:00'),
    },
    {
      from: 'garv',
      to: 'neha',
      msg: "I will, thanks! Let's catch up soon.",
      created_at: new Date('2024-12-17T10:25:00'),
    },
    {
      from: 'neha',
      to: 'garv',
      msg: 'For sure! Take care!',
      created_at: new Date('2024-12-17T10:30:00'),
    },
    {
      from: 'rajesh',
      to: 'kavita',
      msg: 'Good morning Kavita, did you complete the report?',
      created_at: new Date('2024-12-17T11:00:00'),
    },
    {
      from: 'kavita',
      to: 'rajesh',
      msg: 'Morning! Yes, I finished it and sent it to you.',
      created_at: new Date('2024-12-17T11:05:00'),
    },
    {
      from: 'rajesh',
      to: 'kavita',
      msg: "Great! I'll review it now.",
      created_at: new Date('2024-12-17T11:10:00'),
    },
    {
      from: 'kavita',
      to: 'rajesh',
      msg: 'Let me know if you need any changes.',
      created_at: new Date('2024-12-17T11:15:00'),
    },
    {
      from: 'raj',
      to: 'simran',
      msg: "Hey Simran, what's up?",
      created_at: new Date('2024-12-17T12:00:00'),
    },
    {
      from: 'simran',
      to: 'raj',
      msg: 'Not much, just relaxing. You?',
      created_at: new Date('2024-12-17T12:05:00'),
    },
    {
      from: 'raj',
      to: 'simran',
      msg: 'Same here, just catching up on some shows.',
      created_at: new Date('2024-12-17T12:10:00'),
    },
    {
      from: 'simran',
      to: 'raj',
      msg: 'Sounds fun! What shows are you watching?',
      created_at: new Date('2024-12-17T12:15:00'),
    },
    {
      from: 'raj',
      to: 'simran',
      msg: "I'm watching that new thriller on Netflix. It's really good!",
      created_at: new Date('2024-12-17T12:20:00'),
    },
    {
      from: 'simran',
      to: 'raj',
      msg: "I'll check it out! Thanks for the recommendation.",
      created_at: new Date('2024-12-17T12:25:00'),
    },
  ]



// Chat.insertMany(chats)
Chat.find()

// //  Delete all chats where 'from' is 'anita'
// Chat.deleteMany({ from: 'vishal' })
//   .then((result) => {
//     console.log(`${result.deletedCount} chats deleted`)
//   })
//   .catch((error) => {
//     console.error('Error deleting chats:', error)
//   })

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/whatsapp')
}
