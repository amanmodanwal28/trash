const mongoose = require("mongoose");


async function  main(){
  await mongoose.connect("mongodb://127.0.0.1:27017/amazon")
}

main().then((res) => {
  console.log("connection establized")
}).catch((err) => {
  console.log(err)
})

const bookSchema = new mongoose.Schema({
  title: {
    type: String,
    required:true
  },
  author: {
    type:String
  },
  price: {
    type:String
  }
})

const Book = mongoose.model('Book', bookSchema)

const book1 = new Book({
  title: "maths XII",
  author: "RD Sharma",
  price: 590
})
// 6762cde0ad28e0e02e43b207

book1.save().then((res) => {
  console.log(res)
}).catch((err) => {
  console.log(err)
})
