const QRCode = require('qrcode')
const Jimp = require('jimp')

async function generateQRCodeWithLogo() {
  const url = 'http://ptwifibox.in'
  const qrCodePath = 'qrcode_with_logo.png'
  const logoPath = './pt_logo.png' // Make sure this path is correct

  try {
    // Generate QR Code
    const qrCodeBuffer = await QRCode.toBuffer(url, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 600,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })

    // Load QR code and logo images
    const qrCodeImage = await Jimp.read(qrCodeBuffer)
    const logoImage = await Jimp.read(logoPath)

    // Resize the logo to 20% of QR code size
    const qrCodeWidth = qrCodeImage.bitmap.width
    const logoSize = qrCodeWidth * 0.2
    logoImage.resize(logoSize, logoSize)

    // Center the logo on the QR code
    const x = (qrCodeWidth - logoSize) / 2
    const y = (qrCodeWidth - logoSize) / 2

    // Composite logo onto QR code
    qrCodeImage.composite(logoImage, x, y, {
      mode: Jimp.BLEND_SOURCE_OVER,
      opacitySource: 1,
    })

    // Save the final QR code with logo
    await qrCodeImage.writeAsync(qrCodePath)
    console.log('QR code with logo generated successfully:', qrCodePath)
  } catch (error) {
    console.error('Error generating QR code with logo:', error)
  }
}

generateQRCodeWithLogo()
