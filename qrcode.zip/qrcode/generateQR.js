const QRCode = require('qrcode')
const fs = require('fs')

// URL to encode in the QR code
const url = 'http://ptwifibox.in'

// Generate QR code and save it as an image
QRCode.toFile(
  'qrcode.png',
  url,
  {
    color: {
      dark: '#000000', // Black for the QR code
      light: '#ffffff', // White background
    },
  },
  (err) => {
    if (err) {
      console.error('Error generating QR code:', err)
    } else {
      console.log('QR code generated successfully: qrcode.png')
    }
  }
)
