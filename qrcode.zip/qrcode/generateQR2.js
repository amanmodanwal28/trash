const QRCode = require('qrcode')
const fs = require('fs')

const generateStyledQRCode = async () => {
  const url = 'http://ptwifibox.in'

  const options = {
    width: 600, // Increase the size
    margin: 2, // Less margin
    color: {
      dark: '#000000', // QR code color (dark modules)
      light: '#ffffff', // Background color
    },
    errorCorrectionLevel: 'H', // High error correction allows logos or designs
  }

  try {
    const qrCodeData = await QRCode.toDataURL(url, options)

    // Convert base64 data URL to image
    const base64Data = qrCodeData.replace(/^data:image\/png;base64,/, '')
    fs.writeFileSync('styled_qrcode.png', base64Data, 'base64')

    console.log('Styled QR code generated successfully: styled_qrcode.png')
  } catch (error) {
    console.error('Error generating QR code:', error)
  }
}

generateStyledQRCode()
