const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const sqlite3 = require("sqlite3").verbose();
const logger = require("./logger");
const { app } = require("electron");

const isDevelopment = !app.isPackaged;

let dbPath;
if (isDevelopment) {
  dbPath = path.resolve(__dirname, "auth.sqlite");
  console.log("Development Mode: Using local database path");
} else {
  dbPath = path.join(app.getPath("userData"), "auth.db");
  console.log("Production Mode: Using user data path");
}

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    logger.error("Error opening database: " + err.message);
  } else {
    logger.info(`SQLite database file path: ${dbPath}`);
  }
});

let isFirstTimeSetup = !fs.existsSync(dbPath);

db.serialize(() => {
  db.run(
    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL
    )`,
    (err) => {
      if (err) {
        
        logger.error("Error creating users table: " + err.message);
      } else {
        db.get("SELECT COUNT(*) as count FROM users", (err, row) => {
          if (err) {
            logger.error("Error checking user count: " + err.message);
            isFirstTimeSetup = true;
          } else {
            isFirstTimeSetup = row.count === 0;
            if (isFirstTimeSetup) {
              console.log(
                "No users found or first-time setup detected. Redirecting to sign-up.",
              );
            } else {
              console.log(
                "Database and user table detected. Proceed to login.",
              );
            }
          }
        });
      }
    },
  );
});

function insertNewUser(username, password) {
  return new Promise((resolve) => {
    bcrypt.hash(password, 10, (err, hashedPassword) => {
      if (err) {
        logger.error("Error hashing password: " + err.message);
        return resolve({ success: false, message: "Hashing error" });
      }
      db.run(
        "INSERT INTO users (username, password) VALUES (?, ?)",
        [username, hashedPassword],
        (err) => {
          if (err) {
            logger.error("Error inserting user: " + err.message);
            resolve({ success: false, message: "Error creating user." });
          } else {
            logger.info("New user inserted successfully.");
            resolve({ success: true, message: "User created successfully." });
          }
        },
      );
    });
  });
}

function getStoredHashedPassword(username) {
  return new Promise((resolve) => {
    db.get(
      "SELECT password FROM users WHERE username = ?",
      [username],
      (err, row) => {
        if (err) {
          logger.error("Error fetching user: " + err.message);
          resolve(null);
        } else {
          resolve(row ? row.password : null);
        }
      },
    );
  });
}

async function updatePasswordInDatabase(username, oldPassword, newPassword) {
  return new Promise((resolve) => {
    db.get(
      "SELECT password FROM users WHERE username = ?",
      [username],
      async (err, row) => {
        if (err || !row) {
          logger.warn("The username or password is incorrect.");
          return resolve({
            success: false,
            message: "The username or password is incorrect.",
          });
        }

        const isMatch = await bcrypt.compare(oldPassword, row.password);
        if (!isMatch) {
          logger.warn("Old password does not match.");
          return resolve({
            success: false,
            message: "Old password does not match.",
          });
        }

        if (oldPassword === newPassword) {
          logger.warn("New password cannot be the same as the old one.");
          return resolve({
            success: false,
            message: "The new password cannot be the same as the old password.",
          });
        }

        bcrypt.hash(newPassword, 10, (hashErr, newHashedPassword) => {
          if (hashErr) {
            logger.error("Hashing error: " + hashErr.message);
            return resolve({ success: false, message: "Hashing error" });
          }

          db.run(
            "UPDATE users SET password = ? WHERE username = ?",
            [newHashedPassword, username],
            (updateErr) => {
              if (updateErr) {
                logger.error("Error updating password: " + updateErr.message);
                return resolve({ success: false, message: "Update failed." });
              }
              logger.info(`Password for ${username} updated successfully.`);
              return resolve({
                success: true,
                message: "Password updated successfully.",
              });
            },
          );
        });
      },
    );
  });
}

module.exports = {
  isFirstTimeSetup,
  insertNewUser,
  getStoredHashedPassword,
  updatePasswordInDatabase,
};
