const { DeviceSSHManager } = require('./DeviceSSHManager1') // Adjust path as needed

// Configuration
const TARGET_IPS = ['192.168.10.101', '192.168.10.102']
const LOCAL_FILE =
  'C:\\Users\\AMAN-RND\\Downloads\\j\\Old_Content_data\\movies\\regional2\\Luck.mp4'
const REMOTE_PATH = '/home/ptcs/Desktop/Alan Walkerb.mp4'

async function uploadToDevice(ip, localPath, remotePath) {
  const manager = new DeviceSSHManager(ip)

  try {
    console.log(`\n📡 Connecting to ${ip}...`)
    await manager.connect()

    console.log(`📤 Uploading file to ${ip}...`)
    console.log(`   Local: ${localPath}`)
    console.log(`   Remote: ${remotePath}`)

    await manager.uploadFile(localPath, remotePath)

    console.log(`✅ Upload completed successfully to ${ip}`)

    await manager.close()

    return {
      ip,
      status: 'success',
      message: 'Upload completed'
    }
  } catch (error) {
    console.error(`❌ Upload failed for ${ip}: ${error.message}`)

    await manager.close().catch(() => {})

    return {
      ip,
      status: 'failed',
      message: error.message
    }
  }
}

async function uploadToAllDevices() {
  console.log('='.repeat(60))
  console.log('🚀 Starting upload to multiple devices')
  console.log('='.repeat(60))
  console.log(`Target IPs: ${TARGET_IPS.join(', ')}`)
  console.log(`Local File: ${LOCAL_FILE}`)
  console.log(`Remote Path: ${REMOTE_PATH}`)
  console.log('='.repeat(60))

  const results = []

  // Upload to each device sequentially
  for (const ip of TARGET_IPS) {
    const result = await uploadToDevice(ip, LOCAL_FILE, REMOTE_PATH)
    results.push(result)
  }

  // Summary
  console.log('\n' + '='.repeat(60))
  console.log('📊 UPLOAD SUMMARY')
  console.log('='.repeat(60))

  results.forEach(result => {
    const icon = result.status === 'success' ? '✅' : '❌'
    console.log(`${icon} ${result.ip} - ${result.status.toUpperCase()}`)
    if (result.status === 'failed') {
      console.log(`   Error: ${result.message}`)
    }
  })

  const successCount = results.filter(r => r.status === 'success').length
  const failCount = results.filter(r => r.status === 'failed').length

  console.log('='.repeat(60))
  console.log(`✅ Success: ${successCount} | ❌ Failed: ${failCount}`)
  console.log('='.repeat(60))
}

// Run the upload
uploadToAllDevices()
  .then(() => {
    console.log('\n✨ Process completed')
    process.exit(0)
  })
  .catch(error => {
    console.error('\n💥 Fatal error:', error)
    process.exit(1)
  })