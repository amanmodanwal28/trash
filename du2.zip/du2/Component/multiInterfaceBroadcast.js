const dgram = require('dgram')
const os = require('os')

const PORT = 8002

const TARGET_IPS = [
  '192.168.0.243',
  '192.168.10.101',
  '192.168.0.3',
  '192.168.99.5',
]

const MESSAGE = Buffer.from('MESSAGE_FROM_SPUT_TOOL')

const SEND_INTERVAL = 10000
const NETWORK_CHECK_INTERVAL = 2500

let sockets = []
let lastSignature = ''
let networkMonitorTimer = null
let isRunning = false

// ---------------------------------------------

function getNetworkSignature() {
  const interfaces = os.networkInterfaces()
  const list = []

  Object.values(interfaces).forEach((ifaces) => {
    ifaces.forEach((iface) => {
      if (iface.family === 'IPv4' && !iface.internal) {
        list.push(iface.address)
      }
    })
  })

  return list.sort().join('|')
}

// ---------------------------------------------

function startSending() {
  stopSending()

  const interfaces = os.networkInterfaces()

  Object.keys(interfaces).forEach((ifaceName) => {
    interfaces[ifaceName].forEach((iface) => {
      if (iface.family === 'IPv4' && !iface.internal) {
        const socket = dgram.createSocket('udp4')

        socket.on('error', (err) => {
          console.error(`[${ifaceName}] socket error:`, err.message)
        })

        socket.bind(0, iface.address, () => {
          console.log(`📡 Sending via ${ifaceName} (${iface.address})`)

          const timer = setInterval(() => {
            TARGET_IPS.forEach((ip) => {
              socket.send(MESSAGE, PORT, ip, (err) => {
                if (err) {
                  console.error(
                    `Send failed → ${iface.address} → ${ip}:${PORT}`,
                    err.message,
                  )
                }
              })
            })
          }, SEND_INTERVAL)

          sockets.push({ socket, timer })
        })
      }
    })
  })
}

// ---------------------------------------------

function stopSending() {
  sockets.forEach(({ socket, timer }) => {
    clearInterval(timer)
    socket.close()
  })

  sockets = []
  isRunning = false
}

// ---------------------------------------------

function monitorNetwork() {
  if (networkMonitorTimer) return // prevent duplicate interval

  networkMonitorTimer = setInterval(() => {
    const currentSignature = getNetworkSignature()

    if (currentSignature !== lastSignature) {
      console.log('🔄 Network change detected, restarting UDP sender...')
      lastSignature = currentSignature
      startSending()
    }
  }, NETWORK_CHECK_INTERVAL)
}

// ---------------------------------------------

function stopMonitorNetwork() {
  if (networkMonitorTimer) {
    clearInterval(networkMonitorTimer)
    networkMonitorTimer = null
  }
}

// ---------------------------------------------

function startMultiInterfaceBroadcast() {
  if (isRunning) {
    console.log('⚠ Multicast already running')
    return
  }

  console.log('🚀 Starting multicast broadcast...')

  lastSignature = getNetworkSignature()
  startSending()
  monitorNetwork()

  isRunning = true
}

// ---------------------------------------------

function stopMultiInterfaceBroadcast() {
  console.log('🛑 Stopping multicast broadcast...')

  stopSending()
  stopMonitorNetwork()
}

// ---------------------------------------------

module.exports = {
  startMultiInterfaceBroadcast,
  stopMultiInterfaceBroadcast,
}
