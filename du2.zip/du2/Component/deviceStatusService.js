const express = require('express')
const app = express()
const ping = require('ping')

// ✅ FIX
const devices = new Map()

const TIMEOUT = 4000
const CLEAN_INTERVAL = 1000

// =============================
// Ping based
// =============================
function checkIP(ip, aliance_name) {
  return new Promise((resolve) => {
    ping.sys.probe(ip, function (isAlive) {
      const status = isAlive ? 'active' : 'inactive'
      const DB_Version = isAlive ? 'Loading' : 'DB Ver: _._._'

      resolve({ ip, aliance_name, status, DB_Version })
    })
  })
}

// =============================
// Heartbeat manual diff check
// =============================
function checkIP2(ip, aliance_name) {
  return new Promise((resolve) => {
    if (!devices.has(ip)) {
      devices.set(ip, {
        name: aliance_name,
        lastSeen: 0,
        status: 'inactive',
      })
    }

    const device = devices.get(ip)

    const diff = Date.now() - device.lastSeen
    const status = diff <= TIMEOUT ? 'active' : 'inactive'

    const DB_Version = status === 'active' ? 'Loading' : 'DB Ver: _._._'

    resolve({
      ip,
      aliance_name: device.name,
      status,
      DB_Version,
    })
  })
}

// =============================
// Map monitored status
// =============================
function checkIP3(ip, aliance_name) {
  if (!devices.has(ip)) {
    devices.set(ip, {
      name: aliance_name,
      lastSeen: 0,
    })
  }

  const device = devices.get(ip)

  // ⭐ Dynamic status calculation
  const isAlive = Date.now() - device.lastSeen < TIMEOUT

  const status = isAlive ? 'active' : 'inactive'

  return {
    ip,
    aliance_name,
    status,
    DB_Version: status === 'active' ? 'Loading' : 'DB Ver: _._._',
  }
}

// =============================
// Heartbeat receiver
// =============================
app.get('/heartbeat', (req, res) => {
  const ip = req.query.ip
  const name = req.query.name || 'Unknown'

  devices.set(ip, {
    name,
    lastSeen: Date.now(),
    status: 'active',
  })

  res.send('ok')
})

// =============================
// Monitor loop
// =============================
setInterval(() => {
  const now = Date.now()

  for (const [ip, device] of devices.entries()) {
    const diff = now - device.lastSeen

    device.status = diff <= TIMEOUT ? 'active' : 'inactive'
  }
}, CLEAN_INTERVAL)

app.listen(6000, '0.0.0.0', () =>
  console.log('Heartbeat monitor running on 0.0.0.0:6000'),
)

module.exports = { checkIP, checkIP2, checkIP3 }
