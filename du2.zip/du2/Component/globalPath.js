const path = require('path')
const fs = require('fs')
const os = require('os')
// ================= ELECTRON SAFE LOAD =================
let app
let isElectron = false
// ================= DEV / PROD =================
const isDev = isElectron ? !app.isPackaged : true
try {
  app = require('electron').app
  isElectron = !!app
} catch {
  isElectron = false
}

// ================= INSTALLATION PATH =================
const INSTALLATION_PATH = path.dirname(process.execPath)



// ================= RESOURCES BASE =================
const RESOURCE_DIR = isDev
  ? path.join(__dirname, '..', 'resources')
  : path.join(process.resourcesPath, 'resources')


// -------------------------------
// XML CONFIG PATH
// -------------------------------
function resolveXmlPath() {
  let xmlPath = path.join(RESOURCE_DIR, 'Iot_Config.xml')

  if (!fs.existsSync(xmlPath)) {
    xmlPath = path.join(
      INSTALLATION_PATH,
      'resources',
      'resources',
      'Iot_Config.xml'
    )
  }

  return xmlPath
}

// ================= FFMPEG =================
// -------------------------------
// FFMPEG DIRECTORY
// -------------------------------
function resolveFfmpegPath() {
  const platform = os.platform()

  // Default resource ffmpeg path
  let ffmpegPath =
    platform === 'win32'
      ? path.join(RESOURCE_DIR, 'ffmpeg')
      : path.join(RESOURCE_DIR, 'ffmpeg_linux')

  // ✅ If exists → return directly
  if (fs.existsSync(ffmpegPath)) {
    return ffmpegPath
  }

  // ✅ Fallback → Installation directory
  let fallbackPath =
    platform === 'win32'
      ? path.join(INSTALLATION_PATH, 'resources', 'resources', 'ffmpeg')
      : path.join(INSTALLATION_PATH, 'resources', 'resources', 'ffmpeg_linux')

  if (fs.existsSync(fallbackPath)) {
    return fallbackPath
  }

  throw new Error(`FFmpeg not found for platform: ${platform}`)
}

// -------------------------------
// Final Resolved Paths
// -------------------------------
const XML_CONFIG_PATH = resolveXmlPath()
const FFMPEG_DIR = resolveFfmpegPath()
// ================= SERVER PATHS =================
const SERVER_CONTENT_PATH = '/home/ptcs/Iob/bin/IOB_Server/src/content'
const posix = path.posix

const SERVER_INDEX_SYS_PATH = posix.join(
  SERVER_CONTENT_PATH,
  'database',
  'INDEX.SYS',
)

const SERVER_INDEX_TXT_PATH = posix.join(
  SERVER_CONTENT_PATH,
  'database',
  'videoAdvertismentTime.txt',
)

// ================= DEBUG PRINT =================
function printAllPaths() {
  console.log('========== APP PATH CONFIG ==========')

  console.log('INSTALLATION_PATH →', INSTALLATION_PATH)
  console.log('RESOURCE_DIR →', RESOURCE_DIR)
  console.log('XML_CONFIG_PATH →', XML_CONFIG_PATH)
  console.log('FFMPEG_DIR →', FFMPEG_DIR)

  console.log('SERVER_CONTENT_PATH →', SERVER_CONTENT_PATH)
  console.log('SERVER_INDEX_SYS_PATH →', SERVER_INDEX_SYS_PATH)
  console.log('SERVER_INDEX_TXT_PATH →', SERVER_INDEX_TXT_PATH)

  console.log('isDev →', isDev)
  console.log('isElectron →', isElectron)

  console.log('=====================================')
}

// ================= EXPORT =================
module.exports = {
  INSTALLATION_PATH,
  RESOURCE_DIR,
  XML_CONFIG_PATH,
  FFMPEG_DIR,
  SERVER_CONTENT_PATH,
  SERVER_INDEX_SYS_PATH,
  SERVER_INDEX_TXT_PATH,
  isDev,
  printAllPaths,
}
