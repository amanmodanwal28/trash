const { app } = require("electron");
const { createLogger, format, transports } = require("winston");
const path = require("path");
const fs = require("fs");

// ✅ Electron-safe writable directory
const logsPath = path.join(app.getPath("userData"), "logs");

// Ensure directory exists
try {
  fs.mkdirSync(logsPath, { recursive: true });
} catch (e) {
  // last-resort fallback
  console.error("Failed to create log directory", e);
}

const logger = createLogger({
  level: "info",
  format: format.combine(
    format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    format.errors({ stack: true }),
    format.json(),
  ),
  transports: [
    new transports.File({
      filename: path.join(logsPath, "error.log"),
      level: "error",
    }),
    new transports.File({
      filename: path.join(logsPath, "combined.log"),
    }),
  ],
});

// Dev console only
if (!app.isPackaged) {
  logger.add(
    new transports.Console({
      format: format.combine(format.colorize(), format.simple()),
    }),
  );
}

module.exports = logger;
