const { BrowserWindow, screen } = require('electron')
const path = require('path')
const { getSavedWindowState, trackWindowState } = require('./windowState')
let store

// Function to create the splash screen
async function createSplashScreen() {
  const { default: Store } = await import('electron-store')
  store = new Store()

  const minWidth = 1200 // You can adjust this value as needed
  const minHeight = minWidth / 2
  const windowState = await getSavedWindowState(minWidth, minHeight)

  const splash = new BrowserWindow({
    width: windowState.width,
    height: windowState.height,
    minWidth: minWidth,
    minHeight: minHeight,
    x: windowState.x,
    y: windowState.y,
    frame: false, // Remove window frame
    icon: path.join(__dirname, '../public/assets/Logo/pps_logo.ico'),
    transparent: true,
    alwaysOnTop: true,
    resizable: false,
    show: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  })

  await trackWindowState(splash)

  // Load splash HTML file
  splash.loadFile(path.join(__dirname, '../public/HTML/splashScreen.html'))

  // Show only when ready
  splash.once('ready-to-show', () => {
    splash.show()
  })

  // Safety timeout to auto-close splash if main window doesn't open
  // This prevents splash from staying open indefinitely
  const splashTimeout = setTimeout(() => {
    if (splash && !splash.isDestroyed()) {
      console.warn('Splash screen auto-closed after timeout')
      splash.close()
    }
  }, 10000) // 10 seconds timeout

  // Clear timeout if splash closes normally
  splash.on('closed', () => {
    clearTimeout(splashTimeout)
  })

  return splash
}

module.exports = createSplashScreen
