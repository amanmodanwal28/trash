const SftpClient = require('ssh2-sftp-client')
const { Client: SSH } = require('ssh2')
const path = require('path')
const fs = require('fs')
const SERVER_CONTENT_PATH = '/home/ptcs/Iob/bin/IOB_Server/src/content'

const SERVER_INDEX_SYS_PATH = SERVER_CONTENT_PATH + '/database/INDEX.SYS'

const SERVER_INDEX_TXT_PATH =
  SERVER_CONTENT_PATH + '/database/videoAdvertismentTime.txt'
const { checkIP, checkIP2, checkIP3 } = require('./deviceStatusService')
let mainWindow
class DeviceSSHManager {
  constructor(host) {
    this.config = {
      host,
      port: 22,
      username: 'ptcs',
      password: 'Ptcs@!1357',
      readyTimeout: 10000, // ⚡ Increased for stability
      keepaliveInterval: 10000, // ⚡ Keep connection alive
      keepaliveCountMax: 3,
      // ⚡ Optimized cipher algorithms for speed
      algorithms: {
        cipher: [
          'aes128-gcm@openssh.com', // Fastest
          'aes256-gcm@openssh.com',
          'aes128-ctr',
          'aes192-ctr',
          'aes256-ctr',
        ],
        compress: ['none', 'zlib@openssh.com', 'zlib'],
      },
    }

    this.sftp = new SftpClient()
    this.ssh = new SSH()
    this.connected = false
  }

  // =========================
  // CONNECT
  // =========================
  async connect() {
    if (this.connected) return

    await this.sftp.connect(this.config)

    await new Promise((res, rej) => {
      this.ssh.on('ready', res).on('error', rej).connect(this.config)
    })

    this.connected = true
    // console.log(`✅ Connected ${this.config.host}`)
  }

  // =========================
  // RECONNECT
  // =========================
  async reconnect() {
    console.log('⚠ Reconnecting...')
    await this.close()
    await this.connect()
  }

  // =========================
  // FILE EXIST CHECK
  // =========================
  async fileExists(remotePath) {
    try {
      const exists = await this.sftp.exists(remotePath)
      return !!exists
    } catch {
      return false
    }
  }

  // =========================
  // ⚡ OPTIMIZED UPLOAD WITH RESUME
  // =========================
  async uploadFile(localPath, remotePath, options = {}) {

    await this._retry(async () => {
      const fileName = path.basename(localPath)

      // ========================================
      // ⚡ DIRECT COPY SMALL CONFIG FILES
      // ========================================
      if (
        fileName === 'INDEX.SYS' ||
        fileName === 'videoAdvertismentTime.txt'
      ) {
        console.log(`⚡ Direct copying config file → ${fileName}`)

        await this.sftp.fastPut(localPath, remotePath)

        console.log(` Uploaded → ${remotePath}`)

        return
      }

      // ========================================
      // NORMAL UPLOAD FLOW
      // ========================================

      const stats = fs.statSync(localPath)
      const fileSize = stats.size

      let remoteSize = 0
      try {
        const stat = await this.sftp.stat(remotePath)
        remoteSize = stat.size
      } catch {}

      // Skip if already uploaded
      if (remoteSize === fileSize) {
        console.log(`✅ Already uploaded → ${remotePath}`)
        return
      }

      // ========================================
      // ⚡ DYNAMIC CONFIGURATION BASED ON FILE SIZE
      // ========================================
      let config = {
        highWaterMark: 256 * 1024, // 256KB default
        concurrency: 64, // SFTP concurrent requests
        chunkSize: 32768, // 32KB default chunk
        showProgress: options.showProgress !== false,
      }

      if (fileSize < 100 * 1024) {
        // Small files < 100KB
        config.highWaterMark = 64 * 1024 // 64KB
        config.concurrency = 32
        config.chunkSize = 16384 // 16KB
      } else if (fileSize < 10 * 1024 * 1024) {
        // Medium files < 10MB
        config.highWaterMark = 512 * 1024 // 512KB
        config.concurrency = 128
        config.chunkSize = 65536 // 64KB
      } else if (fileSize < 100 * 1024 * 1024) {
        // Large files < 100MB
        config.highWaterMark = 1024 * 1024 // 1MB
        config.concurrency = 256
        config.chunkSize = 131072 // 128KB
      } else {
        // Very large files > 100MB (300MB, 1GB)
        config.highWaterMark = 2 * 1024 * 1024 // 2MB
        config.concurrency = 512
        config.chunkSize = 262144 // 256KB
      }

      // ========================================
      // ⚡ PROGRESS TRACKING
      // ========================================
      let uploadedBytes = remoteSize
      let lastProgress = 0
      const startTime = Date.now()

      const showProgress = () => {
        const progress = ((uploadedBytes / fileSize) * 100).toFixed(1)
        const elapsed = (Date.now() - startTime) / 1000
        const speed = uploadedBytes / elapsed / (1024 * 1024) // MB/s

        if (
          parseFloat(progress) - lastProgress >= 5 ||
          uploadedBytes === fileSize
        ) {
          // console.log(
          //   `📤 ${remotePath.split('/').pop()} → ${progress}% ` +
          //   `(${(uploadedBytes / (1024 * 1024)).toFixed(1)}MB / ` +
          //   `${(fileSize / (1024 * 1024)).toFixed(1)}MB) ` +
          //   `@ ${speed.toFixed(2)} MB/s`
          // )
          lastProgress = parseFloat(progress)
        }
      }

      // ========================================
      // ⚡ OPTIMIZED SFTP OPTIONS
      // ========================================
      this.sftp.client.setMaxListeners(config.concurrency + 10)

      // Set SFTP options for better performance
      const sftpOptions = {
        concurrency: config.concurrency,
        chunkSize: config.chunkSize,
        step: (transferred, chunk, total) => {
          uploadedBytes = remoteSize + transferred
          if (config.showProgress) {
            showProgress()
          }
        },
      }

      // ========================================
      // ⚡ UPLOAD WITH FASTPUT (OPTIMIZED)
      // ========================================
      try {
        if (remoteSize > 0) {
          // Resume upload - use stream method
          const read = fs.createReadStream(localPath, {
            start: remoteSize,
            highWaterMark: config.highWaterMark,
          })

          const write = await this.sftp.createWriteStream(remotePath, {
            flags: 'a',
            encoding: null,
            highWaterMark: config.highWaterMark,
          })

          await new Promise((res, rej) => {
            let lastUpdate = Date.now()

            read.on('data', (chunk) => {
              uploadedBytes += chunk.length

              // Update progress every 500ms to avoid console spam
              if (config.showProgress && Date.now() - lastUpdate > 500) {
                showProgress()
                lastUpdate = Date.now()
              }
            })

            read.pipe(write).on('finish', res).on('error', rej)
          })
        } else {
          // New upload - use fastPut for better performance
          await this.sftp.fastPut(localPath, remotePath, sftpOptions)
        }

        // Final progress
        uploadedBytes = fileSize
        if (config.showProgress) {
          showProgress()
        }

        const totalTime = (Date.now() - startTime) / 1000
        const avgSpeed = fileSize / (1024 * 1024) / totalTime

        console.log(
          ` Uploaded → ${remotePath} ` +
            `(${(fileSize / (1024 * 1024)).toFixed(2)}MB in ${totalTime.toFixed(1)}s ` +
            `@ ${avgSpeed.toFixed(2)} MB/s avg)`,
        )
      } catch (error) {
        console.error(`❌ Upload error: ${error.message}`)
        throw error
      }
    })
  }
  // =========================
  // RUN COMMAND
  // =========================
  async exec(cmd) {
    return this._retry(
      () =>
        new Promise((res, rej) => {
          this.ssh.exec(cmd, (err, stream) => {
            if (err) return rej(err)

            let output = ''

            stream
              .on('data', (d) => (output += d))
              .on('close', () => res(output))
          })
        }),
    )
  }

  // =========================
  // VERIFY INDEX.SYS
  // =========================
  async verifyFromSys(remoteSysPath, ServerContentPath) {
    await this.connect()

    // ⭐ Read INDEX.SYS from board using SFTP
    const buffer = await this.sftp.get(remoteSysPath)
    const data = buffer.toString('utf8')

    // ⭐ Step 1 : Clean & split lines
    let lines = data
      .replace(/\r/g, '')
      .split('\n')
      .map((line) => line.trimEnd())

    let localPath = []
    let remotePath = []
    let textFileSize = []
    let textCrc = []

    // ⭐ Step 2 : Parse entries (Skip DB Ver & header automatically)
    lines.forEach((line) => {
      const parts = line.match(/^([A-F0-9]{8})\s+(\d+)\s+(.*)$/)

      if (parts && parts.length === 4) {
        const crc = parts[1]
        const size = parts[2]
        const filename = parts[3].trim()

        if (!localPath.includes(filename)) {
          localPath.push(filename)
          remotePath.push(ServerContentPath + filename)
          textFileSize.push(size)
          textCrc.push(crc)
        }
      }
    })

    // console.log('Parsed Paths:', remotePath)

    // ⭐ Step 3 : Verify file existence
    const missing = []
    const found = []

    for (const fullPath of remotePath) {


      const exist = await this.fileExists(fullPath)

      if (!exist) {
        // console.log(` Missing  ${fullPath}`)
        missing.push(fullPath)
      } else {
        found.push(fullPath)
      }
    }

    await this.close()

    // ⭐ Step 4 : Return Result
    return {
      success: missing.length === 0,
      total: remotePath.length,
      foundCount: found.length,
      missingCount: missing.length,
      missingFiles: missing,
      foundFiles: found,
    }
  }

  // =========================
  // GET DB VERSION + SONG LIST
  // =========================
  async getDBVersion(SERVER_INDEX_SYS_PATH) {
    await this.connect()

    try {
      const buffer = await this.sftp.get(SERVER_INDEX_SYS_PATH)
      const data = buffer.toString('utf8')

      const lines = data
        .replace(/\r/g, '')
        .split('\n')
        .map((l) => l.trim())

      let dbVersion = 'Unknown'

      lines.forEach((line) => {
        // ⭐ Extract DB Version
        const dbMatch = line.match(/DB\s*Ver:\s*([^\s]+)/i)
        if (dbMatch) {
          dbVersion = dbMatch[1]
        }
      })

      return {
        DB_Version: `DB Ver: ${dbVersion}`,
      }
    } catch (err) {
      console.log(`❌ ${this.config.host} DB read failed`, err.message)

      return {
        DB_Version: 'DB Ver: ERROR',
      }
    } finally {
      await this.close()
    }
  }

  // =========================
  // GET CONTENT AVAILABLE SPACE
  // =========================
  async getContentAvailableSpace() {
    await this.connect()

    try {
      const output = await this.exec(`du -sb ${SERVER_CONTENT_PATH} | cut -f1`)
      const folderBytes = parseInt(output.trim(), 10)

      const TOTAL_BYTES = 250 * 1024 * 1024 * 1024
      const availableBytes = TOTAL_BYTES - folderBytes

      const availableGB = (availableBytes / (1024 * 1024 * 1024)).toFixed(1)

      return {
        available: `${availableGB} GB`,
      }
    } catch (err) {
      console.log(`❌ ${this.config.host} space check failed`, err.message)

      return {
        available: 'ERROR',
      }
    }
  }

  // =========================
  // BULK FETCH FROM DEVICE LIST
  // =========================
  static async fetchDevicesRuntimeInfo(xml_result) {
    // Extract device list from XML
    const deviceList = xml_result.IOTConfig.Device_list.Ipaddress

    // Step 1 → Check status for all devices
    const statusResults = await Promise.all(
      deviceList.map((ip) => {
        // ⭐ OPTION 1 → Basic IP check
        // return checkIP(ip.$.ip, ip.$.aliance_name);

        // ⭐ OPTION 2 → Heartbeat / Alternate logic
        // return checkIP2(ip.$.ip, ip.$.aliance_name);

        // ⭐ OPTION 3 → Latest / Preferred logic
        return checkIP3(ip.$.ip, ip.$.aliance_name)
      }),
    )
    // Step 2 → Sort Active first
    statusResults.sort((a, b) => {
      const order = { active: 0, inactive: 1 }
      return order[a.status] - order[b.status]
    })

    const results = []

    for (const device of statusResults) {
      // Skip inactive devices but still return required structure

      // ✅ Skip inactive devices completely
      // if (device.status !== 'active') continue

      // Skip inactive devices but still return required structure
      if (device.status !== 'active') {
        results.push({
          ip: device.ip,
          aliance_name: device.aliance_name,
          status: device.status,
          DB_Version: 'DB Ver: _._._',
          available: 'offline',
        })

        continue
      }

      const manager = new DeviceSSHManager(device.ip)

      try {
        const dbInfo = await manager.getDBVersion(SERVER_INDEX_SYS_PATH)
        const spaceInfo = await manager.getContentAvailableSpace()

        results.push({
          ip: device.ip,
          aliance_name: device.aliance_name,
          status: device.status,
          DB_Version: dbInfo.DB_Version,
          available: spaceInfo.available,
        })
      } catch (err) {
        console.log(`❌ ${device.ip} failed`, err.message)

        results.push({
          ip: device.ip,
          aliance_name: device.aliance_name,
          status: device.status,
          DB_Version: 'DB Ver: _._._',
          available: 'offline',
        })
      }
    }

    // console.log('result ', results)

    return results
  }

  // =========================
  // GENERIC RETRY
  // =========================
  async _retry(fn, retries = 3) {
    for (let i = 0; i < retries; i++) {
      try {
        return await fn()
      } catch (err) {
        console.log(`⚠️ Attempt ${i + 1} failed: ${err.message}`)
        if (i < retries - 1) {
          console.log('🔄 Retrying...')
          await this.reconnect()
        } else {
          throw err // Show actual error on final failure
        }
      }
    }
  }

  // =========================
  // CLOSE
  // =========================

  async close() {
    this.connected = false
    await this.sftp.end().catch(() => {})
    this.ssh.end()
  }
}

module.exports = {
  DeviceSSHManager,
  SERVER_CONTENT_PATH,
  SERVER_INDEX_SYS_PATH,
  SERVER_INDEX_TXT_PATH,
}
