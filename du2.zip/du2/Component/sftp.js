const fs = require('fs')
const { Client } = require('ssh2')

const path = require('path')
const logger = require('./logger') // Import your logger
let mainWindow
let results = [] // Define results array globally to store data for all IPs

const mainWindowfn = (window) => {
  mainWindow = window
}
// SFTP connection details
// const privateKeyPath = path.join(__dirname, '../auth/PTCS_key11.ppk') // Adjust the private key path as necessary

async function connection(ipAddress) {
  return new Promise((resolve, reject) => {
    const conn = new Client()

    // Try to connect with private key
    // const tryPrivateKey = () => {
    //   const privateKey = fs.readFileSync(privateKeyPath)
    //   conn.connect({
    //     host: ipAddress,
    //     username: 'root',
    //     privateKey: privateKey,
    //   })
    // }

    // Try to connect with alternative username and password
    const tryUsernamePassword = () => {
      conn.connect({
        host: ipAddress,
        username: 'ptcs',
        password: 'Ptcs@!1357', // Replace 'ptcs' with the actual password if necessary
      })
    }

    conn
      .on('ready', () => {
        // logger.info(`connection: Connected successfully to ${ipAddress}`)
        resolve(conn)
      })
      .on('error', (err) => {
        if (err.level === 'client-authentication') {
          // Retry with username 'ptcs' and password if private key fails
          // logger.warn(
          //   `connection: Private key authentication failed for ${ipAddress}, retrying with username 'ptcs' and password`
          // )
          tryUsernamePassword()
        } else {
          logger.error(
            `connection: SFTP connection error to ${ipAddress}: SFTP connection error}`
          )
          // console.log(err)
          reject(err)
        }
      })
     tryUsernamePassword();
    // Start by trying the private key
    // tryPrivateKey()


  })
}

async function uploadFile(sftp, localPath, remotePath) {
  return new Promise((resolve, reject) => {
    sftp.fastPut(localPath, remotePath, (err) => {
      if (err) {
        logger.error(
          `uploadFile: Error uploading file from ${localPath} to ${remotePath}: ${err.message}`
        )
        reject(err)
      } else {
        logger.info(
          `uploadFile: File successfully uploaded from ${localPath} to ${remotePath}`
        )
        resolve()
      }
    })
  })
}

async function checkRemoteFileExists(sftp, remotePath) {
  return new Promise((resolve, reject) => {
    sftp.stat(remotePath, (err, stats) => {
      if (err) {
        if (err.code === 2) {
          // No such file or directory
          logger.info(
            `checkRemoteFileExists: Remote file does not exist: ${remotePath}`
          )
          resolve(false)
        } else {
          logger.error(
            `checkRemoteFileExists: Error checking remote file existence for ${remotePath}: ${err.message}`
          )
          reject(err)
        }
      } else {
        logger.info(`checkRemoteFileExists: Remote file exists: ${remotePath}`)
        resolve(true)
      }
    })
  })
}



async function findContentFolder(conn) {
  return new Promise((resolve, reject) => {
    const command = `
      find / -type d -name "content" -exec sh -c '
        for dir; do
          if [ -d "$dir/movies" ] && [ -d "$dir/poster" ] && [ -d "$dir/music" ]; then
            echo "$dir"
          fi
        done
      ' sh {} + || echo "No matching folders found"
    `

    conn.exec(command, (err, stream) => {
      if (err) {
        logger.error('findContentFolder: Error executing SSH command')
        return reject(err)
      }

      let output = ''

      stream
        .on('close', (code, signal) => {
          if (code === 0) {
            // logger.info('findContentFolder: Command executed successfully')
          } else {
            logger.warn(`findContentFolder: Command failed with code ${code}`)
          }

          // Filter and extract valid folder paths
          const lines = output.split('\n').filter((line) => {
            const trimmedLine = line.trim()
            return (
              trimmedLine.startsWith('/') &&
              trimmedLine.includes('/content') &&
              !trimmedLine.includes('logout')
            )
          })

          const cleanedPaths = lines.map((line) => line.replace(/\r/g, ''))
          // resolve(cleanedPaths)

          // Set ServerContentPath to the first valid folder with /src/content
          if (cleanedPaths.length > 0) {
            const ServerContentPath = cleanedPaths[0] // Use the first valid path
            // logger.info(`findContentFolder: ServerContentPath set to ${ServerContentPath}`)
            resolve(ServerContentPath)
          } else {
            logger.warn(
              'findContentFolder: No valid folder containing /src/content found'
            )
            resolve(null) // Return null if no valid folder is found
          }
        })
        .on('data', (data) => {
          output += data.toString()
        })
        .on('error', (err) => {
          logger.error('findContentFolder: Error during stream processing')
          reject(err)
        })
    })
  })
}
// Function to read the content of a file using 'cat' command
async function readFileWithCat(conn, filePath, ip) {
  return new Promise((resolve, reject) => {
    conn.exec(`cat ${filePath}`, (err, stream) => {
      if (err) {
        reject(new Error(`Failed to execute 'cat' command: ${err.message}`))
        return
      }

      let fileData = ''
      stream.on('data', (data) => {
        // console.log(data,"  data ")
        fileData += data.toString()
      })

      stream.on('end', () => {
        if (fileData) {
          // logger.info(`File contents of ${filePath}:\n${fileData}`)
          parseIndexSysData(fileData, ip)
          resolve(fileData)
        } else {
          reject(new Error(`No data received for file ${filePath}`))
        }
      })

      stream.on('error', (err) => {
        reject(new Error(`Stream error: ${err.message}`))
      })
    })
  })
}
// In your checkVersionAndConnect function, modify to preserve status
async function checkVersionAndConnect(ipList) {
  // console.log('ipList ', ipList)
  const connectedIps = new Set()

  for (const { ip, aliance_name, status } of ipList) {
    if (status === 'active' && ip !== '192.168.0.3' && !connectedIps.has(ip)) {
      try {
        const conn = await connection(ip);
        connectedIps.add(ip);
        // let contentFolderPath = await findContentFolder(conn)
        let contentFolderPath = "/home/ptcs/Iob/bin/IOB_Server/src/content";

        if (!contentFolderPath) {
          contentFolderPath = "/home/ptcs/Iob/bin/IOB_Server/src/content";
          logger.warn(
            `checkVersionAndConnect: No content folder found on ${ip} (${aliance_name}), using default path: ${contentFolderPath}`,
          );
        }

        const databasePath = contentFolderPath + "/database/INDEX.SYS";

        try {
          await readFileWithCat(conn, databasePath, ip);
        } catch (err) {
          logger.error(
            `checkVersionAndConnect: Failed to read INDEX.SYS from ${databasePath}:Failed to connect to ${ip}`,
          )
        }
        // -------- DISK SPACE CHECK (NEW) --------
        try {
          // console.log(`➡️ [SSD] Starting disk check for ${ip}`);

          const diskInfo = await getDiskSpace(conn, ip, contentFolderPath);
          // console.log(`✅ [SSD] Disk info received for ${ip}:`, diskInfo);

          // ✅ Console output
          // console.log(`\n📦 Disk info for ${ip}`)
          diskInfo.disks.forEach((d) => {
            // console.log(`${d.mount} | Total: ${d.total} | Used: ${d.used} | Free: ${d.available} | Usage: ${d.usage}`,)
          });

          // ✅ Send to Electron UI
          if (mainWindow && mainWindow.webContents) {
            // console.log(`📤 [SSD] Sending SSD info to UI for ${ip}`);
            // console.log("diskInfo", diskInfo)
            // mainWindow.webContents.send("disk_space_info", diskInfo);
          }
        } catch (err) {
          //  console.log(`❌ [SSD] mainWindow not available for ${ip}`);
          logger.error(`Disk space check failed for ${ip}: ${err.message}`);
        }

        conn.end();
      } catch (error) {
        logger.error(
          `checkVersionAndConnect: Failed to connect to ${ip} (${aliance_name}): ${error.message}`
        )
      }

    }
  }
}
async function getRemoteFolderSizeGB(conn, folderPath) {
  return new Promise((resolve, reject) => {
    const cmd = `du -sBG ${folderPath} 2>/dev/null | awk '{print $1}'`;

    conn.exec(cmd, (err, stream) => {
      if (err) return reject(err);

      let output = "";
      stream.on("data", (d) => (output += d.toString()));

      stream.on("close", () => {
        if (!output.trim()) {
          return resolve(0); // folder missing or empty
        }

        // Example output: "123G"
        const sizeGB = parseInt(output.replace("G", "").trim(), 10);
        resolve(isNaN(sizeGB) ? 0 : sizeGB);
      });

      stream.on("error", reject);
    });
  });
}

async function getDiskSpace(conn, ip, contentFolderPath) {
  return new Promise((resolve, reject) => {
    const cmd = `
      lsblk -b -o NAME,TYPE,ROTA,MOUNTPOINT,SIZE | awk '
      $2=="part" && $4=="/" { print $0 }
      '
    `;

    conn.exec(cmd, (err, stream) => {
      if (err) return reject(err);

      let output = "";

      stream.on("data", (data) => {
        output += data.toString();
      });

      stream.on("close", () => {
        if (!output.trim()) {
          return reject(new Error("No root SSD partition found"));
        }

        const parts = output.trim().split(/\s+/);

        const mount = parts[3];
        const sizeBytes = parseInt(parts[4]);

        // Convert to human readable
        const totalGB = (sizeBytes / 1024 ** 3).toFixed(0) + "G";

        // Get USED / FREE via df
        const dfCmd = `df -h ${mount} | tail -1`;

        conn.exec(dfCmd, (err, dfStream) => {
          if (err) return reject(err);

          let dfOut = "";
          dfStream.on("data", (d) => (dfOut += d.toString()));

          dfStream.on("close", async () => {
            const df = dfOut.trim().split(/\s+/);
            const total = parseInt(df[1]); // e.g. 468G
            const used = parseInt(df[2]); // e.g. 46G
            // const free = parseInt(df[3]); // e.g. 399G
            const usage = df[4];

            // 🔥 SUBTRACT 250 GB SAFELY
            // const adjustedFree = Math.max(free - 250, 0);
            // 🔥 FIXED SSD CAPACITY LOGIC
            const FIXED_SSD_SIZE_GB = 250;

            // Get content folder size
            const contentSizeGB = await getRemoteFolderSizeGB(
              conn,
              contentFolderPath
            );

            // Calculate remaining usable space
            const adjustedFree = Math.max(
              FIXED_SSD_SIZE_GB - contentSizeGB,
              0
            );

            resolve({
              ip,
              disks: [
                {
                  mount: "/",
                  filesystem: df[0],
                  total: `250G`,
                  used: `${contentSizeGB}G`,
                  available: `${adjustedFree}G`,
                  usage: `${Math.min(
                    Math.round((contentSizeGB / 250) * 100),
                    100,
                  )}%`,
                  diskType: "CONTENT_SSD",
                },
              ],
            });
          });
        });
      });

      stream.on("error", reject);
    });
  });
}

// Update parseIndexSysData to include status information
const parseIndexSysData = (data, ip) => {
  const rows = data.split('\n')
  rows.forEach((row) => {
    row = row.trim()

    if (row === '' || row.startsWith('CRC')) return

    const parts = row.split(/\s+/)

    if (parts.length >= 3) {
      const size = parts[1]
      const filename = parts.slice(2).join(' ')

      if (size === '00000000') {
        const version_name = filename

        const newData = {
          ip,
          version_name,
          status: 'active' // Mark as active since we successfully read the data
        }

        // Filter out existing data with the same ip
        results = results.filter((item) => item.ip !== newData.ip)
        results.push(newData)
        logFinalResults()
      }
    }
  })
}

// Update logFinalResults to properly sort by status
const logFinalResults = () => {
  if (mainWindow && mainWindow.webContents) {
    // Sort results: active IPs first, then inactive
    const sortedResults = results.sort((a, b) => {
      // Active status comes before inactive
      if (a.status === 'active' && b.status !== 'active') return -1
      if (a.status !== 'active' && b.status === 'active') return 1

      // If both have same status, maintain original order (or sort by IP/name if preferred)
      return 0
    })

    // console.log("sortedResults ",sortedResults)
    mainWindow.webContents.send('Database_version_name_module', sortedResults)
  }
}


module.exports = {
  mainWindowfn,
  connection,
  uploadFile,
  checkRemoteFileExists,
  findContentFolder,
  checkVersionAndConnect,
}
