const { app, BrowserWindow, ipcMain } = require('electron')
const { getSavedWindowState, trackWindowState,buildMenu } = require('./windowState')
const path = require('path')
const fs = require('fs')
const os = require('os')
let newWindow = null // Ensure only one instance
async function processDatabaseFolder(CreateMainFolder, mainWindow) {
  const triggersPath = getTriggersPath()
  const imageFiles = getImageFiles(triggersPath)
  const tftFolder = path.join(CreateMainFolder, 'add') // Corrected folder name
  const triggerJsonPath = path.join(CreateMainFolder, 'TriggerData.json')
  let selectedImage = null // Global variable to store selected image name
  ipcMain.on('open-new-window', async (event) => {
    if (newWindow && !newWindow.isDestroyed()) {
      newWindow.focus() // Bring to front if already open
      return
    }

    const minWidth = 1200
    const minHeight = minWidth / 2
    const windowState = await getSavedWindowState(minWidth, minHeight)

    newWindow = new BrowserWindow({
      width: windowState.width,
      height: windowState.height,
      minWidth: minWidth,
      minHeight: minHeight,
      x: windowState.x,
      y: windowState.y,
      // parent: BrowserWindow.getFocusedWindow(), // Attach to main window
      parent: mainWindow, // Attach to main window
      modal: true, // Make it a modal window
      alwaysOnTop: true, // Keep on top
      resizable: false, // Prevent resizing
      maximizable: false, // Disable maximize button
      minimizable: false, // Disable minimize button
      closable: true, // Allow closing
      frame: true, // Show frame
      icon: path.join(__dirname, '../public/assets/Logo/pps_logo.ico'),
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false,
      },
    })

    await trackWindowState(newWindow)

    // Hide menu bar
    newWindow.setMenu(null)
    // const menu = buildMenu(newWindow)

    // Load HTML file
    newWindow.loadFile(path.join(__dirname, '../public/HTML/tft_database.html'))
    // Reset reference when closed
    newWindow.on('closed', () => {
      newWindow = null
    })
    // Use the new function to create the menu

    // Send image list when window is ready
    newWindow.webContents.once('did-finish-load', () => {
      newWindow.webContents.send('image-list', {
        images: imageFiles,
        path: triggersPath,
      })
    })

    // Send images when requested
    ipcMain.on('request-image-list', (event) => {
      const updatedImageFiles = getImageFiles(triggersPath) // Get the latest files

      event.reply('image-list', {
        images: updatedImageFiles,
        path: triggersPath,
      }) // Send images back
    })
  })

  // Function to determine correct `Triggers` path
  function getTriggersPath() {
    let installationPath = path.dirname(process.execPath)
    return app.isPackaged
      ? path.join(installationPath, 'resources', 'resources', 'Triggers')
      : path.join(__dirname, '../resources/Triggers')
  }

  // Function to get image files
  function getImageFiles(directory) {
    try {
      return fs
        .readdirSync(directory)
        .filter((file) => /\.(jpg|jpeg|png|gif)$/i.test(file))
    } catch (error) {
      console.error('Error reading directory:', error)
      return []
    }
  }

  // Handle View Button Click (Load New HTML in Same Window)
  ipcMain.on('open-new-window', (event, imageName) => {
    if (newWindow) {
      selectedImage = imageName // Store selected image name
      newWindow.loadFile(
        path.join(__dirname, '../public/HTML/tft_fileHandler.html')
      )

      newWindow.webContents.once('did-finish-load', () => {
        const updatedTriggerFiles = getFilesBySelectedTrigger(
          triggerJsonPath,
          selectedImage
        ) // Get the latest files
        newWindow.webContents.send('selected-files', {
          imageName: selectedImage,
          triggerFiles: updatedTriggerFiles,
          CreateMainFolder: CreateMainFolder,
        })
      })
    }
  })

  // ✅ **Handle Request for Image Data When Page Reloads**
  ipcMain.on('request-selected-files', (event) => {
    const updatedTriggerFiles = getFilesBySelectedTrigger(
      triggerJsonPath,
      selectedImage
    ) // Get the latest files
    event.sender.send('selected-files', {
      imageName: selectedImage, // Keep the last selected image
      triggerFiles: updatedTriggerFiles, // Send full image list
      CreateMainFolder: CreateMainFolder,
    })
  })

  ipcMain.removeHandler('get-tft-files') // Important line to avoid double registration

  // 🟢 Fetch list of files for TFT from the "adv" folder
  ipcMain.handle('get-tft-files', async () => {
    try {
      const files = fs
        .readdirSync(tftFolder)
        .map((file) => path.join(tftFolder, file)) // Get full path
        .filter((filePath) => fs.statSync(filePath).isFile()) // Only keep files
        .map((filePath) => ({
          name: path.basename(filePath), // Extract only filename
          path: filePath, // Full path of file
        }))

      // console.log(files)
      return files
    } catch (error) {
      console.error('Error reading TFT folder:', error)
      return []
    }
  })

  ipcMain.on('tft-confirm-selection', (event, data) => {
    console.log('Received TFT selection data:', data)

    // Extract values
    const { selectedFiles, advertismentPath, TriggerName } = data

    // Process or store data as needed
    console.log('TFT Selected Files:', selectedFiles)
    console.log('TFT Advertisment Path:', advertismentPath)
    console.log('TFT Trigger Name:', TriggerName)

    // Call the function to save the data
    const result = saveTriggerData(TriggerName, selectedFiles)

    // Send response back to frontend
    event.reply(
      result.success ? 'tft-success' : 'tft-save-error',
      result.message
    )
  })

  ipcMain.on('tft-delete-request', (event, data) => {
    console.log('Received TFT deletion data:', data)

    // Extract values
    const { selectedFiles, TriggerName } = data

    const result = deleteTriggerFiles(TriggerName, selectedFiles)
    // Send response back to frontend
    event.reply(result.success ? 'tft-success' : 'tft-error', result.message)
  })

  ipcMain.on('request-to-Back', (event, data) => {
    if (newWindow) {
      newWindow.loadFile(
        path.join(__dirname, '../public/HTML/tft_database.html')
      )
    }

    // Send image list when window is ready
    newWindow.webContents.once('did-finish-load', () => {
      newWindow.webContents.send('image-list', {
        images: imageFiles,
        path: triggersPath,
      })
    })
  })
  //  request-to-Back

  // Function to save trigger data
  function saveTriggerData(TriggerName, selectedFiles) {
    try {
      // Read existing data (if file exists)
      let existingData = []
      if (fs.existsSync(triggerJsonPath)) {
        const fileContent = fs.readFileSync(triggerJsonPath, 'utf-8')
        existingData = JSON.parse(fileContent || '[]')
      }

      // Find the trigger in the existing data
      let triggerEntry = existingData.find(
        (item) => item.trigger === TriggerName
      )

      // If the trigger doesn't exist, create a new entry
      if (!triggerEntry) {
        triggerEntry = { trigger: TriggerName, files: [] }
        existingData.push(triggerEntry)
      }

      // Get existing file names in the trigger entry
      const existingFileNames = new Set(
        triggerEntry.files.map((file) => file.name)
      )

      // Filter new files (skip existing ones)
      const newFiles = selectedFiles
        .filter((file) => !existingFileNames.has(path.basename(file))) // Skip if already exists
        .map((file) => ({
          name: path.basename(file),
          path: path.join(tftFolder, file),
        }))

      const skippedCount = selectedFiles.length - newFiles.length // Count skipped files

      // Add new files to the trigger entry
      triggerEntry.files.push(...newFiles)

      // Save the updated JSON file
      fs.writeFileSync(triggerJsonPath, JSON.stringify(existingData, null, 2))
      console.log(
        `TFT selection saved successfully! Skipped ${skippedCount} files.`
      )

      return {
        success: true,
        message: `Files saved successfully!`,
      }
    } catch (error) {
      console.error('Error saving TFT data:', error)
      return { success: false, message: 'Error saving files!' }
    }
  }

  function getFilesBySelectedTrigger(triggerJsonPath, selectedImage) {
    try {
      // Read existing JSON data
      if (!fs.existsSync(triggerJsonPath)) {
        console.error('Trigger JSON file not found!')
        return {
          success: false,
          message: 'Trigger JSON file not found!',
          files: [],
        }
      }

      const fileContent = fs.readFileSync(triggerJsonPath, 'utf-8')
      const triggerData = JSON.parse(fileContent || '[]')
      // console.log('Parsed JSON Data:', JSON.stringify(triggerData, null, 2)) // Debugging

      // Ensure correct comparison (case-insensitive & trimmed)
      const selectedTrigger = selectedImage
        .replace(/\.[^/.]+$/, '')
        .trim()
        .toLowerCase()

      // Find the trigger entry matching selectedImage
      const triggerEntry = triggerData.find(
        (entry) => entry.trigger.trim().toLowerCase() === selectedTrigger
      )

      if (!triggerEntry) {
        console.log('No matching trigger found for the selected image.')
        return {
          success: false,
          message: 'No matching trigger found!',
          files: [],
        }
      }

      return {
        success: true,
        message: `Files found for trigger: ${triggerEntry.trigger}`,
        files: triggerEntry.files, // Return all files of the found trigger
      }
    } catch (error) {
      console.error('Error reading trigger data:', error)
      return {
        success: false,
        message: 'Error reading trigger data!',
        files: [],
      }
    }
  }

  function deleteTriggerFiles(TriggerName, filesToDelete) {
    try {
      // Read existing data
      if (!fs.existsSync(triggerJsonPath)) {
        console.log('Trigger JSON file does not exist.')
        return { success: false, message: 'No data found!' }
      }

      const fileContent = fs.readFileSync(triggerJsonPath, 'utf-8')
      let existingData = JSON.parse(fileContent || '[]')

      // Find the trigger entry
      let triggerEntry = existingData.find(
        (item) => item.trigger === TriggerName
      )

      if (!triggerEntry) {
        console.log('Trigger not found:', TriggerName)
        return { success: false, message: 'Trigger not found!' }
      }

      // Filter out files that need to be deleted
      const initialCount = triggerEntry.files.length
      triggerEntry.files = triggerEntry.files.filter(
        (file) => !filesToDelete.includes(file.name)
      )

      const deletedCount = initialCount - triggerEntry.files.length

      // Remove trigger entry if no files remain
      if (triggerEntry.files.length === 0) {
        existingData = existingData.filter(
          (item) => item.trigger !== TriggerName
        )
      }

      // Save updated JSON file
      fs.writeFileSync(triggerJsonPath, JSON.stringify(existingData, null, 2))
      console.log(`Deleted ${deletedCount} files from trigger: ${TriggerName}`)

      return {
        success: true,
        message: `Deleted ${deletedCount} files successfully!`,
      }
    } catch (error) {
      console.error('Error deleting files:', error)
      return { success: false, message: 'Error deleting files!' }
    }
  }
}


module.exports = { processDatabaseFolder }
