const { dialog } = require("electron");

/*
================================
Dialog Templates
================================
*/
const templates = {
  PATH_ERROR: {
    type: 'error',
    title: 'Path Error',
    message: 'Wrong Database Selected.',
  },

  TRANSFER_PATH_ERROR: {
    type: 'error',
    title: 'Path Error',
    message: 'Please choose the correct path for file transfer.',
  },
 
  DB_FILES_MISSING: {
    type: 'error',
    title: 'Database Incomplete',
    message: (data) =>
      `Database upload incomplete on ${data.totalFailed} device(s).

    Devices:
    ${data.ipList}`,
  },

  CONFIG_NOT_FOUND: {
    type: 'error',
    title: 'File Not Found',
    message: (data) => `Configuration file not found at ${data.path}`,
  },

  CONNECTION_LOSS: {
    type: 'error',
    title: 'Connection Loss',
    message: (data) =>
      `Connection to ${data.ip} lost. Please check connection.`,
  },

  SKIP_FILES: {
    type: 'warning',
    title: 'Skip Files',
    message: (data) =>
      `Destination already has ${data.existing} out of ${data.total} files.`,
  },

  SOME_FILES_NOT_FOUND: {
    type: 'error',
    title: 'File Not Found',
    message: 'Error: Some files not found.',
  },

  SFTP_CONNECTION_ERROR: {
    type: 'error',
    title: 'SFTP Connection Error',
    message: (data) =>
      `An error occurred while connecting to the SFTP server:\n${data.errorMessage}`,
  },

  FILE_TRANSFER_ERROR: {
    type: 'error',
    title: 'File Transfer Error',
    message: 'Error uploading file. Connection loss.',
  },

  NO_FILES_FOUND: {
    type: 'warning',
    title: 'No Files Found',
    message: 'No files found in selected Database.',
  },

  GENERIC_ERROR: {
    type: 'error',
    title: 'Error',
    message: 'Something went wrong while displaying the message.',
  },
}

/*
================================
Dynamic Show Function
================================
*/
async function show(templateName, mainWindow, data = {}) {

  const template = templates[templateName];

  if (!template) {
    console.error(`Dialog template ${templateName} not found`);
    return;
  }

  const message =
    typeof template.message === "function"
      ? template.message(data)
      : template.message;

  return await dialog.showMessageBox(mainWindow, {
    type: template.type,
    title: template.title,
    message,
    buttons: ["OK"],
    alwaysOnTop: true
  });
}

/*
================================
Error Box Shortcut
================================
*/
function showError(title, message) {
  dialog.showErrorBox(title, message);
}




async function openFolder(mainWindow, options = {}) {
  return await dialog.showOpenDialog(mainWindow, {
    title: 'Select a folder',
    properties: ['openDirectory'],
    ...options,
  })
}




/*
================================
Confirm Dialog
================================
*/
async function confirm(mainWindow, options) {
  return await dialog.showMessageBox(mainWindow, options);
}

module.exports = {
  show,
  showError,
  confirm,
  openFolder,
}
