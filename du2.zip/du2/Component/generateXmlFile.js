const fs = require("fs").promises; // Use fs.promises for async file operations
const path = require("path");
const logger = require("./logger");
// Define the XML content
const xmlContent = `<?xml version="1.0" standalone="yes"?>
<IOTConfig version="1.0.0">
  <IPConfig>
    <address />
    <subnetmask />
    <gateway />
    <dns />
    <unitmask enable="true" default="1" minimum="0" maximum="255" shift="8" />
    <carmask enable="false" default="0" minimum="0" maximum="255" shift="0" />
  </IPConfig>

  <Device_list>
    <Ipaddress ip="192.168.0.243" aliance_name="coach 243" />
    <Ipaddress ip="192.168.10.100" aliance_name="coach 0"/>
    <Ipaddress ip="192.168.10.101" aliance_name="coach 2"/>
    <Ipaddress ip="192.168.10.102" aliance_name="coach 3"/>
    <Ipaddress ip="192.168.10.103" aliance_name="coach 4"/>
    <Ipaddress ip="192.168.10.104" aliance_name="coach 5"/>
    <Ipaddress ip="192.168.10.105" aliance_name="coach 6"/>
    <Ipaddress ip="192.168.10.106" aliance_name="coach 7"/>
    <Ipaddress ip="192.168.10.107" aliance_name="coach 8"/>
    <Ipaddress ip="192.168.10.108" aliance_name="coach 9"/>
    <Ipaddress ip="192.168.10.109" aliance_name="coach 10"/>
    <Ipaddress ip="192.168.10.110" aliance_name="coach 11"/>
    <Ipaddress ip="192.168.10.111" aliance_name="coach 12"/>
    <Ipaddress ip="192.168.10.112" aliance_name="coach 13"/>
    <Ipaddress ip="192.168.10.113" aliance_name="coach 14"/>
    <Ipaddress ip="192.168.10.114" aliance_name="coach 10"/>
    <Ipaddress ip="192.168.10.115" aliance_name="coach 11"/>
    <Ipaddress ip="192.168.10.116" aliance_name="coach 12"/>
    <Ipaddress ip="192.168.10.117" aliance_name="coach 13"/>
    <Ipaddress ip="192.168.10.118" aliance_name="coach 14"/>
    <Ipaddress ip="192.168.10.119" aliance_name="coach 13"/>
    <Ipaddress ip="192.168.10.120" aliance_name="coach 14"/>
  </Device_list>

  <DATA_STRUCTURE>
    <ADD folder_name="Add" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/add" />
    <ADD2 folder_name="Add2" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/add2" />
    <ADVERTISMENT folder_name="Advertisment" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/advertisment" />

    <IMG folder_name="Img" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/img">
      <TOURIST Img_Sub_folder_name="Tourist" Img_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/img/tourist" />
    </IMG>

    <KIDSZONE folder_name="Kidszone" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/kidszone">
      <ENGLISH Kidszone_Sub_folder_name="english" Kidszone_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/kidszone/english" />
      <HINDI Kidszone_Sub_folder_name="hindi" Kidszone_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/kidszone/hindi" />
      <regional1 Kidszone_Sub_folder_name="regional1" Kidszone_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/kidszone/regional1" />
      <regional2 Kidszone_Sub_folder_name="regional2" Kidszone_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/kidszone/regional2" />
    </KIDSZONE>

    <MOVIES folder_name="Movies" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/movies">
      <BOLLYWOOD Movies_Sub_folder_name="Bollywood" Movies_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/movies/bollywood" />
      <HOLLYWOOD Movies_Sub_folder_name="Hollywood" Movies_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/movies/hollywood" />
      <regional1 Movies_Sub_folder_name="Regional1" Movies_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/movies/regional1" />
      <regional2 Movies_Sub_folder_name="Regional2" Movies_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/movies/regional2" />
    </MOVIES>

    <MUSIC folder_name="Music" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/music">
      <ENGLISH Music_Sub_folder_name="english" Music_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/music/english" />
      <HINDI Music_Sub_folder_name="hindi" Music_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/music/hindi" />
      <regional1 Music_Sub_folder_name="Regional1" Music_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/music/regional1" />
      <regional2 Music_Sub_folder_name="Regional2" Music_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/music/regional2" />
    </MUSIC>

    <POSTER folder_name="Poster" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/poster">
      <POSTER_KIDSZONE Poster_Sub_folder_name="kidszone" Poster_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/kidszone">
        <POSTER_ENGLISH Kidszone_Sub_folder_name2="english" Kidszone_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/kidszone/english" />
        <POSTER_HINDI Kidszone_Sub_folder_name2="hindi" Kidszone_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/kidszone/hindi" />
        <POSTER_regional1 Kidszone_Sub_folder_name2="regional1" Kidszone_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/kidszone/regional1" />
        <POSTER_regional2 Kidszone_Sub_folder_name2="regional2" Kidszone_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/kidszone/regional2" />
      </POSTER_KIDSZONE>

      <POSTER_MOVIES Poster_Sub_folder_name="movies" Poster_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/movies">
        <POSTER_BOLLYWOOD Movies_Sub_folder_name2="bollywood" Movies_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/movies/bollywood" />
        <POSTER_HOLLYWOOD Movies_Sub_folder_name2="hollywood" Movies_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/movies/hollywood" />
        <POSTER_regional1 Movies_Sub_folder_name2="regional1" Movies_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/movies/regional1" />
        <POSTER_regional2 Movies_Sub_folder_name2="regional2" Movies_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/movies/regional2" />
      </POSTER_MOVIES>

      <POSTER_VIDEOS Poster_Sub_folder_name="videos" Poster_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/videos">
        <POSTER_ENGLISH Videos_Sub_folder_name2="english" Videos_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/videos/english" />
        <POSTER_HINDI Videos_Sub_folder_name2="hindi" Videos_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/videos/hindi" />
        <POSTER_regional1 Videos_Sub_folder_name2="regional1" Videos_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/videos/regional1" />
        <POSTER_regional2 Videos_Sub_folder_name2="regional2" Videos_Sub_folder_url2="/home/ptcs/Iob/bin/IOB_Server/src/content/poster/videos/regional2" />
      </POSTER_VIDEOS>
    </POSTER>

    <VIDEOS folder_name="Videos" folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/videos">
      <ENGLISH Videos_Sub_folder_name="english" Videos_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/videos/english" />
      <HINDI Videos_Sub_folder_name="hindi" Videos_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/videos/hindi" />
      <regional1 Videos_Sub_folder_name="Regional1" Videos_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/videos/regional1" />
      <regional2 Videos_Sub_folder_name="Regional2" Videos_Sub_folder_url="/home/ptcs/Iob/bin/IOB_Server/src/content/videos/regional2" />
    </VIDEOS>
  </DATA_STRUCTURE>
</IOTConfig>`;

// Define the function to check file existence and create if not present
async function createFileIfNotExists(filePath) {
  try {
    // Check if the file exists
    logger.info(`createFileIfNotExists: Checking file at ${filePath}`);
    try {
      await fs.access(filePath);
      logger.info(`createFileIfNotExists: File already exists at ${filePath}`);
    } catch (err) {
      // File does not exist, create it
      await fs.writeFile(filePath, xmlContent, "utf8");
      logger.info(`createFileIfNotExists: File created at ${filePath}`);
    }
  } catch (error) {
    logger.error(`createFileIfNotExists: Error: ${error}`);
  }
}

// Usage

module.exports = { createFileIfNotExists };
