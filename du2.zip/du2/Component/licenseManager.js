const os = require('os')
const crypto = require('crypto')
const fs = require('fs')

// =======================
// Generate Machine ID
// =======================
function getMachineInfo() {
  return {
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    cpu: os.cpus()[0].model,
    totalMem: os.totalmem(),
  }
}

// =======================
// Create Product Fingerprint
// =======================
function generateMachineKey() {
  const info = getMachineInfo()

  const raw = `${info.hostname}-${info.platform}-${info.arch}-${info.cpu}-${info.totalMem}`

  return crypto.createHash('sha256').update(raw).digest('hex').toUpperCase()
}

// =======================
// Verify License File
// =======================
function verifyLicenseFile(filePath) {
  try {
    const machineKey = generateMachineKey()

    const licenseContent = fs.readFileSync(filePath, 'utf8').trim()

    return {
      valid: licenseContent === machineKey,
      machineKey,
    }
  } catch (err) {
    return { valid: false, machineKey: null }
  }
}

module.exports = {
  generateMachineKey,
  verifyLicenseFile,
}
