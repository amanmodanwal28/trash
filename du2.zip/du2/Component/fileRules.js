const path = require("path");

// ===== EXTENSIONS =====
const musicFileExtensions = [
  "mp3",
  "wav",
  "ogg",
  "pcm",
  "aif",
  "aiff",
  "aac",
  "wma",
  "flac",
  "alac",
  "opus",
  "dts",
  "ac3",
  "amr",
  "mid",
];

const videoFileExtensions = [
  "mp4",
  "avi",
  "mkv",
  "mov",
  "wmv",
  "flv",
  "webm",
  "mpeg",
  "mpg",
  "m4v",
  "3gp",
  "ogv",
  "ts",
  "vob",
];

const imageExtensions = [
  "jpg",
  "jpeg",
  "png",
  "gif",
  "bmp",
  "tiff",
  "tif",
  "svg",
  "webp",
  "heic",
  "ico",
  "avif",
];

// ===== HELPERS =====
function getSecondFolder(currentFolderPath, createMainFolderPath) {
  if (!currentFolderPath || !createMainFolderPath) return "";

  const normalizedCurrent = path.normalize(currentFolderPath);
  const normalizedBase = path.normalize(createMainFolderPath);

  // get relative path from IOB_DB
  const relativePath = path.relative(normalizedBase, normalizedCurrent);
  // poster/videos/regional2
  const parts = relativePath.split(path.sep);

  return parts[0]?.toLowerCase() || "";
}

function getExtension(filePathOrName) {
  return path.extname(filePathOrName).replace(".", "").toLowerCase();
}

// ===== CORE RULE ENGINE =====
function isExtensionAllowed(ext, secondFolder) {
  if (!ext || !secondFolder) return false;

  if (["add", "add2", "advertisment"].includes(secondFolder)) {
    return imageExtensions.includes(ext) || videoFileExtensions.includes(ext);
  }

  if (["videos", "movies", "kidszone"].includes(secondFolder)) {
    return videoFileExtensions.includes(ext); // ✅ kidszone FIXED
  }

  if (secondFolder === "music") {
    return musicFileExtensions.includes(ext);
  }

  if (["img", "poster"].includes(secondFolder)) {
    return imageExtensions.includes(ext);
  }

  return false;
}

// ===== EXPORT =====
module.exports = {
  imageExtensions,
  videoFileExtensions,
  musicFileExtensions,
  getSecondFolder,
  getExtension,
  isExtensionAllowed,
};
