const { screen, Menu, app, dialog, Notification } = require('electron')
const path = require('path')
const fs = require('fs')
const {
  createDatabaseDirectories,

} = require('./xmlParser')
const { startMultiInterfaceBroadcast,stopMultiInterfaceBroadcast } = require('./multiInterfaceBroadcast')
const logger = require('./logger')
const {
  getMainPath,
} = require('./fileAdd')

let connectionState = 'disconnected' // ⭐ Track state


const ABOUT_TEXT = `
SPUT Tool
Version: 1.0.0

Designed, Developed and Supported By:
PPS International Pvt Ltd.


© PPS International Pvt Ltd. All Rights Reserved
`

function refreshMenu(mainWindow) {
  if (!mainWindow || mainWindow.isDestroyed()) return

  const menu = buildMenu(mainWindow)
  Menu.setApplicationMenu(menu)
}

async function getSavedWindowState(defaultWidth = 1235, defaultHeight = 600) {
  const Store = (await import('electron-store')).default
  const store = new Store()

  const savedPosition = store.get('windowPosition')
  const savedSize = store.get('windowSize')

  const primaryDisplay = screen.getPrimaryDisplay()
  let { width, height } = primaryDisplay.workAreaSize

  const minWidth = defaultWidth
  const minHeight = minWidth / 2

  return {
    x: savedPosition?.x ?? (width - minWidth) / 2,
    y: savedPosition?.y ?? (height - minHeight) / 2,
    width: savedSize?.width ?? minWidth,
    height: savedSize?.height ?? minHeight,
  }
}

async function trackWindowState(mainWindow) {
  const Store = (await import('electron-store')).default
  const store = new Store()

  // Listen for the 'move' event
  mainWindow.on('move', () => {
    const [x, y] = mainWindow.getPosition()
    store.set('windowPosition', { x, y })

  })

  // Listen for the 'resize' event
  mainWindow.on('resize', () => {
    const bounds = mainWindow.getBounds()
    const { width, height } = bounds
    store.set('windowSize', { width, height })
  })
}

// ----------------------------------------------------
// Notification Safe Wrapper
// ----------------------------------------------------
function showConnectionNotification(title, body) {
  try {
    if (Notification.isSupported()) {
      new Notification({ title, body }).show()
    }
  } catch (err) {
    logger.error(`Notification Error: `)
  }
}

// ----------------------------------------------------
// MENU BUILDER
// ----------------------------------------------------
function buildMenu(mainWindow) {
  const isMac = process.platform === 'darwin'
  const statusLabel =
    connectionState === 'connected'
      ? '🟢 Status: Connected'
      : '🔴 Status: Disconnected'

  const template = [
    ...(isMac
      ? [
          {
            label: app.name,
            submenu: [
              { role: 'about' },
              { type: 'separator' },
              { role: 'services' },
              { type: 'separator' },
              { role: 'hide' },
              { role: 'hideOthers' },
              { role: 'unhide' },
              { type: 'separator' },
              { role: 'quit' },
            ],
          },
        ]
      : []),

    // ================= FILE MENU =================
    {
      label: 'File',
      submenu: [
        {
          label: 'New',
          click: async () => {
            try {
              const { canceled, filePath } = await dialog.showSaveDialog(
                mainWindow,
                {
                  title: 'Select location to create new folder',
                  buttonLabel: 'Create Folder',
                  properties: ['createDirectory'],
                },
              )

              if (!canceled && filePath) {
                fs.mkdir(filePath, { recursive: true }, async (err) => {
                  if (err) {
                    console.error(`Failed to create folder: ${err}`)
                  } else {
                    console.info(`New folder created at: ${filePath}`)

                    getMainPath(filePath)
                    logger.info(
                      `createMainWindow: New folder created at: ${filePath}`,
                    )
                    await createDatabaseDirectories(filePath)
                    mainWindow.webContents.send('create-database-Dir', filePath)
                  }
                })
              }
            } catch (err) {
              console.error(`Error during folder creation: ${err}`)
            }
          },
        },
        {
          label: 'Open',
          click: async () => {
            mainWindow.webContents.send('click-database-button')
          },
        },
        { type: 'separator' },
        isMac ? { role: 'close' } : { role: 'quit' },
      ],
    },
    // ================= CONNECTION  MENU =================
    {
      label: 'Connection',
      submenu: [
        {
          label: statusLabel,
          enabled: false,
        },

        { type: 'separator' },

        {
          label: '🔌 Connect',
          enabled: connectionState !== 'connected',
          click: () => {
            try {
              startMultiInterfaceBroadcast()

              connectionState = 'connected'

              showConnectionNotification('SPUT Tool', '✅ Multicast Connected')
              refreshMenu(mainWindow)

            } catch (err) {
              logger.error(`Connect error: ${err}`)
            }
          },
        },

        {
          label: '❌ Disconnect',
          enabled: connectionState === 'connected',
          click: () => {
            try {
              stopMultiInterfaceBroadcast()

              connectionState = 'disconnected'

              showConnectionNotification(
                'SPUT Tool',
                '❌ Multicast Disconnected',
              )

              refreshMenu(mainWindow)
            } catch (err) {
              logger.error(`Disconnect error: ${err}`)
            }
          },
        },
      ],
    },

    // ================= VIEW MENU =================
    {
      label: 'View',
      submenu: [
        {
          label: 'Toggle Developer Tools',
          accelerator: isMac ? 'Command+I' : 'Ctrl+I',
          click: () => {
            mainWindow.webContents.toggleDevTools()
          },
        },
        {
          label: 'Refresh',
          accelerator: isMac ? 'Command+R' : 'Ctrl+R',
          click: () => {
            mainWindow.reload()
          },
        },
      ],
    },
    // ================= HELP MENU =================
    {
      label: 'Help',
      submenu: [
        {
          label: 'About SPUT Tool',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About SPUT Tool',
              message: 'SPUT Tool',
              detail: ABOUT_TEXT,
              buttons: ['OK'],
            })
          },
        },
      ],
    },
  ]

  const menu = Menu.buildFromTemplate(template)
  Menu.setApplicationMenu(menu)

  return menu
}

module.exports = { getSavedWindowState, trackWindowState, buildMenu }
