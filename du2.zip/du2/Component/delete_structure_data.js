const path = require("path");
const fs = require("fs");
const logger = require("./logger");
function sftpReaddir(sftp, dir) {
  return new Promise((resolve, reject) => {
    sftp.readdir(dir, (err, list) => {
      if (err) return reject(err);
      resolve(list);
    });
  });
}

function sftpUnlink(sftp, filePath) {
  return new Promise((resolve, reject) => {
    sftp.unlink(filePath, (err) => (err ? reject(err) : resolve()));
  });
}

async function recursiveFileCleanup(sftp, currentDir, allowedFiles, skipDirs) {
  let entries;

  try {
    entries = await sftpReaddir(sftp, currentDir);
  } catch (err) {
    logger.error(`Read failed: ${currentDir}`, err);
    return;
  }

  for (const entry of entries) {
    const entryPath = path.posix.join(currentDir, entry.filename);

    // 🔒 Directory handling
    if (entry.attrs.isDirectory()) {
      if (skipDirs.has(entry.filename)) {
        logger.info(`Skipping directory: ${entryPath}`);
        continue;
      }

      // 🔁 recurse inside directory
      await recursiveFileCleanup(sftp, entryPath, allowedFiles, skipDirs);

      continue;
    }

    // 📄 FILE handling
    if (!allowedFiles.has(entryPath)) {
      try {
        logger.warn(`Deleting file: ${entryPath}`);
        await sftpUnlink(sftp, entryPath);
      } catch (err) {
        logger.error(`Failed to delete: ${entryPath}`, err);
      }
    }
  }
}

async function cleanupContentFolder(sftp, ServerContentPath, remotePaths) {
  // Build allowed file list (absolute remote paths)
  const allowedFiles = new Set(
    remotePaths.map((p) =>
      path.posix.join(ServerContentPath, p.replace(/^\/+/, "")),
    ),
  );

  const skipDirs = new Set(["database", "default_img", "img"]);

  await recursiveFileCleanup(sftp, ServerContentPath, allowedFiles, skipDirs);
}

async function deleteAllFilesRecursive(sftp, currentDir, skipDirs) {
  let entries;

  try {
    entries = await new Promise((res, rej) =>
      sftp.readdir(currentDir, (e, d) => (e ? rej(e) : res(d))),
    );
  } catch (err) {
    logger.error(`Read failed: ${currentDir}`, err);
    return;
  }

  for (const entry of entries) {
    const entryPath = path.posix.join(currentDir, entry.filename);

    // 📁 Directory
    if (entry.attrs.isDirectory()) {
      if (skipDirs.has(entry.filename)) {
        logger.info(`Skipping directory: ${entryPath}`);
        continue;
      }

      // 🔁 recurse into directory
      await deleteAllFilesRecursive(sftp, entryPath, skipDirs);
      continue;
    }

    // 📄 File → DELETE
    try {
      logger.warn(`Deleting file: ${entryPath}`);
      await new Promise((res, rej) =>
        sftp.unlink(entryPath, (err) => (err ? rej(err) : res())),
      );
    } catch (err) {
      logger.error(`Failed to delete: ${entryPath}`, err);
    }
  }
}
async function cleanAllContentFiles(sftp, ServerContentPath) {
  const skipDirs = new Set(["database", "default_img"]);

  await deleteAllFilesRecursive(sftp, ServerContentPath, skipDirs);
}

module.exports = { cleanupContentFolder, cleanAllContentFiles };
