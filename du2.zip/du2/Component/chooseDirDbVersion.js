const fs = require('fs')
const path = require('path')

// Function to choose database version and read INDEX.SYS file
async function chooseDirDbVersion(DatabaseFolder) {
  const indexFilePath = path.join(DatabaseFolder, 'INDEX.SYS')

  try {
    // Read the INDEX.SYS file asynchronously
    const data = await fs.promises.readFile(indexFilePath, 'utf8')
    // console.log(`Successfully read INDEX.SYS from ${indexFilePath}`)

    // Process the content of INDEX.SYS
    const parsedData = parseIndexSysData(data, DatabaseFolder)
    // console.log(parsedData, 'parsedData')
    return parsedData // Return the parsed data
  } catch (error) {
    console.error(`Failed to read INDEX.SYS from ${indexFilePath}: ${error.message}`)
    return null // Return null if reading or parsing fails
  }
}

// Function to parse the INDEX.SYS data
const parseIndexSysData = (data, DatabaseFolder) => {
  const rows = data.split('\n') // Split file into rows
  const parsedEntries = [];
  const crcArray = []

  let versionName
  rows.forEach((row) => {
    row = row.trim() // Remove any leading/trailing spaces
    if (row === '' || row.startsWith('CRC')) return // Skip header and empty rows

    const parts = row.match(/^(\S+)\s+(\d+)\s+(.+)$/) // Match CRC, SIZE, and FILENAME
    if (parts) {
      const crc = parts[1]
      const size = parts[2]
      const filename = parts[3]
      if (size === '00000000') {
        // Handle database version
         versionName = filename // The "filename" field actually contains the version
        // console.log(`Database version found: ${versionName}`)
        parsedEntries.push({ type: 'version', DatabaseFolder, versionName })
      } else {
        // Handle regular file entries
        parsedEntries.push({ type: 'file', crc, size, filename })
        crcArray.push(crc)
      }
    } else {
      console.warn(`Unrecognized row format: ${row}`)
    }
  })

  return { versionName, crcArray } // Return all parsed entries
}

module.exports = { chooseDirDbVersion } // Export the function
