const { ipcRenderer } = require('electron')

// Request images when the window loads
window.addEventListener('DOMContentLoaded', () => {
  ipcRenderer.send('request-image-list') // Ask the main process for images
})

ipcRenderer.on('image-list', (event, data) => {
  const { images, path } = data
  const imageContainer = document.getElementById('image-container')
  imageContainer.innerHTML = '' // Clear previous images

  images.forEach((image) => {
    const card = document.createElement('div')
    card.classList.add('image-card')
    const imgElement = document.createElement('img')
    imgElement.src = `file://${path}/${image}`
    imgElement.alt = image

    // Format name: Replace "_" with " "
    const formattedName = image.replace(/_/g, ' ').replace(/\.[^/.]+$/, '')
    const nameElement = document.createElement('div')
    nameElement.classList.add('nameElement')
    nameElement.textContent = formattedName

    // Create View Button (Initially Hidden)
    const viewButton = document.createElement('button')
    viewButton.textContent = 'View'
    viewButton.classList.add('view-button')

    // Click Event for View Button
    viewButton.addEventListener('click', (e) => {
      e.stopPropagation() // Prevent triggering the card hover event
      // alert(`Viewing: ${formattedName}`) // Replace with your action

      ipcRenderer.send('open-new-window', formattedName)
    })

    // Append elements
    card.appendChild(imgElement)
    card.appendChild(nameElement)
    card.appendChild(viewButton)
    imageContainer.appendChild(card)
  })
})
