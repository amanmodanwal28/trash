const { ipcRenderer } = require('electron')
const path = require('path')
let TriggerName
let advertismentPath
// Function to fetch files using await
async function fetchFiles() {
  try {
    const files = await ipcRenderer.invoke('get-tft-files')
    // console.log(files)
    populateFileList(files)
  } catch (error) {
    console.error('Error fetching files:', error)
  }
}

// Function to populate the file list
function populateFileList(files) {
  const fileListContainer = document.getElementById('file-list')
  fileListContainer.innerHTML = '' // Clear existing content

  const fileNames = files.map((file) => file.name)
  fileNames.forEach((file, index) => {
    const listItem = document.createElement('div')
    listItem.classList.add('file-item')

    const checkbox = document.createElement('input')
    checkbox.type = 'checkbox'
    checkbox.id = `checkbox-${index}` // Unique ID for each checkbox
    checkbox.value = file
    checkbox.classList.add('file-checkbox')
    checkbox.style.display = 'none' // Initially hide checkbox

    const label = document.createElement('label')
    label.textContent = file
    label.setAttribute('for', `checkbox-${index}`) // Associate label with checkbox

    // Get file icon
    const iconUrl = getFileIcon(file)

    // Create image icon
    const img = document.createElement('img')
    img.src = iconUrl
    img.alt = 'File Icon'
    img.classList.add('file-icon')

    // Click anywhere on item to toggle checkbox
    listItem.addEventListener('click', () => {
      checkbox.checked = !checkbox.checked

      // Show all checkboxes
      document.querySelectorAll('.file-checkbox').forEach((cb) => {
        cb.style.display = 'inline-block'
      })
 

      // Apply hover effect to items with checked checkboxes
      document.querySelectorAll('.file-checkbox').forEach((cb, index) => {
        if (cb.checked) {
          const item = document.querySelectorAll('.file-item')[index]
        }
      })

    })

    listItem.appendChild(checkbox)
    listItem.appendChild(img) // Append icon before label
    listItem.appendChild(label)
    fileListContainer.appendChild(listItem)
  })
}

// Function to get file icon based on file extension
function getFileIcon(fileName) {
  const ext = fileName.split('.').pop().toLowerCase()

  if (['mp4', 'avi', 'mov', 'mkv'].includes(ext)) {
    return '../assets/FileImages/video.png'
  } else if (['mp3', 'wav', 'flac', 'aac'].includes(ext)) {
    return '../assets/FileImages/music.png'
  } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(ext)) {
    return '../assets/FileImages/images.png'
  } else {
    return '../assets/FileImages/default.png' // Default icon for other files
  }
}

ipcRenderer.on('selected-files', (event, data) => {
  const { imageName, triggerFiles, CreateMainFolder } = data

  TriggerName = imageName.replace(/\.[^/.]+$/, '')

  const triggerHeading = document.getElementById('Trigger-name')

  if (triggerHeading) {
    triggerHeading.innerText = TriggerName // Set the heading text
  } else {
    console.error("Element with ID 'Trigger-name' not found.")
  }
  advertismentPath = CreateMainFolder
  // Extract file names from triggerFiles.files
  const fileNames = triggerFiles.files.map((file) => file.name)

  // console.log('File Names:', fileNames) // Display only names in console
  // Populate Image List
  const imageList = document.getElementById('image-list')
  imageList.innerHTML = '' // Clear previous entries

  let checkboxesVisible = false // To track checkbox visibility

  fileNames.forEach((fileName, index) => {
    // Create list item
    const li = document.createElement('li')
    li.classList.add('image-item')

    // Get icon
    const iconUrl = getFileIcon(fileName)

    // Create image icon
    const img = document.createElement('img')
    img.src = iconUrl
    img.alt = 'File Icon'
    img.classList.add('file-icon') // Optional: Add CSS class for styling

    // Create checkbox (hidden initially)
    const checkbox = document.createElement('input')
    checkbox.type = 'checkbox'
    checkbox.id = `delete-checkbox-${index}` // Unique ID for each checkbox
    checkbox.value = fileName
    checkbox.classList.add('delete-file-checkbox') // Unique class for delete functionality
    checkbox.style.display = 'none' // Hide checkbox initially

    // Create file name text
    const textNode = document.createTextNode(` ${fileName}`)

    // Append elements to list item
    li.appendChild(checkbox)
    li.appendChild(img)
    li.appendChild(textNode)

    // Click handler to show checkboxes and select file
    li.addEventListener('click', () => {
      checkboxesVisible = true

      // Show all checkboxes
      document.querySelectorAll('.delete-file-checkbox').forEach((cb) => {
        cb.style.display = 'inline-block'
      })

      // Select the clicked file
      checkbox.checked = !checkbox.checked
    })

    // Append list item to image list
    imageList.appendChild(li)
  })
})

// Get necessary elements
const insertBtn = document.getElementById('insert-btn')
const deleteBtn = document.getElementById('delete-btn')
const confirmBtn = document.getElementById('confirm-btn')
const insertionContainer = document.querySelector('.insertion-container')
const mainContainer = document.querySelector('.main-container')
const backBtn = document.getElementById('back-btn')


// Insert button click - Show Insertion Container
insertBtn.addEventListener('click', () => {
  console.log('Insert button clicked')

  insertionContainer.classList.add('show')
  insertionContainer.classList.remove('hidden')

  mainContainer.classList.add('hidden')
  mainContainer.classList.remove('show')
})

// Delete button click
deleteBtn.addEventListener('click', () => {
  console.log('Delete button clicked')
  // Get all selected files
  const selectedFiles = []
  document
    .querySelectorAll('.delete-file-checkbox:checked')
    .forEach((checkbox) => {
      selectedFiles.push(checkbox.value) // Get file name
    })

  if (selectedFiles.length > 0) {
    ipcRenderer.send('tft-delete-request', {
      selectedFiles,
      TriggerName,
    })// Send selected files to delete
  } else {
    console.log('No files selected for deletion')
    showMessage('error', 'Please select a file to delete.') // Show error message
    return // Stop further execution
  }
   ipcRenderer.send('request-selected-files')
})



 // Confirm button click - Show Main Container & Log Selected Files
confirmBtn.addEventListener('click', () => {
  console.log('Confirm button clicked')

  const selectedFiles = []
  document.querySelectorAll('.file-checkbox:checked').forEach((checkbox) => {
    selectedFiles.push(checkbox.value)
  })
  // console.log('Selected Files:', selectedFiles)
  // console.log('advertismentPath name:', advertismentPath)
  // console.log('Trigger name:', TriggerName)


  if (selectedFiles.length === 0) {
    console.log('No files selected')
    showMessage('error', 'Please select at least one file.') // Show error message
    return // Stop further execution
  }

  if (!advertismentPath || !TriggerName) {
    console.log('Missing advertismentPath or TriggerName')
    showMessage('error', 'Missing required data. Please check your selections.')
    return
  }
  // Send data to the backend (Main process) using "tft"
  ipcRenderer.send('tft-confirm-selection', {
    selectedFiles,
    advertismentPath,
    TriggerName,
  })

  insertionContainer.classList.add('hidden')
  insertionContainer.classList.remove('show')

  mainContainer.classList.add('show')
  mainContainer.classList.remove('hidden')

  ipcRenderer.send('request-selected-files')
})



// Function to display messages
function showMessage(type, message) {
    const messageContainer = document.getElementById('message-container')

    if (!messageContainer) return

    messageContainer.innerHTML = `<div class="message ${type}">${message}</div>`

    // Auto-hide message after 3 seconds
    setTimeout(() => {
        messageContainer.innerHTML = ''
    }, 3000)
}

// Listen for success response
ipcRenderer.on('tft-success', (event, message) => {
    // console.log('✅ Success:', message)
    showMessage('success', message)
})

// Listen for error response
ipcRenderer.on('tft-error', (event, message) => {
    // console.error('❌ Error:', message)
    showMessage('error', message)
})


backBtn.addEventListener('click', () => {
  // console.log('back button click')
  ipcRenderer.send('request-to-Back')

})

window.addEventListener('DOMContentLoaded', async () => {
  ipcRenderer.send('request-selected-files')
  await fetchFiles()
})
