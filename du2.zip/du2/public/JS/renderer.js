console.log("🚀 renderer.js file LOADED");

window.addEventListener("DOMContentLoaded", () => {
  let selectedZipFile = null;

  const swButton = document.getElementById("swButton");
  const swDialog = document.getElementById("swUploadDialog");
  const cancelButton = document.getElementById("cancelSwButton");
  const zipInput = document.getElementById("swZipFile");
  const uploadSwBtn = document.getElementById("uploadSwButton");
  const fileNameLabel = document.getElementById("fileName");

  // =========================
  // OPEN DIALOG
  // =========================
  swButton.addEventListener("click", () => {
    swDialog.classList.add("show");
  });

  // =========================
  // CLOSE DIALOG
  // =========================
  cancelButton.addEventListener("click", closeDialog);

  function closeDialog() {
    swDialog.classList.remove("show");
    resetDialog();
  }

  function resetDialog() {
    selectedZipFile = null;
    zipInput.value = "";
    fileNameLabel.textContent = "No file selected";
    uploadSwBtn.disabled = true;
    uploadSwBtn.textContent = "Upload";
  }

  // =========================
  // FILE SELECT
  // =========================
  zipInput.addEventListener("change", (e) => {
    const file = e.target.files[0];

    if (!file || !file.name.endsWith(".zip")) {
      alert("Please select a ZIP file only");
      resetDialog();
      return;
    }

    selectedZipFile = file;
    fileNameLabel.textContent = file.name;
    uploadSwBtn.disabled = false;
  });

  // =========================
  // UPLOAD CLICK
  // =========================

uploadSwBtn.addEventListener("click", async () => {
  const ipContainer = document.getElementById("ipSelectionContainer");

  const selectedIPs = ipContainer
    ? ipContainer.querySelectorAll("input[type='checkbox']:checked")
    : [];

  if (selectedIPs.length === 0) {
    alert("Kindly select IP first");
    return;
  }

  if (!selectedZipFile) {
    alert("Please select ZIP file");
    return;
  }

  uploadSwBtn.disabled = true;
  uploadSwBtn.textContent = "Uploading...";

  try {
    for (const ipEl of selectedIPs) {
      const ip = ipEl.value; // ✅ SAFE

      console.log(`🔌 Uploading to ${ip}`);

      const result = await ipcRenderer.invoke("sw-upload", {
        ip,
        filePath: selectedZipFile.path,
        fileName: selectedZipFile.name,
      });

      if (!result.success) {
        throw new Error(`Upload failed for ${ip}: ${result.error}`);
      }
    }

    alert("Uploading completed successfully");
    closeDialog();
  } catch (err) {
    console.error(err);
    alert(err.message);
  }

  uploadSwBtn.textContent = "Upload";
  uploadSwBtn.disabled = false;
});

  

  // =========================
  // ESC KEY
  // =========================
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && swDialog.classList.contains("show")) {
      closeDialog();
    }
  });
});
