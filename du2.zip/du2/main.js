const electron = require('electron')
const path = require('path')
const fs = require('fs')
const os = require('os')
const crc = require('crc')

const { processDatabaseFolder } = require('./Component/tft_database_backend.js')

const { spawn, exec } = require('child_process')
const { app, BrowserWindow, ipcMain, dialog,Menu } = electron
const Dialog = require('./Component/dialogManager')

const bcrypt = require('bcrypt')
const xml2js = require('xml2js')
const {
  isFirstTimeSetup,
  insertNewUser,
  getStoredHashedPassword,
  updatePasswordInDatabase,
} = require('./Component/db') // Importing from db.js
const ProgressBar = require('electron-progressbar')
const { setupFfmpeg } = require('./Component/ffmpeg_path') // Adjust the path as necessary
const logger = require('./Component/logger')
const { chooseDirDbVersion } = require('./Component/chooseDirDbVersion')
const { incrementVersion } = require('./Component/incrementVersion.js')

const {
  mainWindowfn,
  connection,
  uploadFile,
} = require('./Component/sftp') // Import functions from sftp.js

// âœ… REPLACED: Import DeviceSSHManager instead of sftp functions
const {
  DeviceSSHManager,
} = require('./Component/DeviceSSHManager1')

const {
  readXmlFile,
  extractFolderInfo,
  extractField,
} = require('./Component/xmlParser')
const {
  getMainPath,
  processMediaFile,
  processImageFile,
  copyFile,
  writeToFile,
  calculateFileCRC32,
  updateConfigFile,
  addPpsInternation,
} = require('./Component/fileAdd')
const {
  imageExtensions,
  videoFileExtensions,
  musicFileExtensions,
  getSecondFolder,
  getExtension,
  isExtensionAllowed,
} = require('./Component/fileRules')
const { createFileIfNotExists } = require('./Component/generateXmlFile')
const createSplashScreen = require('./Component/splashScreen')
const { checkPathsSync } = require('./Component/pathExistVerify')
const {
  getSavedWindowState,
  trackWindowState,
  buildMenu,
} = require('./Component/windowState')
const { cleanupContentFolder } = require('./Component/delete_structure_data')

const {
  printAllPaths,
  INSTALLATION_PATH,
  RESOURCE_DIR,
  XML_CONFIG_PATH,
  FFMPEG_DIR,
  SERVER_CONTENT_PATH,
  SERVER_INDEX_SYS_PATH,
  SERVER_INDEX_TXT_PATH,

} = require('./Component/globalPath')

printAllPaths()

const license = require('./Component/licenseManager')

// Send machine key to frontend
ipcMain.handle('get-machine-key', () => {
  return license.generateMachineKey()
})

// Verify license file
ipcMain.handle('verify-key-file', (event, filePath) => {
  return license.verifyLicenseFile(filePath)
})

// Create a new instance of the parser
const parser = new xml2js.Parser({ explicitArray: false })
let userLoggedIn = false
let CreateMainFolder
let videoAdvertismentPath = null
let currentFolder

// Define your music and video file extensions

const musicVideoEXT = [...musicFileExtensions, ...videoFileExtensions]
let SourceFilePath = []
let DestinationFilePath = [] // where files will be copied
let store
let splash //splash screen window
let mainWindow //main electron window
let activeSelectedIPs = [] //user selected IPs
let localPath = 'content'
let renderIDfromWeb
let count = 0
let progressBar

// Get the path to the installation directory
let installationPath = path.dirname(process.execPath)

// Use this for both dev and production
let xmlFilePath = XML_CONFIG_PATH

let sourceFfmpegDir = path.join(
  installationPath,
  'resources',
  'resources',
  'ffmpeg',
)

//creates the main UI window
async function createMainWindow(ipList) {
  try {
    const minWidth = 1210 // You can adjust this value as needed
    const minHeight = minWidth / 2

    const windowState = await getSavedWindowState(minWidth, minHeight)

    //  Create the BrowserWindow first
    mainWindow = new BrowserWindow({
      width: windowState.width,
      height: windowState.height,
      minWidth: minWidth,
      minHeight: minHeight,
      x: windowState.x,
      y: windowState.y,
      title: 'SPUT Tool',
      icon: path.join(__dirname, './public/assets/Logo/pps_logo.ico'),
      // alwaysOnTop: true,
      show: false,
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false,
      },
    })

    await trackWindowState(mainWindow)

    mainWindow.loadFile(path.join(__dirname, './public/HTML/login.html'))

    ipcMain.on('renderer-ready', () => {
      // console.log('Renderer ready → sending initial data')

      if (mainWindow) {
        mainWindow.webContents.send('initial-data', { ipList })
        mainWindow.webContents.send('isFirstTimeSetup', isFirstTimeSetup)
      }
    })


    Menu.setApplicationMenu(null)

    mainWindow.once('ready-to-show', () => {
      // Close splash screen before showing main window
      if (splash && !splash.isDestroyed()) {
        splash.close()
      }
      // Show main window after splash is closed
      mainWindow.show()
    })

    mainWindow.on('closed', () => {
      mainWindow = null
    })
  } catch (error) {
    logger.error(`Error in createMainWindow: %o`, error)
    // Ensure splash closes even if there's an error
    if (splash && !splash.isDestroyed()) {
      splash.close()
    }
  }
}
ipcMain.on('enable-menu', () => {
  console.log("hello")
  if (!mainWindow) return
  const menu = buildMenu(mainWindow)
  Menu.setApplicationMenu(menu)
})


// Handle first-time setup request
ipcMain.handle('firstTimeSetup', async (event, { username, password }) => {
  try {
    logger.info('First-time setup with username: %s', username)
    return await insertNewUser(username, password)
  } catch (error) {
    logger.error(`Error during first-time setup: ${error.message}`)
    return { success: false, message: 'Error during first-time setup.' }
  }
})

// Handle login request
ipcMain.handle('login', async (event, { username, password }) => {
  logger.info('Login attempt with username: %s', username)

  const storedHashedPassword = await getStoredHashedPassword(username)
  if (storedHashedPassword) {
    const passwordMatch = await bcrypt.compare(password, storedHashedPassword)
    if (passwordMatch) {
      logger.info('Password match!')
      return { success: true, token: 'dummy_token' }
    } else {
      logger.warn('Password does not match!')
      return { success: false, message: 'Invalid username or password' }
    }
  } else {
    logger.warn('User not found!')
    return { success: false, message: 'User not found' }
  }
})

// Handle password update request
ipcMain.handle(
  'updatePassword',
  async (event, { username, oldPassword, newPassword }) => {
    try {
      logger.info('Updating password for user: %s', username)
      const updateResult = await updatePasswordInDatabase(
        username,
        oldPassword,
        newPassword,
      )
      return updateResult
    } catch (error) {
      logger.error(`Error during password update: ${error.message}`)
      return { success: false, message: 'Error during password update.' }
    }
  },
)

app.whenReady().then(async () => {
  try {
    splash = await createSplashScreen() // Show the splash screen
    // â­ give renderer time to paint
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Set sourceFfmpegDir based on the platform (Windows vs Linux)
    if (os.platform() === 'win32') {
      sourceFfmpegDir = path.join(
        installationPath,
        'resources',
        'resources',
        'ffmpeg',
      )
    } else if (os.platform() === 'linux') {
      sourceFfmpegDir = path.join(
        installationPath,
        'resources',
        'resources',
        'ffmpeg_linux',
      )
    } else {
      logger.error(`Unsupported platform: ${os.platform()}`)
      return // Exit early if the platform is unsupported
    }

    // Get the path to the installation directory
    installationPath = path.dirname(process.execPath)

    // Ensure the required paths exist
    const paths = checkPathsSync(xmlFilePath, sourceFfmpegDir)
    xmlFilePath = paths.xmlFilePath
    sourceFfmpegDir = paths.sourceFfmpegDir

    // Initialize configuration and resources
    await createFileIfNotExists(xmlFilePath)
    await processXmlData()

    await setupFfmpeg(sourceFfmpegDir)
  } catch (error) {
    handleCriticalError(error)
    logger.error(`app.whenReady(): Failed to initialize: ${error}`)
  }
})

// Example error handling
function setupGlobalErrorHandling(logger) {
  // Handle uncaught exceptions
  process.on('uncaughtException', (error) => {
    console.error(`Uncaught Exception: ${error}`)
    logger.error(`Uncaught Exception: ${error}`)
  })

  // Handle unhandled promise rejections
  process.on('unhandledRejection', (reason, promise) => {
    console.error('UNHANDLED REJECTION:', reason)
    let reasonMessage = ''
    if (reason instanceof Error) {
      reasonMessage = `${reason.message}\n${reason.stack}`
    } else {
      reasonMessage = JSON.stringify(reason)
    }

    logger.error({
      level: 'error',
      message: 'Unhandled Rejection at:',
      promise: promise.toString(),
      reason: reasonMessage,
      service: 'user-service',
      timestamp: new Date().toISOString(),
    })
  })
}
async function exampleFunction(logger) {
  try {
    await new Promise((resolve, reject) => {
      reject(new Error('Simulated error'))
    })
  } catch (error) {
    console.error(`Handled Promise Rejection: ${error}`)
    logger.error(`Handled Promise Rejection: ${error}`)
  }
}
// Set up global error handling
setupGlobalErrorHandling(logger)
// Example function call
exampleFunction(logger)

function handleCriticalError(error) {
  console.error('A critical error occurred:', error)
  // Log the error (optional)
  if (logger) {
    logger.error(`Critical Error: ${error.stack || error.message || error}`)
  }
  // Show error dialog
  Dialog.showError('Application Error', `An error occurred:\n${error.message}`)

  // Close the application
  app.quit()
}
async function processXmlData() {
  try {
    const data = await readXmlFile(xmlFilePath) // Adjust the path as necessary
    const xml_result = await parser.parseStringPromise(data)
    const dataStructure = xml_result.IOTConfig.DATA_STRUCTURE
    const folderInfo = extractFolderInfo(dataStructure)
    // Extract folder information from DATA_STRUCTURE
    main_folders = extractField(folderInfo, 'folder_name')
    const updatedList =
      await DeviceSSHManager.fetchDevicesRuntimeInfo(xml_result)
    await createMainWindow(updatedList)

    mainWindowfn(mainWindow)

  } catch (error) {
    logger.error(`processXmlData: Error: ${error}`)
  }
}

// Update the interval function in user-logged-in event
ipcMain.on('user-logged-in', async () => {
  if (userLoggedIn) return
  userLoggedIn = true
  const data = await readXmlFile(xmlFilePath)
  const xml_result = await parser.parseStringPromise(data)
  setInterval(async () => {
    try {
      const updatedList =
        await DeviceSSHManager.fetchDevicesRuntimeInfo(xml_result)

      if (mainWindow) {
        mainWindow.webContents.send('update-ip-status', { updatedList })
      }
    } catch (err) {
      console.error('Device refresh error:', err)
    }
  }, 5000)
})


  // ======================================
  // Directory CRC Generator (INDEX format)
  // ======================================

async function generateCRCReport(baseDir) {
  let outputLines = []

  // Header
  outputLines.push('CRC             SIZE   FILENAME')

  // Read ONLY first level folders
  const firstLevelEntries = await fs.promises.readdir(baseDir, {
    withFileTypes: true,
  })

  // Loop through subfolders only
  for (const entry of firstLevelEntries) {
    if (!entry.isDirectory()) continue // ⛔ Skip root files

    const folderPath = path.join(baseDir, entry.name)

    await scanDirectory(folderPath)
  }

  // ======================================
  // Recursive scan
  // ======================================
  async function scanDirectory(currentDir) {
    const entries = await fs.promises.readdir(currentDir, {
      withFileTypes: true,
    })

    for (const entry of entries) {
      const fullPath = path.join(currentDir, entry.name)

      if (entry.isDirectory()) {
        await scanDirectory(fullPath)
      } else if (entry.isFile()) {
        try {
          // CRC
          const crcValue = await calculateFileCRC32(fullPath)

          // SIZE
          const stats = await fs.promises.stat(fullPath)
          const fileSize = stats.size

          // Relative Path
          let relativePath = path.relative(baseDir, fullPath)

          // Convert Windows slash to Linux style
          relativePath = relativePath.replace(/\\/g, '/')

          // Add leading /
          relativePath = '/' + relativePath

          // Format line EXACT spacing
          const line =
            crcValue.padEnd(8) +
            fileSize.toString().padStart(12) +
            '   ' +
            relativePath

          outputLines.push(line)
        } catch (err) {
          logger.error('CRC error:', err.message)
        }
      }
    }
  }

  return outputLines.join('\n')
}

ipcMain.on('export-database-request',async (event, version) => {
  console.log('Export version:', version)


  console.log('Export request received in main process', CreateMainFolder)
  try {
    const report = await generateCRCReport(CreateMainFolder)

    console.log(report)

    // ✅ Version header line
    const versionLine =
      '00000000'.padEnd(8) + '00000000'.padStart(12) + '   DB Ver: ' + version

    // ✅ Final File Content
    const finalContent = versionLine + '\n' + report

    // OPTIONAL → Save as INDEX.SYS style file
    const outputPath = path.join(CreateMainFolder, 'INDEX_NEW.SYS')

    await fs.promises.writeFile(outputPath, finalContent)

    console.log('CRC File Generated:', outputPath)
  } catch (err) {
    logger.error('Directory CRC failed:', err)
  }
})

let exportWindow

ipcMain.on('open-export-prompt', () => {
  if (exportWindow) {
    exportWindow.focus()
    return
  }

  let dbVersion = 'Unknown'

  try {
    const indexPath = path.join(CreateMainFolder, 'INDEX.SYS')

    if (fs.existsSync(indexPath)) {
      const data = fs.readFileSync(indexPath, 'utf8')

      const match = data.match(/DB Ver:\s*([^\r\n]+)/)

      if (match) {
        dbVersion = match[1].trim()
      }
    }
  } catch (err) {
    console.error('Error reading INDEX.SYS:', err)
  }

  exportWindow = new BrowserWindow({
    width: 400,
    height: 250,
    resizable: false,
    parent: BrowserWindow.getFocusedWindow(),
    modal: true,
    frame: false,
    titleBarStyle: 'hidden',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  })
  const exportPrompt_htmlpath = path.join(
    __dirname,
    './public/HTML/exportPrompt.html',
  )

  exportWindow.loadFile(exportPrompt_htmlpath)

  // 👉 Send version after window loads
  exportWindow.webContents.once('did-finish-load', () => {
    exportWindow.webContents.send('set-db-version', dbVersion)
  })

  exportWindow.on('closed', () => {
    exportWindow = null
  })
})




ipcMain.on('selected-ips', async (event, selectedIPs) => {
  try {
    // console.log('Received selected-ips event with:', selectedIPs)
    activeSelectedIPs = selectedIPs
  } catch (e) {
    console.error('Error connecting to selected IPs:', e)
  }
})

ipcMain.handle('choose-contentdir', async () => {
  try {
    const result = await Dialog.openFolder(mainWindow)

    return result
  } catch (err) {
    logger.error(
      `ipcMain.handle('choose-contentdir'): Error opening folder selection dialog: ${err}`,
    )
    throw err
  }
})

async function create_Database(event, DatabaseFolder) {
  count++

  try {
    CreateMainFolder = DatabaseFolder
    getMainPath(CreateMainFolder)
    selectedfilePathDir = CreateMainFolder

    // Call function from tft_database_backend.js and get result
    const dbResult = await processDatabaseFolder(CreateMainFolder, mainWindow)

    console.log('Database open ', CreateMainFolder)
    videoAdvertismentPath = path.join(
      CreateMainFolder,
      'videoAdvertismentTime.txt',
    )

    if (fs.existsSync(videoAdvertismentPath)) {
      console.log('videoAdvertismentTime.txt already exists, skipping writefiles',)
    } else {
      console.log('File not found, creating it with default value')
      writefiles('0.2')
    }

    // Paths for all folders and INDEX.SYS
    const folderPaths = main_folders.map((folder) =>
      path.join(CreateMainFolder, folder),
    )
    const indexFilePath = path.join(CreateMainFolder, 'INDEX.SYS')

    // Check if all folders and the INDEX.SYS file exist
    const checks = await Promise.all([
      ...folderPaths.map(
        (folderPath) =>
          new Promise((resolve) => {
            fs.access(folderPath, (err) => {
              if (err) {
                // console.log(`Folder missing: ${folderPath}`)
                resolve(false) // Resolve with false if folder is missing
              } else {
                // console.log(`Folder exists: ${folderPath}`)
                resolve(true) // Resolve with true if folder exists
              }
            })
          }),
      ),
      new Promise((resolve) => {
        fs.access(indexFilePath, (err) => {
          if (err) {
            console.log(`File missing: ${indexFilePath}`)
            resolve(false) // Resolve with false if file is missing
          } else {
            // console.log(`File exists: ${indexFilePath}`)
            resolve(true) // Resolve with true if file exists
          }
        })
      }),
    ])

    // Extract results from checks
    const folderChecks = checks.slice(0, main_folders.length)
    const indexFileExists = checks[main_folders.length]
    // Check if all folders exist
    const allFoldersExist = folderChecks.every((exists) => exists)
    const allConditionsMet = allFoldersExist && indexFileExists

    // console.log('All folders exist:', allFoldersExist)
    // console.log('INDEX.SYS exists:', indexFileExists)

    if (allConditionsMet) {
      // Proceed to list files and folders if all folders and the file exist
      event.sender.send('local-path', path.basename(CreateMainFolder))

      const { folders } = await listFilesAndFolders(CreateMainFolder)
      mainWindow.webContents.send('database-created', {
        folders,
        count,
        CreateMainFolder,
      })

      event.sender.send('choose-mainfolder-update', CreateMainFolder)
      // await openCustomPrompt()

      // console.log('Folders listed:', folders)
    } else {
      // Show dialog if any folder or the file is missing
      await Dialog.show('PATH_ERROR', mainWindow)

      //  window reload
      mainWindow.reload()
      console.log(
        'One or more required directories or INDEX.SYS file are missing in the database folder.',
      )
    }

    // console.log(count)
  } catch (error) {
    logger.error(`create_Database: Error creating database: ${error}`)
  }
}

ipcMain.on('create-database', async (event, DatabaseFolder) => {
  console.log('Database Folder Path', DatabaseFolder)
  await create_Database(event, DatabaseFolder)
  // Call chooseDbVersion and handle the returned data
  const parsedData = await chooseDirDbVersion(DatabaseFolder)
  if (parsedData) {
    console.log('Parsed Data Version:', parsedData.versionName)

    // Send the parsed data to the renderer process if needed
    event.sender.send('choose_Dir_VersionName', parsedData.versionName)
  } else {
    console.error('Failed to parse database version or read INDEX.SYS.')
  }
})

ipcMain.on('open-advertisement-prompt', async () => {
  try {
    const value = await openCustomPrompt()

    console.log('Advertisement value:', value)
  } catch (err) {
    console.error('Failed to open advertisement prompt', err)
  }
})

async function listFilesAndFolders(directoryPath) {
  try {
    const items = await fs.promises.readdir(directoryPath)
    let folders = []
    let regularFiles = []

    for (const item of items) {
      const fullPath = path.join(directoryPath, item)
      const stats = await fs.promises.stat(fullPath)

      if (stats.isDirectory()) {
        folders.push(item)
      } else {
        regularFiles.push(item)
      }
    }

    return { folders, regularFiles }
  } catch (err) {
    logger.error(`listFilesAndFolders: Error reading directory: ${err}`)
    throw err // Propagate the error upwards
  }
}

ipcMain.on('selected-folder', async (event, folderName, renderID) => {
  try {
    const folderPath = path.join(CreateMainFolder, folderName)
    currentFolder = folderPath
    const BrowserolderPath = path.join(
      path.basename(CreateMainFolder),
      folderName,
    )
    localPath = folderPath
    renderIDfromWeb = renderID
    console.log('Selected folderName:', folderPath)
    const { folders, regularFiles } = await listFilesAndFolders(folderPath)
    event.sender.send('folder-contents', { folders, regularFiles })
    // Send localPath to renderer process
    event.sender.send('local-path', BrowserolderPath)
  } catch (e) {
    logger.error(`selected-folder: Error listing folders: %s, ${e.message}`)
  }
})

ipcMain.on('selected-subfolder', async (event, subfolderPath, renderID) => {
  try {
    const SubfolderPath = path.join(CreateMainFolder, subfolderPath)
    currentFolder = SubfolderPath
    const BrowserSubfolderPath = path.join(
      path.basename(CreateMainFolder),
      subfolderPath,
    )
    localPath = SubfolderPath
    renderIDfromWeb = renderID
    console.log('selected SubfolderPath ', SubfolderPath)
    const { folders, regularFiles } = await listFilesAndFolders(SubfolderPath)
    event.sender.send('subfolder-contents', { folders, regularFiles })
    // Send localPath to renderer process
    event.sender.send('local-path', BrowserSubfolderPath)
  } catch (e) {
    logger.error(
      `selected-subfolder: Error listing subfolders: %s, ${e.message}`,
    )
  }
})

// Handle 'selected-subsubfolder' event from renderer process
ipcMain.on(
  'selected-subsubfolder',
  async (event, subsubfolderPath, renderID) => {
    try {
      const SubsubfolderPath = path.join(CreateMainFolder, subsubfolderPath)
      currentFolder = SubsubfolderPath
      const BrowserSubsubfolderPath = path.join(
        path.basename(CreateMainFolder),
        subsubfolderPath,
      )
      localPath = SubsubfolderPath
      renderIDfromWeb = renderID
      console.log('Selected Sub-Subfolder :', SubsubfolderPath)
      // List files and folders in the selected sub-subfolder path
      const { folders, regularFiles } =
        await listFilesAndFolders(SubsubfolderPath)
      // Send the list of files back to the renderer process
      event.sender.send('subsubfolder-files', { folders, regularFiles })
      // Send localPath to renderer process
      event.sender.send('local-path', BrowserSubsubfolderPath)
    } catch (e) {
      logger.error(
        `selected-subsubfolder: Error listing files in sub-subfolder: %s, ${e.message}`,
      )
    }
  },
)

ipcMain.on('refresh-folder-fileList', async (event, selectedfilePathDir) => {
  try {
    let RefreshfilePathDir = path.join(
      path.dirname(CreateMainFolder),
      selectedfilePathDir,
    )
    const { folders, regularFiles } =
      await listFilesAndFolders(RefreshfilePathDir) // Use the new function
    event.sender.send(renderIDfromWeb, { folders, regularFiles })
    // console.log('refresh-folder-fileList')
  } catch (error) {
    logger.error(
      `refresh-folder-fileList: Error refreshing folder contents: %s, ${error.message}`,
    )
    // Handle error appropriately (send error to renderer process or log)
  }
})

let progressBarClosed = false // Flag to monitor progress bar status

ipcMain.on('upload-files', async (event, { filePaths }) => {
  progressBarClosed = false
  let progressBar = null
  try {
    SourceFilePath = []
    DestinationFilePath = []
    // console.log('Received file upload request:', filePaths)
    // localPath = SubfolderPath;
    const destinationFolder = localPath // Ensure `localPath` is defined

    const filesToWrite = []
    let extension
    let ExtensionNotMatch = false
    let ExtensionNotSupport = []

    const secondFolder = getSecondFolder(currentFolder, CreateMainFolder)

    const validFiles = []
    const invalidFiles = []

    for (const fp of filePaths) {
      const ext = getExtension(fp)

      if (isExtensionAllowed(ext, secondFolder)) {
        validFiles.push(fp)
      } else {
        invalidFiles.push(fp)
      }
    }

    if (invalidFiles.length > 0) {
      event.sender.send(
        'alert',
        `Skipped ${invalidFiles.length} invalid file(s) in ${secondFolder}`,
      )
    }

    // ðŸ›‘ Nothing valid â†’ stop
    if (validFiles.length === 0) {
      event.sender.send('alert', 'No valid files to upload')
      return
    }

    // Initialize progress bar
    progressBar = new ProgressBar({
      title: 'Adding Files',
      text: 'Initializing...',
      detail: 'Starting Add...',
      indeterminate: false,
      alwaysOnTop: true,
      closeOnComplete: false,
      maxValue: 100,
      style: {
        text: {
          color: '#contextIsolation',
          'font-Size': '14px',
        },
        detail: {
          color: '#000000',
          'font-Size': '16px',
        },
        bar: {
          background: '#ffffff',
          height: 10,
          width: 50,
        },
        value: {
          background: '#059212',
        },
      },
      browserWindow: {
        width: 500,
        height: 200,
        closable: true,
        parent: mainWindow,
        modal: false,
        alwaysOnTop: true,
        minimizable: true,
        resizable: false,
        maximizable: true,
        closable: true,
        icon: path.join(__dirname, './public/assets/Logo/pps_logo.ico'),
        backgroundColor: '#FAF6F0',
      },
    })
    progressBar
      .on('completed', () => {
        progressBar.detail = 'File adding...'
        console.log('Upload complete')
      })
      .on('aborted', () => {
        console.warn('Upload aborted')
        aborted = true // Set aborted flag
        progressBarClosed = true
      })
    // First loop: initial file processing

    for (let index = 0; index < validFiles.length; index++) {
      if (progressBarClosed) break // Stop processing if progress bar is closed

      const filePath = validFiles[index]
      let filename = path.basename(filePath)
      extension = path.extname(filename).toLowerCase().slice(1)
      let destinationPath = path.join(destinationFolder, filename)

      // Adjust file extensions based on type
      if (videoFileExtensions.includes(extension)) {
        destinationPath = path.join(destinationFolder, filename)
      } else if (musicFileExtensions.includes(extension)) {
        destinationPath = path.join(
          destinationFolder,
          filename.replace(path.extname(filename), '.mp3'),
        )
      }

      SourceFilePath.push(filePath)
      DestinationFilePath.push(destinationPath)
    }

    // Second loop: file operations
    for (let index = 0; index < SourceFilePath.length; index++) {
      if (progressBarClosed) break // Stop processing if progress bar is closed

      const filePath = SourceFilePath[index]
      const destinationPath = DestinationFilePath[index]

      // Check if destination file already exists
      try {
        await fs.promises.access(destinationPath)
        console.log(`File already exists: ${destinationPath}`)
        continue // Skip processing if file exists
      } catch {
        console.log(`File does not exist, processing: ${destinationPath}`)

        // Process file based on type
        checkFileSize(progressBar)

        let processFilePromise
        if (musicVideoEXT.some((ext) => filePath.toLowerCase().endsWith(ext))) {
          processFilePromise = processMediaFile(
            filePath,
            destinationPath,
            progressBarClosed,
            progressBar,
          )
        } else if (
          imageExtensions.some((ext) => filePath.toLowerCase().endsWith(ext))
        ) {
          processFilePromise = processImageFile(
            filePath,
            destinationPath,
            progressBarClosed,
            progressBar,
          )
        } else {
          processFilePromise = copyFile(
            filePath,
            destinationPath,
            progressBarClosed,
            progressBar,
          )
        }

        // Run file processing and CRC32 calculation sequentially
        try {
          await processFilePromise
          await addPpsInternation(destinationPath)
          const crc32 = await calculateFileCRC32(
            destinationPath,
            event,
            progressBarClosed,
            progressBar,
          )
          // console.log(crc32)
          filesToWrite.push({ destinationPath, crc32 })
        } catch (err) {
          logger.error(
            `'upload-files: Error processing file or calculating CRC32 for %s: %s',${filePath}, ${err.message}`,
          )
          throw err // Propagate error to outer catch block
        }
      }
    }

    if (filesToWrite.length > 0) {
      await writeToFile(filesToWrite, destinationFolder)
    } else {
      console.log('All files already exist, skipping write to INDEX.SYS')
    }

    event.sender.send('files-uploaded-now-reload', {
      filePaths: validFiles.map((fp) => {
        path.join(destinationFolder, path.basename(fp))
      }),
    })

    if (ExtensionNotMatch) {
      event.sender.send(
        'alert',
        `File with extension: (${ExtensionNotSupport}) is not supported`,
      )
    }
    if (progressBar) {
      progressBar.close() // Only close if it was created
    }
  } catch (error) {
    logger.error(`upload-files: Error uploading files: %s, ${error.message}`)
    event.sender.send('alert', `some File could not be processed.`)
    if (progressBar && !progressBarClosed) {
      progressBar.close() // Only close if it exists and wasn't already closed
    }
    event.sender.send('files-uploaded-now-reload', {})
  }
})

async function checkFileSize(progressBar = null) {
  let filepaths = SourceFilePath
  let destination = DestinationFilePath
  let processedFiles = 0
  const totalFiles = filepaths.length

  // Check each file and update the progress bar accordingly
  for (let i = 0; i < filepaths.length; i++) {
    const filepath = filepaths[i]
    const destPath = destination[i]

    // Wait until destination file exists
    while (true) {
      try {
        await fs.promises.access(destPath)
        break
      } catch (err) {
        await new Promise((resolve) => setTimeout(resolve, 100)) // Wait for 0.1 second before checking again
      }
    }

    // Update progress bar after confirming the file exists at the destination
    processedFiles++
    const progressPercent = (processedFiles / totalFiles) * 100
    // console.log(progressPercent, "progressPercent", "progressPercent")
    progressBar.value = progressPercent // Update progress value
    progressBar.detail = `${Math.floor(progressPercent)}% Complete`
    progressBar.text = `Processing file:${processedFiles} out of ${totalFiles} ${path.basename(
      filepath,
    )}`
  }
  // logger.info('checkFileSize: Processed %d out of %d files.', processedFiles, totalFiles)
  // console.log(`Processed ${processedFiles} out of ${totalFiles} files.`)
}

// Handle SFTP connection errors
ipcMain.on('sftp-connection-error', async (event, errorMessage) => {
  await Dialog.show('SFTP_CONNECTION_ERROR', mainWindow, {
    error: errorMessage,
  })
})



ipcMain.on('uploadButton-sending-request', async (event) => {
  console.log('hello upload button')
  let local, remote
  let dbVerificationFailures = []
  let progressBar = null // Initialize outside try block

  // let sftp
  let existingFileCount = 0 // Counter for existing files with matching size
  let replacedFileCount = 0 // Counter for files replaced due to size mismatch
  let uploadedFileCount = 0 // Counter for newly uploaded files
  progressBarClosed = false
  let errorShown = false // Flag to track if error dialog has been shown
  let connectionErrors = [] // Track connection failures

  try {
    if (!CreateMainFolder) {
      await Dialog.show('TRANSFER_PATH_ERROR', mainWindow)

      logger.error('Path not selected for file transfer.')
      return
    }

    ConfigFilePath = path.join(CreateMainFolder, 'INDEX.SYS')

    // Check if the configuration file exists
    try {
      await fs.promises.access(ConfigFilePath)
    } catch (err) {
      await Dialog.show('CONFIG_NOT_FOUND', mainWindow, {
        path: ConfigFilePath,
      })

      logger.error(`Configuration file not found at ${ConfigFilePath}.`)
      return
    }

    const paths = await readConfigFile(ConfigFilePath)

    let crcMismatchFound = false

    if (activeSelectedIPs.length === 0) {
      event.sender.send('alert', 'Please choose an IP for file transfer.')
      logger.error('No IP selected for file transfer.')
      return
    }

    const totalFiles = paths.localPath.length * activeSelectedIPs.length
    let completedFiles = 0

    progressBar = new ProgressBar({
      indeterminate: false,
      text: 'Uploading files...',
      detail: 'Initializing...',
      maxValue: totalFiles,
      browserWindow: {
        parent: mainWindow,
        modal: false,
        alwaysOnTop: true,
        minimizable: true,
        resizable: false,
        maximizable: true,
        closable: true,
        icon: path.join(__dirname, './public/assets/Logo/pps_logo.ico'),
        backgroundColor: '#FAF6F0',
      },
    })

    progressBar
      .on('completed', () => {
        console.log('Upload complete')
        progressBar.detail = 'Upload complete'
        progressBarClosed = true
      })
      .on('aborted', () => {
        logger.warn('Upload aborted')
        progressBarClosed = true
      })
      .on('progress', (value) => {
        progressBar.detail = `Processing file ${value} of ${totalFiles}...`
      })

    const updateProgressBar = (action = 'Processing') => {
      completedFiles++
      if (progressBar && !progressBar.isCompleted()) {
        progressBar.value = completedFiles
        progressBar.detail = `${action} file ${completedFiles} of ${totalFiles}...`

        if (completedFiles >= totalFiles) {
          progressBar.setCompleted()
        }
      }
    }

    if (!paths || !paths.localPath || paths.localPath.length === 0) {
      if (progressBar) progressBar.close()
      logger.info('upload-folder - No files found to process.')
      await Dialog.show('NO_FILES_FOUND', mainWindow)
      return
    }

    const uploadTasks = activeSelectedIPs.map(async (ip) => {
      // Track stats per IP
      let ipStats = {
        uploaded: 0,
        skipped: 0,
        replaced: 0,
        errors: 0,
        connected: false,
      }

      let deviceManager = null
      let conn = null
      let sftp = null

      try {
        // ========================================
        // ⚡ STEP 1: Test Connection First
        // ========================================
        logger.info(`[${ip}] Attempting connection...`)
        progressBar.detail = `Connecting to ${ip}...`

        // ✅ Create DeviceSSHManager instance for this IP
        deviceManager = new DeviceSSHManager(ip)

        try {
          // ✅ Connect using the manager (with retry logic built-in)
          await deviceManager.connect()
          ipStats.connected = true
          logger.info(`[${ip}] ✅ Connected successfully`)
        } catch (connectErr) {
          logger.error(`[${ip}] ❌ Connection failed: ${connectErr.message}`)
          connectionErrors.push({
            ip,
            error: connectErr.message,
          })

          // Mark all files for this IP as errors in progress bar
          for (let i = 0; i < paths.localPath.length; i++) {
            updateProgressBar('Connection Failed')
          }

          return // Skip this IP entirely
        }



        // ========================================
        // ⚡ STEP 3: Process Files
        // ========================================
        for (let i = 0; i < paths.localPath.length; i++) {
          try {
            local = path.join(CreateMainFolder, paths.localPath[i])
            remote = SERVER_CONTENT_PATH + paths.remotePath[i]
            const expectedSize = parseInt(paths.textFileSize[i], 10)
            const expectedCrc = paths.textCrc[i]

            // Get local file info
            const localStats = await fs.promises.stat(local)
            const localSize = localStats.size
            const localCrc = await calculateFileCRC32(local)

            // logger.info(`[${ip}] Checking file: ${paths.localPath[i]} (Local: ${localSize} bytes, Expected: ${expectedSize} bytes)`,)

            // Check if remote file exists
            const exists = await deviceManager.fileExists(remote)

            let shouldUpload = false
            let uploadReason = ''

            if (!exists) {
              shouldUpload = true
              uploadReason = 'New file'
              ipStats.uploaded++
            } else {
              // Compare file sizes
              try {
                const remoteStat = await deviceManager.sftp.stat(remote)
                const remoteSize = remoteStat.size

                logger.info(`[${ip}] File exists: ${paths.localPath[i]} - Remote: ${remoteSize} bytes, Local: ${localSize} bytes`,)

                if (remoteSize !== localSize) {
                  shouldUpload = true
                  uploadReason = `Size mismatch (Remote: ${remoteSize}B, Local: ${localSize}B)`
                  ipStats.replaced++
                  replacedFileCount++

                  logger.warn(
                    `[${ip}] Size mismatch for ${remote}. Remote: ${remoteSize}, Local: ${localSize}. Will replace.`,
                  )
                } else {
                  shouldUpload = false
                  uploadReason = 'Identical (name + size match)'
                  ipStats.skipped++
                  existingFileCount++

                  logger.info(
                    `[${ip}] File already exists with matching size: ${remote}. Skipping.`,
                  )
                }
              } catch (statErr) {
                shouldUpload = true
                uploadReason = 'Cannot verify remote file'
                ipStats.uploaded++

                logger.warn(
                  `[${ip}] Cannot stat remote file ${remote}. Will upload. Error: ${statErr.message}`,
                )
              }
            }

            // Verify CRC before upload
            if (shouldUpload) {
              if (localCrc === expectedCrc) {
                logger.info(
                  `[${ip}] Uploading: ${paths.localPath[i]} - Reason: ${uploadReason}`,
                )

                await deviceManager.uploadFile(local, remote)

                logger.info(
                  `[${ip}] ✅ Successfully uploaded: ${local} → ${remote}`,
                )

                if (!uploadReason.includes('Size mismatch')) {
                  uploadedFileCount++
                }

                updateProgressBar('Uploaded')
              } else {
                logger.warn(
                  `[${ip}] ❌ CRC mismatch for ${local}. Expected ${expectedCrc}, got ${localCrc}. Skipping upload.`,
                )
                crcMismatchFound = true
                ipStats.errors++
                updateProgressBar('Skipped (CRC error)')
              }
            } else {
              logger.info(
                `[${ip}] ⏭️  Skipped: ${paths.localPath[i]} - Reason: ${uploadReason}`,
              )
              updateProgressBar('Skipped')
            }
          } catch (err) {
            ipStats.errors++

            if (!errorShown) {
              if (err.code === 'ENOENT') {
                const PathParsing = path.parse(err.path)
                const errPath = path.join(
                  path.basename(PathParsing.dir),
                  PathParsing.base,
                )
                await Dialog.show('SOME_FILES_NOT_FOUND', mainWindow)
                logger.error(`[${ip}] Some Files not found: ${errPath}`)
              } else {
                logger.error(
                  `[${ip}] Error uploading file from ${local} to ${remote}:`,
                  err,
                )
              }
            }
            updateProgressBar('Error')
          }
        }

        // ========================================
        // ⚡ STEP 4: Upload INDEX.SYS and config files
        // ========================================
        try {
          logger.info(
            `[${ip}] Uploading INDEX.SYS and videoAdvertismentTime.txt...`,
          )

          await deviceManager.uploadFile(ConfigFilePath, SERVER_INDEX_SYS_PATH)
          await deviceManager.uploadFile(
            videoAdvertismentPath,
            SERVER_INDEX_TXT_PATH,
          )

          const verify = await deviceManager.verifyFromSys(
            SERVER_INDEX_SYS_PATH,
            SERVER_CONTENT_PATH,
          )

          logger.info(
            `[${ip}] 📊 Upload Summary: ` +
              `Uploaded: ${ipStats.uploaded}, ` +
              `Replaced: ${ipStats.replaced}, ` +
              `Skipped: ${ipStats.skipped}, ` +
              `Errors: ${ipStats.errors}`,
          )

          if (!verify.success) {
            logger.error(
              `[${ip}] ❌ DB Verification failed. Missing ${verify.missingCount} files.`,
            )

            dbVerificationFailures.push({
              ip,
              missingCount: verify.missingCount,
              missingFiles: verify.missingFiles,
            })
            return
          }

          logger.info(
            `[${ip}] ✅ DB Verification passed. All ${verify.total} files present.`,
          )

          // Cleanup
          await cleanupContentFolder(
            sftp,
            SERVER_CONTENT_PATH,
            paths.remotePath,
          )

          logger.info(`[${ip}] ✅ Upload completed successfully`)
        } catch (e) {
          logger.error(`[${ip}] Error uploading config files:`, e)
        }
      } catch (err) {
        logger.error(
          `[${ip}] Error with connection or file transfer: ${err.message}`,
        )

        connectionErrors.push({
          ip,
          error: err.message,
        })
      } finally {
        // ========================================
        // ⚡ CLEANUP: Always close connections
        // ========================================
        try {
          if (conn) conn.end()
          if (deviceManager) await deviceManager.close()
        } catch (cleanupErr) {
          logger.error(`[${ip}] Cleanup error: ${cleanupErr.message}`)
        }
      }
    })

    // ========================================
    // ⚡ Wait for all uploads to complete
    // ========================================
    await Promise.all(uploadTasks)

    // ========================================
    // ⚡ FINAL SUMMARY DIALOGS
    // ========================================

    // Close progress bar
    if (progressBar && !progressBar.isCompleted()) {
      progressBar.setCompleted()
    }

    // Show connection errors first
    if (connectionErrors.length > 0) {
      const errorList = connectionErrors
        .map((item) => `${item.ip}: ${item.error}`)
        .join('\n')

      await Dialog.show('CONNECTION_ERRORS', mainWindow, {
        errorList,
        totalFailed: connectionErrors.length,
      })
    }

    // Show DB verification failures
    if (dbVerificationFailures.length > 0) {
      const failedIPs = dbVerificationFailures
        .map((item) => `${item.ip} (${item.missingCount} missing files)`)
        .join('\n')

      await Dialog.show('DB_FILES_MISSING', mainWindow, {
        ipList: failedIPs,
        totalFailed: dbVerificationFailures.length,
      })
    }

    // Show CRC mismatch warning
    if (crcMismatchFound) {
      event.sender.send('alert', 'Error code 45')
    }

    // Show upload summary (only if at least one device connected successfully)
    const totalProcessed =
      uploadedFileCount + existingFileCount + replacedFileCount

    if (totalProcessed > 0) {
      let summaryMessage = `Upload Complete!\n\n`

      if (uploadedFileCount > 0) {
        summaryMessage += `✅ New files uploaded: ${uploadedFileCount}\n`
      }

      if (existingFileCount > 0) {
        summaryMessage += `⏭️  Files skipped (already exist with matching size): ${existingFileCount}\n`
      }

      if (replacedFileCount > 0) {
        summaryMessage += `🔄 Files replaced (size mismatch): ${replacedFileCount}\n`
      }

      summaryMessage += `\nTotal files processed: ${totalProcessed}`

      await Dialog.show('UPLOAD_SUMMARY', mainWindow, {
        uploaded: uploadedFileCount,
        skipped: existingFileCount,
        replaced: replacedFileCount,
        total: totalProcessed,
        summary: summaryMessage,
      })

      logger.info(summaryMessage)
    } else if (connectionErrors.length === activeSelectedIPs.length) {
      // All connections failed
      logger.error('All connections failed. No files were processed.')
    }

    activeSelectedIPs = []
    mainWindow.webContents.send('refresh-activeSelectedIPs', activeSelectedIPs)
  } catch (err) {
    logger.error(`Error: ${err}`)
    await Dialog.show('GENERIC_ERROR', mainWindow)
  } finally {
    // ========================================
    // ⚡ ALWAYS close progress bar
    // ========================================
    if (progressBar && !progressBar.isCompleted()) {
      try {
        progressBar.setCompleted()
      } catch (pbErr) {
        // Force close if setCompleted fails
        try {
          progressBar.close()
        } catch (closeErr) {
          logger.error('Failed to close progress bar:', closeErr)
        }
      }
    }
  }
})


// ipcMain.on('uploadButton-sending-request', async (event) => {

//   console.log('hello upload button')
//   let local, remote
//   let dbVerificationFailures = []

//   // let sftp
//   let existingFileCount = 0 // Counter for existing files
//   progressBarClosed = false
//   let errorShown = false // Flag to track if error dialog has been shown

//   try {
//     if (!CreateMainFolder) {
//       await Dialog.show('TRANSFER_PATH_ERROR', mainWindow)

//       logger.error('Path not selected for file transfer.')
//       return
//     }

//     ConfigFilePath = path.join(CreateMainFolder, 'INDEX.SYS')

//     // Check if the configuration file exists
//     try {
//       await fs.promises.access(ConfigFilePath)
//     } catch (err) {
//       await Dialog.show('CONFIG_NOT_FOUND', mainWindow, {
//         path: ConfigFilePath,
//       })

//       logger.error(`Configuration file not found at ${ConfigFilePath}.`)
//       // console.log(err, 'Error checking file existence')
//       return
//     }

//     const paths = await readConfigFile(ConfigFilePath)
//     // logger.info(`'Text CRC:', ${paths.textCrc}`)

//     let crcMismatchFound = false

//     if (activeSelectedIPs.length === 0) {
//       event.sender.send('alert', 'Please choose an IP for file transfer.')
//       logger.error('No IP selected for file transfer.')
//       return
//     }

//     const totalFiles = paths.localPath.length * activeSelectedIPs.length
//     let completedFiles = 0

//     const progressBar = new ProgressBar({
//       indeterminate: false,
//       text: 'Uploading files...',
//       detail: 'Initializing...',
//       maxValue: totalFiles,
//       browserWindow: {
//         parent: mainWindow,
//         modal: false,
//         alwaysOnTop: true,
//         minimizable: true,
//         resizable: false,
//         maximizable: true,
//         closable: true,
//         icon: path.join(__dirname, './public/assets/Logo/pps_logo.ico'),
//         backgroundColor: '#FAF6F0',
//       },
//     })

//     progressBar
//       .on('completed', () => {
//         console.log('Upload complete')
//         progressBar.detail = 'Upload complete'
//         progressBarClosed = true // Set flag to indicate progress bar is closed
//       })
//       .on('aborted', () => {
//         logger.warn('Upload aborted')
//         progressBarClosed = true // Set flag to indicate progress bar is closed
//       })
//       .on('progress', (value) => {
//         progressBar.detail = `Uploading file ${value} of ${totalFiles}`
//       })

//     const updateProgressBar = () => {
//       completedFiles++
//       progressBar.value = completedFiles

//       if (completedFiles === totalFiles) {
//         progressBar.setCompleted()
//       }
//     }

//     if (!paths || !paths.localPath || paths.localPath.length === 0) {
//       if (progressBar) progressBar.close()
//       logger.info('upload-folder - No files found to process.')
//       // Show a warning dialog box to the user
//       await Dialog.show('NO_FILES_FOUND', mainWindow)

//       return
//     }

//     const uploadTasks = activeSelectedIPs.map(async (ip) => {
//       // ✅ Create DeviceSSHManager instance for this IP
//       const deviceManager = new DeviceSSHManager(ip)
//       try {
//         // ✅ Connect using the manager (with retry logic built-in)
//         await deviceManager.connect()

//         const conn = await connection(ip)
//         logger.info(`SFTP connection established to ${ip}`)

//         let sftp = await new Promise((resolve, reject) => {
//           conn.sftp((err, sftp) => {
//             if (err) {
//               logger.error(`Error obtaining SFTP client for ${ip}:, ${err}`)
//               conn.end()
//               reject(err)
//             } else {
//               resolve(sftp)
//             }
//           })
//         })

//         for (let i = 0; i < paths.localPath.length; i++) {
//           try {
//             local = path.join(CreateMainFolder, paths.localPath[i])
//             remote = SERVER_CONTENT_PATH + paths.remotePath[i]
//             const size = paths.textFileSize[i]
//             const expectedCrc = paths.textCrc[i]

//             const localCrc = await calculateFileCRC32(local)
//             logger.info(
//               `Local CRC32 : ${localCrc} and Expected CRC32: ${expectedCrc}   for ${local}`,
//             )
//             // logger.info(`Expected CRC32: ${expectedCrc}`)

//             const exists = await deviceManager.fileExists(remote)

//             if (!exists) {
//               if (localCrc === expectedCrc) {
//                 await deviceManager.uploadFile(local, remote)
//                 logger.info(
//                   `File successfully uploaded to ${ip} from ${local} to ${remote}`,
//                 )
//               } else {
//                 logger.warn(
//                   `CRC mismatch for ${local}. Expected ${expectedCrc}, got ${localCrc}. Skipping upload.`,
//                 )
//                 crcMismatchFound = true
//               }
//             } else {
//               logger.info(
//                 `File already exists on ${ip} at ${remote}, skipping upload.`,
//               )
//               existingFileCount++
//             }
//             updateProgressBar()
//           } catch (err) {
//             if (!errorShown) {
//               if (err.code === 'ENOENT') {
//                 const PathParsing = path.parse(err.path)
//                 const errPath = path.join(
//                   path.basename(PathParsing.dir),
//                   PathParsing.base,
//                 )
//                 await Dialog.show('SOME_FILES_NOT_FOUND', mainWindow)

//                 logger.error(`Some Files not found: ${errPath}`)
//               } else {
//                 logger.error(
//                   `Error uploading file to ${ip} from ${local} to ${remote}:`,
//                   err,
//                 )
//                 await Dialog.show('FILE_TRANSFER_ERROR', mainWindow)

//                 if (progressBar) progressBar.close()
//                 activeSelectedIPs = []
//               }
//               errorShown = true // Set the flag to prevent showing the dialog again
//             }
//             updateProgressBar()
//           }
//         }

//         // Now upload these 2 files per IP
//         try {
//           await deviceManager.uploadFile(ConfigFilePath, SERVER_INDEX_SYS_PATH)
//           await deviceManager.uploadFile(videoAdvertismentPath, SERVER_INDEX_TXT_PATH)

//           const verify = await deviceManager.verifyFromSys(
//             SERVER_INDEX_SYS_PATH,
//             SERVER_CONTENT_PATH,
//           )



//           // ✅ NEW CHECK
//           if (!verify.success) {
//             logger.error(
//               `DB Verification failed on ${ip}. Missing files detected.`,
//             )

//             dbVerificationFailures.push({
//               ip,
//               missingCount: verify.missingCount,
//             })
//             // OPTIONAL → stop cleanup if DB incomplete
//             return
//           }
//           // paths.remotePath comes from INDEX.SYS
//           await cleanupContentFolder(
//             sftp,
//             SERVER_CONTENT_PATH,
//             paths.remotePath,
//           )
//           // Step 3 Cleanup

//           logger.info(
//             `Uploading INDEX.SYS and videoAdvertismentTime.txt to ${ip}`,
//           )
//         } catch (e) {
//           logger.error(`Error uploading config files to ${ip}:`, e)
//         }

//         conn.end()
//         if (progressBar) progressBar.close()
//       } catch (err) {
//         logger.error(
//           `Error with connection or file transfer to ${ip}:, ${err} `,
//         )
//         await Dialog.show('CONNECTION_LOSS', mainWindow, { ip })

//         if (progressBar) progressBar.close() // Close the progress bar on connection error
//       }

//       // Ensure progress bar is updated even if there's an error
//       updateProgressBar()
//     })

//     await Promise.all(uploadTasks)
//     if (dbVerificationFailures.length > 0) {
//       const failedIPs = dbVerificationFailures
//         .map((item) => `${item.ip} (${item.missingCount})`)
//         .join('\n')

//       await Dialog.show('DB_FILES_MISSING', mainWindow, {
//         ipList: failedIPs,
//         totalFailed: dbVerificationFailures.length,
//       })
//     }
//     if (crcMismatchFound) {
//       event.sender.send('alert', 'Error code 45')
//       // "CRC mismatch detected (Error code 45). Some files were skipped.",
//     }

//     // Show a single popup if any files already existed
//     if (existingFileCount > 0) {
//       await Dialog.show('SKIP_FILES', mainWindow, {
//         existing: existingFileCount,
//         total: totalFiles,
//       })
//     }
//     activeSelectedIPs = []

//     mainWindow.webContents.send('refresh-activeSelectedIPs', activeSelectedIPs)
//   } catch (err) {
//     logger.error(`Error:, ${err}`)
//     // Fallback dialog to notify the user
//     await Dialog.show('GENERIC_ERROR', mainWindow)
//   } finally {
//     if (progressBar && !progressBar.completed) {
//       progressBar.setCompleted() // Ensure progress bar is closed
//     }
//   }
// })

async function readConfigFile(ConfigFilePath) {
  try {
    logger.info(
      'readConfigFile: Attempting to read configuration file - ' +
        ConfigFilePath,
    )

    const data = await fs.promises.readFile(ConfigFilePath, {
      encoding: 'utf8',
    })

    logger.info('readConfigFile: Configuration file read successfully')

    let lines = data.split('\n').map((line) => line.trimEnd()) // Clean line endings

    let localPath = []
    let remotePath = []
    let textFileSize = []
    let textCrc = []

    // Step 1: Collect all necessary information
    lines.forEach((line) => {
      const parts = line.match(/^([A-F0-9]{8})\s+(\d+)\s+(.*)$/)
      if (parts && parts.length === 4) {
        const filename = parts[3].trim()
        const crc = parts[1]
        const size = parts[2]
        if (!localPath.includes(filename)) {
          localPath.push(filename)
          remotePath.push(filename)
          textFileSize.push(size)
          textCrc.push(crc)
        }
      }
    })

    // Step 2: Calculate combined CRC32
    const joinedTextCrc = textCrc.join('')
    logger.info(`Joined textCrc: ${joinedTextCrc}`)
    const combinedCrc32 = await calculateStringCRC32(joinedTextCrc)
    logger.info(`Combined CRC32 checksum: ${combinedCrc32}`)

    // Step 3: Update first line with combined CRC32
    if (lines.length > 0) {
      lines[0] = lines[0].replace(
        /^([A-F0-9]{8})/,
        combinedCrc32.padEnd(8, ' '),
      )
    }

    // Step 4: Update "DB Ver:" line
    let versionUpdated = false
    lines = lines.map((line) => {
      if (line.includes('DB Ver:')) {
        const updatedLine = incrementVersion(line)
        console.log('Updated version line:', updatedLine)
        versionUpdated = true
        return updatedLine
      }
      return line
    })

    if (!versionUpdated) {
      logger.warn('No version line found, no version update applied.')
    }

    // Step 5: Update localPath and remotePath
    localPath = localPath
      .filter((path) => path !== 'FILENAME' && !path.startsWith('DB Ver:'))
      .map((path) => (path.startsWith('/') ? path.substring(1) : path))
    remotePath = remotePath
      .filter((path) => path !== 'FILENAME' && !path.startsWith('DB Ver:'))
      .map((path) => {
        const parts = path.split('/')
        const lowercaseParts = parts.map((part, index) => {
          return index === parts.length - 1 ? part : part.toLowerCase()
        })
        return lowercaseParts.join('/')
      })

    // Step 6: Write back the updated file
    await fs.promises.writeFile(ConfigFilePath, lines.join('\n') + '\n', {
      encoding: 'utf8',
    })
    logger.info('readConfigFile: Configuration file updated successfully')

    return { localPath, remotePath, textFileSize, textCrc }
  } catch (err) {
    logger.error(
      `readConfigFile: Error reading or processing configuration file - ${err.message}`,
    )
    throw err
  }
}

// Helper function to calculate CRC32 for a string
async function calculateStringCRC32(input) {
  return new Promise((resolve, reject) => {
    try {
      const crc32 = crc.crc32(Buffer.from(input, 'utf8'))
      const checksum = crc32.toString(16).toUpperCase().padStart(8, '0')
      resolve(checksum)
    } catch (error) {
      logger.error(
        `calculateStringCRC32: Error calculating CRC32: ${error.message}`,
      )
      reject(error)
    }
  })
}

ipcMain.on('delete-request', async (event, filePaths) => {
  let success = true

  try {
    for (let filePath of filePaths) {
      // Resolve the full path based on the system's directory separator
      const fullPath = path.join(path.dirname(CreateMainFolder), filePath)

      try {
        console.log('Deleting file:', fullPath)
        await fs.promises.unlink(fullPath)
      } catch (err) {
        logger.error(
          `'delete-request: Error deleting file - ' + ${fullPath} + ' - ' + ${err.message}`,
        )
        success = false
      }
    }

    try {
      // console.log('delete-request: delete filePaths => ', filePaths)
      await updateConfigFile(filePaths)
      logger.info('delete-request: INDEX.SYS updated successfully')
    } catch (err) {
      logger.error(
        `'delete-request: Error updating INDEX.SYS - ' + ${err.message}`,
      )
      success = false
    }

    if (success) {
      event.reply('delete-status', { delete_success: true })
      event.sender.send('files-uploaded-now-reload', {
        filePaths: filePaths.map((fp) => path.resolve(fp)),
      })
    } else {
      // User clicked Cancel or closed the dialog
      logger.info('delete-request: Delete operation cancelled by user.')
      event.reply('delete-status', { error: true })
    }
  } catch (error) {
    logger.error(
      ` delete-request: Unexpected error during delete-request -  + ${error.message}`,
    )
    event.reply('delete-response', {
      error: true,
      message: 'Unexpected error: ' + error.message,
    })
  }
})

ipcMain.on('confirm-delete', async (event) => {
  const options = {
    type: 'question',
    buttons: ['OK', 'Cancel'],
    defaultId: 1,
    title: 'Confirmation',
    message: 'Are you sure you want to delete the file?',
  }
  const choice = await dialog.showMessageBox(mainWindow, options)
  if (choice.response === 0) {
    event.reply('delete-status', { success: true })
  } else {
    // User clicked Cancel or closed the dialog
    console.log('Delete operation cancelled.')
    event.reply('delete-status', { error: true })
  }
})
async function openCustomPrompt() {
  return new Promise((resolve) => {
    const htmlpath = path.join(__dirname, './public/HTML/prompt.html')
    // pathname: path.join(__dirname,'./public/HTML/index.html')),
    const promptWindow = new BrowserWindow({
      width: 300,
      height: 150,
      parent: BrowserWindow.getFocusedWindow(),
      modal: true,
      frame: false,
      titleBarStyle: 'hidden',
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false,
      },
    })

    promptWindow.loadFile(htmlpath)

    // Adjust size based on content once loaded
    promptWindow.webContents.on('did-finish-load', () => {
      promptWindow.webContents
        .executeJavaScript('document.body.scrollHeight')
        .then((height) => {
          promptWindow.setSize(300, height) // Adjust width and height
        })
        .catch((error) => {
          logger.error(`Error adjusting window size: ${error}`)
        })
    })

    ipcMain.once('prompt-response', (event, value) => {
      logger.info(`Prompt response received: ${value}`)
      promptWindow.close()

      resolve(value)
      writefiles(value)
    })
  })
}

// Function to write and then copy the file
function writefiles(value) {
  // const filePath = path.join('./auth/', 'videoAdvertismentTime.txt') // Full path to the file in the auth folder
  // const filePath = 'videoAdvertismentTime.txt'
  const filePath = path.join(
    os.homedir(),
    'Downloads',
    'videoAdvertismentTime.txt',
  )

  const downloadsFolder = path.join(os.homedir(), 'Downloads')

  videoAdvertismentPath = path.join(
    CreateMainFolder,
    'videoAdvertismentTime.txt',
  )

  logger.info(`videoAdvertismentPath generate`, filePath)

  // Write the file to the current location

  fs.writeFile(filePath, value, (err) => {
    if (err) {
      logger.error('Error writing file:', err)
      return
    }
    // logger.info(`videoAdvertismentPath File to videoAdvertismentPath`,videoAdvertismentPath)
    fs.copyFile(filePath, videoAdvertismentPath, (err) => {
      if (err) {
        // logger.error(`Error copying file videoAdvertismentPath: %s,`,err)
      } else {
        // Delete the original file from the Downloads folder after the copy
        const downloadedFilePath = path.join(
          downloadsFolder,
          'videoAdvertismentTime.txt',
        )
        fs.unlink(downloadedFilePath, (err) => {
          if (err) {
            // logger.error(`Error deleting file from Downloads: %s, ${err}`)
          } else {
            // logger.info(
            //   `File successfully deleted from Downloads: ${downloadedFilePath}`
            // )
          }
        })
      }
    })
  })
}
