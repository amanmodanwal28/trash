const mongoose = require("mongoose");

async function main(){
  await mongoose.connect('mongodb://127.0.0.1:27017/test')
}

main().then(() => {
  console.log("connection successfull")
}).catch((err) => {
  console.log(err)
})

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  age: Number
});

const User = mongoose.model("User", userSchema);
// const Employee = mongoose.model('Employee', userSchema)


// const user1 = new User({
//   name: "aman",
//   email: "itisaman@gmail.com",
//   age:18
// })

// const user2 = new User({
//   name: 'garv',
//   email: 'garv@gmail.com',
//   age: 28,
// })

// user2.save().then((data) => {
//   console.log(data)
// }).catch((err) => {
//   console.log(err)
// })

// User.insertMany([{ name: "aman1 modanwal", email: "modanwal12@gmail.com", age: 22 },
//   { name: "garv1 srivastava", email: "garv@gmail.com",age:23 },
//   { name: "irfan", email: "irfan@gmail.com", age: 32 }]).then((result) => {
//   console.log(result)
//   }).catch((err) => {
//   console.log(err)
// })

User.find({age: {$or:30}}).then((res) => {
  console.log(res)
}).catch((err) => {
  console.log(err)
})

