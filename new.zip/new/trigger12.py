# from main import *
import main
from tkinter import *
import tkinter.ttk
from tkinter import messagebox
import pyodbc
import tkinter as tk
import trigger
import tkinterDnD

class MainApplication4:
    def __init__(self):
        self.trigger = tkinterDnD.Tk()
        self.trigger.geometry("700x500+70+40")
        self.trigger.title("Combined Trigger")
        self.trigger.iconbitmap("logo2.ico")
        self.trigger.configure(bg="MediumPurple4")
        self.trigger.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.trigger.resizable(False, False)
        self.trigger.maxsize(700, 500)
        self.trigger.minsize(700, 500)

       ################################### main frame ##############################
        self.trigger_main_frame = Frame(self.trigger, relief=RIDGE, background='MediumPurple4', bd=4)
        self.trigger_main_frame.place(x=0, y=0, height=500, width=700)

       ################################### upper main frame ##############################
        self.trigger_upper_frame = Frame(self.trigger, relief=RIDGE, background='MediumPurple3', bd=4)
        self.trigger_upper_frame.place(x=5, y=5, height=80, width=690)

        ################################### left main frame ##############################
        self.trigger_left_frame = Frame(self.trigger, relief=RIDGE, background='MediumPurple1', bd=4)
        self.trigger_left_frame.place(x=5, y=85, height=410, width=340)

        self.left_label = Label(self.trigger_left_frame, font=('arial', 12, 'bold'), text=" Triggers in combined trigger :", bg="MediumPurple1")
        self.left_label.place(x=20, y=10)
             ########################## delete function left treeview data  #########################
        def delete_left_treeview_list():
            print(46)
            count = self.trigger_left_table.get_children()
            cursor_row3 = self.trigger_left_table.focus()
            content3 = self.trigger_left_table.item(cursor_row3)
            data3 = content3["values"]
            num1 = combobox_routeID()
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute(f"DELETE FROM tbl_combiTriggerItems WHERE combiTriggerID={num1} and triggerName='{data3[0]}'")
            conn.commit()
            conn.close()
            left_text_frame()

        self.trigger_button_remove = Button(self.trigger_left_frame, text="Remove", font=('arial', 11, 'bold'), width=8, height=1, bg="cyan", fg="black", command=delete_left_treeview_list, cursor='hand2')
        self.trigger_button_remove.place(x=30, y=350)

  ########################### right main frame ##############################
        self.trigger_right_frame = Frame(self.trigger, relief=RIDGE, background='MediumPurple1', bd=4)
        self.trigger_right_frame.place(x=346, y=85, height=410, width=350)

        self.right_label = Label(self.trigger_right_frame, font=('arial', 12, 'bold'), bg='MediumPurple1', text="Available Triggers : ")
        self.right_label.place(x=20, y=10)

        def trigger_top():
            print(73)
            self.trigger.destroy()
            trigger.MainApplication5()

        trigger_button_trigger = Button(self.trigger_right_frame, text="Trigger", font=('arial', 11, 'bold'), width=8, height=1, bg="cyan", fg="black", command=trigger_top, cursor='hand2')
        trigger_button_trigger.place(x=210, y=350)

         ########################################## style for combobox ##################################################
        self.t = tkinter.ttk.Style(self.trigger)
        self.t.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        self.t.configure('Treeview.Heading', background="darkseagreen")

        ########################################## upper frame combobox ################################################
        self.combobox_trigger_list = tkinter.ttk.Combobox(self.trigger_upper_frame, font=("arial", 13, 'bold'), width=20)
        self.combobox_trigger_list.place(x=100, y=5)

        self.name_label = Label(self.trigger_upper_frame, font=('arial', 11, 'bold'), bg='MediumPurple3', text="Name : ")
        self.name_label.place(x=20, y=38)

        self.name_entry = Entry(self.trigger_upper_frame, state="disabled", font=('arial', 11, 'bold'), width=24)
        self.name_entry.place(x=100, y=40)


        ############################## ENABLE DISABLED FUNCTION ENTRY BOX #################################################3

        def insert_data_combo():
            print(100)
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute("select top 1 combiTriggerID from tbl_combiTrigger order by combiTriggerID desc")
            data = my_cursor.fetchall()
            if data:
                my_cursor.execute(f"insert into tbl_combiTrigger values({data[0][0]+1},'{self.name_entry.get()}')")
            else:
                my_cursor.execute(f"insert into tbl_combiTrigger values(1,'{self.name_entry.get()}')")
            conn.commit()
            conn.close()
            show_trigger_in_combobox()
        ################################# combox delete with button #######################################
        def delete_combobox_list():
            print(114)
            self.num_of_combo_list = combobox_routeID()
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute("select max(combiTriggerID) from tbl_combiTrigger")
            max_number = my_cursor.fetchall()
            if max_number:
                if int(max_number[0][0]) == self.num_of_combo_list:
                    sql_data = f"DELETE FROM tbl_combiTrigger WHERE combiTriggerID={self.num_of_combo_list}"
                    my_cursor.execute(sql_data)
                else:
                    sql_data = f"UPDATE tbl_combiTrigger SET combiTriggerName='Empty' WHERE combiTriggerID={self.num_of_combo_list}"
                    my_cursor.execute(sql_data)
            # for i in range(self.num_of_combo_list, len(self.o)+1):
            #     sql_data = f"UPDATE tbl_combiTrigger SET combiTriggerID = combiTriggerID - 1 WHERE combiTriggerID = {i}"
            #     my_cursor.execute(sql_data)
            conn.commit()
            conn.close()
            show_trigger_in_combobox()

        ########################################## Enable disable function ################################
        def enable_entry():
            print(132)
            self.name_entry.config(state='normal')
        ##############################
        def disable_entry(event=""):
            insert_data_combo()
            self.name_entry.delete(0, END)
            self.name_entry.config(state='disable')

        self.name_entry.bind("<Return>", disable_entry)

        ############################################### Button new delete ###################################################
        trigger_button_new = Button(self.trigger_upper_frame, text="New", font=('arial', 11, 'bold'), width=8, height=1, bg="cyan", fg="black", command=enable_entry, cursor='hand2')
        trigger_button_new.place(x=400, y=8)

        trigger_button_delete = Button(self.trigger_upper_frame, text="Delete", font=('arial', 11, 'bold'), width=8, height=1, bg="cyan", fg="black", command=delete_combobox_list, cursor='hand2')
        trigger_button_delete.place(x=530, y=8)

         ########################################### left trigger frame #############################################
        def left_text_frame(event=""):
            print(152)
            combitriggersID = combobox_routeID()
            print(combitriggersID, "hhhhhhhhhhhhhhhhhhhhhhhhhhhhh")
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            if combitriggersID == 1:
                my_cursor.execute(f"select triggerName from tbl_combiTriggerItems where combiTriggerID={combitriggersID}")
            else:
                my_cursor.execute(f"select triggerName from tbl_combiTriggerItems where combiTriggerID={combitriggersID}")
            data = my_cursor.fetchall()
            if len(data) != 0:
                self.trigger_left_table.delete(*self.trigger_left_table.get_children())
                for i in data:
                    self.trigger_left_table.insert("", END, values=list(i))
                conn.commit()
            else:
                self.trigger_left_table.delete(*self.trigger_left_table.get_children())
            conn.close()

        ################################### Left trigger table #############################
        self.trigger_left_list = Frame(self.trigger_left_frame)
        self.trigger_left_list.place(x=20, y=35, height=290, width=300)
        self.scroll_y = Scrollbar(self.trigger_left_list, orient=VERTICAL)
        self.trigger_left_table = tkinter.ttk.Treeview(self.trigger_left_list, columns="trigg", yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.scroll_y.config(command=self.trigger_left_table.yview)
        self.trigger_left_table.heading("trigg", text="Combined Trigger")
        self.trigger_left_table.pack(fill=BOTH, expand=1)
        self.trigger_left_table["show"] = "headings"
        self.combobox_trigger_list.bind("<<ComboboxSelected>>", left_text_frame)
        # self.trigger_left_table.bind("<ButtonRelease>", get_left_treeview)
        def combobox_routeID():
            conn = pyodbc.connect(
                'DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute(f"SELECT combiTriggerID FROM tbl_combiTrigger where combiTriggerName='{self.combobox_trigger_list.get()}'")
            trigger_id = my_cursor.fetchall()
            if trigger_id:
                print(trigger_id[0][0], 123456789098765432)
                self.routeID_variable = int(trigger_id[0][0])
                return self.routeID_variable
            # print(self.combobox_trigger_list.get(), "kkkkkkkl")
            # conn.commit()
            conn.close()
            # self.routeID = dict(self.table_name)
            # print(self.routeID, 34567898765567876545678987654)
            # for i in self.routeID:
            #     if self.routeID[i] == self.combobox_trigger_list.get():
            #         self.routeID_variable = i
            #         return self.routeID_variable


        ############################################# show table combobox ###################################################
        def show_trigger_in_combobox():
            print(182)
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute("SELECT * FROM tbl_combiTrigger")
            self.table_name = my_cursor.fetchall()
            if self.table_name:
                self.o = []
                for j in self.table_name:
                    s = list(j)
                    self.o.append(s[1])
                self.combobox_trigger_list["value"] = self.o
                conn.commit()
                conn.close()
                self.combobox_trigger_list.set(self.o[0])
                left_text_frame()


        # print(combobox_routeID(), "ppppppppppppppppppppppppppppp")
        show_trigger_in_combobox()

        ############################################# combined trigger insert function ##################################
        def Insert_data_left_treeview(event=""):
            print(201)
            cursor_row1 = self.trigger_table.focus()
            content = self.trigger_table.item(cursor_row1)
            data = content["values"]
            num = combobox_routeID()
            conn = pyodbc.connect(
                'DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute(f"insert into tbl_combiTriggerItems values(?,?)", (num, data[0]))
            conn.commit()
            conn.close()
            left_text_frame()

        # def add(event):
        #     print(event.data)
        def drag_command(event):
            for selected_item in self.trigger_table.selection():
                item = self.trigger_table.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", record[0]

        ################################### right trigger table #############################
        self.trigger_table_list = Frame(self.trigger_right_frame)
        self.trigger_table_list.place(x=20, y=35, height=290, width=300)
        self.scroll_y = Scrollbar(self.trigger_table_list, orient=VERTICAL)
        self.trigger_table = tkinter.ttk.Treeview(self.trigger_table_list, columns="trigg", yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.scroll_y.config(command=self.trigger_table.yview)
        self.trigger_table.heading("trigg", text="Available Trigger")
        self.trigger_table.pack(fill=BOTH, expand=1)
        self.trigger_table["show"] = "headings"
        self.trigger_table.bind("<Return>", Insert_data_left_treeview)
        self.trigger_table.register_drag_source("*")
        self.trigger_table.bind("<<DragInitCmd>>", drag_command)
        self.trigger_left_table.bind("<<Drop>>", Insert_data_left_treeview)
        self.trigger_left_table.register_drop_target("*")


        ############################################# Fetch data avilable triggers ######################################################
        def show_data_available_trigger_table():
            print(229)
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute("SELECT triggerName FROM tbl_trigger")
            data = my_cursor.fetchall()
            if len(data) != 0:
                self.trigger_table.delete(*self.trigger_table.get_children())
                for i in data:
                    self.trigger_table.insert("", END, values=list(i))
                conn.commit()
            conn.close()
        show_data_available_trigger_table()
        self.trigger.mainloop()
    def on_exit(self):
        self.trigger.destroy()
        main.MainApplication()

if __name__ == "__main__":
    MainApplication4()
