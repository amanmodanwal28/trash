# import cv2
# # import numpy as np

# # from cv2 import cv2
# # cap = cv2.VideoCapture("http://192.168.0.105:8080/video")
# # cap = cv2.VideoCapture("http://192.168.1.10:34567/video")
# cap = cv2.VideoCapture("rtsp://192.168.0.11:554/avstream/channel=1/stream=0-1.sdp")
# # cap = cv2.VideoCapture(0)

# while(True):
#     ret, frame = cap.read()
#     # if frame is not None:
#     #     cv2.imshow("frame", frame)
#     # q = cv2.waitkey(1)
#     # if q == ord("q"):
#     #     break
#     cv2.imshow('frame', frame)
#     if cv2.waitKey(1) & 0xFF == ord('a'):
#         break

# cap.release()
# cv2.destroyAllWindows()


