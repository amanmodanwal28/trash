import sqlite3
from pysqlcipher3 import dbapi2 as sqlite

class GUI_ICON:
  def __init__(self):
      self.gui_icon_file = "UIFILES/logo2.ico"

class File_Path:
  def __init__(self):
      self.Audio_Path = "sqlData\\audio\\"
      self.TEXT_Path = "sqlData\\txt\\"
      self.VIDEO_Path = "sqlData\\video\\"
      self.IMAGE_Path = "sqlData\\Image\\"

class SQL_QUERY:
  def __init__(self, sql_query):
      self.sql_query = sql_query
  def QUERY_COMMAND(self):
      conn = sqlite3.connect("triggers_abhay.db")
      my_cursor = conn.cursor()
      my_cursor.execute(self.sql_query)
      if self.sql_query.find("Select") > -1 or self.sql_query.find("SELECT") > -1 or self.sql_query.find("select") > -1:
          data = my_cursor.fetchall()
          conn.commit()
          conn.close()
          return data
      else:
          conn.commit()
          conn.close()


class SQL_QUERY_PASS:
  def __init__(self, sql_query):
      self.sql_query_pass = sql_query

  def QUERY_COMMAND(self):
      conn = sqlite.connect('triggers_abhay - Copy.db')
      my_cursor = conn.cursor()
      my_cursor.execute("PRAGMA key='PPS'")
      my_cursor.execute(self.sql_query_pass)
      if self.sql_query_pass.find("Select") > -1 or self.sql_query_pass.find("SELECT") > -1 or self.sql_query_pass.find("select") > -1:
          data = my_cursor.fetchall()
          conn.close()
          return data
      else:
          conn.commit()
          conn.close()