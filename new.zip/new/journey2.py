import main
import tkinter as tk
from tkinter import *
import tkinter.ttk
from tkinter import messagebox
import pyodbc
import simulation
import xml.etree.ElementTree as ET
data_list_route = ""

class MainApplication3:
    def __init__(self):
        self.journey = tk.Tk()
        self.journey.geometry("1200x615+70+40")
        self.journey.title("Journey")
        self.journey.iconbitmap("logo2.ico")
        self.journey.configure(bg="light gray")
        self.journey.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.journey.resizable(False, False)
        self.journey.maxsize(1200, 615)
        self.journey.minsize(1200, 615)
        ############################## style for combobox ##################################
        self.z = tkinter.ttk.Style(self.journey)
        self.z.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        self.z.configure('Treeview.Heading', background="light gray")
        
        ################################### left main frame ##############################
        self.journey_left_frame1 = Frame(self.journey, relief=RIDGE, background='light gray', bd=4)
        self.journey_left_frame1.place(x=0, y=30, height=530, width=450)
        
        ################################### right main frame ##############################
        self.journey_right_frame2 = Frame(self.journey, relief=RIDGE, background='light gray', bd=4)
        self.journey_right_frame2.place(x=451, y=30, height=530, width=748)


        #################################### journey route label box ##########################
        self.journey_route1 = Label(self.journey, bd=4, bg='light gray', padx=2, font=('arial', 10, 'bold'), text='Journeys of route :-')
        self.journey_route1.place(x=10, y=0)

        #################################### combobox list ####################################
        self.combobox_journey_list = tkinter.ttk.Combobox(self.journey, font=("arial", 13, 'bold'), width=20)
        self.combobox_journey_list.place(x=150, y=2)
        self.combobox_journey_list.bind("<<ComboboxSelected>>", self.Insert_data_left_journey_treeview)
        
        ################################### Button New Delete #############################################
        journey_button_new = Button(self.journey, text=" New ", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.add_new_data)
        journey_button_new.place(x=70, y=565)

        journey_button_delete = Button(self.journey, text=" Delete", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.delete_data_left)
        journey_button_delete.place(x=140, y=565)
        
        journey_button_simulate = Button(self.journey, text="Simulate", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.simulate_top)
        journey_button_simulate.place(x=800, y=565)
        

        ########################################### scroll bar in (left journey frame) ############################################
        self.left_journey_scroll_y = tk.Scrollbar(self.journey_left_frame1, orient=VERTICAL)
        self.left_journey_treeview = tkinter.ttk.Treeview(self.journey_left_frame1, columns=("name", "condition", "departure", "service", "totalcars", "handicars"),
                                                          yscrollcommand=self.left_journey_scroll_y.set, show="headings")
        self.left_journey_scroll_y.pack(side=RIGHT, fill=Y)
        self.left_journey_scroll_y.config(command=self.left_journey_treeview.yview)
        self.left_journey_treeview.heading("name", text="Name")
        self.left_journey_treeview.column("name", width=25, anchor='c')
        self.left_journey_treeview.heading("condition", text="Condition")
        self.left_journey_treeview.column("condition", width=25, anchor='c')
        self.left_journey_treeview.heading("departure", text="Departure")
        self.left_journey_treeview.column("departure", width=25, anchor='c')
        self.left_journey_treeview.heading("service", text="Service")
        self.left_journey_treeview.column("service", width=25, anchor='c')
        self.left_journey_treeview.heading("totalcars", text="Totalcars")
        self.left_journey_treeview.column("totalcars", width=25, anchor='c')
        self.left_journey_treeview.heading("handicars", text="Handicars")
        self.left_journey_treeview.column("handicars", width=25, anchor='c')
        self.left_journey_treeview.pack(fill=BOTH, expand=1)
        self.left_journey_treeview.bind("<ButtonRelease>", self.get_left_treeview)

        ############################### scroll bar in (right journey frame) #################################
        self.right_journey_scroll_y = tk.Scrollbar(self.journey_right_frame2, orient=VERTICAL)
        self.right_journey_treeview = tkinter.ttk.Treeview(self.journey_right_frame2, columns=(
                                                          "stnno", "stn", "arriv", "depar", "cond", "plat", "trigg", "lng"),
                                                            yscrollcommand=self.right_journey_scroll_y.set, show="headings")
        self.right_journey_scroll_y.pack(side=RIGHT, fill=Y)
        self.right_journey_scroll_y.config(command=self.right_journey_treeview.yview)
        self.right_journey_treeview.heading("stnno", text="StationNo")
        self.right_journey_treeview.column("stnno", width=25, anchor='c')
        self.right_journey_treeview.heading("stn", text="Station")
        self.right_journey_treeview.column("stn", width=25, anchor='c')
        self.right_journey_treeview.heading("arriv", text="Arrival")
        self.right_journey_treeview.column("arriv", width=25, anchor='c')
        self.right_journey_treeview.heading("depar", text="Departure")
        self.right_journey_treeview.column("depar", width=25, anchor='c')
        self.right_journey_treeview.heading("cond", text="Condition")
        self.right_journey_treeview.column("cond", width=25, anchor='c')
        self.right_journey_treeview.heading("plat", text="Platform")
        self.right_journey_treeview.column("plat", width=25, anchor='c')
        self.right_journey_treeview.heading("trigg", text="Trigger")
        self.right_journey_treeview.column("trigg", width=25, anchor='c')
        self.right_journey_treeview.heading("lng", text="Language")
        self.right_journey_treeview.column("lng", width=25, anchor='c')
        self.right_journey_treeview.pack(fill=BOTH, expand=1)
        # self.right_journey_treeview.bind("<ButtonRelease>", self.get_right_treeview)
        self.right_journey_treeview.bind("<Double-1>", self.edit_data_right_treeview)

        ######################################## Menu bar #################################################
        self.menu = tk.Menu(self.journey)
        self.Edit = tk.Menu(self.menu, tearoff=0)
        self.Edit.add_command(label="New")
        self.Edit.add_command(label="Delete")

        self.menu.add_cascade(label="Menu", menu=self.Edit)
        self.journey.config(menu=self.menu)
        ###########################################################
        popup = Menu(self.journey_left_frame1, tearoff=0)
        popup.add_command(label="new")
        popup.add_command(label="Edit")
        self.show_journey_in_combobox()
        self.journey.mainloop()

    ####### show table in combobox function in previous route ########
    def combobox_routeID(self):
        self.routeID = dict(self.table_name)
        for i in self.routeID:
            if self.routeID[i] == self.combobox_journey_list.get():
                self.routeID_variable = i
                return self.routeID_variable
    def show_journey_in_combobox(self):
        print(125)
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT routeID,routeName FROM tbl_routes")
        self.table_name = my_cursor.fetchall()
        m = []
        for j in self.table_name:
            p = list(j)
            m.append(p[1])
        self.combobox_journey_list["value"] = m
        if m:
            self.combobox_journey_list.set(m[0])
            self.Insert_data_left_journey_treeview()

    ################## treeview data insert in left frame #########################################
    def Insert_data_left_journey_treeview(self, event=""):
        print(140)
        self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
        self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(
            f'''select journeyName,condition,departure,serviceType,totalCars,handicapCar,journeyID from tbl_journeys where routeID={self.combobox_routeID()}''')
        stn_left_table = my_cursor.fetchall()
        if len(stn_left_table) != 0:
            self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
            for i in stn_left_table:
                self.left_journey_treeview.insert("", END, values=list(i))
            self.journey_id = stn_left_table[0][6]
            self.Insert_data_right_journey_treeview()
        else:
            self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
        conn.commit()
        conn.close()
        if self.left_journey_treeview.get_children():
            children = self.left_journey_treeview.get_children()
            self.left_journey_treeview.selection_set(children[0])
            self.left_journey_treeview.focus(children[0])


       ############################# fetchone value name call in combobox ##############LP-ABHAY-PT new################
    def left_treeview_data_insert(self):

        print(160)
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select journeyID from tbl_journeys where routeID={self.combobox_routeID()}''')
        self.data2 = my_cursor.fetchone()
        self.data23 = str(self.data2)

        ########################################### right journey treeview #########################
    def Insert_data_right_journey_treeview(self, event=""):
        global data_list_route
        print(172)
        try:
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute(f"select * from tbl_journeys where journeyID={self.journey_id}")
            data_tbl_journeys = my_cursor.fetchall()
            data_list_route = data_tbl_journeys
            data_list_route.append(self.combobox_journey_list.get())
            my_cursor.execute(f'''select stationNo, stationName, arrivalTime, depactureTime, conditional, platformNum, combiTriggerID,languageArea, journeyID, routeStopID from tbl_journeyStops where journeyID={self.journey_id} order by routeStopID''')
            data2 = my_cursor.fetchall()
            if len(data2) != 0:
                self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
                for i in data2:
                    self.right_journey_treeview.insert("", END, values=list(i))
            else:
                self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
            conn.commit()
            conn.close()
        except Exception as es:
            print("not saved", f"due to:{str(es)}")
    ############## bind function call left treeview click ###############################
    def get_left_treeview(self, event=""):
        print(190)
        self.cursor_row3 = self.left_journey_treeview.focus()
        self.content3 = self.left_journey_treeview.item(self.cursor_row3)
        self.data3 = self.content3["values"]
        self.journey_id = self.data3[6]
        self.Insert_data_right_journey_treeview()
    ########################## delete function left treeview data  #########################
    def delete_data_left(self):
        print(196)
        if self.left_journey_treeview.focus() == "":
            messagebox.showerror("Error", "Select the file ", parent=self.journey)
        else:
            try:
                Delete = messagebox.askyesno("Delete", "Are you sure delete the data", parent=self.journey)
                if Delete > 0:
                    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
                    my_cursor = conn.cursor()
                    sql_data1 = f"delete from tbl_journeys where journeyID=? and routeID=?"
                    value1 = (self.journey_id, self.combobox_routeID(),)
                    my_cursor.execute(sql_data1, value1)
                    sql_data = f"delete from tbl_journeyStops where journeyID=?"
                    value = (self.journey_id,)
                    my_cursor.execute(sql_data, value)
                else:
                    if not Delete:
                        return
                conn.commit()
                conn.close()
                self.Insert_data_left_journey_treeview()
                messagebox.showinfo("Delete", "your train data has been deleted", parent=self.journey)
            except Exception as es:
                messagebox.showerror("Error", f"Due To:{str(es)}", parent=self.journey)
    ############## bind function call right treeview data ############################
    def get_right_treeview(self, event=""):
        print(219)
        # self.cursor_row4 = self.right_journey_treeview.focus()
        # self.content4 = self.right_journey_treeview.item(self.cursor_row4)
        # self.data4 = self.content4["values"]

        # mg = self.right_journey_treeview.get_children()
        ev = self.right_journey_treeview.identify_column(event.x)
        ev1 = self.right_journey_treeview.focus()
        ev1_text = self.right_journey_treeview.item(ev1)
        # print(ev1_text, "67890")
        ev_value = ev1_text.get("values")
        new_ev = int(ev[1]) - 1
        # print(ev_value)
        # print(ev, ev1, "yooooo")
        # # self.total_lenth_journey_treeview = len(mg) + 1
        # self.count_journey_treeview = mg.index(self.cursor_row4) + 1
        colum_box = self.right_journey_treeview.bbox(ev1, ev)
        # print(colum_box, "000000")
        if new_ev == 2 or new_ev == 3:
            entry_box = tkinter.ttk.Entry(self.journey_right_frame2, width=colum_box[2], justify="center")
            entry_box.insert(END, ev_value[new_ev])
        elif 3 < new_ev < 8:
            entry_box = tkinter.ttk.Combobox(self.journey_right_frame2, font=("arial", 9, 'bold'), width=10, justify="center")
            entry_box.set(ev_value[new_ev])
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            days = []
            for i in root.findall("timeConditional"):
                it = i.find("name").text
                days.append(it)
            # days = "Mon to Fri", "Not on Mon", "Not on Tues", "Not on Wed", "Not on Thurs", "Not on Fri", "Not on Sat",
            # "Weekends"
            entry_box["values"] = days
        # print(new_ev, "ghjhghhjhjhj")
        # entry_box = tkinter.ttk.Entry(self.journey_right_frame2, width=colum_box[2])
        # entry_box.editing_column_index = new_ev
        # entry_box.editing_item_iid = ev1
        # print(entry_box.editing_column_index, "yooooo")
        # print(entry_box.editing_item_iid, "yooooo")
        entry_box.place(x=colum_box[0], y=colum_box[1], w=colum_box[2], h=colum_box[3])
        # entry_box.insert(END, ev_value[new_ev])
        # entry_box.select_range(0, tk.END)
        entry_box.focus()
        entry_box.bind("<FocusOut>", self.on_focus_out)
        # def destroy_en(event):
        #     entry_box.destroy()
        # entry_box.bind("<FocusOut>", destroy_en)

    @staticmethod
    def on_focus_out(event):
        event.widget.destroy()
    ################################### combobox #################################
    def edit_data_right_treeview(self, event=""):
        print(287)
        self.cursor_row4 = self.right_journey_treeview.focus()
        self.content4 = self.right_journey_treeview.item(self.cursor_row4)
        self.data4 = self.content4["values"]
        if not self.data4:
            pass
        else:
            self.Edit_Route = tk.Tk()
            self.Edit_Route.geometry("700x130+550+400")
            self.Edit_Route.title(f"Edit Route :{self.data4[1]}")

            ################################### Arrival #######################################
            def show_arrival_entry(event=""):
                if len(arrival_entry.get()) == 2:
                    arrival_entry.insert(2, ":")
                if not event.char.isdigit():
                    return "break"
                elif len(arrival_entry.get()) > 3:
                    arrival_entry.delete(4, tk.END)
                elif not event.char.isdigit():
                    return "break"

            def do_backspace(event=""):
                pass

            arrival_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Arrival ↓")
            arrival_label.place(x=20, y=17)
            arrival_entry = tkinter.ttk.Entry(self.Edit_Route, font=('arial', 9, 'bold'), width=10)
            arrival_entry.insert(END, self.data4[2])
            arrival_entry.place(x=10, y=40)
            old_data = arrival_entry.get()
            def remove(event):
                arrival_entry.delete(0, END)
            def insert_data(event):
                now_data = arrival_entry.get()
                if old_data == now_data or now_data == "":
                    arrival_entry.delete(0, END)
                    arrival_entry.insert(END, self.data4[2])
                else:
                    pass
            arrival_entry.bind("<Key>", show_arrival_entry)
            arrival_entry.bind("<BackSpace>", do_backspace)
            arrival_entry.bind("<ButtonRelease>", remove)
            arrival_entry.focus()
            arrival_entry.bind("<FocusOut>", insert_data)

            ################################# Departure ########################################

            def show_departure_entry(event=""):
                if len(departure_entry.get()) == 2:
                    departure_entry.insert(2, ":")
                if not event.char.isdigit():
                    return "break"
                elif len(departure_entry.get()) > 3:
                    departure_entry.delete(4, tk.END)
                elif not event.char.isdigit():
                    return "break"

            def do_backspace(event=""):
                pass

            departure_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Departure ↓")
            departure_label.place(x=110, y=17)
            departure_entry = tkinter.ttk.Entry(self.Edit_Route, font=('arial', 9, 'bold'), width=10)
            departure_entry.insert(END, self.data4[3])
            departure_entry.place(x=110, y=40)
            old_data = arrival_entry.get()
            def remove1(event):
                departure_entry.delete(0, END)
            def insert_data1(event):
                now_data = arrival_entry.get()
                if old_data == now_data or now_data == "":
                    departure_entry.delete(0, END)
                    departure_entry.insert(END, self.data4[3])
                else:
                    pass
            departure_entry.bind("<Key>", show_departure_entry)
            departure_entry.bind("<BackSpace>", do_backspace)
            departure_entry.bind("<ButtonRelease>", remove1)
            departure_entry.focus()
            departure_entry.bind("<FocusOut>", insert_data1)

            ################################# Condition #########################################
            condition_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Condition ↓")
            condition_label.place(x=210, y=17)
            combobox_condition = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10)
            combobox_condition.set(self.data4[4])
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            date_condition_right = ["-None-"]
            for i in root.findall("timeConditional"):
                name = i.find("name").text
                date_condition_right.append(name)
            combobox_condition["values"] = date_condition_right
            combobox_condition.place(x=210, y=40)
            ################################# Platform #########################################
            Platform_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Platform ↓")
            Platform_label.place(x=330, y=17)
            combobox_platform = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10)
            combobox_platform.set(self.data4[5])
            combobox_platform["values"] = ("Left", "Right", "Both")
            combobox_platform.place(x=330, y=40)
            ################################# Trigger  ##########################################
            trigger_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Trigger ↓")
            trigger_label.place(x=450, y=17)
            combobox_trigger = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10, )
            combobox_trigger.place(x=450, y=40)
            self.combi_trigger_id = {}

            def show_trigger_in_combobox_journey():
                print(264)
                self.combi_trigger_id.copy()
                conn = pyodbc.connect(
                    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
                my_cursor = conn.cursor()
                my_cursor.execute("SELECT combiTriggerName, combiTriggerID from tbl_combiTrigger")
                table_name = my_cursor.fetchall()
                self.combi_trigger_id = dict(table_name)
                n = []
                for j in table_name:
                    q = list(j)
                    n.append(q[0])
                combobox_trigger["value"] = n
                combobox_trigger.set(self.data4[6])
                conn.commit()
                conn.close()

            show_trigger_in_combobox_journey()

            ################################ Language ############################################
            Language_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Language ↓")
            Language_label.place(x=560, y=17)
            combobox_english = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
            combobox_english.set("EN")
            combobox_english["values"] = ("EN", "HI", "MR")
            combobox_english.place(x=558, y=40)

            combobox_hindi = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
            combobox_hindi.set("HI")
            combobox_hindi["values"] = ("EN", "HI", "MR")
            combobox_hindi.place(x=605, y=40)

            combobox_regional = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
            combobox_regional.set("MR")
            combobox_regional["values"] = ("EN", "HI", "MR")
            combobox_regional.place(x=653, y=40)

            ################################# save data edit in right treeview ##########################
            def save_insert_right_data():
                print(298)
                try:
                  combi_trigger_id_new = self.combi_trigger_id[combobox_trigger.get()]
                except KeyError:
                    combi_trigger_id_new = 0
                combobox_language = combobox_english.get() + ',' + combobox_hindi.get() + ',' + combobox_regional.get()
                conn = pyodbc.connect(
                    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
                my_cursor = conn.cursor()
                # my_cursor.execute(f"UPDATE {self.combobox_journey_list.get()} SET arrival='{arrival_entry.get()}', departure='{departure_entry.get()}', conditions='{combobox_condition.get()}', platform='{combobox_platform.get()}', triggers='{combobox_trigger.get()}', language='{combobox_language}' WHERE orders={self.data4[0]}")
                my_cursor.execute(
                    f"UPDATE tbl_journeyStops SET arrivalTime=?, depactureTime=?, conditional=?, platformNum=?, combiTriggerID=?, languageArea=?, combiTriggerIDn=? WHERE journeyID = {self.data4[8]} and routeStopID = {self.data4[9]}",
                    (arrival_entry.get(), departure_entry.get(), combobox_condition.get(), combobox_platform.get(),
                     combobox_trigger.get(), combobox_language, combi_trigger_id_new))
                conn.commit()
                self.Insert_data_right_journey_treeview()
                conn.close()
                self.Edit_Route.destroy()

            distance_button_add = Button(self.Edit_Route, text=" Submit ", font=('arial', 9, 'bold'), bg="#7C7CFC",
                                         fg="white", command=save_insert_right_data)
            distance_button_add.place(x=300, y=80)
            self.Edit_Route.mainloop()


    ########################################### Add New data in left frame ############################
    def add_new_data(self):
        print(361)
        self.Add_New = Tk()
        self.Add_New.geometry("400x300+80+300")
        self.Add_New.title("Add New")
        
        def show_column_entry(event=""):
            if len(self.Entry3.get()) == 2:
                self.Entry3.insert(2, ":")
            if not event.char.isdigit():
                return "break"
            elif len(self.Entry3.get()) > 3:
                self.Entry3.delete(4, tk.END)
            elif not event.char.isdigit():
                return "break"
        def do_backspace(event=""):
            pass

        ################################### Name ######################################################
        self.label1 = Label(self.Add_New, text="Name", width=12, font=('Times', 11, "bold"))
        self.Entry1 = Entry(self.Add_New, width=25,)
        self.label1.place(x=10, y=10)
        self.Entry1.place(x=200, y=10)
        ################################## Condition #################################################
        self.label2 = Label(self.Add_New, text="Condition", width=12, font=('Times', 11, "bold"))
        self.label2.place(x=10, y=50)
        self.combobox_left_condition = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_left_condition.set("none")
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        date_condition = ["-None-"]
        for i in root.findall("timeConditional"):
            name = i.find("name").text
            date_condition.append(name)
        self.combobox_left_condition.set("-None-")
        self.combobox_left_condition["values"] = date_condition
        self.combobox_left_condition.place(x=200, y=50)
        ################################ Departure ###################################################

        self.label3 = Label(self.Add_New, text="Departure", width=12, font=('Times', 11, "bold"))
        self.Entry3 = Entry(self.Add_New, width=25)
        self.label3.place(x=10, y=90)
        self.Entry3.place(x=200, y=90)
        self.Entry3.bind("<Key>", show_column_entry)
        self.Entry3.bind("<BackSpace>", do_backspace)
        ############################### Service #######################################################
        self.label4 = Label(self.Add_New, text="Service", width=12, font=('Times', 11, "bold"))
        self.label4.place(x=10, y=130)
        self.combobox_service = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_service.set("none")
        self.combobox_service["values"] = ("Fast", "Slow")
        self.combobox_service.place(x=200, y=130)
        ############################# Total cars #######################################################
        self.label5 = Label(self.Add_New, text="Total cars", width=12, font=('Times', 11, "bold"))
        self.Entry5 = Entry(self.Add_New, width=25)
        self.label5.place(x=10, y=170)
        self.Entry5.place(x=200, y=170)
        ############################# Handicars ######################################################
        self.label6 = Label(self.Add_New, text="Handicars", width=12, font=('Times', 11, "bold"))
        self.label6.place(x=10, y=210)
        self.combobox_handicars = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_handicars.set("none")
        self.combobox_handicars["values"] = ("3", "6", "9", "12", "15")
        self.combobox_handicars.place(x=200, y=210)

                
        ################################# insert data in new frame #####################################
        def insert_data_left():
            print(373)
            n = self.Entry1.get()
            c = self.combobox_left_condition.get()
            d = self.Entry3.get()
            s = self.combobox_service.get()
            t = self.Entry5.get()
            h = self.combobox_handicars.get()
            route_ID = self.combobox_routeID()

            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute("select journeyID from tbl_journeys")
            data_journeyID = my_cursor.fetchall()
            my_cursor.execute("select top(1) journeyID from tbl_journeys order by journeyID desc")
            data_journey_last_ID = my_cursor.fetchall()
            if len(data_journeyID) == 0:
                my_cursor.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)',
                                  (1, route_ID, n, c, d, s, t, h))
                sql_query = f'''select r.stopOrder,s.shortName, r.stationID, s.stationNr from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={route_ID} order by r.stopOrder'''
                my_cursor.execute(sql_query)
                data_tree = my_cursor.fetchall()
                for i in range(len(data_tree)):
                    journey_name = data_tree[i][3]
                    my_cursor.execute(f'INSERT INTO tbl_journeyStops VALUES(?,?,?,?,?,?,?,?,?,?)',
                                      (1, data_tree[i][0], journey_name.replace(" ", ""), data_tree[i][1], "--:--", "--:--", "-None-", " ", "-None-", "-None-"))

            else:
                my_cursor.execute('''SELECT CASE WHEN MAX([journeyID]) = COUNT(*)
THEN CAST(NULL AS INTEGER)
-- THEN MAX(column_name) + 1 as other option
WHEN MIN([journeyID]) > 1
THEN 1
WHEN MAX([journeyID]) <> COUNT(*)
THEN (SELECT MIN([journeyID])+1
FROM [triggers].[dbo].[tbl_journeys]
WHERE ([journeyID]+ 1)
NOT IN (SELECT [journeyID] FROM [triggers].[dbo].[tbl_journeys]))
ELSE NULL END
FROM [triggers].[dbo].[tbl_journeys]''')
                left_number = my_cursor.fetchall()
                if not left_number[0][0]:
                    my_cursor.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)',
                                      (data_journey_last_ID[0][0] + 1, route_ID, n, c, d, s, t, h))
                    sql_query = f'''select r.stopOrder,s.shortName, r.stationID, s.stationNr from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={route_ID} order by r.stopOrder'''
                    my_cursor.execute(sql_query)
                    data_tree = my_cursor.fetchall()
                    for i in range(len(data_tree)):
                        journey_name = data_tree[i][3]
                        my_cursor.execute(f'INSERT INTO tbl_journeyStops VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                                          (data_journey_last_ID[0][0] + 1, data_tree[i][0],
                                           journey_name.replace(" ", ""), data_tree[i][1], "--:--",
                                           "--:--", "-None-", " ", "-None-", "-None-", 0))
                else:
                    my_cursor.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)',
                                      (left_number[0][0], route_ID, n, c, d, s, t, h))
                    sql_query = f'''select r.stopOrder,s.shortName, r.stationID, s.stationNr from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={route_ID} order by r.stopOrder'''
                    my_cursor.execute(sql_query)
                    data_tree = my_cursor.fetchall()
                    for i in range(len(data_tree)):
                        journey_name = data_tree[i][3]
                        my_cursor.execute(f'INSERT INTO tbl_journeyStops VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                                          (left_number[0][0], data_tree[i][0],
                                           journey_name.replace(" ", ""), data_tree[i][1], "--:--",
                                           "--:--", "-None-", " ", "-None-", "-None-", 0))



            conn.commit()
            conn.close()
            self.Insert_data_left_journey_treeview()
            # messagebox.showinfo("Submit", "your data has been saved", parent=self.Add_New)
            self.Add_New.destroy()
        self.submitbutton = Button(self.Add_New, text="Submit11", command=insert_data_left)
        self.submitbutton.configure(font=('Times', 11, 'bold'), bg="#7C7CFC", fg="white")
        self.submitbutton.place(x=160, y=250)
        
    ############################################# simulate ################################################################
    
    def simulate_top(self):
        self.journey.destroy()
        simulation.MainApplicationSimulate()
        print(395)
    def on_exit(self):
        self.journey.destroy()
        main.MainApplication()


class data_from_route_list(tk.Frame):
    def __init__(self, parent):
        tk.Frame.__init__(self)
    @staticmethod
    def journey_list():
        global data_list_route
        return data_list_route

if __name__ == "__main__":
    MainApplication3()
