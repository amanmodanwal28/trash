// #include <stdio.h>

// unsigned char* GetAsciiBytes(unsigned char* dest, unsigned char* srce, unsigned char size);
// unsigned char* GetAsciiByte(unsigned char* srce, unsigned char* byte);
// unsigned char* GetAsciiDouble(unsigned char* srce, double* dest);
// unsigned char* GetAsciiWord(unsigned char* srce, unsigned short* word, unsigned char BigEndian);
// //unsigned char *p = "000000009CCE104100000080AB7D5641";
// unsigned char *p = "9CCE104100000080AB7D5641";
// double x; 
// unsigned char t;


// unsigned char * GetAsciiDouble(unsigned char * srce, double * dest)
// {
//     union {	
// 	       double	d;
//            unsigned char	a[8];  //[sizeof(double)];
//           } data;
//     // For GCC following conversion should work
//     srce = GetAsciiBytes(data.a + 4, srce, sizeof(double) / 2);
//     srce = GetAsciiBytes(data.a + 0, srce, sizeof(double) / 2);
//     *dest = data.d;
//     return srce;
// }


// unsigned char * GetAsciiWord(unsigned char * srce, unsigned short * word, unsigned char BigEndian)
// {
//     unsigned char	upper;
//     unsigned char	lower;
//     if (BigEndian)
//     {
//         srce = GetAsciiByte(srce,&upper);
//         srce = GetAsciiByte(srce,&lower);
//     }
//     else
//     {
//         srce = GetAsciiByte(srce,&lower);
//         srce = GetAsciiByte(srce,&upper);
//     }
//     *word = (unsigned short)((upper << 8) + lower);
//     return srce;
// }

// unsigned char * GetAsciiByte(unsigned char * srce, unsigned char * byte)
// {
//     unsigned char	upper,lower;

//     *byte = 0;
//     upper = toupper(*srce++);   // Uppercase upper nibble
//     lower = toupper(*srce++);   // Uppercase lower nibble
//     if (isxdigit(upper) && isxdigit(lower))
//     {
//         upper -= '0'; if (upper > 9) upper -= 7;
//         lower -= '0'; if (lower > 9) lower -= 7;
//         *byte  = (upper << 4) | lower;
//     }
//     return srce;
// }

// unsigned char * GetAsciiBytes(unsigned char *dest, unsigned char *srce, unsigned char size)
// {
//     unsigned char	upper, lower;

//     while (size--)
//     {
//         upper = toupper(*srce++);       // Uppercase upper nibble
//         lower = toupper(*srce++);       // Uppercase lower nibble
//         *dest = 0;
//         if (isxdigit(upper) && isxdigit(lower))
//         {
//             upper -= '0'; if (upper > 9) upper -= 7;
//             lower -= '0'; if (lower > 9) lower -= 7;
//             *dest  = (upper << 4) | lower;
//         }
//         dest++;
//     }
//     return srce;
// }


// /*unsigned char * GetAsciiBytes(unsigned char *dest, unsigned char *srce, unsigned char size)
// {
//     unsigned char	upper, lower;

//     while (size--)
//     {
//         upper = toupper(*srce++);       // Uppercase upper nibble
//         lower = toupper(*srce++);       // Uppercase lower nibble
//         *dest = 0;
//         if (isxdigit(upper) && isxdigit(lower))
//         {
//             upper -= '0'; if (upper > 9) upper -= 7;
//             lower -= '0'; if (lower > 9) lower -= 7;
//             *dest  = (upper << 4) | lower;
//         }
//         dest++;
//     }
//     return srce;
// }
// */
// // int isxdigit( int c )
// // {
// //     return ( isdigit(c) ||
// //              (('a' <= c) && (c <= 'f')) ||
// //              (('A' <= c) && (c <= 'F')) );
// // } /* isxdigit() */


// // int isdigit(int c)
// // {
// //     return ( ('0' <= c) && (c <= '9') );
// // } /* isdigit() */


// int main()
// {
//   t = GetAsciiDouble(p, &x);	
//   printf(" GPS x - %lf",x);	
// }







//  ################################ reverse calculate ######################################


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

unsigned char* GetAsciiBytes(unsigned char* dest, unsigned char* srce, unsigned char size);
unsigned char* GetAsciiByte(unsigned char* srce, unsigned char* byte);
unsigned char* GetAsciiDouble(unsigned char* srce, double* dest);
unsigned char* GetAsciiWord(unsigned char* srce, unsigned short* word, unsigned char BigEndian);

unsigned char* p = "276111";
double x;

unsigned char* GetAsciiDouble(unsigned char* srce, double* dest)
{
    union {
        double d;
        unsigned char a[8];
    } data;
    *dest = strtod(srce, NULL);
    memcpy(data.a, dest, sizeof(double));
    return srce;
}

unsigned char* GetAsciiWord(unsigned char* srce, unsigned short* word, unsigned char BigEndian)
{
    unsigned char upper;
    unsigned char lower;
    if (BigEndian)
    {
        srce = GetAsciiByte(srce, &upper);
        srce = GetAsciiByte(srce, &lower);
    }
    else
    {
        srce = GetAsciiByte(srce, &lower);
        srce = GetAsciiByte(srce, &upper);
    }
    *word = (unsigned short)((upper << 8) + lower);
    return srce;
}

unsigned char* GetAsciiByte(unsigned char* srce, unsigned char* byte)
{
    unsigned char upper, lower;

    *byte = 0;
    upper = toupper(*srce++);
    lower = toupper(*srce++);
    if (isxdigit(upper) && isxdigit(lower))
    {
        upper -= '0';
        if (upper > 9)
            upper -= 7;
        lower -= '0';
        if (lower > 9)
            lower -= 7;
        *byte = (upper << 4) | lower;
    }
    return srce;
}

unsigned char* GetAsciiBytes(unsigned char* dest, unsigned char* srce, unsigned char size)
{
    unsigned char upper, lower;

    while (size--)
    {
        upper = toupper(*srce++);
        lower = toupper(*srce++);
        *dest = 0;
        if (isxdigit(upper) && isxdigit(lower))
        {
            upper -= '0';
            if (upper > 9)
                upper -= 7;
            lower -= '0';
            if (lower > 9)
                lower -= 7;
            *dest = (upper << 4) | lower;
        }
        dest++;
    }
    return srce;
}

int main()
{
    GetAsciiDouble(p, &x);
    printf("Output: ");
    for (int i = 0; i < sizeof(double); i++) {
        printf("%02X", ((unsigned char*)&x)[i]);
    }
    printf("\n");
    return 0;
}

