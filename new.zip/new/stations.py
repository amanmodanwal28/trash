import sys
import tkinter.ttk
from tkinter import *
import shutil
# import pyodbc
from tkinter import messagebox
import main
import tkinter as tk
import pygame
from pathlib import Path
from tkinter import filedialog as fd
from math import *
import xml.etree.ElementTree as ET
import os
import sqlite3
from customtkinter import CTkButton
from file_dir import GUI_ICON, SQL_QUERY, File_Path

# Define the class the application
class MainApplication1:
    # init method or constructor that call by instance variable
    def __init__(self):
        # tk.Tk is crate a window

        self.window_bg_color = "#DDD0C8"
        # self.window_bg_color = "#ecd1b9" # some have different color example: ('azure4', 'lightsteelblue2', 'gray 85', 'gray 75', 'cyan')
        self.fg_color_button = "#323232"
        self.text_color_button = "#ffffff"
        self.hover_color_button = "black"
        # self.fontstyle_for_button = ("dubai medium", 8, "bold")
        self.fontstyle_for_button = ("arial", 8, "bold")
        # self.button_width = 70


        self.top = tk.Tk()
        # write a top title name line
        self.top.title('Station')
        # window frame geometry size (width,height,x-place,y-place)
        self.top.geometry("1100x600+150+40")
        # self.top.iconbitmap("UIFILES/logo2.ico")
        self.top.iconbitmap(GUI_ICON().gui_icon_file)
        # the background colour change by config
        # self.top.configure(bg="lightsteelblue2")
        self.top.configure(bg=self.window_bg_color)
        self.top.protocol("WM_DELETE_WINDOW", self.on_exit)


        # button = CTkButton(master=self.top, corner_radius=50, command=button_function, bg_color=self.window_bg_color,
        #                    fg_color=self.fg_color_button,
        #                    font=self.fontstyle_for_button, text="SHOP NOW", text_color=self.text_color_button,
        #                    hover_color=self.hover_color_button)


        # self.top.grab_set()
        # Allowing root window to not change it's size according to user's need
        self.top.resizable(False, False)
        # Fixing the size of the root window No one can now expand the size of the root window than the specified one.
        # self.top.maxsize(1100, 600)
        # self.top.minsize(1100, 600)
        self.var_station_name = StringVar()
        self.s = tkinter.ttk.Style(self.top)
        self.s.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        self.s.configure('Treeview.Heading', background="light gray")
        self.s.map('Treeview', background=[('selected', "#b79d62")])
        self.full_name_xml = []
        self.code_name_xml = [""]
        def search_items_in_listbox2(*args):
            print(75)
            # self.top.update()
            if self.search_entry.get() == "":
                self.show_data_in_station_table()
            else:
                try:
                    # data = self.connection_with_sql(execute_q="select * from tbl_station where shortName LIKE '%" + str(self.search_entry.get()) + "%'"
                    #                                 , save_or_update="view")
                    data = SQL_QUERY(f"select * from tbl_station where shortName LIKE '%{str(self.search_entry.get())}%'").QUERY_COMMAND()
                    # print(data, "asdfghjkl")
                    if len(data) != 0:
                        self.station_table.delete(*self.station_table.get_children())
                        for i in data:
                            self.station_table.insert("", END, values=list(i))
                except Exception as es:
                    messagebox.showerror("Error", f"Due To:{str(es)}", parent=self.top)
        ########################################## delete ##########################################
        def delete_data():
            print(93)
            if self.station_name_entry.get() == "" and self.station_serial_number_entry.get() == "":
                messagebox.showerror("Error", "Are Fields Are required", parent=self.top)
            else:
                try:
                    Delete = messagebox.askyesno("Delete", "Are you sure delete the data", parent=self.top)
                    if Delete > 0:
                        # conn = sqlite3.connect("triggers_abhay.db")
                        # my_cursor = conn.cursor()
                        # my_cursor.execute("select stationID from tbl_station order by stationID desc limit 1")
                        # station_id = my_cursor.fetchall()
                        station_id = SQL_QUERY("select stationID from tbl_station order by stationID desc limit 1").QUERY_COMMAND()

                        # print(self.data[1], "self.data[1]", self.data[5])

                        if station_id:
                            if not station_id[0][0] == self.data[1]:
                                # sql_data = "update tbl_station set shortName='Empty', GPSPosX=0, GPSPosY=0, GPSPosZ=0 where stationID=?"
                                # sql_data = "update tbl_station set shortName='Empty', GPSPosX=0, GPSPosY=0, GPSPosZ=0 where stationID=?"
                                # value = (self.data[1],)
                                # my_cursor.execute(sql_data, value)
                                SQL_QUERY(f"update tbl_station set shortName='Empty', GPSPosX=0, GPSPosY=0, GPSPosZ=0 where stationID={self.data[1]}").QUERY_COMMAND()
                            else:
                                # tbl_station
                                # sql_data1 = "delete from tbl_station where stationID=?"
                                # value1 = (self.data[1],)
                                # my_cursor.execute(sql_data1, value1)
                                SQL_QUERY(f"delete from tbl_station where stationID={self.data[1]}").QUERY_COMMAND()
                            # # tbl_stationNames
                            # sql_data1 = "delete from tbl_stationNames where stationID=?"
                            # value1 = (self.data[1],)
                            # my_cursor.execute(sql_data1, value1)
                            SQL_QUERY(f"delete from tbl_stationNames where stationID={self.data[1]}").QUERY_COMMAND()

                            # sql_data1 = "delete from tbl_routeStops where stationID=?"
                            # value1 = (self.data[1],)
                            # my_cursor.execute(sql_data1, value1)
                            SQL_QUERY(f"delete from tbl_routeStops where stationID={self.data[1]}").QUERY_COMMAND()

                            # sql_data1 = "delete from tbl_journeyStops where stationNo=?"
                            # value1 = (self.data[5],)
                            # my_cursor.execute(sql_data1, value1)
                            SQL_QUERY(f"delete from tbl_journeyStops where stationNo={self.data[5]}").QUERY_COMMAND()
                    else:
                        if not Delete:
                            return
                    conn.commit()
                    # self.show_data_in_station_table()
                    conn.close()
                    messagebox.showinfo("Delete", "your train data has been deleted", parent=self.top)
                except Exception as es:
                    messagebox.showerror("Error", f"Due To:{str(es)}", parent=self.top)
            self.show_data_in_station_table()
            self.station_name_entry.delete(0, END)
            self.station_serial_number_entry.delete(0, END)
            self.x_entry.delete(0, END)
            self.y_entry.delete(0, END)
            self.z_entry.delete(0, END)
            self.language_station_table.delete(*self.language_station_table.get_children())


        ################################### station view in Entry box and label ##############################
        self.station_view_frame = LabelFrame(self.top, relief=RIDGE, text='Station Details', font=('times new roman', 13, "bold"), bg=self.window_bg_color,
                                             fg="blue", bd=4)
        self.station_view_frame.place(x=280, y=35, height=520, width=810)
        # self.var_value = IntVar()
        # self.var_value1 = IntVar()
        # def thread():
        #     if self.var_value.get():
        #         pass
        #     if self.var_value1.get():
        #         print(self.var_value1.get())
        # self.stop_station_Label = Label(self.station_view_frame, font=("arial", 10, "bold"), bg='azure4',
        #                                 text='Train can stop here')
        # self.stop_station_Label.place(x=640, y=1)
        # self.check_box = Checkbutton(self.station_view_frame, offvalue=0, onvalue=1,
        #                              variable=self.var_value, bg="azure4", command=thread)
        # self.check_box.place(x=772, y=1)
        # self.var_value.set(1)
        #
        # self.stop_station_Label = Label(self.station_view_frame, font=("arial", 10, "bold"), bg='azure4',
        #                                 text='Used as language border')
        # self.stop_station_Label.place(x=605, y=35)
        # self.check_box1 = Checkbutton(self.station_view_frame, offvalue=0, onvalue=1,
        #                               variable=self.var_value1, bg="azure4", command=thread)
        # self.check_box1.place(x=772, y=35)

        self.station_name_label = Label(self.station_view_frame, font=("arial", 12, "bold"), bg=self.window_bg_color, text='Station Name :')
        self.station_name_label.place(x=10, y=20)
        self.station_name_entry = tkinter.ttk.Entry(self.station_view_frame, textvariable=self.var_station_name,
                                                    font=('arial', 10, 'bold'), width=34)
        self.station_name_entry.place(x=180, y=20)

        self.station_serial_number_label = Label(self.station_view_frame, font=("arial", 12, "bold"), bg=self.window_bg_color, text='Station Number :')
        self.station_serial_number_label.place(x=10, y=60)
        
        self.station_serial_number_entry = tkinter.ttk.Entry(self.station_view_frame, font=('arial', 10, 'bold'), width=34)
        self.station_serial_number_entry.place(x=180, y=60)
        self.var_value = IntVar()
        self.var_value1 = IntVar()

        def thread():
            cursor_row_select = self.station_table.focus()
            children2 = self.station_table.get_children()
            index_value = children2.index(cursor_row_select)
            if self.var_value.get():
                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute(f"update tbl_station set isStopArea=1 where [shortName]='{self.station_name_entry.get()}' and [stationNr]='{self.station_serial_number_entry.get()}'")
                # my_cursor.commit()
                # my_cursor.close()
                SQL_QUERY(f"update tbl_station set isStopArea=1 where [shortName]='{self.station_name_entry.get()}' and [stationNr]='{self.station_serial_number_entry.get()}'").QUERY_COMMAND()

            else:
                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute(
                #     f"update tbl_station set isStopArea=0 where [shortName]='{self.station_name_entry.get()}' and [stationNr]='{self.station_serial_number_entry.get()}'")
                # my_cursor.commit()
                # my_cursor.close()
                SQL_QUERY(f"update tbl_station set isStopArea=0 where [shortName]='{self.station_name_entry.get()}' and [stationNr]='{self.station_serial_number_entry.get()}'").QUERY_COMMAND()

            if self.var_value1.get():
                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute(
                #     f"update [tbl_station] set [isLanguageBorder]=1 where [shortName]='{self.station_name_entry.get()}' and [stationNr]='{self.station_serial_number_entry.get()}'")
                # my_cursor.commit()
                # my_cursor.close()
                SQL_QUERY(f"update [tbl_station] set [isLanguageBorder]=1 where [shortName]='{self.station_name_entry.get()}' and [stationNr]='{self.station_serial_number_entry.get()}'").QUERY_COMMAND()
            else:
                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute(
                #     f"update [tbl_station] set [isLanguageBorder]=0 where [shortName]='{self.station_name_entry.get()}' and [stationNr]='{self.station_serial_number_entry.get()}'")
                # my_cursor.commit()
                # my_cursor.close()
                SQL_QUERY(f"update [tbl_station] set [isLanguageBorder]=0 where [shortName]='{self.station_name_entry.get()}' and [stationNr]='{self.station_serial_number_entry.get()}'").QUERY_COMMAND()
            self.show_data_in_station_table()
            self.top.update()
            children1 = self.station_table.get_children()
            self.station_table.focus(children1[index_value])
            self.station_table.selection_set(children1[index_value])

        self.stop_station_Label = Label(self.station_view_frame, font=("arial", 10, "bold"), bg=self.window_bg_color,
                                        text='Train can stop here')
        self.stop_station_Label.place(x=640, y=1)
        self.check_box = Checkbutton(self.station_view_frame, offvalue=0, onvalue=1,
                                     variable=self.var_value, bg=self.window_bg_color, command=thread)
        self.check_box.place(x=772, y=1)

        self.stop_station_Label = Label(self.station_view_frame, font=("arial", 10, "bold"), bg=self.window_bg_color,
                                        text='Used as language border')
        self.stop_station_Label.place(x=605, y=35)
        self.check_box1 = Checkbutton(self.station_view_frame, offvalue=0, onvalue=1,
                                      variable=self.var_value1, bg=self.window_bg_color, command=thread)
        self.check_box1.place(x=772, y=35)

        ##################################### frame for station language ###################################
        self.station_language_frame = LabelFrame(self.station_view_frame, relief=RIDGE, text='Station Language', bg=self.window_bg_color,
                                                 font=('times new roman', 13, "bold"), fg="blue", bd=3)
        self.station_language_frame.place(x=7, y=120, height=250, width=720)
        self.language_scroll_y = tk.Scrollbar(self.station_language_frame, orient=VERTICAL)
        self.language_station_table = tkinter.ttk.Treeview(self.station_language_frame, columns=("Stat", "StatN", "StatNS", "StatAN"), yscrollcommand=self.language_scroll_y.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_station_table.heading("Stat", text="ISO language")
        self.language_station_table.column("Stat", width=100, anchor='c')

        self.language_station_table.heading("StatN", text="StationName")
        self.language_station_table.column("StatN", width=100, anchor='c')

        self.language_station_table.heading("StatNS", text="StationNameShort")
        self.language_station_table.column("StatNS", width=100, anchor='c')

        self.language_station_table.heading("StatAN", text="StationAudioName")
        self.language_station_table.column("StatAN", width=100, anchor='c')

        self.language_station_table.pack(fill=BOTH, expand=1)
        self.language_station_table["show"] = "headings"
        self.language_station_table.bind("<Double-1>", self.edit_audio_treeview)

        self.language_add_button = Button(self.top, height=1, width=8, text="ADD", font=('arial', 8, 'bold'), bg=self.fg_color_button, fg="black", cursor='hand2', command=self.add_language_and_edit1,
                                          foreground="white", activeforeground="white", activebackground="black"
                                          )
        # self.language_add_button = CTkButton(master=self.top, corner_radius=50, command=self.add_language_and_edit1, bg_color=self.window_bg_color,
        #                                      fg_color=self.fg_color_button, font=self.fontstyle_for_button, text="ADD", text_color=self.text_color_button,
        #                                      hover_color=self.hover_color_button, width=self.button_width)
        self.language_add_button.place(x=1015, y=350)

        self.language_delete_button = Button(self.top, height=1, width=8, text="DELETE", font=self.fontstyle_for_button, bg=self.fg_color_button, fg="black", cursor='hand2', command=self.delete_language,
                                             foreground="white", activeforeground="white", activebackground="black")
        # self.language_delete_button = CTkButton(master=self.top, corner_radius=50, command=self.delete_language, bg_color=self.window_bg_color,
        #                                      fg_color=self.fg_color_button, font=self.fontstyle_for_button, text="DELETE", text_color=self.text_color_button,
        #                                      hover_color=self.hover_color_button, width=60)

        self.language_delete_button.place(x=1015, y=380)


        ############################################### GPS Coordinates frame ##############################
        self.gps_coordinate_frame = LabelFrame(self.station_view_frame, relief=RIDGE, text='GPS Coordinates', bg=self.window_bg_color,
                                               font=('times new roman', 13, "bold"), fg="blue", bd=3)
        self.gps_coordinate_frame.place(x=7, y=400, height=80, width=790)

        self.x_label = Label(self.gps_coordinate_frame, font=('arial', 9, 'bold'), bg=self.window_bg_color, text="X :-")
        self.x_label.place(x=20, y=10)
        self.x_entry = tkinter.ttk.Entry(self.gps_coordinate_frame, font=('arial', 9, 'bold'), width=26)
        self.x_entry.place(x=50, y=8)

        self.y_label = Label(self.gps_coordinate_frame, font=('arial', 9, 'bold'), bg=self.window_bg_color, text="Y :-")
        self.y_label.place(x=280, y=10)
        self.y_entry = tkinter.ttk.Entry(self.gps_coordinate_frame, font=('arial', 9, 'bold'), width=26)
        self.y_entry.place(x=310, y=8)

        self.z_label = Label(self.gps_coordinate_frame, font=('arial', 9, 'bold'), bg=self.window_bg_color, text="Z :-")
        self.z_label.place(x=550, y=10)
        self.z_entry = tkinter.ttk.Entry(self.gps_coordinate_frame, font=('arial', 9, 'bold'), width=26)
        self.z_entry.place(x=580, y=8)





        ###################### fetch data #######################
        # def show_data_in_station_table():
        #     print(221)
        #     conn = sqlite3.connect("triggers_abhay.db")
        #     my_cursor = conn.cursor()
        #     my_cursor.execute("select * from tbl_station")
        #     data = my_cursor.fetchall()
        #     if len(data) != 0:
        #         self.station_table.delete(*self.station_table.get_children())
        #         for i in data:
        #             print(i[1])
        #             self.station_table.insert("", END, values=list(i))
        #         conn.commit()
        #     conn.close()

        ################################### get dat in entry box from MySql #######################################
        def get_station_data_entry_box(event=""):
            print(236)
            # self.short_station_name_entry.delete(0, END)
            self.station_name_entry.delete(0, END)
            self.station_serial_number_entry.delete(0, END)

            self.x_entry.delete(0, END)
            self.y_entry.delete(0, END)
            self.z_entry.delete(0, END)
            self.cursor_row = self.station_table.focus()
            self.content = self.station_table.item(self.cursor_row)
            self.data = self.content["values"]
            if self.data:
                self.var_value.set(self.data[7])
                self.var_value1.set(self.data[8])
                self.station_name_entry.insert(END, self.data[0])
                # self.short_station_name_entry.insert(END, self.data[1])
                self.station_serial_number_entry.insert(END, self.data[5])
                self.x_entry.insert(END, self.data[2])
                self.y_entry.insert(END, self.data[3])
                self.z_entry.insert(END, self.data[4])
                self.insert_data_with_focus()

        ########################################## Scroll bar search ########################
        self.search_entry_var = tk.StringVar()
        self.search_entry = tkinter.ttk.Entry(self.top, font=('arial', 11, 'bold'), width=22, textvariable=self.search_entry_var)
        self.search_entry.place(x=80, y=10)
        # self.search_entry.bind("<Key>", search_items_in_listbox)
        self.search_entry_var.trace("w", search_items_in_listbox2)

        self.search_label = Label(self.top, font=('arial', 11, 'bold'), text="Search : ", bg=self.window_bg_color)
        self.search_label.place(x=11, y=10)

        self.table_station = tk.Frame(self.top)
        self.table_station.place(x=10, y=35, height=520, width=250)
        self.scroll_y = tk.Scrollbar(self.table_station, orient=VERTICAL)
        self.station_table = tkinter.ttk.Treeview(self.table_station, columns="Stat", yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.station_table.heading("Stat", text="Station")
        self.station_table.pack(fill=BOTH, expand=1)
        self.station_table["show"] = "headings"
        self.show_data_in_station_table()
        self.station_table.bind("<ButtonRelease>", get_station_data_entry_box)
        self.scroll_y.configure(command=self.station_table.yview)
        # self.station_table.focus_set()
        children = self.station_table.get_children()
        if children:
            self.station_table.focus(children[0])
            # self.station_table.focus(0)
            self.station_table.selection_set(children[0])
            # self.station_table.selection_set(0)
            get_station_data_entry_box()
            self.insert_data_with_focus()
        ######################################### menu bar #########################
        self.menu = tk.Menu(self.top)
        self.Edit = tk.Menu(self.menu, tearoff=0, bg='sky blue')
        self.Edit.add_command(label="Delete", command=delete_data)
        self.Edit.add_command(label="Add New Station", command=self.new_data_in_station_tbl)
        self.Edit.add_command(label="Edit Station", command=self.edit_station)

        self.menu.add_cascade(label="Edit", menu=self.Edit)
        self.top.config(menu=self.menu)

        self.language_from_xml = ET.parse("projectinfo.xml")
        root = self.language_from_xml.getroot()
        for i in root.findall("ImsLanguages"):
            full_name = i.find("Name").text
            code_name = i.find("Code").text
            self.full_name_xml.append(full_name)
            self.code_name_xml.append(code_name)
            # print(full_name)
            # print(code_name)
        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()
        self.station_table.bind("<Button-3>", menu_popup)
        ########################################################################################
        popup = Menu(self.top, tearoff=0)
        popup.add_command(label="Delete", command=delete_data)
        popup.add_command(label="Add New Station", command=self.new_data_in_station_tbl)
        popup.add_command(label="Edit Station", command=self.edit_station)
        self.top.mainloop()

    # def connection_with_sql(self, execute_q="", save_or_update=""):
    #     if save_or_update == "view":
    #         conn = sqlite3.connect("triggers_abhay.db")
    #         my_cursor = conn.cursor()
    #         my_cursor.execute(execute_q)
    #         data = my_cursor.fetchall()
    #         conn.commit()
    #         conn.close()
    #         return data
    #     elif save_or_update == "save_or_update":
    #         conn = sqlite3.connect("triggers_abhay.db")
    #         my_cursor = conn.cursor()
    #         my_cursor.execute(execute_q)
    #         data = "done"
    #         conn.commit()
    #         conn.close()
    #         return data


    def show_data_in_station_table(self):
        print(221)
        self.station_table.tag_configure("odd_row", background=self.window_bg_color)
        self.station_table.tag_configure("even_row", background=self.text_color_button)
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute("select * from tbl_station order by stationID")
        # data = my_cursor.fetchall()
        data = SQL_QUERY("select * from tbl_station order by stationID").QUERY_COMMAND()
        if len(data) != 0:
            self.station_table.delete(*self.station_table.get_children())
            change_even_odd = "odd_row"
            for i in data:
                # print(i)
                if change_even_odd == "odd_row":
                    self.station_table.insert("", END, values=list(i), tags=("even_row",))
                    change_even_odd = "even_row"
                else:
                    self.station_table.insert("", END, values=list(i), tags=("odd_row",))
                    change_even_odd = "odd_row"
        else:
            self.station_table.delete(*self.station_table.get_children())
        # conn.commit()
        # conn.close()

    def edit_station(self):
        self.new_data = tk.Toplevel()
        self.new_data.grab_set()
        self.new_data.title("Edit Station")
        self.new_data.geometry("600x460+390+90")
        # self.new_data.iconbitmap("UIFILES/logo2.ico")
        self.new_data.iconbitmap(GUI_ICON().gui_icon_file)
        self.new_data.config(bg=self.window_bg_color)
        # self.top1.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.LabelFrame_new = LabelFrame(self.new_data, height=400, width=590, bd=5, bg=self.window_bg_color)
        self.LabelFrame_new.place(x=5, y=20)
        self.GPS_coordinates = LabelFrame(self.LabelFrame_new, text="GPS coordinates", height=150, width=560, bd=2,
                                          bg=self.window_bg_color, fg="blue")
        self.GPS_coordinates.place(x=10, y=90)
        self.language_area = LabelFrame(self.LabelFrame_new, text="Language Area", height=70, width=560, bd=2,
                                        bg=self.window_bg_color, fg="blue")
        self.language_area.place(x=10, y=270)
        ######################################################################################
        ###################################  Label #############################################
        ######################################################################################
        self.station_Number_label = Label(self.LabelFrame_new, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                          text='Station Number :')
        self.station_Number_label.place(x=40, y=15)

        self.station_name_label = Label(self.LabelFrame_new, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                        text='Station Name :')
        self.station_name_label.place(x=40, y=50)

        self.coordinates_X_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='coordinates_X :')
        self.coordinates_X_label.place(x=9, y=10)

        self.coordinates_Y_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='coordinates_Z :')
        self.coordinates_Y_label.place(x=10, y=50)

        self.coordinates_Z_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='coordinates_Z :')
        self.coordinates_Z_label.place(x=10, y=90)

        self.coordinates_latitude_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                                text='latitude :')
        self.coordinates_latitude_label.place(x=310, y=10)

        self.coordinates_longitude_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                                 text='longitude :')
        self.coordinates_longitude_label.place(x=310, y=50)

        self.coordinates_altitude_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                                text='altitude :')
        self.coordinates_altitude_label.place(x=310, y=90)
        ######################################################################################
        ######################################################################################
        ######################################################################################
        #####                                 Entry                                       ####
        ######################################################################################
        ######################################################################################
        self.station_Number_new_Entry = tkinter.ttk.Entry(self.LabelFrame_new, font=('arial', 9, 'bold'), width=26)
        # self.station_Number_new_Entry.configure(state=DISABLED)
        self.station_Number_new_Entry.place(x=260, y=15)

        self.station_name_new_Entry = tkinter.ttk.Entry(self.LabelFrame_new, font=('arial', 9, 'bold'), width=26)
        self.station_name_new_Entry.place(x=260, y=50)

        self.coordinates_X_Entry_var = tk.StringVar()
        self.coordinates_X_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20, textvariable=self.coordinates_X_Entry_var)
        self.coordinates_X_Entry.place(x=135, y=10)
        self.coordinates_X_Entry_var.trace("w", self.lat_long_altitude_decoder)

        self.coordinates_Y_Entry_var = tk.StringVar()
        self.coordinates_Y_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20, textvariable=self.coordinates_Y_Entry_var)
        self.coordinates_Y_Entry.place(x=135, y=50)
        self.coordinates_Y_Entry_var.trace("w", self.lat_long_altitude_decoder)

        self.coordinates_Z_Entry_var = tk.StringVar()
        self.coordinates_Z_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20, textvariable=self.coordinates_Z_Entry_var)
        self.coordinates_Z_Entry.place(x=135, y=90)
        self.coordinates_Z_Entry_var.trace("w", self.lat_long_altitude_decoder)


        self.coordinates_latitude_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20,)
        self.coordinates_latitude_Entry.place(x=400, y=10)


        self.coordinates_longituede_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20,)
        self.coordinates_longituede_Entry.place(x=400, y=50)

        self.coordinates_altitude_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20,)
        self.coordinates_altitude_Entry.place(x=400, y=90)


        self.station_Number_new_Entry.insert(0, self.station_serial_number_entry.get())
        self.station_name_new_Entry.insert(0, self.station_name_entry.get())
        self.coordinates_X_Entry.insert(0, self.x_entry.get())
        self.coordinates_Y_Entry.insert(0, self.y_entry.get())
        self.coordinates_Z_Entry.insert(0, self.z_entry.get())
        ######################################################################################
        ######################################################################################
        ####                                   combobox                                   ####
        ######################################################################################
        ######################################################################################
        self.language_area_1 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_1.place(x=20, y=20)

        self.language_area_2 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_2.place(x=130, y=20)

        self.language_area_3 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_3.place(x=240, y=20)

        self.language_area_4 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_4.place(x=350, y=20)

        self.language_area_5 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_5.place(x=450, y=20)
        self.lat_long_altitude_decoder()

        L1 = ""
        L2 = ""
        L3 = ""
        L4 = ""
        L5 = ""
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute(
        #     f"select defaultLanguageArea from tbl_station where shortName='{self.station_name_entry.get()}'")
        # data = my_cursor.fetchall()
        data = SQL_QUERY(f"select defaultLanguageArea from tbl_station where shortName='{self.station_name_entry.get()}'").QUERY_COMMAND()
        if data:
            data_1 = data[0][0]
            data_2 = data_1.split(",")
            for language_name in data_2:
                if data_2[0] == language_name:
                    L1 = language_name
                elif data_2[1] == language_name:
                    L2 = language_name
                elif data_2[2] == language_name:
                    L3 = language_name
                elif data_2[3] == language_name:
                    L4 = language_name
                elif data_2[4] == language_name:
                    L5 = language_name
        self.language_area_1["value"] = self.code_name_xml
        self.language_area_1.set(L1)
        # self.language_area_1.bind("<<ComboboxSelected>>", )
        self.language_area_2["value"] = self.code_name_xml
        self.language_area_2.set(L2)
        # self.language_area_2.bind("<<ComboboxSelected>>", )
        self.language_area_3["value"] = self.code_name_xml
        self.language_area_3.set(L3)
        # self.language_area_3.bind("<<ComboboxSelected>>", )
        self.language_area_4["value"] = self.code_name_xml
        self.language_area_4.set(L4)
        # self.language_area_4.bind("<<ComboboxSelected>>", )
        self.language_area_5["value"] = self.code_name_xml
        self.language_area_5.set(L5)
        # self.language_area_5.bind("<<ComboboxSelected>>", )

        ######################################################################################
        ######################################################################################
        #####                               Button                                       #####
        ######################################################################################
        ######################################################################################
        self.english_play_button = Button(self.new_data, text="SAVE", width=13, font=('arial', 8, 'bold'),
                                          bg=self.window_bg_color, fg="black", cursor='hand2',
                                          command=self.edit_button_fun)
        self.english_play_button.place(x=365, y=430)

        def new_data():
            self.new_data.destroy()

        self.english_play_button = Button(self.new_data, text="CANCEL", width=13, font=('arial', 8, 'bold'),
                                          bg=self.window_bg_color, fg="black", cursor='hand2', command=new_data)
        self.english_play_button.place(x=475, y=430)
        #####################################################################################
        ######################################################################################
        ######################################################################################
        self.new_data.mainloop()
    def edit_button_fun(self):
        print(424)
        list_1 = []
        list_2 = []
        list_1.append(self.language_area_1.get())
        list_1.append(self.language_area_2.get())
        list_1.append(self.language_area_3.get())
        list_1.append(self.language_area_4.get())
        list_1.append(self.language_area_5.get())
        for i in list_1:
            if i == "":
                pr = None
            else:
                list_2.append(i)
        defaultLanguageArea = ",".join(list_2)
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute(f"update tbl_station set shortName='{self.station_name_new_Entry.get()}', "
        #                   f"GPSPosX={int(self.coordinates_X_Entry.get())}, GPSPosY={int(self.coordinates_Y_Entry.get())}, GPSPosZ={int(self.coordinates_Z_Entry.get())}, defaultLanguageArea='{defaultLanguageArea}'"
        #                   f"where stationNr='{self.station_Number_new_Entry.get()}'")
        # conn.commit()
        # conn.close()
        try:
            SQL_QUERY(f'''update tbl_station set shortName='{self.station_name_new_Entry.get()}',GPSPosX={int(self.coordinates_X_Entry.get())}, GPSPosY={int(self.coordinates_Y_Entry.get())}, GPSPosZ={int(self.coordinates_Z_Entry.get())}, defaultLanguageArea='{defaultLanguageArea}' where stationNr='{self.station_Number_new_Entry.get()}' ''').QUERY_COMMAND()
        except ValueError:
            SQL_QUERY(f'''update tbl_station set shortName='{self.station_name_new_Entry.get()}',GPSPosX={int(float(self.coordinates_X_Entry.get()))}, GPSPosY={int(float(self.coordinates_Y_Entry.get()))}, GPSPosZ={int(float(self.coordinates_Z_Entry.get()))}, defaultLanguageArea='{defaultLanguageArea}' where stationNr='{self.station_Number_new_Entry.get()}' ''').QUERY_COMMAND()
        self.new_data.destroy()
        self.show_data_in_station_table()

    def geodetic_WGS84(self, *args):
        if (self.coordinates_latitude_Entry.get() != "" and self.coordinates_longituede_Entry.get() != ""
                and self.coordinates_altitude_Entry.get() != ""):
            latitude = float(self.coordinates_latitude_Entry.get())
            longitude = float(self.coordinates_longituede_Entry.get())
            altitude = float(self.coordinates_altitude_Entry.get())

            a = 6378137.0  # radius a of earth in meters cfr WGS84
            b = 6356752.3  # radius b of earth in meters cfr WGS84
            e2 = 1 - (b ** 2 / a ** 2)

            latr = latitude / 90 * 0.5 * pi  # latitude in radians
            lonr = longitude / 180 * pi  # longituede in radians

            Nphi = a / sqrt(1 - e2 * sin(latr) ** 2)

            x = (Nphi + altitude) * cos(latr) * cos(lonr)
            y = (Nphi + altitude) * cos(latr) * sin(lonr)
            z = (b ** 2 / a ** 2 * Nphi + altitude) * sin(latr)
            print(x, y, z)
            # 26.4047, 90.2723
            self.coordinates_X_Entry.delete(0, END)
            self.coordinates_Y_Entry.delete(0, END)
            self.coordinates_Z_Entry.delete(0, END)
            self.coordinates_X_Entry.insert(0, str(x))
            self.coordinates_Y_Entry.insert(0, str(y))
            self.coordinates_Z_Entry.insert(0, str(z))
    def lat_long_altitude_decoder(self, *args):
        if (self.coordinates_X_Entry.get() != "" and self.coordinates_Y_Entry.get() != ""
                and self.coordinates_Z_Entry.get() != ""):
            # self.coordinates_Y_Entry.get()
            x = float(self.coordinates_X_Entry.get())
            y = float(self.coordinates_Y_Entry.get())
            z = float(self.coordinates_Z_Entry.get())
            a = 6378137.0  # semi-major axis in meters (WGS84)
            b = 6356752.3  # semi-minor axis in meters (WGS84)
            e2 = 1 - (b ** 2 / a ** 2)  # square of eccentricity
            ep2 = (a ** 2 / b ** 2) - 1  # second eccentricity squared

            # Calculate longitude
            lon = atan2(y, x) * 180 / pi

            # Iterative solution for latitude
            p = sqrt(x ** 2 + y ** 2)
            theta = atan2(z * a, p * b)
            lat = atan2(z + ep2 * b * sin(theta) ** 3, p - e2 * a * cos(theta) ** 3) * 180 / pi

            # Calculate height
            Nphi = a / sqrt(1 - e2 * sin(lat * pi / 180) ** 2)
            h = p / cos(lat * pi / 180) - Nphi

            self.coordinates_latitude_Entry.delete(0, END)
            self.coordinates_longituede_Entry.delete(0, END)
            self.coordinates_altitude_Entry.delete(0, END)
            self.coordinates_latitude_Entry.insert(0, str(lat))
            self.coordinates_longituede_Entry.insert(0, str(lon))
            self.coordinates_altitude_Entry.insert(0, str(h))

            # return [lat, lon, h]




    def new_data_in_station_tbl(self):
        print(305)
        self.new_data = tk.Toplevel()
        self.new_data.grab_set()
        self.new_data.title("Add Station")
        self.new_data.geometry("600x460+390+90")
        # self.new_data.iconbitmap("UIFILES/logo2.ico")
        self.new_data.iconbitmap(GUI_ICON().gui_icon_file)
        self.new_data.config(bg=self.window_bg_color)
        # self.top1.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.LabelFrame_new = LabelFrame(self.new_data, height=400, width=590, bd=5, bg=self.window_bg_color)
        self.LabelFrame_new.place(x=5, y=20)
        self.GPS_coordinates = LabelFrame(self.LabelFrame_new, text="GPS coordinates", height=150, width=560, bd=2, bg=self.window_bg_color, fg="blue")
        self.GPS_coordinates.place(x=10, y=90)
        self.language_area = LabelFrame(self.LabelFrame_new, text="Language Area", height=70, width=560, bd=2,
                                        bg=self.window_bg_color, fg="blue")
        self.language_area.place(x=10, y=270)
        ######################################################################################
        ###################################  Label #############################################
        ######################################################################################
        self.station_Number_label = Label(self.LabelFrame_new, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                          text='Station Number :')
        self.station_Number_label.place(x=40, y=15)

        self.station_name_label = Label(self.LabelFrame_new, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                        text='Station Name :')
        self.station_name_label.place(x=40, y=50)

        self.coordinates_X_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='coordinates_X :')
        self.coordinates_X_label.place(x=9, y=10)

        self.coordinates_Y_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='coordinates_Z :')
        self.coordinates_Y_label.place(x=10, y=50)

        self.coordinates_Z_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='coordinates_Z :')
        self.coordinates_Z_label.place(x=10, y=90)

        self.coordinates_latitude_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='latitude :')
        self.coordinates_latitude_label.place(x=310, y=10)

        self.coordinates_longitude_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='longitude :')
        self.coordinates_longitude_label.place(x=310, y=50)

        self.coordinates_altitude_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='altitude :')
        self.coordinates_altitude_label.place(x=310, y=90)
        ######################################################################################
        ######################################################################################
        ######################################################################################
        #####                                 Entry                                       ####
        ######################################################################################
        ######################################################################################
        self.station_Number_new_Entry = tkinter.ttk.Entry(self.LabelFrame_new, font=('arial', 9, 'bold'), width=26)
        self.station_Number_new_Entry.place(x=260, y=15)

        self.station_name_new_Entry = tkinter.ttk.Entry(self.LabelFrame_new, font=('arial', 9, 'bold'), width=26)
        self.station_name_new_Entry.place(x=260, y=50)

        self.coordinates_X_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20)
        self.coordinates_X_Entry.place(x=135, y=10)

        self.coordinates_Y_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20)
        self.coordinates_Y_Entry.place(x=135, y=50)

        self.coordinates_Z_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20)
        self.coordinates_Z_Entry.place(x=135, y=90)

        self.coordinates_latitude_Entry_var = tk.StringVar()
        self.coordinates_latitude_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20, textvariable=self.coordinates_latitude_Entry_var)
        self.coordinates_latitude_Entry.place(x=400, y=10)
        self.coordinates_latitude_Entry_var.trace("w", self.geodetic_WGS84)

        self.coordinates_longituede_Entry_var = tk.StringVar()
        self.coordinates_longituede_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20, textvariable=self.coordinates_longituede_Entry_var)
        self.coordinates_longituede_Entry.place(x=400, y=50)
        self.coordinates_longituede_Entry_var.trace("w", self.geodetic_WGS84)

        self.coordinates_altitude_Entry_var = tk.StringVar()
        self.coordinates_altitude_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=20, textvariable=self.coordinates_altitude_Entry_var)
        self.coordinates_altitude_Entry.place(x=400, y=90)
        self.coordinates_altitude_Entry_var.trace("w", self.geodetic_WGS84)

        ######################################################################################
        ######################################################################################
        ####                                   combobox                                   ####
        ######################################################################################
        ######################################################################################
        self.language_area_1 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_1.place(x=20, y=20)

        self.language_area_2 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_2.place(x=130, y=20)

        self.language_area_3 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_3.place(x=240, y=20)

        self.language_area_4 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_4.place(x=350, y=20)

        self.language_area_5 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
        self.language_area_5.place(x=450, y=20)
        self.language_area_1["value"] = self.code_name_xml
        # self.language_area_1.bind("<<ComboboxSelected>>", )
        self.language_area_2["value"] = self.code_name_xml
        # self.language_area_2.bind("<<ComboboxSelected>>", )
        self.language_area_3["value"] = self.code_name_xml
        # self.language_area_3.bind("<<ComboboxSelected>>", )
        self.language_area_4["value"] = self.code_name_xml
        # self.language_area_4.bind("<<ComboboxSelected>>", )
        self.language_area_5["value"] = self.code_name_xml
        # self.language_area_5.bind("<<ComboboxSelected>>", )
        # self.count_table()
        self.table_name = SQL_QUERY("SELECT * from tbl_station ORDER BY stationID DESC LIMIT 1").QUERY_COMMAND()

        ######################################################################################
        ######################################################################################
        #####                               Button                                       #####
        ######################################################################################
        ######################################################################################
        self.english_play_button = Button(self.new_data, text="SAVE", width=13, font=('arial', 8, 'bold'),
                                          bg=self.window_bg_color, fg="black", cursor='hand2', command=self.insert_data_in_station_tbl)
        self.english_play_button.place(x=365, y=430)
        def new_data():
            self.new_data.destroy()
        self.english_play_button = Button(self.new_data, text="CANCEL", width=13, font=('arial', 8, 'bold'),
                                          bg=self.window_bg_color, fg="black", cursor='hand2', command=new_data)
        self.english_play_button.place(x=475, y=430)
        #####################################################################################
        ######################################################################################
        ######################################################################################
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute("select stationID from tbl_station order by [stationNr] desc LIMIT 1")
        # data = my_cursor.fetchall()
        data = SQL_QUERY("select stationID from tbl_station order by [stationNr] desc LIMIT 1").QUERY_COMMAND()

        if len(data) > 0:
            data_num = int(data[0][0])+1
            num_zero = 4 - len(str(data_num))
            add_num = "ST" + "0" * num_zero + str(data_num)
            # print("ST" + "0" * num_zero + str(data_num))
            self.station_Number_new_Entry.insert(0, add_num)
            # if int(data[0][0]) < 9:
            #     self.station_Number_new_Entry.insert(0, f"ST000{data_num}")
            # elif int(data[0][0]) < 99:
            #     self.station_Number_new_Entry.insert(0, f"ST00{data_num}")
            # elif int(data[0][0]) < 999:
            #     self.station_Number_new_Entry.insert(0, f"ST0{data_num}")
            # elif int(data[0][0]) < 9999:
            #     self.station_Number_new_Entry.insert(0, f"ST{data_num}")
        else:
            self.station_Number_new_Entry.insert(0, f"ST0001")
        # print(data[0])
        ### select top 1 stationID from [triggers_ankit].[dbo].[tbl_station] order by [stationNr] desc
        ######################################################################################
        ######################################################################################
        self.new_data.mainloop()
    def insert_data_with_focus(self):
        print(408)
        self.language_station_table.tag_configure("odd_row", background=self.window_bg_color)
        self.language_station_table.tag_configure("even_row", background=self.text_color_button)

        self.cursor_row = self.station_table.focus()
        self.content = self.station_table.item(self.cursor_row)
        self.station_number = self.content["values"]
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute(f"select ISOlang,stationName,stationNameShort,stationNameAudio  from tbl_stationNames where stationID = {self.station_number[1]} order by numLanguage")
        # data = my_cursor.fetchall()
        data = SQL_QUERY(f"select ISOlang,stationName,stationNameShort,stationNameAudio  from tbl_stationNames where stationID = {self.station_number[1]} order by numLanguage").QUERY_COMMAND()
        if len(data) != 0:
            self.language_station_table.delete(*self.language_station_table.get_children())
            change_even_odd = "odd_row"
            for i in data:
                if change_even_odd == "odd_row":
                    self.language_station_table.insert("", END, values=list(i), tags=("even_row",))
                    change_even_odd = "even_row"
                else:
                    self.language_station_table.insert("", END, values=list(i), tags=("odd_row",))
                    change_even_odd = "odd_row"
            # conn.commit()
        else:
            self.language_station_table.delete(*self.language_station_table.get_children())
        # conn.close()
    def insert_data_in_station_tbl(self):
        print(424)
        if not self.station_name_new_Entry.get() == "" or self.station_Number_new_Entry.get() == "":
            list_1 = []
            list_2 = []
            list_1.append(self.language_area_1.get())
            list_1.append(self.language_area_2.get())
            list_1.append(self.language_area_3.get())
            list_1.append(self.language_area_4.get())
            list_1.append(self.language_area_5.get())
            for i in list_1:
                if i == "":
                    pr = None
                else:
                    list_2.append(i)
            defaultLanguageArea = ",".join(list_2)
            if self.table_name:
                stationID = self.table_name[0][1] + 1
            else:
                stationID = 1
            # conn = sqlite3.connect("triggers_abhay.db")
            # my_cursor = conn.cursor()
            # my_cursor.execute(f"insert into tbl_station values(?,?,?,?,?,?,?,?,?)",
            #                   (self.station_name_new_Entry.get(),
            #                    stationID,
            #                    self.coordinates_X_Entry.get(),
            #                    self.coordinates_Y_Entry.get(),
            #                    self.coordinates_Z_Entry.get(),
            #                    self.station_Number_new_Entry.get(),
            #                    defaultLanguageArea, 1, 0))
            # conn.commit()
            # conn.close()
            SQL_QUERY(f"insert into tbl_station values('{self.station_name_new_Entry.get()}',{stationID},{self.coordinates_X_Entry.get()},{self.coordinates_Y_Entry.get()},{self.coordinates_Z_Entry.get()},'{self.station_Number_new_Entry.get()}','{defaultLanguageArea}',1,0)").QUERY_COMMAND()
            self.new_data.destroy()
            self.show_data_in_station_table()
        else:
            self.new_data.destroy()

    # def count_table(self):
    #     print(454)
    #     conn = sqlite3.connect("triggers_abhay.db")
    #     my_cursor = conn.cursor()
    #     # my_cursor.execute("select count(stationID) from tbl_station")
    #     my_cursor.execute("SELECT * from tbl_station ORDER BY stationID DESC LIMIT 1")
    #     self.table_name = my_cursor.fetchall()
    #     self.table_name = SQL_QUERY("SELECT * from tbl_station ORDER BY stationID DESC LIMIT 1").QUERY_COMMAND()
    #     # print(self.table_name, "3456789434567890987654567890-098765445678765456787656787655678987678965678765")
    #     # print(self.table_name[0][1], "3456789434567890987654567890-098765445678765456787656787655678987678965678765")
    #     conn.commit()
    #     conn.close()

    def add_language_and_edit(self):
        print(465)
        self.audio_data = tk.Toplevel()
        self.audio_data.grab_set()
        self.audio_data.title("Station Name")
        self.audio_data.geometry("500x250+390+100")
        # self.audio_data.iconbitmap("UIFILES/logo2.ico")
        self.audio_data.iconbitmap(GUI_ICON().gui_icon_file)
        self.audio_data.config(bg=self.window_bg_color)

        self.language_station_label = Label(self.audio_data, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                            text='Language :')
        self.language_station_label.place(x=30, y=10)

        self.language_combobox = tkinter.ttk.Combobox(self.audio_data, font=("arial", 10, 'bold'), width=25)
        self.language_combobox.place(x=200, y=12)
        self.language_combobox["value"] = self.code_name_xml
        self.language_combobox.bind("<<ComboboxSelected>>", self.combobox_select_for_audio_id)

        # self.check_var = tk.IntVar()
        # self.main_language_check_buttons = tk.Checkbutton(self.audio_data, variable=self.check_var, bg='gray75')
        # self.main_language_check_buttons.place(x=195, y=40)

        self.main_language_label = Label(self.audio_data, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                         text='Main Languages')
        self.main_language_label.place(x=230, y=40)

        self.station_name_label = Label(self.audio_data, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                        text='Station Name :')
        self.station_name_label.place(x=30, y=80)

        self.station_name_Entry = tkinter.ttk.Entry(self.audio_data, font=('arial', 9, 'bold'), width=28)
        self.station_name_Entry.place(x=200, y=80)

        self.station_short_name_label = Label(self.audio_data, font=("arial", 12, "bold"), bg=self.window_bg_color,
                                              text='Station Short Name :')
        self.station_short_name_label.place(x=30, y=120)

        self.station_short_name_Entry = tkinter.ttk.Entry(self.audio_data, font=('arial', 9, 'bold'), width=28)
        self.station_short_name_Entry.place(x=200, y=120)

        self.audio_file_label = Label(self.audio_data, font=("arial", 12, "bold"), bg=self.window_bg_color, text='Audio File :')
        self.audio_file_label.place(x=30, y=160)

        self.audio_file_Entry = tkinter.ttk.Entry(self.audio_data, font=('arial', 9, 'bold'), width=28)
        self.audio_file_Entry.place(x=200, y=160)
        self.audio_file_Entry_copy = tkinter.ttk.Entry(self.audio_data)

        self.language_audio_upload_button = Button(self.audio_data, text="▲",
                                                   font=('arial', 9, 'bold'),
                                                   width=5, height=0, bg="#7C7CFC", fg="white", command=self.select_file_hindi)
        self.language_audio_upload_button.place(x=405, y=160)



        self.language_play_audio_button = Button(self.audio_data, text="♫",
                                                 font=('arial', 9, 'bold'),
                                                 width=5, height=0, bg="#7C7CFC", fg="white", command=self.play_audio_hindi)
        self.language_play_audio_button.place(x=453, y=160)

        self.language_cancel_button = Button(self.audio_data, text="Cancel",
                                             font=('arial', 9, 'bold'),
                                             width=10, height=1, bg="#7C7CFC", fg="white", command=lambda: self.audio_data.destroy())
        self.language_cancel_button.place(x=300, y=200)
    def combobox_select_for_audio_id(self, event=""):
        self.audio_file_Entry.delete(0, END)
        self.audio_file_Entry.insert(0, f"{self.station_serial_number_entry.get()}{self.language_combobox.get()}.MP3")


    def select_file_hindi(self):
        try:
            pygame.mixer.music.unload()
        except Exception as es:
            pass
        self.audio_file_Entry_copy.delete(0, END)
        filetypes = (('mp3 files', '*.mp3'), ('All files', '*.*'))
        filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.audio_data)
        self.audio_file_Entry_copy.insert(END, filename)
        self.copy_other_folder()

    def copy_other_folder(self):
        try:
            src = self.audio_file_Entry_copy.get()
            # print(src, "0000000000")
            # dst = f"D:\\abhay\\ab\\sir soft\\New folder\\{self.audio_file_Entry.get()}"
            # dst = f"sqlData\\audio\\{self.audio_file_Entry.get()}"
            dst = File_Path().Audio_Path+self.audio_file_Entry.get()
            shutil.copy(src, dst)
            self.top.update()
        except FileNotFoundError:
            pass


    def play_audio_hindi(self):
        # path = "sqlData\\audio\\"
        path = File_Path().Audio_Path
        dir_list = os.listdir(path)
        print("dir_list", dir_list)

        if self.audio_file_Entry.get() in dir_list:
            pygame.mixer.init()
            # pygame.mixer.music.load(f"sqlData\\audio\\{self.audio_file_Entry.get()}")
            pygame.mixer.music.load(path+self.audio_file_Entry.get())
            pygame.mixer.music.play(loops=0)
            # pygame.mixer.music.unload()
        # for i in dir_list:
        #     if i == self.audio_file_Entry.get():
        #         pygame.mixer.init()
        #         pygame.mixer.music.load(f"sqlData\\audio\\{self.audio_file_Entry.get()}")
        #         pygame.mixer.music.play(loops=0)
        #         break
        #     else:
        #         pass
        #         # print("noo")


    def add_language_and_edit1(self):
        print(522)
        def insert_tbl_station_Name():
            if self.station_name_Entry.get() == "":
                self.audio_data.destroy()
            else:
                station_id = int(self.station_number[1])
                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute(f"SELECT ISOlang FROM tbl_stationNames where stationID={station_id} and  ISOlang LIKE '%{self.language_combobox.get()}%'")
                # find_lang = my_cursor.fetchall()
                find_lang = SQL_QUERY(f"SELECT ISOlang FROM tbl_stationNames where stationID={station_id} and  ISOlang LIKE '%{self.language_combobox.get()}%'").QUERY_COMMAND()
                if find_lang:
                    messagebox.showinfo("Language", "This language already exists in table", parent=self.top)
                else:
                    # my_cursor.execute(f"select max(numLanguage) from tbl_stationNames where stationID={station_id}")
                    # max_id = my_cursor.fetchall()
                    max_id = SQL_QUERY(f"select max(numLanguage) from tbl_stationNames where stationID={station_id}").QUERY_COMMAND()
                    id_num = 1
                    if max_id[0][0]:
                        id_num = int(max_id[0][0]) + 1
                    # my_cursor.execute(f"insert into tbl_stationNames values(?,?,?,?,?,?)",
                    #                   (self.station_number[1],
                    #                    self.language_combobox.get(),
                    #                    self.station_name_Entry.get(),
                    #                    self.station_short_name_Entry.get(),
                    #                    self.audio_file_Entry.get(),
                    #                    id_num))
                    SQL_QUERY(f"insert into tbl_stationNames values({self.station_number[1]},'{self.language_combobox.get()}','{self.station_name_Entry.get()}','{self.station_short_name_Entry.get()}','{self.audio_file_Entry.get()}',{id_num})").QUERY_COMMAND()
                # conn.commit()
                # conn.close()
                self.audio_data.destroy()
                self.insert_data_with_focus()
        self.add_language_and_edit()
        self.language_ok_button = Button(self.audio_data, text="OK",
                                         font=('arial', 9, 'bold'),
                                         width=10, height=1, bg="#7C7CFC", fg="white", command=insert_tbl_station_Name)
        self.language_ok_button.place(x=200, y=200)
    def edit_audio_treeview(self, event=""):
        print(541)
        self.cursor_row1 = self.language_station_table.focus()
        self.content1 = self.language_station_table.item(self.cursor_row1)
        self.data5 = self.content1["values"]
        # print(self.data5)
        if self.data5 == "":
            pass
            # print("noo")
        else:
            def update_tbl_stationName():
                # print(self.language_combobox.get())

                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute(f'''UPDATE tbl_stationNames SET stationName='{self.station_name_Entry.get()}',
                #   stationNameShort='{self.station_short_name_Entry.get()}', stationNameAudio='{self.audio_file_Entry.get()}' WHERE
                #   stationID={self.station_number[1]} and ISOlang='{self.language_combobox.get()}' ''')
                # conn.commit()
                # conn.close()

                SQL_QUERY(f'''UPDATE tbl_stationNames SET stationName='{self.station_name_Entry.get()}',
                  stationNameShort='{self.station_short_name_Entry.get()}', stationNameAudio='{self.audio_file_Entry.get()}' WHERE 
                  stationID={self.station_number[1]} and ISOlang='{self.language_combobox.get()}' ''').QUERY_COMMAND()
                self.audio_data.destroy()
                self.insert_data_with_focus()

            self.add_language_and_edit()
            self.language_ok_button = Button(self.audio_data, text="OK",
                                             font=('arial', 9, 'bold'),
                                             width=10, height=1, bg="#7C7CFC", fg="white", command=update_tbl_stationName)
            self.language_ok_button.place(x=200, y=200)
            self.get_data_language()

    def delete_language(self):
        cursor_row2 = self.language_station_table.focus()
        content2 = self.language_station_table.item(cursor_row2)
        ISOlanguage_data = content2["values"]
        if ISOlanguage_data:
            # conn = sqlite3.connect("triggers_abhay.db")
            # my_cursor = conn.cursor()
            # my_cursor.execute(
            #     f"delete from tbl_stationNames where stationID={self.station_number[1]} and ISOlang='{ISOlanguage_data[0]}' ")
            # conn.commit()
            # conn.close()
            SQL_QUERY(f"delete from tbl_stationNames where stationID={self.station_number[1]} and ISOlang='{ISOlanguage_data[0]}' ").QUERY_COMMAND()
            self.insert_data_with_focus()



    def get_data_language(self):
        print(562)
        self.cursor_row = self.language_station_table.focus()
        self.content = self.language_station_table.item(self.cursor_row)
        self.data4 = self.content["values"]
        self.language_combobox.set(self.data4[0])
        self.language_combobox.config(state=DISABLED)
        self.station_name_Entry.delete(0, END)
        self.station_name_Entry.insert(0, self.data4[1])
        self.station_short_name_Entry.delete(0, END)
        self.station_short_name_Entry.insert(0, self.data4[2])
        self.audio_file_Entry.delete(0, END)
        self.audio_file_Entry.insert(0, self.data4[3])



    def on_exit(self):
        self.top.destroy()
        main.MainApplication()

if __name__ == "__main__":
    MainApplication1()
