import pygame.mixer
from main import *
from tkinter import *
import tkinter.ttk
from tkinter import messagebox
# import pyodbc
import tkinter as tk
import trigger1
import xml.etree.ElementTree as ET
import tkinterDnD
from tkinter import filedialog as fd
import shutil
import os
# from playsound import playsound
from PIL import Image, ImageTk
from tkVideoPlayer import TkinterVideo
import sqlite3
import glob
from file_dir import GUI_ICON, SQL_QUERY, File_Path

num_of_combo_available_global_actionMess = 1

class MainApplication6:
    def __init__(self):
        global num_of_combo_available_global_actionMess
        self.top = tkinterDnD.Tk()
        self.top.title("Create Message")
        self.top.geometry("900x510+200+20")
        self.top.resizable(False, False)
        # self.top.iconbitmap("UIFILES/logo2.ico")
        self.top.iconbitmap(GUI_ICON().gui_icon_file)
        self.top.protocol("WM_DELETE_WINDOW", self.on_exit)


        self.drop_button = {}
        self.file_formate = ""
        self.position_number = 1
        self.x_position = 0  # Initial x-coordinate          #####
        self.y_position = 0
        self.row_position = 0
        self.column_position = 0
        self.selected_action = []


        animal = trigger1.Reptile(tk.Frame)
        num_of_combo_available_global_actionMess = animal.return_value()


        # call class method
        self.action_ID = animal.action_ID_num() # action_ID from tbl_action
        self.message_dis = animal.var2()    # all saved massage
        self.resource = animal.print_animal() # resource or device type (display, tft, speaker, other)


        # self.action_ID = 1
        # self.message_dis = "<field01>[MT0001][MT0006]</field01><field00>[MV0001]</field00>"
        # self.resource = "front display right"



        # print(self.resource, self.action_ID, "jjjjjjjj")
        # self.message_dis = "<field02>{carcount}{servicetype}</field02><hi><field01>{endstationlong}</field01></hi>[MT0007]"
        # self.message_dis = ""
        self.int_values_for_resource = 0
        self.int_values_for_resource_group = 0 # text_group = 1 | audio_group = 2 | video_group = 3 | image_group = 4

        resource = ET.parse("projectinfo.xml")
        root = resource.getroot()
        for i in root.findall("resource"):
            resource_name = i.find("name").text
            if resource_name.upper() == self.resource.upper():
                self.int_values_for_resource = i.find("value").text
                self.int_values_for_resource_group = str(i.find("group").text)
        # print(self.int_values_for_resource, self.int_values_for_resource_group)
        # print(self.action_ID, self.resource, type(self.action_ID),  self.message_dis, "sdfghhgfxgjcxxcghjihgcghjjhgcghgcvhjjhvcvhjhgcg")
        ################################### message type frame ##############################


        self.message_type_frame = LabelFrame(self.top, relief=RIDGE, text='Message Type', font=('times new roman', 13, "bold"),
                                             fg="red", bd=4)
        self.message_type_frame.place(x=0, y=0, height=60, width=900)

        self.var = IntVar(self.message_type_frame)

        self.text_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Text', font=('arial', 11, 'bold'), command=lambda: self.insert_data_on_all_treeview(file_format="MT", markup_group="1"), value=1)
        self.text_mess.place(x=150, y=0)

        self.audio_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Audio', font=('arial', 11, 'bold'), command=lambda: self.insert_data_on_all_treeview(file_format="MA", markup_group="2"), value=2)
        self.audio_mess.place(x=20, y=0)

        self.video_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Video', font=('arial', 11, 'bold'), command=lambda: self.insert_data_on_all_treeview(file_format="MV", markup_group="3"), value=3)
        self.video_mess.place(x=280, y=0)

        self.Image_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Image', font=('arial', 11, 'bold'), command=lambda: self.insert_data_on_all_treeview(file_format="MI", markup_group="4"), value=4)
        self.Image_mess.place(x=410, y=0)

        ################################### message type frame ##############################
        ######################### two label frame  in mai window frame ################################
        self.trigger_and_action_frame = LabelFrame(self.top, relief=RIDGE, bd=4)
        self.trigger_and_action_frame.place(x=0, y=60, height=300, width=900)

        self.drag_and_drop_message_frame = LabelFrame(self.top, relief=RIDGE, bd=4)
        self.drag_and_drop_message_frame.place(x=0, y=361, height=115, width=900)

        self.label_for_file_type = Label(self.drag_and_drop_message_frame, text='Not selected', font=('arial', 8, "bold"),
                                         fg="red", bd=4)
        self.label_for_file_type.place(x=0, y=0)


        self.view_drop_message_frame = LabelFrame(self.drag_and_drop_message_frame, relief=RIDGE, bd=4)
        self.view_drop_message_frame.place(x=0, y=20, height=85, width=891)
        self.view_drop_message_frame.register_drop_target("*")
        self.view_drop_message_frame.bind("<<Drop>>", self.drop_all_items_in_frame)

        # self.action_view_frame = LabelFrame(self.top, relief=RIDGE, bd=4)
        # self.action_view_frame.place(x=0, y=470, height=127, width=900)

        # ᅘ == "\u1158" : ᅇ == \u1147 : ⌾ == \u233e
        self.add_new_data = Button(self.drag_and_drop_message_frame, text="\u232c", font=('arial', 9, 'bold'), width=0,
                                   bg="#7C7CFC", fg="white", command=lambda: self.view_all_action_with_field())
        self.add_new_data.place(x=866, y=0, height=18)

        full_message_ok = Button(self.top, text="Ok", font=('arial', 10, 'bold'), width=9,
                                 height=1, bg="#7C7CFC", fg="white", command=self.save_data_in_sql)
        full_message_ok.place(x=700, y=479)

        full_message_cancel = Button(self.top, text="Cancel", font=('arial', 10, 'bold'),
                                     width=9, height=1, bg="#7C7CFC", fg="white", command=self.on_exit)
        full_message_cancel.place(x=800, y=479)

        #########################################################################################################################################################################
        #################################################################################
        ############################## Fixed Message Part ###############################
        #################################################################################
        def drag_command(event):
            record = 0
            for selected_item in self.table_for_fixed_mess.selection():
                item = self.table_for_fixed_mess.item(selected_item)
                record = item['values']
            if record:
                return tkinterDnD.COPY, "DND_Text", "[" + record[0] + "]"

        self.fixed_message_part = LabelFrame(self.trigger_and_action_frame, relief=RIDGE, text='Fixed Message Part',
                                             font=('times new roman', 13, "bold"), fg="red", bd=4)
        self.fixed_message_part.place(x=0, y=0, height=255, width=290)
        self.scroll_y_fixed_message = Scrollbar(self.fixed_message_part, orient=VERTICAL)
        self.table_for_fixed_mess = tkinter.ttk.Treeview(self.fixed_message_part, columns="trigg",
                                                         yscrollcommand=self.scroll_y_fixed_message.set)
        self.scroll_y_fixed_message.pack(side=RIGHT, fill=Y)
        self.scroll_y_fixed_message.config(command=self.table_for_fixed_mess.yview)
        self.table_for_fixed_mess.heading("trigg", text="Fixed Message Part")
        self.table_for_fixed_mess.pack(fill=BOTH, expand=1)
        self.table_for_fixed_mess.register_drag_source("*")
        self.table_for_fixed_mess.bind("<<DragInitCmd>>", drag_command)
        self.table_for_fixed_mess.bind("<ButtonRelease>", self.fix_treeview_selected_details)
        self.table_for_fixed_mess["show"] = "headings"

        #################################################################################
        ############################## Keywords (variable Part) ###############################
        #################################################################################
        def drag_command(event):
            record = 0
            for selected_item in self.table_for_keyword_mess.selection():
                item = self.table_for_keyword_mess.item(selected_item)
                record = item['values']
            if record:
                return tkinterDnD.COPY, "DND_Text", "{"+record[0]+"}"

        self.keyword_message_part = LabelFrame(self.trigger_and_action_frame, relief=RIDGE, text='Keywords (variable Part)',
                                               font=('times new roman', 13, "bold"), fg="red", bd=4)
        self.keyword_message_part.place(x=300, y=0, height=255, width=290)
        self.scroll_y_keyword_message = Scrollbar(self.keyword_message_part, orient=VERTICAL)
        self.table_for_keyword_mess = tkinter.ttk.Treeview(self.keyword_message_part, columns="trigg",
                                                           yscrollcommand=self.scroll_y_keyword_message.set)
        self.scroll_y_keyword_message.pack(side=RIGHT, fill=Y)
        self.scroll_y_keyword_message.config(command=self.table_for_keyword_mess.yview)
        self.table_for_keyword_mess.heading("trigg", text="Keywords (variable Part)")
        self.table_for_keyword_mess.pack(fill=BOTH, expand=1)
        self.table_for_keyword_mess.register_drag_source("*")
        self.table_for_keyword_mess.bind("<<DragInitCmd>>", drag_command)
        self.table_for_keyword_mess["show"] = "headings"

        #################################################################################
        ############################## Markup Code ###############################
        #################################################################################
        def drag_command(event):
            record = 0
            for selected_item in self.table_for_markup_mess.selection():
                item = self.table_for_markup_mess.item(selected_item)
                record = item['values']
            if record:
                return tkinterDnD.COPY, "DND_Text", "<"+record[0]+">"+",</"+record[0]+">"

        self.markup_message_part = LabelFrame(self.trigger_and_action_frame, relief=RIDGE, text='Markup Code',
                                              font=('times new roman', 13, "bold"), fg="red", bd=4)
        self.markup_message_part.place(x=600, y=0, height=255, width=290)
        self.scroll_y_markup_message = Scrollbar(self.markup_message_part, orient=VERTICAL)
        self.table_for_markup_mess = tkinter.ttk.Treeview(self.markup_message_part, columns="trigg",
                                                          yscrollcommand=self.scroll_y_markup_message.set)
        self.scroll_y_markup_message.pack(side=RIGHT, fill=Y)
        self.scroll_y_markup_message.config(command=self.table_for_markup_mess.yview)
        self.table_for_markup_mess.heading("trigg", text="Markup Code")
        self.table_for_markup_mess.pack(fill=BOTH, expand=1)
        self.table_for_markup_mess.register_drag_source("*")
        self.table_for_markup_mess.bind("<<DragInitCmd>>", drag_command)
        self.table_for_markup_mess["show"] = "headings"
        self.insert_data_on_all_treeview()

        ###########################################################################################################
        ###########################################// Button //####################################################
        ###########################################################################################################

        self.add_new_data = Button(self.trigger_and_action_frame, text="New", font=('arial', 10, 'bold'), width=8, bg="#7C7CFC", fg="white", command=lambda: self.new_and_edit(title="ADD NEW"))
        self.add_new_data.place(x=10, y=260)

        self.edit_data = Button(self.trigger_and_action_frame, text="Edit", font=('arial', 10, 'bold'), width=8, bg="#7C7CFC", fg="white", command=lambda: (self.new_and_edit(title="Edit") if self.table_for_fixed_mess.selection() else self.pop_message(text="File Not Selected")))
        self.edit_data.place(x=100, y=260)

        self.delete_data = Button(self.trigger_and_action_frame, text="Delete", font=('arial', 10, 'bold'), width=8, bg="#7C7CFC", fg="white", command=lambda: self.delete_all_message_tbl_sql())
        self.delete_data.place(x=200, y=260)

        file_format = ""
        print("self.int_values_for_resource_group", self.int_values_for_resource_group)

        if self.int_values_for_resource_group == "1":
            self.var.set(1)
            file_format = "MT"
            self.audio_mess.configure(state=DISABLED)
            self.video_mess.configure(state=DISABLED)
            self.Image_mess.configure(state=DISABLED)
        elif self.int_values_for_resource_group == "2":
            self.var.set(2)
            file_format = "MA"
            self.text_mess.configure(state=DISABLED)
            self.video_mess.configure(state=DISABLED)
            self.Image_mess.configure(state=DISABLED)
        elif self.int_values_for_resource_group == "3":
            self.var.set(3)
            file_format = "MV"
            self.audio_mess.configure(state=DISABLED)
        elif self.int_values_for_resource_group == "4":
            self.var.set(4)
            file_format = "MI"
            self.text_mess.configure(state=DISABLED)
            self.audio_mess.configure(state=DISABLED)
            self.video_mess.configure(state=DISABLED)
            # self.Image_mess.configure(state=DISABLED)
        if file_format:
            self.insert_data_on_all_treeview(file_format=file_format, markup_group=self.int_values_for_resource_group)

        self.message_filter_x()
        # self.drop_all_items_in_frame(text="[MT0001]")
        self.top.mainloop()
    def message_filter_x(self):
        open_pattern = "[{<"
        close_pattern = "]}>"
        temp_list_message = []
        text = ""
        for item in self.message_dis:
            if close_pattern.count(item):
                text = text + str(item)
                temp_list_message.append(text)
                text = ""
            else:
                text = text + str(item)
        num_index = 0
        for item in temp_list_message:
            if item[0] == "[":
                item_name = item[1:-1:]
                description_name = self.sql_data(f"SELECT [description] FROM [messageA] where [name]='{item_name}'")
                if len(description_name) != 0:
                    temp_list_message[num_index] = f"[{description_name[0][0]}]"
            num_index += 1
        for text in temp_list_message:
            self.create_button_message(text=text)

    def sql_data(self, sql_query):
        return SQL_QUERY(sql_query).QUERY_COMMAND()
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute(sql_query)
        # if sql_query.find("Select") > -1 or sql_query.find("SELECT") > -1 or sql_query.find("select") > -1:
        #     data = my_cursor.fetchall()
        #     conn.commit()
        #     conn.close()
        #     return data
        # else:
        #     conn.commit()
        #     conn.close()

    def insert_data_on_all_treeview(self, file_format="", markup_group=""):
        self.file_formate = file_format
        if file_format:
            data = self.sql_data(f"SELECT description, [name] from messageA where name like'%{file_format}%'")
            if len(data) != 0:
                self.table_for_fixed_mess.delete(*self.table_for_fixed_mess.get_children())
                for i in data:
                    self.table_for_fixed_mess.insert("", END, values=list(i))
            else:
                self.table_for_fixed_mess.delete(*self.table_for_fixed_mess.get_children())

        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        value_inserted = 0
        for i in root.findall("stationCode"):
            it = i.find("name").text
            self.table_for_keyword_mess.insert("", END, values=it)
            value_inserted += 1
        if not value_inserted:
            self.table_for_keyword_mess.delete(*self.table_for_keyword_mess.get_children())

        xml_markupCode = ET.parse("projectinfo.xml")
        root_markupCode = xml_markupCode.getroot()
        self.table_for_markup_mess.delete(*self.table_for_markup_mess.get_children())
        for i in root_markupCode.findall("markupCode"):
            group_item = i.find("group").text
            if group_item == markup_group:
                it = i.find("name").text
                self.table_for_markup_mess.insert("", END, values=it)

    def do_popup(self, event):
        # display the popup menu
        try:
            self.popup.tk_popup(event.x_root, event.y_root, 0)
        finally:
            # make sure to release the grab (Tk 8.0a1 only)
            self.popup.grab_release()

    def create_button_message(self, text="", color="gray"):  # after the if condition : (if text_item:-->>)
        if text.find("[") == 0:
            bg_color = "cyan"
        elif text.find("{") == 0:
            bg_color = "pink"
        elif text.find("<") == 0:
            bg_color = "light green"
        self.enter_position_num = 0

        def delete_selected_pop_message(position_num=self.position_number):
            if self.enter_position_num:
                self.position_number = self.enter_position_num
                self.drop_all_items_in_frame(delete_item=True)
            self.enter_position_num = 0

        def enter_action_button(event, position_num=self.position_number):
            self.enter_position_num = position_num
            self.drop_button[self.enter_position_num].focus_force()
            if self.drop_button[self.enter_position_num]['text'][0] == "<":
                skip_num = 0
                first_tag = 0
                last_tag = 0
                if self.drop_button[self.enter_position_num]['text'][1] == "/":
                    for item in list(self.drop_button)[self.enter_position_num - 1::-1]:
                        if self.enter_position_num == item:
                            continue
                        if self.drop_button[self.enter_position_num]['text'].replace("/", "") == \
                                self.drop_button[item]['text']:
                            if skip_num:
                                skip_num -= 1
                                continue
                            first_tag = item
                            last_tag = self.enter_position_num
                            break
                        elif self.drop_button[self.enter_position_num]['text'] == self.drop_button[item]['text']:
                            skip_num += 1
                    if first_tag:
                        self.drop_button[first_tag]['bg'] = "red"
                        self.drop_button[last_tag]['bg'] = "red"
                else:
                    for item in list(self.drop_button)[self.enter_position_num:]:
                        if self.enter_position_num == item:
                            continue
                        if self.drop_button[self.enter_position_num]['text'].replace("<", "</") == \
                                self.drop_button[item]['text']:
                            if skip_num:
                                skip_num -= 1
                                continue
                            first_tag = self.enter_position_num
                            last_tag = item
                            break
                        elif self.drop_button[self.enter_position_num]['text'] == self.drop_button[item]['text']:
                            skip_num += 1
                    if first_tag:
                        self.drop_button[first_tag]['bg'] = "red"
                        self.drop_button[last_tag]['bg'] = "red"

            # else:
            #     if self.drop_button[self.enter_position_num]['bg'] == "cyan":  # ff0000, #f90000
            #         self.drop_button[self.enter_position_num]['bg'] = "#ff0000"
            #     elif self.drop_button[self.enter_position_num]['bg'] == "pink":
            #         self.drop_button[self.enter_position_num]['bg'] = "#f90000"

        def leave_action_button(event, position_num=self.position_number):
            if self.drop_button[self.enter_position_num]['text'][0] == "<":
                skip_num = 0
                first_tag = 0
                last_tag = 0
                if self.drop_button[self.enter_position_num]['text'][1] == "/":
                    for item in list(self.drop_button)[self.enter_position_num - 1::-1]:
                        if self.enter_position_num == item:
                            continue
                        if self.drop_button[self.enter_position_num]['text'].replace("/", "") == \
                                self.drop_button[item]['text']:
                            if skip_num:
                                skip_num -= 1
                                continue
                            first_tag = item
                            last_tag = self.enter_position_num
                            break
                        elif self.drop_button[self.enter_position_num]['text'] == self.drop_button[item]['text']:
                            skip_num += 1
                    if first_tag:
                        self.drop_button[first_tag]['bg'] = "light green"
                        self.drop_button[last_tag]['bg'] = "light green"
                else:
                    for item in list(self.drop_button)[self.enter_position_num:]:
                        if self.enter_position_num == item:
                            continue
                        if self.drop_button[self.enter_position_num]['text'].replace("<", "</") == \
                                self.drop_button[item]['text']:
                            if skip_num:
                                skip_num -= 1
                                continue
                            first_tag = self.enter_position_num
                            last_tag = item
                            break
                        elif self.drop_button[self.enter_position_num]['text'] == self.drop_button[item]['text']:
                            skip_num += 1
                    if first_tag:
                        self.drop_button[first_tag]['bg'] = "light green"
                        self.drop_button[last_tag]['bg'] = "light green"
            # else:
            #     if self.drop_button[self.enter_position_num]['bg'] == "#ff0000": #ff0000, #f90000
            #         self.drop_button[self.enter_position_num]['bg'] = "cyan"
            #     elif self.drop_button[self.enter_position_num]['bg'] == "#f90000":
            #         self.drop_button[self.enter_position_num]['bg'] = "pink"

        def select_action_button(position_num=self.position_number):
            if self.drop_button[position_num]['bg'] == "cyan":
                self.drop_button[position_num]['bg'] = "#ffff06"
                self.selected_action.append(position_num)
            elif self.drop_button[position_num]['bg'] == "#ffff06":
                self.drop_button[position_num]['bg'] = "cyan"
                self.selected_action.remove(position_num)
            elif self.drop_button[position_num]['bg'] == "pink":
                self.drop_button[position_num]['bg'] = "#ffff00"
                self.selected_action.append(position_num)
            elif self.drop_button[position_num]['bg'] == "#ffff00":
                self.drop_button[position_num]['bg'] = "pink"
                self.selected_action.remove(position_num)

        self.drop_button[self.position_number] = Button(self.view_drop_message_frame, text=text,
                                                        font=('arial', 7, 'bold'), command=select_action_button,
                                                        bg=bg_color)
        self.drop_button[self.position_number].place(x=self.x_position, y=self.y_position)
        self.drop_button[self.position_number].bind("<Button-3>", self.do_popup)
        self.drop_button[self.position_number].bind('<Enter>', enter_action_button)
        self.drop_button[self.position_number].bind('<Leave>', leave_action_button)

        self.x_position = self.x_position + self.drop_button[self.position_number].winfo_reqwidth()
        self.position_number += 1
        if 750 < self.x_position:
            self.x_position = 0
            self.y_position += 22

        self.popup = Menu(self.view_drop_message_frame, tearoff=0)
        self.popup.add_command(label="  Delete ", command=delete_selected_pop_message)

    def drop_all_items_in_frame(self, event="", delete_item=False, text="no item"):
        text_item = text
        bg_color = "gray"
        if not delete_item:
            if event:
                text_item = event.data

        if text_item:
            if text_item.find("<") == 0:
                if self.selected_action:
                    self.selected_action.sort()
                    new_text = text_item.split(",")
                    new_text_2 = []
                    for item in self.selected_action:
                        if self.drop_button[item]['text'][0] == "<":
                            self.selected_action.clear()
                            break
                        new_text_2.append(self.drop_button[item]['text'])
                    new_text_2.append(new_text[1])
                    new_text_2.insert(0, new_text[0])

                    self.position_number = self.selected_action[0]
                    # self.x_position = self.x_position - self.drop_button[self.position_number].winfo_reqwidth()
                    self.x_position = int(self.drop_button[self.position_number].place_info().get("x"))
                    self.y_position = int(self.drop_button[self.position_number].place_info().get("y"))
                    for item in self.drop_button:
                        if self.selected_action[-1] < item:
                            new_text_2.append(self.drop_button[item]['text'])
                            self.drop_button[item].destroy()
                        elif self.selected_action[0] <= item:
                            self.drop_button[item].destroy()
                    self.selected_action.clear()
                    for item in new_text_2:
                        self.create_button_message(text=item)


            elif delete_item:
                first_tag = 0
                last_tag = 0
                if self.drop_button[self.position_number]['text'][0] == "<":
                    skip_num = 0
                    if self.drop_button[self.position_number]['text'][1] == "/":
                        for item in list(self.drop_button)[self.position_number-1::-1]:
                            if self.position_number == item:
                                continue
                            if self.drop_button[self.position_number]['text'].replace("/", "") == self.drop_button[item]['text']:
                                if skip_num:
                                    skip_num -= 1
                                    continue
                                first_tag = item
                                last_tag = self.position_number
                                break
                            elif self.drop_button[self.position_number]['text'] == self.drop_button[item]['text']:
                                skip_num += 1
                    else:
                        for item in list(self.drop_button)[self.position_number:]:
                            if self.position_number == item:
                                continue
                            if self.drop_button[self.position_number]['text'].replace("<", "</") == self.drop_button[item]['text']:
                                if skip_num:
                                    skip_num -= 1
                                    continue
                                first_tag = self.position_number
                                last_tag = item
                                break
                            elif self.drop_button[self.position_number]['text'] == self.drop_button[item]['text']:
                                skip_num += 1

                    self.x_position = 0
                    self.y_position = 0
                    self.position_number = 1
                    self.drop_button[first_tag].destroy()
                    self.drop_button[last_tag].destroy()
                    self.drop_button.pop(first_tag)
                    self.drop_button.pop(last_tag)
                    tem_list_drop = []
                    for item in self.drop_button: # delete loop
                        tem_list_drop.append(self.drop_button[item]['text'])
                        self.drop_button[item].destroy()

                    self.drop_button.clear()
                    # for item in list(self.drop_button):  # delete loop
                    for item in tem_list_drop:  # delete loop
                        self.create_button_message(text=item)

                else:
                    # self.x_position = self.x_position - self.drop_button[self.position_number].winfo_reqwidth()
                    self.x_position = int(self.drop_button[self.position_number].place_info().get("x"))
                    self.y_position = int(self.drop_button[self.position_number].place_info().get("y"))
                    last_value = 0
                    for item in self.drop_button: # delete loop
                        try:
                            if self.position_number <= item:
                                name_action = self.drop_button[item + 1]['text']
                                self.drop_button[item].destroy()
                                self.create_button_message(text=name_action)
                        except KeyError:
                            self.drop_button[item].destroy()
                            last_value = item
                    if last_value:
                        self.drop_button.pop(last_value)
            else:
                # self.selected_action.clear()
                self.create_button_message(text=text_item)
    def fix_treeview_selected_details(self, event):
        self.column_number = self.table_for_fixed_mess.identify_column(event.x)  ### with #1,#2,#3,....
        self.row_ID = self.table_for_fixed_mess.focus()  ### I001, I002, I003, ........
        self.item_data = self.table_for_fixed_mess.item(self.row_ID)
        self.item_text_value = self.item_data.get("values")
        print(self.item_text_value, "yoooo")
        # self.second_column_number = int(self.column_number[1]) - 1
        # self.colum_box = self.table_for_fixed_mess.bbox(self.row_ID, self.column_number)

    def new_and_edit(self, formate="", title=""):
        if self.file_formate:
            file_type = ""
            dst_path = ""
            if self.file_formate == "MA":
                file_type = "MP3"
                # dst_path = "sqlData/audio/"
                dst_path = File_Path().Audio_Path
            elif self.file_formate == "MT":
                file_type = "TXT"
                # dst_path = "sqlData/txt/"
                dst_path = File_Path().TEXT_Path
            elif self.file_formate == "MV":
                file_type = "MP4"
                # dst_path = "sqlData/video/"
                dst_path = File_Path().VIDEO_Path
            elif self.file_formate == "MI":
                file_type = "jpg"
                # dst_path = "sqlData/Image/"
                dst_path = File_Path().IMAGE_Path
            self.top1 = Toplevel()
            self.top1.title(title)
            self.top1.geometry("900x320+400+150")
            ############################## style for combobox ##################################
            z = tkinter.ttk.Style(self.top1)
            z.theme_use('clam')
            z.configure('Treeview.Heading', background="light gray")

            self.import_message_main_frame = Frame(self.top1, relief=RIDGE, background='light gray', bd=4)
            self.import_message_main_frame.place(x=0, y=0, height=320, width=900)

            import_message_top_frame = Frame(self.import_message_main_frame, relief=RIDGE, background='light gray',
                                             bd=4)
            import_message_top_frame.place(x=10, y=10, height=100, width=530)

            message_name_label = Label(import_message_top_frame, text='Message Name',
                                       font=('times new roman', 13, "bold"), background='light gray', fg="Black", bd=4)
            message_name_label.place(x=10, y=10)

            self.message_name_entry = Entry(import_message_top_frame, font=('times new roman', 15, 'bold'))
            self.message_name_entry.place(x=150, y=10, width=350)

            description_label = Label(import_message_top_frame, text='Description',
                                      font=('times new roman', 13, "bold"), background='light gray', fg="Black", bd=4)
            description_label.place(x=10, y=50)

            self.description_entry = Entry(import_message_top_frame, font=('times new roman', 15, 'bold'))
            self.description_entry.place(x=150, y=50, width=350)

            import_message_bottom_frame = Frame(self.import_message_main_frame, relief=RIDGE, background='light gray',
                                                bd=4)
            import_message_bottom_frame.place(x=10, y=115, height=160, width=530)

            source_file_label = Label(import_message_bottom_frame, text='Source File',
                                      font=('times new roman', 13, "bold"), background='light gray', fg="Black", bd=4)
            source_file_label.place(x=10, y=10)

            self.source_file_entry = Entry(import_message_bottom_frame, font=('times new roman', 15, 'bold'))
            # self.source_file_entry.place(x=150, y=10, width=300)
            self.source_file_entry1 = Entry(import_message_bottom_frame, font=('times new roman', 15, 'bold'))
            self.source_file_entry1.place(x=150, y=10, width=300)

            language_label = Label(import_message_bottom_frame, text='Language', font=('times new roman', 13, "bold"),
                                   background='light gray', fg="Black", bd=4)
            language_label.place(x=10, y=80)
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            self.list_language_combo = []
            for i in root.findall("ImsLanguages"):
                it = i.find("Code").text
                self.list_language_combo.append(it)
            self.language_combobox = tkinter.ttk.Combobox(import_message_bottom_frame, font=("arial", 9, 'bold'),
                                                          height=15, width=30)
            self.language_combobox.set("")
            self.language_combobox["values"] = self.list_language_combo
            self.language_combobox.place(x=150, y=85)

            self.import_message_right_frame = Frame(self.import_message_main_frame, relief=RIDGE,
                                                    background='light gray',
                                                    bd=4)
            self.import_message_right_frame.place(x=550, y=10, height=291, width=331)

            Import_log_label = Label(self.import_message_right_frame, text='Import Log :',
                                     font=('times new roman', 17, "bold"), background='light gray', fg="Black", bd=4)
            Import_log_label.place(x=10, y=10)

            self.import_log_main_frame = Frame(self.import_message_right_frame)
            self.import_log_main_frame.place(x=20, y=45, height=220, width=290)

            ################################### play audio trigger table #############################
            self.play_audio_trreview_frame = Frame(self.import_log_main_frame)
            self.play_audio_trreview_frame.place(x=0, y=0, height=220, width=290)
            self.scroll_y = Scrollbar(self.play_audio_trreview_frame, orient=VERTICAL)
            self.import_message_play_treeview = tkinter.ttk.Treeview(self.play_audio_trreview_frame, columns="trigg",
                                                                     yscrollcommand=self.scroll_y.set)
            self.scroll_y.pack(side=RIGHT, fill=Y)
            self.scroll_y.config(command=self.import_message_play_treeview.yview)
            self.import_message_play_treeview.heading("trigg", text="Combined Trigger")
            self.import_message_play_treeview.pack(fill=BOTH, expand=1)
            self.import_message_play_treeview["show"] = ""

            def play_audio_focus_data(event):
                self.file_view_frame = Frame(self.import_log_main_frame)
                self.file_view_frame.place(x=0, y=0, height=220, width=290)

                cursor_row = self.import_message_play_treeview.focus()
                content = self.import_message_play_treeview.item(cursor_row)
                data = content["values"]
                # dst_path = File path
                if file_type == "TXT":
                    open_file = open(f"{dst_path}{data[0]}", encoding="utf-8")
                    self.view_file = tk.Text(self.file_view_frame, height=14, width=36)
                    self.view_file.place(x=0, y=0)
                    self.view_file.insert('1.0', f"\n\n{open_file.read()}")

                elif file_type == "MP3":
                    play_audio_in_logo = Label(self.file_view_frame, font=('arial', 28, "bold"), fg='black',
                                               text="🔈",
                                               bg='light gray')
                    play_audio_in_logo.place(x=40, y=50)

                    play_audio_in_logo1 = Label(self.file_view_frame, font=('arial', 12, "bold"), fg='black',
                                                text=f":- {data[0]}", bg='light gray')
                    play_audio_in_logo1.place(x=90, y=60)
                    pygame.mixer.init()
                    pygame.mixer.music.load(f"{dst_path}{data[0]}")
                    print(f"{dst_path}{data[0]}", "fffffffffffffffffff")
                    # pygame.mixer.music.load("sqlData\\audio\\MA0006EN.MP3")
                    pygame.mixer.music.play(loops=0)
                    # pygame.mixer.music.unload()
                elif file_type == "MP4":
                    self.label_frame_video = LabelFrame(self.file_view_frame, text="Video Play")
                    self.label_frame_video.place(x=0, y=20, height=200, width=290)
                    self.vid = TkinterVideo(master=self.label_frame_video)
                    self.vid.load(f"{dst_path}{data[0]}")
                    self.vid.pack(expand=True, fill="both")
                    self.vid.play()
                elif file_type == "JPG":
                    pass

                def cancel_file():
                    if file_type == "MP3":
                        pygame.mixer.music.unload()
                    elif file_type == "JPG":
                        pass
                    self.file_view_frame.destroy()

                self.cancel_button_text = tk.Button(self.file_view_frame, text="X", bg="red",
                                                    cursor="arrow", command=cancel_file)
                self.cancel_button_text.place(x=269, y=2)

            self.import_message_play_treeview.bind("<ButtonRelease>", play_audio_focus_data)

            def final_save_file(title=''):
                if self.message_name_entry.get() == "" or self.description_entry.get() == "":
                    messagebox.showerror("Error", f"All filed are required", parent=self.top1)
                else:
                    if title == "Edit": # file_type = (MP3, MP4, JPG, Etc)
                        self.sql_data(
                            f"UPDATE tbl_file SET fileDescription='{self.description_entry.get()}' WHERE fileName='{self.message_name_entry.get()}'")
                        self.sql_data(
                            f"UPDATE messageA SET description='{self.description_entry.get()}' WHERE name='{self.message_name_entry.get()}'")
                        self.table_for_fixed_mess.set(self.row_ID, column=self.column_number, value=self.description_entry.get())
                        self.top1.destroy()
                    elif title == "ADD NEW":
                        data_name = self.sql_data(sql_query=f"select description from messageA where description=='{self.description_entry.get()}'")
                        print(data_name)
                        if data_name:
                            messagebox.showerror("Error", f"Data already exists: ''{data_name[0][0]}'' \n To save the Description. Please change the Description name", parent=self.top1)
                            # self.pop_message(text=f"Data already exists: {data_name}")
                            print(f"Data already exists: {data_name}")
                        else:
                            # print("yooooo")
                            self.sql_data(f"insert into tbl_file values('{file_type}','{self.message_name_entry.get()}','{self.description_entry.get()}')")
                            self.sql_data(f"insert into [messageA] values('{self.message_name_entry.get()}','{self.description_entry.get()}')")
                            self.table_for_fixed_mess.insert("", END, values=[self.description_entry.get(), self.message_name_entry.get()])
                            self.top1.destroy()


            select_file_button = tk.Button(import_message_bottom_frame, text="Select", font=('arial', 10, 'bold'),
                                           bg="#7C7CFC", fg="white", command=lambda: self.select_file(file_type=file_type))
            select_file_button.place(x=460, y=10)

            done_button = Button(self.import_message_main_frame, text="Done", font=('arial', 10, 'bold'), width=12,
                                 height=1, bg="#7C7CFC", fg="white", command=lambda: final_save_file(title=title))
            done_button.place(x=426, y=279)

            view_log_button = Button(import_message_bottom_frame, text="Upload", font=('arial', 10, 'bold'),
                                     width=12, height=1, bg="#7C7CFC", fg="white", command=lambda: self.copy_past_and_delete_files(event="upload", file_type=file_type, dst=dst_path))
            view_log_button.place(x=410, y=120)

            if title == "ADD NEW":
                # done_button.configure(command=lambda: None)
                data = self.sql_data(f"SELECT name from messageA where name like'%{self.file_formate}%' order by name desc limit 1")
                plus_number = f"{self.file_formate}0001"
                if data:
                    number = int(data[0][0].replace(self.file_formate, "")) + 1
                    number_len = 4 - len(str(number))
                    plus_number = f"{self.file_formate}{'0'*number_len}{number}"
                self.message_name_entry.insert(0, plus_number)
                self.message_name_entry.configure(state=DISABLED)
                number_of_item = self.sql_data(
                    f"SELECT messageName FROM fileImport WHERE FullFileName = '{plus_number}'")
                # print("\u26A0") == # ⚠
                for item_name in number_of_item:
                    path_check = glob.glob(f'{dst_path}{item_name[0]}', recursive=True)  # check file exist or not
                    if path_check:
                        self.import_message_play_treeview.insert("", END, values=item_name[0])
                    else:
                        self.import_message_play_treeview.insert("", END, values=item_name[0] + "\u26A0")

            elif title == "Edit":
                for selected_item in self.table_for_fixed_mess.selection():
                    item = self.table_for_fixed_mess.item(selected_item)
                    selected_item_fix = item['values']
                    self.top1.title(selected_item_fix[0])
                    self.description_entry.insert(0, selected_item_fix[0])
                    self.message_name_entry.insert(0, selected_item_fix[1])
                    self.message_name_entry.configure(state=DISABLED)
                    number_of_item = self.sql_data(f"SELECT messageName FROM fileImport WHERE FullFileName = '{selected_item_fix[1]}'")
                    # print("\u26A0") == # ⚠
                    for item_name in number_of_item:
                        path_check = glob.glob(f'{dst_path}{item_name[0]}', recursive=True) # check file exist or not
                        if path_check:
                            self.import_message_play_treeview.insert("", END, values=item_name[0])
                        else:
                            self.import_message_play_treeview.insert("", END, values=item_name[0]+"\u26A0")


            self.top1.mainloop()
        else:
            self.pop_message(text="No Device Selected")

    def select_file(self, file_type=""):
        if file_type:
            filetypes = (('mp4 files', f'*.{file_type}'), ('All files', '*.*'))
            filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top1)
            self.source_file_entry.delete(0, END)
            self.source_file_entry1.delete(0, END)
            self.source_file_entry.insert(0, filename)
            self.source_file_entry1.insert(0, os.path.basename(filename))


    def copy_past_and_delete_files(self, dst='', event="", file_type=""):
        if event == "upload":
            dst_path = f'{dst}{self.message_name_entry.get()}{self.language_combobox.get()}.{file_type}'
            scr = self.source_file_entry.get()
            shutil.copy(scr, dst_path)
            find_file_in_fileImport = self.sql_data(f"SELECT messageName FROM fileImport WHERE messageName = '{self.message_name_entry.get()}{self.language_combobox.get()}.{file_type}'")
            if not find_file_in_fileImport:
                self.sql_data(f"insert into fileImport values('{self.message_name_entry.get()}', '{self.message_name_entry.get()}{self.language_combobox.get()}.{file_type}')")
                self.import_message_play_treeview.insert("", END, values=f'{self.message_name_entry.get()}{self.language_combobox.get()}.{file_type}')
            # self.import_message_play_treeview.delete(*self.import_message_play_treeview.get_children())


        elif event == "delete":
            pass

    def pop_message(self, text=""):
        messagebox.showerror("Error", text, parent=self.top)


    def audio_radio_button_select(self):
        pass
    def text_radio_button_select(self):
        pass
    def video_radio_button_select(self):
        pass
    def banner_radio_button_select(self):
        pass

    def save_data_in_sql(self):
        list_for_message_description = []
        for item in self.drop_button.values():
            list_for_message_description.append(item['text'])
        # print("wwwwwwwwwwwwwww", self.drop_button)
        # print("vvvvvvvvvvvvvvvvv", list_for_message_description)
        for item in list_for_message_description:
            if item[0] == "[":
                item_name = item[1:-1:]
                description_name = self.sql_data(f"SELECT [name] FROM [messageA] where [description]='{item_name}'")
                if len(description_name) != 0:
                    list_for_message_description[
                        list_for_message_description.index(item)] = f"[{description_name[0][0]}]"
        message_Description_text = "".join(list_for_message_description)
        self.sql_data(
            f"UPDATE tbl_action SET message_Description = '{message_Description_text}' WHERE action_ID = {self.action_ID}")
        self.on_exit()

    def delete_all_message_tbl_sql(self):
        print(self.item_text_value, "1111111111")
        id_type = self.item_text_value[1][0:2]
        print(id_type)
        data = self.sql_data(
            f"SELECT name from messageA where name like'%{id_type}%' order by name desc limit 1")
        print("data", data)
        if data:
            if data[0][0] == self.item_text_value[1]:
                self.sql_data(f"delete from messageA where description='{self.item_text_value[0]}' and name='{self.item_text_value[1]}'")
                self.sql_data(f"delete from tbl_file where fileDescription='{self.item_text_value[0]}' and fileName='{self.item_text_value[1]}'")
                self.table_for_fixed_mess.delete(self.row_ID)
                # print("delete")
            else:
                # print("change")
                self.sql_data(f"update messageA set description='Empty_data' where name='{self.item_text_value[1]}'")
                self.sql_data(f"update tbl_file set fileDescription='Empty_data' where fileName='{self.item_text_value[1]}'")
                self.table_for_fixed_mess.set(self.row_ID, column=self.column_number, value="Empty_data")

    def view_all_action_with_field(self):
        # self.action_view_frame
        self.view_toplevel = Toplevel()
        self.view_toplevel.title("title")
        self.view_toplevel.geometry("600x400+400+150")
        self.view_toplevel.overrideredirect(1)

        Button(self.view_toplevel, text="X", font=('arial', 8, 'bold'), width=0,
               bg="red", command=lambda: self.view_toplevel.destroy()).place(x=582, y=0)
        action_view_LabelFrame = LabelFrame(self.view_toplevel, relief=RIDGE, bd=4)
        action_view_LabelFrame.place(x=0, y=25, height=375, width=600)
        self.size_width = 1920
        self.size_height = 1200
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("resource"):
            resource_name = i.find("name").text
            if resource_name.upper() == self.resource.upper():
                resource_display_resolution = i.find("display_resolution").text
                if resource_display_resolution:
                    self.size_width = int(resource_display_resolution.split("x")[0])
                    self.size_height = int(resource_display_resolution.split("x")[1])

        dis_for_elements = {"full": []}
        tag_name = "full"
        if self.drop_button:
            print("self.drop_button", self.drop_button.values())
            # text = ""
            for item in self.drop_button.values():
                # print(item)
                if item["text"][1] == "/":
                    tag_name = "full"
                elif item["text"][0] == "<":
                    tag_name = item["text"]
                    dis_for_elements[tag_name] = []
                elif item["text"][0] == "[":
                    dis_for_elements[tag_name].append(item["text"])
        print("dis_for_elements", dis_for_elements)
        # self.num_counter_frame = 0
        self.field_size_frame = {}
        def size_frame(x_h=0, y_w=0, x_v=0, y_v=0, field_name=""):
            # self.num_counter_frame += 1
            # print("x_h ,y_w ,x_v ,y_v ,field_name ===== ", self.num_counter_frame)
            scale_x_width = (int(x_h) * 100 / self.size_width) * (591 / 100)
            scale_x_height = (int(y_w) * 100 / self.size_height) * (366 / 100)

            scale_x_place = (int(x_v) * 100 / self.size_width) * (591 / 100)
            scale_y_place = (int(y_v) * 100 / self.size_height) * (366 / 100)

            self.field_size_frame[field_name] = LabelFrame(action_view_LabelFrame, background="sky blue", bd=1, relief=RAISED)
            self.field_size_frame[field_name].place(y=int(scale_y_place), x=int(scale_x_place),
                                                    height=int(scale_x_height), width=int(scale_x_width))
            # if field_name == "full":
            if "full" in self.field_size_frame:
                # print("ooooooooooooooooooooooooooooooo")
                self.field_size_frame["full"].lift()
            file_name_list = dis_for_elements[field_name]
            # print("file_name_list", file_name_list)
            lbl = tk.Label(self.field_size_frame[field_name], font='Bell 15 bold', bg="sky blue", wraplength=int(scale_x_width))
            # lbl.pack(expand=True, fill="both")
            # print(file_name_list, "kkkkkk")


            # def animate_label(n=0): # variable 𝑛 that can be either 0 or -1. If 𝑛 is -1, it means to stop the loop. If 𝑛 is 0, the loop keeps running.
            #     print(file_name_list)
            #     lbl.after(3000, animate_label, 1)
            #     pass


            def animate_label(n=0): # variable 𝑛 that can be either 0 or -1. If 𝑛 is -1, it means to stop the loop. If 𝑛 is 0, the loop keeps running.
                # print(file_name_list, "hhhhh")
                # print(n)
                if n == len(file_name_list) - 1:
                    find_file = self.sql_data(f"select name from messageA where description='{file_name_list[n].replace('[', '').replace(']', '')}'")
                    if find_file:
                        file_formate_2 = self.sql_data(
                            f"select messageName from fileImport where FullFileName='{find_file[0][0]}'")
                        if file_formate_2:
                            file_formate_1 = file_formate_2[0][0]
                            # print("find_file", file_formate_1)
                            if file_formate_1[:2] == "MA":
                                # dst_path = "sqlData/audio/"
                                dst_path = File_Path().Audio_Path
                                lbl.pack(expand=True, fill="both")
                                lbl.after(3000, animate_label, 0)
                            elif file_formate_1[:2] == "MT":
                                # dst_path = "sqlData/txt/"
                                dst_path = File_Path().TEXT_Path
                                open_file = open(f"{dst_path}{file_formate_1}", encoding="utf-8")
                                # lbl['text'] = file_name_list[n].replace("[", "").replace("]", "")
                                lbl['text'] = open_file.read()
                                lbl.pack(expand=True, fill="both")
                                lbl.after(3000, animate_label, 0)
                            elif file_formate_1[:2] == "MV":
                                # lbl['text'] = file_name_list[n].replace("[", "").replace("]", "")
                                lbl.pack_forget()
                                self.vid = TkinterVideo(master=self.field_size_frame[field_name])
                                # self.vid.load(f"sqlData/video/{file_formate_1}")
                                self.vid.load(f"{File_Path().VIDEO_Path}{file_formate_1}")
                                self.vid.pack(expand=True, fill="both")
                                self.vid.lift()
                                self.vid.play()
                                # print(self.vid.winfo_y())
                                # print("video222222", file_formate_1, x_h, y_w, x_v, y_v, field_name)
                                lbl.after(0, animate_label, -1)
                            elif file_formate_1[:2] == "MI":
                                # dst_path = "sqlData/Image/"
                                dst_path = File_Path().IMAGE_Path
                                lbl.pack(expand=True, fill="both")
                                lbl.after(3000, animate_label, 0)
                elif n == -1:
                    # print("nooooo")
                    pass

                else:
                    find_file = self.sql_data(f"select name from messageA where description='{file_name_list[n].replace('[', '').replace(']', '')}'")
                    if find_file:
                        file_formate_2 = self.sql_data(
                            f"select messageName from fileImport where FullFileName='{find_file[0][0]}'")
                        if file_formate_2:
                            file_formate_1 = file_formate_2[0][0]
                            # print("find_file", file_formate_1)
                            if file_formate_1[:2] == "MA":
                                # dst_path = "sqlData/audio/"
                                dst_path = File_Path().Audio_Path
                                lbl.pack(expand=True, fill="both")
                                lbl.after(3000, animate_label, n + 1)
                            elif file_formate_1[:2] == "MT":
                                # dst_path = "sqlData/txt/"
                                dst_path = File_Path().TEXT_Path
                                open_file = open(f"{dst_path}{file_formate_1}", encoding="utf-8")
                                # lbl['text'] = file_name_list[n].replace("[", "").replace("]", "")
                                lbl.pack(expand=True, fill="both")
                                lbl['text'] = open_file.read()
                                lbl.after(3000, animate_label, n + 1)
                            elif file_formate_1[:2] == "MV":
                                # lbl['text'] = file_name_list[n].replace("[", "").replace("]", "")
                                lbl.pack_forget()
                                self.vid = TkinterVideo(master=self.field_size_frame[field_name])
                                # self.vid.load(f"sqlData/video/{file_formate_1}")
                                self.vid.load(f"{File_Path().VIDEO_Path}{file_formate_1}")
                                self.vid.pack(expand=True, fill="both")
                                self.vid.play()
                                # print("video", file_formate_1, x_h, y_w, x_v, y_v, field_name)
                                lbl.after(0, animate_label, -1)
                            elif file_formate_1[:2] == "MI":
                                # dst_path = "sqlData/Image/"
                                dst_path = File_Path().IMAGE_Path
                                lbl.pack(expand=True, fill="both")
                                lbl.after(3000, animate_label, n + 1)
            self.view_toplevel.after(1, animate_label)
            # self.view_toplevel.after(1, animate_label)

        for item in dis_for_elements.keys():
            # print(item,"item")
            if len(dis_for_elements[item]):
                field_position = self.sql_data(f"select * from tbl_field where field_name='{item.replace('<','').replace('>','')}'")
                # print(field_position)
                if field_position:
                    # self.int_values_for_resource_group # device id
                    print("nooooooo", item, field_position[0][3], field_position[0][2])
                    size_frame(x_h=int(field_position[0][2]), y_w=int(field_position[0][3]), x_v=int(field_position[0][4]), y_v=int(field_position[0][5]), field_name=item)
                else:
                    print("yppppppp", item, self.size_height, self.size_width)
                    size_frame(x_h=int(self.size_width), y_w=int(self.size_height), x_v=0, y_v=0, field_name=item)
                # elif item == 'full':
                #     len_file = len(dis_for_elements["full"])
                #     print(len_file, "len_file")
                #     if len_file:
                #         size_frame(x_h=int(self.size_width), y_w=int(self.size_height), x_v=0, y_v=0, field_name=item)
                # else: # full screen
                #     pass
        # print(self.drop_button.values())
        message_show_entry = Entry(self.view_toplevel, font=('times new roman', 13, 'bold'), relief=RIDGE)
        message_show_entry.place(x=2, y=2, width=579)
        text = ""
        for item in self.drop_button.values():
            text = text+item['text']
        message_show_entry.insert(0, text)
        message_show_entry.configure(state=DISABLED)


        self.view_toplevel.mainloop()

    def play_and_animate_label(self):
        pass

    def on_exit(self):
        self.top.destroy()
        trigger1.MainApplication5()


class MainApplication_trigger(tk.Frame):
    def __init__(self, parent3):
        tk.Frame.__init__(self)

    @staticmethod
    def num_of_combo_available_global_actionMess_data():
        global num_of_combo_available_global_actionMess
        return num_of_combo_available_global_actionMess

if __name__ == "__main__":
    MainApplication6()
