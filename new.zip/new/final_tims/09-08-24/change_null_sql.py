# import sys
#
# import tkinter as tk
# from tkinter import ttk
# import tkinterDnD
#
# root = tkinterDnD.Tk()
# root.title("tkinterDnD example")
# root.geometry("600x480")
# y = 1
# stringvar = tk.StringVar()
# stringvar.set('Drop here or drag from here!')
# button_dict = {}
# def entry_update(text):
#     lent = len(button_dict)
#     global y
#     if y == 1:
#         button_dict[text].config(bg="yellow")
#         y = 0
#     else:
#         button_dict[text].config(bg="red")
#         y = 1
#
#
# def add(event):
#     print(event.data)
#     global y
#     lenth = len(button_dict)
#     stringvar.set(event.data)
#     x = stringvar.get()
#     lent = len(button_dict)
#
#
#     def func(i = x):
#         # print(button_dict.keys())
#         return entry_update(i)
#     button_dict[stringvar.get()] = tk.Button(text_box1, text=stringvar.get(), command=func)
#     button_dict1 = tk.Button(text_box1, text="/"+stringvar.get(), command=func)
#     if y == 0:
#         old = list(button_dict)[lent-1]
#         new = list(button_dict)[lent - 1]
#         button_dict[old].place(x=lenth*75, y=70)
#         button_dict1.place(x=lenth*75+75, y=70)
#         button_dict[stringvar.get()].place(x=lenth*75-75, y=70)
#     else:
#         button_dict[stringvar.get()].place(x=lenth * 75, y=70)
# def drop(event):
#     print(event.data, 111111111111111)
#     stringvar.set(event.data)
#     text_box.insert(tk.END, stringvar.get())
#
# def drag_command(event):
#     for selected_item in tree.selection():
#         item = tree.item(selected_item)
#         record = item['values']
#     return (tkinterDnD.COPY, "DND_Text", record[0])
#
# text_box = tk.Text(root, height = 5, width = 52)
# text_box1 = tk.LabelFrame(root, height = 150, width = 602, bd=5, bg="gray")
# text_box.register_drop_target("*")
# text_box1.register_drop_target("*")
# # text_box.register_drag_source("*")
# text_box.grid(row=1, column=0, sticky='nsew')
#
# # text_box.bind("<<Drop>>", drop)
# text_box.bind("<<Drop>>", add)
# text_box1.bind("<<Drop>>", add)
# # text_box.bind("<<DragInitCmd>>", drag_command)
#
# columns = ('first_name', 'last_name', 'email')
#
# tree = ttk.Treeview(root, columns=columns, show='headings')
#
# # define headings
# tree.heading('first_name', text='First Name')
# tree.heading('last_name', text='Last Name')
# tree.heading('email', text='Email')
#
# # generate sample data
# contacts = []
# for n in range(1, 100):
#     contacts.append((f'first {n}', f'last {n}', f'email{n}@example.com'))
#
# # add data to the treeview
# for contact in contacts:
#     tree.insert('', tk.END, values=contact)
#
#
# # def item_selected(event):
# #     for selected_item in tree.selection():
# #         item = tree.item(selected_item)
# #         record = item['values']
# #         # show a message
# #         print(record[0])
#
#
# # tree.bind('<<TreeviewSelect>>', item_selected)
#
# tree.grid(row=2, column=0, sticky='nsew')
# # tree.register_drop_target("*")
# tree.register_drag_source("*")
# # tree.bind("<<Drop>>", drop)
# tree.bind("<<DragInitCmd>>", drag_command)
# # add a scroll_bar
# scrollbar = ttk.Scrollbar(root, orient=tk.VERTICAL, command=tree.yview)
# tree.configure(yscroll=scrollbar.set)
# scrollbar.grid(row=2, column=1, sticky='ns')
# text_box1.place(x=0, y=320)
# root.mainloop()


# a = "अम्बत्तुर"
# hex = a.encode("utf-8").hex(sep="_")
# print(hex.replace("e0_a4", "_"))


# hex_value = ''.join([format(ord(char), 'x') for char in a])
# print(hex_value)
# dist_i = {"N3": [(4, None, None, 1, None, 1, 'MR,HI,EN'), (8, None, None, 0, None, 1, 'MR,HI,EN'), (11, None, None, 0, None, 1, 'MR,HI,EN'), (13, None, None, 1, None, 1, 'MR,HI,EN'), (18, None, None, 1, None, 1, 'MR,HI,EN'), (19, None, None, 0, None, 1, 'MR,HI,EN'), (22, None, None, 2, None, 1, 'MR,HI,EN'), (24, None, None, 1, None, 1, 'MR,HI,EN'), (26, None, None, 0, None, 1, 'MR,HI,EN'), (27, None, None, 1, None, 1, 'MR,HI,EN'), (28, None, None, 1, None, 1, 'MR,HI,EN'), (29, None, None, 0, None, 1, 'MR,HI,EN'), (30, None, None, 2, None, 1, 'MR,HI,EN'), (31, None, None, 2, None, 1, 'MR,HI,EN'), (32, None, None, 0, None, 1, 'MR,HI,EN'), (33, None, None, 2, None, 1, 'MR,HI,EN'), (35, None, None, 2, None, 1, 'MR,HI,EN'), (37, None, None, 0, None, 1, 'MR,HI,EN'), (41, None, None, 1, None, 1, 'MR,HI,EN'), (42, None, None, 1, None, 1, 'MR,HI,EN'), (45, None, None, 0, None, 3, 'MR,HI,EN'), (46, None, None, 2, None, 1, 'MR,HI,EN'), (47, None, None, 2, None, 1, 'MR,HI,EN'), (48, None, None, 2, None, 1, 'MR,HI,EN'), (49, None, None, 2, None, 1, 'MR,HI,EN'), (50, None, None, 2, None, 1, 'MR,HI,EN'), (51, None, None, 2, None, 1, 'MR,HI,EN'), (52, None, None, 1, None, 1, 'MR,HI,EN'), (53, None, None, 2, None, 1, 'MR,HI,EN'), (54, None, None, 1, None, 1, 'MR,HI,EN'), (55, None, None, 3, None, 1, 'MR,HI,EN'), (56, None, None, 1, None, 1, 'MR,HI,EN'), (57, None, None, 2, None, 1, 'MR,HI,EN'), (58, None, None, 1, None, 1, 'MR,HI,EN'), (59, None, None, 1, None, 1, 'MR,HI,EN'), (60, None, None, 3, None, 1, 'MR,HI,EN'), (61, None, None, 3, None, 1, 'MR,HI,EN')], "N2": [(4, None, None, 1, None, 1, 'MR,HI,EN'), (8, None, None, 0, None, 1, 'MR,HI,EN'), (11, None, None, 0, None, 1, 'MR,HI,EN'), (13, None, None, 1, None, 1, 'MR,HI,EN'), (18, None, None, 1, None, 1, 'MR,HI,EN')]}
# for i in dist_i.keys():
#     for j in dist_i[i]:
#         print(j)
#     print("***************************")


# import pyodbc
# conn = pyodbc.connect(driver='{SQL Server}', dsn="tts_ims_data.MDF, TrustServerCertificate=yes")
# cursor = conn.cursor()
# print("yoo")
#
# import pandas as pd
# import pyodbc
#
# cnxn_str = (
#     r'DRIVER={ODBC Driver 17 for SQL Server};'
#     r'SERVER=LP-ABHAY-PTC;'
#     r'TrustServerCertificate=yes;'
#     r'AttachDbFileName=tts_ims_data.MDF;'
# )
# cnxn = pyodbc.connect(cnxn_str)
# df = pd.read_sql("SELECT * FROM Table1", cnxn)


# import sqlite3
#
# conn1 = sqlite3.connect("triggers_abhay.db")
# my_cursor = conn1.cursor()
# # my_cursor.execute(f"select distance from tbl_stationDistance where stationID1={self.data_tree[i - 1][2]} and stationID2={self.data_tree[i][2]}")
# # my_cursor.execute(f"UPDATE tbl_routeStops SET [distanceFromPrev] = {distance_entry.get()} WHERE [stationID] = {self.data1[3]}")
# my_cursor.execute(f"select * from tbl_routes order by routeID")
# route_data = my_cursor.fetchall()
# for route_id, name_route in route_data:
#     my_cursor.execute(f"select stationID, stopOrder from tbl_routeStops where routeID={route_id} order by stopOrder")
#     route_stop_data = my_cursor.fetchall()
#     print(name_route)
#     old_num = 0
#     for stationID_data, stopOrder_data in route_stop_data:
#         if old_num > 0:
#             my_cursor.execute(
#                 f"select distance from tbl_stationDistance where stationID1={old_num} and stationID2={stationID_data}")
#             distance_data = my_cursor.fetchall()
#             if distance_data:
#                 print("distance_data", distance_data[0][0])
#
#
#                 my_cursor.execute(
#                     f"UPDATE tbl_routeStops SET [distanceFromPrev] = {distance_data[0][0]} WHERE [stationID] = {stationID_data} and routeID={route_id} and stopOrder={stopOrder_data}")
#
#             else:
#                 my_cursor.execute(
#                     f"select distance from tbl_stationDistance where stationID1={stationID_data} and stationID2={old_num}")
#                 distance_data2 = my_cursor.fetchall()
#                 if distance_data2:
#                    print("distance_data ####################", distance_data2[0][0], stationID_data, stopOrder_data)
#
#
#                    my_cursor.execute(
#                      f"UPDATE tbl_routeStops SET [distanceFromPrev] = {distance_data2[0][0]} WHERE [stationID] = {stationID_data} and routeID={route_id} and stopOrder={stopOrder_data}")
#
#
#             old_num = stationID_data
#
#         else:
#             old_num = stationID_data
#             print("First Station = ", stationID_data)
#
# conn1.commit()
# conn1.close()


# import sqlite3
# conn = sqlite3.connect("triggers_abhay.db")
# cursor = conn.cursor()
# query = "update do_this_combi_item set IntervalUnit = 'second(s)' WHERE IntervalUnit='NULL'"
# cursor.execute(query)
# query = "update do_this_combi_item set actionDelay = 0 WHERE actionDelay='NULL'"
# cursor.execute(query)
# # actionRepetitionInterval
#
# query = "update do_this_combi_item set actionRepetitionInterval = 0 WHERE actionRepetitionInterval='NULL'"
# cursor.execute(query)
#
# query = "update tbl_action set message_Description = '' WHERE message_Description='NULL'"
# cursor.execute(query)
#
#
# query = "update do_this_combi_item set actionRepetitionCount = 0 WHERE actionRepetitionCount='NULL'"
# cursor.execute(query)
# query = "update tbl_journeyStops set arrivalTime = '00:00', depactureTime= '00:00', conditional='-None-', platformNum='' WHERE arrivalTime='NULL' "
# cursor.execute(query)
#
# query = "update tbl_journeyStops set arrivalTime = '00:00', depactureTime= '00:00', conditional='-None-', platformNum='' WHERE depactureTime='NULL' "
# cursor.execute(query)
#
# query = "update tbl_journeyStops set languageArea='MR,HI,EN' WHERE languageArea='NULL' "
# cursor.execute(query)
# query = "update tbl_journeys set handicapCar=0 WHERE handicapCar='NULL' "
# cursor.execute(query)
# query = "update tbl_journeys set departure='' WHERE departure='NULL' "
# cursor.execute(query)
#
# query = "update tbl_journeys set serviceType='Slow' WHERE serviceType='NULL' "
# cursor.execute(query)
#
# query = "update tbl_journeys set condition='-None-' WHERE condition='NULL' "
# cursor.execute(query)
# query = "update tbl_routeStops set distanceFromPrev=0.0 WHERE distanceFromPrev='NULL' "
# cursor.execute(query)
#
# query = "update tbl_trigger set eventType='' WHERE eventType='NULL' "
# cursor.execute(query)
# query = "update tbl_trigger set do_this_combi_ID=0 WHERE do_this_combi_ID='NULL' "
# cursor.execute(query)
# query = "update tbl_trigger set eventValue='' WHERE eventValue='NULL' "
# cursor.execute(query)
# query = "update tbl_trigger set conditional='' WHERE conditional='NULL' "
# cursor.execute(query)
# query = "update tbl_trigger set do_this_combi_ID=0 WHERE triggerID=43 "
# cursor.execute(query)
# conn.commit()
# conn.close()



# cursor.execute(f"SELECT stationName from tbl_journeyStops")

#
# # cursor.execute(f"SELECT do_this_combi_ID, actionOrder, action_ID_int from do_this_combi_item")
# # data = cursor.fetchall()
# # for do_this_combi_ID, actionOrder, action_ID_int in data:
# #     # print(i[0])
# #     cursor.execute(f"SELECT action_Name, resource_ID  from tbl_action where action_ID='{action_ID_int}'")
# #     data2 = cursor.fetchall()
# #     # print(i[0], data2[0][0])
# #     print(data2)
# #     query = f"update do_this_combi_item set actionId='{data2[0][0]}', resource_name='{data2[0][1]}' WHERE do_this_combi_ID={do_this_combi_ID} and actionOrder={actionOrder}"
# #     cursor.execute(query)
#
#
#
# # cursor.execute(f"SELECT  action_ID_int, do_this_combi_ID FROM [do_this_combi_item] order by [do_this_combi_ID] and [ActionOrder]")
# # id_num = 47
# # cursor.execute(f"update do_this_combi_item set action_ID_int=76 WHERE ActionOrder=1 and do_this_combi_ID={id_num}")
# # cursor.execute(f"update do_this_combi_item set action_ID_int=77 WHERE ActionOrder=2 and do_this_combi_ID={id_num}")
# # cursor.execute(f"update do_this_combi_item set action_ID_int=78 WHERE ActionOrder=3 and do_this_combi_ID={id_num}")
# # cursor.execute(f"update do_this_combi_item set action_ID_int=20 WHERE ActionOrder=4 and do_this_combi_ID={id_num}")
# # cursor.execute(f"update do_this_combi_item set action_ID_int=41 WHERE ActionOrder=5 and do_this_combi_ID={id_num}")
# # cursor.execute(f"update do_this_combi_item set action_ID_int=43 WHERE ActionOrder=6 and do_this_combi_ID={id_num}")
# # cursor.execute(f"update do_this_combi_item set action_ID_int=69 WHERE ActionOrder=7 and do_this_combi_ID={id_num}")
# # # cursor.execute(f"update do_this_combi_item set ActionOrder=3 WHERE action_ID_int=20 and do_this_combi_ID={id_num}")
# # cursor.execute(f"SELECT  action_ID_int, do_this_combi_ID, ActionOrder FROM [do_this_combi_item] order by [do_this_combi_ID] , [ActionOrder]")
# # rows = cursor.fetchall()
# # print(rows)
# cursor.execute(query)
# conn.commit()
# conn.close()
# print("Done")
# import pyodbc
# import sqlite3
# conn = pyodbc.connect(
#             'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=abhay;Trusted_Connection=yes;')
# my_cursor = conn.cursor()
# my_cursor.execute(f'''select * from [tbl_combiActionItems] order by combiActionID ,actionOrder''')
#
# tbl_combiActionItems_data = my_cursor.fetchall()
# old = 0
# num = 1
# for combiActionID, actionID, actionOrder, actionDelay, actionRepetitionCount, actionRepetitionInterval, intervalUnit in tbl_combiActionItems_data:
#     if combiActionID == -1:
#         continue
#     print(combiActionID, actionID, actionOrder, actionDelay, actionRepetitionCount, actionRepetitionInterval, intervalUnit)
#     new_num = combiActionID
#     if old != new_num:
#         old = new_num
#         num = 1
#     # actionID_id_name = self.action_ID_name[actionID]
#     # save_tbl_combiActionItems_Items = combiActionID, actionID_id_name[
#     #     0], actionDelay if actionDelay else 0, 0 if not actionRepetitionCount else actionRepetitionCount.replace(" ",
#     #                                                                                                              ""), 0 if not actionRepetitionInterval else actionRepetitionInterval, "second(s)" if not intervalUnit else intervalUnit, actionOrder, 0, actionID, \
#     # actionID_id_name[1]
#     # print(save_tbl_combiActionItems_Items)
#
#     conn_sqlite = sqlite3.connect("triggers_abhay.db")
#     my_cursor_sqlite = conn_sqlite.cursor()
#     my_cursor_sqlite.execute(f"insert into do_this_combi_item values(?,?,?,?,?,?,?,?,?,?)", (
#         combiActionID, "em", actionDelay if actionDelay else 0,
#         0 if not actionRepetitionCount else actionRepetitionCount.replace(" ", ""),
#         0 if not actionRepetitionInterval else actionRepetitionInterval,
#         "second(s)" if not intervalUnit else intervalUnit, num, 0, actionID, "actionID_id_name[1]"))
#     conn_sqlite.commit()
#     num += 1
#     conn_sqlite.close()


# import os
# import sqlite3
# conn = sqlite3.connect("triggers_abhay.db")
# cursor = conn.cursor()
# # cursor.execute(f"update tbl_station set isLanguageBorder=0 WHERE isLanguageBorder='False'")
#
# cursor.execute(f"SELECT  stationID, stationNr, defaultLanguageArea FROM tbl_station")
# station_rows = cursor.fetchall()
# for stationID, stationNr, defaultLanguageArea in station_rows:
#     stationNr_new = int(stationNr[2:])
#     hex_name = hex(stationNr_new).replace("0x", "")
#     len_hex = len(hex_name)
#     fix_len = 4 - len_hex
#     print(stationNr, f"ST{'0'*fix_len}{hex_name.upper()}")
#     final_nr = f"ST{'0'*fix_len}{hex_name.upper()}"
#     cursor.execute(f"update tbl_station set stationNr='{final_nr}' WHERE stationID={stationID}")
#     list_lang = defaultLanguageArea.split(",")
#     # list_lang = ["EN", "HI"]
#     for lang in list_lang:
#         secend_final_nr = f"ST{'0'*fix_len}{hex_name.upper()}{lang}.MP3"
#         old_stationNr = f"{stationNr}{lang}.MP3"
#         print(secend_final_nr, old_stationNr)
#         cursor.execute(f"update tbl_stationNames set stationNameAudio='{secend_final_nr}' WHERE stationID={stationID} and stationNameAudio='{old_stationNr}'")
#         try:
#            os.rename(f'sqlData/audio/{old_stationNr}', f'sqlData/audio/{secend_final_nr}')
#         except FileNotFoundError:
#             continue
#
#     conn.commit()
# conn.close()
