import tkinter.ttk
from tkinter import *
import shutil
import pyodbc
from tkinter import messagebox
import main
import tkinter as tk
from pathlib import Path
from tkinter import filedialog as fd
import xml.etree.ElementTree as ET
import os
import sqlite3


# Define the class the application
class MainApplication1:
    # init method or constructor that call by instance variable
    def __init__(self):
        # tk.Tk is crate a window
        self.field = tk.Tk()
        # write a field title name line
        self.field.title('Station')
        # self.size_width = 1920
        # self.size_height = 360
        # print(for_loop)
        # window frame geometry size (width,height,x-place,y-place)
        self.field.geometry("1230x600+30+20")
        self.field.iconbitmap("logo2.ico")
        # the background colour change by config
        self.field.configure(bg="lightsteelblue2")
        self.field.protocol("WM_DELETE_WINDOW", self.on_exit)
        # self.field.grab_set()
        # Allowing root window to not change it's size according to user's need
        # self.field.resizable(False, False)
        # Fixing the size of the root window No one can now expand the size of the root window than the specified one.
        # self.field.maxsize(1100, 600)
        # self.field.minsize(1100, 600)
        self.var_station_name = StringVar()
        self.s = tkinter.ttk.Style(self.field)
        self.s.theme_use('clam')
        self.size_width = 0
        self.size_height = 0
        def size_width_height(w=228, h=16):
            self.size_width = w
            self.size_height = h
            range_loop = self.size_width
            if self.size_height > self.size_width:
                range_loop = self.size_height
            # for_loop_y = 1000 / self.size_width
            # for_loop_x = 383 / self.size_height
        plus = 140
        screen_size_display = Label(self.field, bg="lightsteelblue2", font=("Courier", 14), text="Display Resolution : ")
        screen_size_display.place(x=60+plus, y=5)

        screen_size_display1 = Label(self.field, bg="lightsteelblue2", font=("Arial", 10, "bold"), text="X")
        screen_size_display1.place(x=420+plus, y=10)


        self.width_entry = Entry(self.field, relief=SUNKEN, font=('arial', 9))
        # self.width_entry.place(x=290+plus, y=9, height=25, width=125)
        self.width_entry.place(x=440+plus, y=9, height=25, width=125)

        self.height_entry = Entry(self.field, relief=SUNKEN, font=('arial', 9))
        # self.height_entry.place(x=440+plus, y=9, height=25, width=125)
        self.height_entry.place(x=290+plus, y=9, height=25, width=125)

        Change_Resolution = Button(self.field, text="Change Resolution", font=('arial', 8, 'bold'), bg="#7C7CFC",
                                   fg="white", command=lambda: size_width_height(w=int(self.width_entry.get()), h=int(self.height_entry.get())))
        Change_Resolution.place(x=580+plus, y=9)

        self.upper_field_frame = LabelFrame(self.field, relief=SUNKEN, height=383, width=1004)
        self.upper_field_frame.place(x=60+plus, y=60)
        size_width_height()

        self.width_entry.insert(0, self.size_width)
        self.height_entry.insert(0, self.size_height)

        # a = 0
        # b = 0
        # for i in range(range_loop+1):
        #     separator = tkinter.ttk.Separator(self.upper_field_frame, orient='vertical')
        #     # print(for_loop_x)
        #     separator.place(x=for_loop_y + a, y=-1, height=380)
        #     # if 128 == i:
        #     #     separator.place(x=for_loop + a, y=-1, height=200)
        #
        #     separator = tkinter.ttk.Separator(self.upper_field_frame, orient=HORIZONTAL)
        #     separator.place(x=-1, y=for_loop_x + b, width=1000)
        #     a += for_loop_y
        #     b += for_loop_x


        self.var_width_x = DoubleVar()
        self.var_height_y = DoubleVar()
        self.var_place_x = DoubleVar()
        self.var_place_y = DoubleVar()

        # def show1(e):
        #     parcent_a = self.var_place_x.get()/10
        #     self.value_x = (self.size_width/100)*parcent_a
        #
        #     parcent_b = self.var_place_y.get() / 3.83
        #     self.value_Y = (self.size_height / 100) * parcent_b
        #
        #     frame_x = self.var_width_x.get()/10
        #     self.frame_x1 = (self.size_width/100)*frame_x
        #
        #     frame_y = self.var_height_y.get() / 3.83
        #     self.frame_y1 = (self.size_height / 100) * frame_y
        #     self.field_size_frame.place(y=int(self.var_place_y.get())-5, x=int(self.var_place_x.get()))
        #
        #     self.field_size_frame.config(height=int(self.var_height_y.get()), width=int(self.var_width_x.get()))
        #
        #     sel = "X Height Scale Value = " + str(int(self.frame_x1))
        #     sel1 = "Y Wight Scale Value = " + str(int(self.frame_y1))
        #     sel3 = "  X Scale Value = " + str(int(self.value_x))
        #     sel4 = "  Y Scale Value = " + str(int(self.value_Y))
        #     l1.config(text=f"{sel}, {sel3}")
        #     l2.config(text=f"{sel1}, {sel4}")
        #     l3.config(text=f"(x={int(self.value_x)},    y={int(self.value_Y)},     x'={int(self.value_x)+int(self.frame_x1)}    y'={int(self.value_Y)+int(self.frame_y1)})")


        self.width_scale_x = tkinter.ttk.Scale(self.field, variable=self.var_width_x, from_=0, to=1001, orient=HORIZONTAL, length=1002)
        self.width_scale_x.place(x=60+plus, y=445)
        self.height_scale_y = tkinter.ttk.Scale(self.field, variable=self.var_height_y, from_=0, to=383, orient=VERTICAL, length=382)
        self.height_scale_y.place(x=45+plus, y=60)
        self.x_place = tkinter.ttk.Scale(self.field, variable=self.var_place_x, from_=0, to=1001, orient=HORIZONTAL, length=1002)
        self.x_place.place(x=60+plus, y=45)
        self.y_place = tkinter.ttk.Scale(self.field, variable=self.var_place_y, from_=0, to=383, orient=VERTICAL, length=382)
        self.y_place.place(x=1064+plus, y=60)
        # self.y_place.set(value=200)
        self.width_scale_x.bind('<Motion>', self.show1)
        self.height_scale_y.bind('<Motion>', self.show1)
        self.x_place.bind('<Motion>', self.show1)
        self.y_place.bind('<Motion>', self.show1)

        # b1 = Button(self.field, text="Display Horizontal", command=show1, bg="yellow")
        # b1.place(x=10, y=450)

        self.l1 = Label(self.field, bg="lightsteelblue2", font=("Courier", 14))
        self.l1.place(x=10, y=500)
        self.l2 = Label(self.field, bg="lightsteelblue2", font=("Courier", 14))
        self.l2.place(x=10, y=530)

        self.l3 = Label(self.field, bg="lightsteelblue2", font=("Courier", 14))
        self.l3.place(x=10, y=560)

        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()

        self.field_size_frame = LabelFrame(self.upper_field_frame, background="yellow", bd=4, relief=RAISED)
        self.field_size_frame.place(x=0, y=40)

        self.field_table_frame = tk.Frame(self.field)
        self.field_table_frame.place(x=10, y=45, height=415, width=160)

        self.display_type_xml = tkinter.ttk.Combobox(self.field, font=("arial", 9, 'bold'), width=20)
        self.display_type_xml.place(x=10, y=23)
        self.display_type_xml.set("Select Display Type")
        dist_for_combo = {}
        for i in root.findall("resource"):
            it = i.find("group").text
            if it == "1":
                field_name = i.find("name").text
                # list_for_combo.append(field_name)
                field_value = i.find("value").text
                dist_for_combo[field_name] = field_value
        self.display_type_xml["value"] = [lis_name for lis_name in dist_for_combo.keys()]

        # self.display_type_xml.bind("<<ComboboxSelected>>", self.Insert_data_left_journey_treeview)

        self.scroll_y = tk.Scrollbar(self.field_table_frame, orient=VERTICAL)
        self.field_table = tkinter.ttk.Treeview(self.field_table_frame, columns="Stat", yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.field_table.heading("Stat", text="Station")
        self.field_table.column("Stat", width=130)
        self.field_table.pack(fill=BOTH, expand=1)
        self.field_table["show"] = "headings"
        self.scroll_y.configure(command=self.field_table.yview)
        self.field_table.bind("<ButtonRelease>", self.get_database)
        def tree_data_insert():
            self.field_table.delete(*self.field_table.get_children())
            for i in root.findall("markupCode"):
                it = i.find("group").text
                if it == "1":
                    field_name = i.find("name").text
                    if field_name.count("field"):
                        self.field_table.insert("", END, values=field_name)

        tree_data_insert()
        save = Button(self.field, text="SAVE", font=('arial', 8, 'bold'), bg="#7C7CFC", fg="white",
                      command=self.database)
        save.place(x=950 + plus, y=565)
        self.field.mainloop()

    def show1(self, e=""):
        parcent_a = self.var_place_x.get() / 10
        self.value_x = (self.size_width / 100) * parcent_a

        parcent_b = self.var_place_y.get() / 3.83
        self.value_Y = (self.size_height / 100) * parcent_b

        frame_x = self.var_width_x.get() / 10
        self.frame_x1 = (self.size_width / 100) * frame_x

        frame_y = self.var_height_y.get() / 3.83
        self.frame_y1 = (self.size_height / 100) * frame_y
        self.field_size_frame.place(y=int(self.var_place_y.get()) - 5, x=int(self.var_place_x.get()),
                                    height=int(self.var_height_y.get()), width=int(self.var_width_x.get()))
        print(int(self.var_height_y.get()), int(self.var_width_x.get()), "hhhhhhh")
        # self.field_size_frame.config(height=int(self.var_height_y.get()), width=int(self.var_width_x.get()))

        sel = "X Height Scale Value = " + str(int(self.frame_x1))
        sel1 = "Y Wight Scale Value = " + str(int(self.frame_y1))
        sel3 = "  X Scale Value = " + str(int(self.value_x))
        sel4 = "  Y Scale Value = " + str(int(self.value_Y))
        self.l1.config(text=f"{sel}, {sel3}")
        self.l2.config(text=f"{sel1}, {sel4}")
        self.l3.config(
            text=f"(x={int(self.value_x)},    y={int(self.value_Y)},     x'={int(self.value_x) + int(self.frame_x1)}    y'={int(self.value_Y) + int(self.frame_y1)})")

    def database(self):
        self.cursor_row = self.field_table.focus()
        self.content = self.field_table.item(self.cursor_row)
        self.field_name_tbl = self.content["values"]
        print(self.field_name_tbl)

        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f"select * from tbl_field where CONVERT(VARCHAR, [field]) ='{self.field_name_tbl[0]}'")
        data = my_cursor.fetchall()
        if data:
            my_cursor.execute(f'''UPDATE [tbl_field] SET [x_height] = {int(self.frame_x1)}
                                    ,[y_width] = {str(int(self.frame_y1))}
                                    ,[x_value] = {int(self.value_x)}
                                    ,[y_value] = {int(self.value_Y)}
                                    ,[display_type] = '{self.display_type_xml.get()}'
                                    ,[field] = '{self.field_name_tbl[0]}'
                                    ,[display_resolution] = '{f"{self.width_entry.get()}X{self.height_entry.get()}"}'
                                    ,[x_y_X_Y] = '{f"({int(self.value_x)}, {int(self.value_Y)}, {int(self.value_x) + int(self.frame_x1)}, {int(self.value_Y) + int(self.frame_y1)})"}'
                                 where CONVERT(VARCHAR, [field]) ='{self.field_name_tbl[0]}' ''')
        else:
            my_cursor.execute(f'''insert into tbl_field ([x_height],[y_width],[x_value],[y_value],[display_type],[field],
                    [display_resolution],[x_y_X_Y]) VALUES({int(self.frame_x1)},{str(int(self.frame_y1))},{int(self.value_x)},
                    {int(self.value_Y)},'{self.display_type_xml.get()}', '{self.field_name_tbl[0]}', '{f"{self.width_entry.get()}X{self.height_entry.get()}"}',
                    '{f"({int(self.value_x)}, {int(self.value_Y)}, {int(self.value_x) + int(self.frame_x1)}, {int(self.value_Y) + int(self.frame_y1)})"}'
                    )''')



        # conn = pyodbc.connect(
        #     'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        # my_cursor = conn.cursor()
        # my_cursor.execute(f'''insert into tbl_field ([x_height],[y_width],[x_value],[y_value],[display_type],[field],
        # [display_resolution],[x_y_X_Y]) VALUES({int(self.frame_x1)},{str(int(self.frame_y1))},{int(self.value_x)},
        # {int(self.value_Y)},'{self.display_type_xml.get()}', '{self.field_name_tbl[0]}', '{f"{self.width_entry.get()}X{self.height_entry.get()}"}',
        # '{f"({int(self.value_x)}, {int(self.value_Y)}, {int(self.value_x) + int(self.frame_x1)}, {int(self.value_Y) + int(self.frame_y1)})"}'
        # )''')
        conn.commit()
        conn.close()
    def get_database(self, event=""):
        self.cursor_row = self.field_table.focus()
        self.content = self.field_table.item(self.cursor_row)
        self.field_name_tbl = self.content["values"]

        # print(int(self.var_width_x.get()), int(self.var_height_y.get()), int(self.var_place_x.get()), int(self.var_place_y.get()))
        # print(self.field_name_tbl)

        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f"select * from tbl_field where CONVERT(VARCHAR, [field]) ='{self.field_name_tbl[0]}'")
        data = my_cursor.fetchall()
        print(data)
        if data:
            scale_x_width = (int(data[0][0]) * 100 / self.size_width) * (1001 / 100)
            scale_x_height = (int(data[0][1]) * 100 / self.size_height) * (383 / 100)

            scale_x_place = (int(data[0][2]) * 100 / self.size_width) * (1001 / 100)
            scale_y_place = (int(data[0][3]) * 100 / self.size_height) * (383 / 100)

            self.width_scale_x.set(value=int(scale_x_width)+1)
            self.height_scale_y.set(value=int(scale_x_height)+1)
            self.x_place.set(value=int(scale_x_place)+1)
            self.y_place.set(value=int(scale_y_place)+1)
            # self.show1()
        else:
            self.width_scale_x.set(value=0)
            self.height_scale_y.set(value=0)
            self.x_place.set(value=0)
            self.y_place.set(value=0)
            # self.field_size_frame.place_forget()
            # self.show1()

        # conn.commit()
        self.show1()
        conn.close()
    def on_exit(self):
        self.field.destroy()
        # main.MainApplication()


if __name__ == "__main__":
    MainApplication1()
