from tkinter import *
import tkinter.ttk
from tkinter import messagebox
import pyodbc
import tkinter as tk
import ActionMess
import trigger
from ActionMess import MainApplication6
import xml.etree.ElementTree as ET
import sqlite3

global_var = ["a"]
global_var1 = ["a"]
global_var_action_ID = [0]

num_of_combo_available_global = 1

class MainApplication5:
    def __init__(self):
        # tk.Frame.__init__(self)
        self.top1 = tk.Tk()
        self.top1.title("Trigger")
        self.top1.geometry("1200x620+70+0")
        self.top1.resizable(False, False)
        self.top1.iconbitmap("logo2.ico")
        self.top1.protocol("WM_DELETE_WINDOW", self.on_exit)

        data_trigger = ActionMess.MainApplication_trigger(tk.Frame)
        data_trigger_value = data_trigger.num_of_combo_available_global_actionMess_data()
        ############################## style for combobox ##################################
        y = tkinter.ttk.Style(self.top1)
        y.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        y.configure('Treeview.Heading', background="darkseagreen")

        ################################ main trigger frame #########################################
        self.trigger_main_frame = Frame(self.top1, relief=RIDGE, background='snow2', bd=4)
        self.trigger_main_frame.place(x=0, y=0, height=620, width=1200)

        ##################################### Available frame #####################################
        self.available_frame = Frame(self.top1, self.trigger_main_frame, width=1190, height=80, relief=RIDGE, background='snow2', bd=4)
        self.available_frame.place(x=5, y=4)

        #################################### available combobox list ####################################
        self.Available_combobox_trigger_list = tkinter.ttk.Combobox(self.available_frame, font=("arial", 13, 'bold'), width=20)
        self.Available_combobox_trigger_list.place(x=30, y=8)
        self.Available_combobox_trigger_value = False
        self.do_combobox_trigger_list_value = True
        self.num_of_combo_available = data_trigger_value
        if data_trigger_value > 1:
            self.Available_combobox_trigger_value = True
        self.show_data_if_available_trigger_treeview()
        self.Available_combobox_trigger_list.bind("<<ComboboxSelected>>", self.available_combo_select)


        ###################################### available entry box enable disable function #################################
        def available_entry_enable_disable():
            self.available_trigger_entry_name.delete(0, END)
            self.available_trigger_entry_priority.delete(0, END)
                
        ###########################################  available button new & delete ###########################        
        self.available_trigger_button_new = Button(self.available_frame, text="New", font=('arial', 9, 'bold'), width=5, height=1,
                                                   bg="#7C7CFC", fg="white", command=available_entry_enable_disable)
        self.available_trigger_button_new.place(x=270, y=6)

        self.available_trigger_button_delete = Button(self.available_frame, text="Delete", font=('arial', 9, 'bold'), width=5, height=1,
                                                      bg="#7C7CFC", fg="white", command=self.delete_available_list)
        self.available_trigger_button_delete.place(x=370, y=6)
        
        ########################################### available name ###############################################
        self.available_trigger_label_name = Label(self.available_frame, font=('arial', 11, 'bold'), text="Name : ", bg="snow2")
        self.available_trigger_label_name.place(x=30, y=45)
        
        self.var_available_trigger_entry_name = StringVar()
        self.available_trigger_entry_name = Entry(self.available_frame, font=('arial', 11, 'bold'), width=24, textvariable=self.var_available_trigger_entry_name)
        self.available_trigger_entry_name.place(x=120, y=45)
        self.available_trigger_entry_name.bind("<Return>", self.insert_data_available_combobox)
        
        ########################################### available priority #######################################################
        self.available_trigger_label_priority = Label(self.available_frame, font=('arial', 11, 'bold'), text="Priority : ", bg="snow2")
        self.available_trigger_label_priority.place(x=370, y=45)
        
        self.var_available_trigger_entry_priority = StringVar()
        self.available_trigger_entry_priority = Entry(self.available_frame, font=('arial', 11, 'bold'), width=24, textvariable=self.var_available_trigger_entry_priority)
        self.available_trigger_entry_priority.place(x=460, y=45)
        self.available_trigger_entry_priority.bind("<Return>", self.insert_data_available_combobox)

        ##################################### frame IF Trigger box #################################################
        ##################################### main frame if box ####################################################
        self.if_trigger_main_frame = LabelFrame(self.trigger_main_frame, relief=RIDGE, text='IF ', bg='snow2',
                                                font=('times new roman', 13, "bold"), fg="red", bd=3)
        self.if_trigger_main_frame.place(x=3, y=76, height=200, width=600)
        
        ##################################### if main frame in inner frame ##########################################
        self.if_trigger_main_inner_frame = LabelFrame(self.if_trigger_main_frame, relief=RIDGE, font=('times new roman', 13, "bold"), fg="blue", bd=3)
        self.if_trigger_main_inner_frame.place(x=2, y=0, height=175, width=590)

        self.if_trigger_scroll_y = tk.Scrollbar(self.if_trigger_main_inner_frame, orient=VERTICAL)  #
        self.if_trigger_treeview = tkinter.ttk.Treeview(self.if_trigger_main_inner_frame, columns=("kum", "jaiz"),
                                                        yscrollcommand=self.if_trigger_scroll_y.set, show="headings")
        self.if_trigger_scroll_y.pack(side=RIGHT, fill=Y)
        self.if_trigger_scroll_y.config(command=self.if_trigger_treeview.yview)
        self.if_trigger_treeview.column("kum", width=90, minwidth=0, stretch=True, anchor='c')
        self.if_trigger_treeview.column("jaiz", width=460, minwidth=0, stretch=True, anchor='c')
        self.if_trigger_treeview.pack()
        self.if_trigger_treeview.bind("<ButtonRelease>", self.if_trigger_treeview_focus_data)
        #################### popup left click in treeview delete button work ######################################
        self.popup = Menu(self.top1, tearoff=0)
        self.popup.add_command(label="Delete", command=self.delete_data_if_treeview_trigger)
        self.if_trigger_treeview.bind("<Button-3>", self.menu_popup)
        self.do_this_cancel_button = []
        self.do_this_save_button = []
        self.show_data_in_position_treeview()
        self.top1.mainloop()


        ###################################### left click then delete treeview data ###############################

    def combobox_triggerID(self):
        self.tbl_trigger_triggerID = dict(self.data_from_tbl_trigger)
        for i in self.tbl_trigger_triggerID:
            if self.tbl_trigger_triggerID[i] == self.Available_combobox_trigger_list.get():
                self.triggerID = i
                return self.triggerID

    def combobox_do_this_combiID(self):
        # self.count_combobox_do_this = self.n.index(self.do_combobox_trigger_list.get()) + 1
        self.tbl_do_this_combi_combiID = dict(self.data_from_do_this_combi)
        for i in self.tbl_do_this_combi_combiID:
            if self.tbl_do_this_combi_combiID[i] == self.do_combobox_trigger_list.get():
                self.combi_ID = i
                return self.combi_ID
    def combobox_actionID(self):
        print(132)
        # self.count_combobox_do_this = self.n.index(self.do_combobox_trigger_list.get()) + 1
        self.tbl_actionID = dict(self.data_tbl_action1)
        # print(self.tbl_actionID, "dfghj")
        for i in self.tbl_actionID:
            if self.tbl_actionID[i] == self.message_combobox_trigger_midd_list.get():
                self.actionID = i
                return self.actionID
    def menu_popup(self, event=""):
        print(105)
        try:
            self.popup.tk_popup(event.x_root, event.y_root, 0)
        finally:
            self.popup.grab_release()

        ####################################### if trigger treeview focus data #########################################
    def if_trigger_treeview_focus_data(self, event=""):
        print(113)
        self.cursor_row4 = self.if_trigger_treeview.focus()
        self.content4 = self.if_trigger_treeview.item(self.cursor_row4)
        self.data4 = self.content4["values"]
    def show_data_in_position_treeview(self): # **for** if treeview
        print(158)
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        print(self.Available_combobox_trigger_value, "llllllll")
        if self.Available_combobox_trigger_value:
            my_cursor.execute(
                f"select triggerID, eventValue, do_this_combi_ID,[conditional],[eventType] from tbl_trigger where triggerID={self.num_of_combo_available}")
            print("111111")
        else:
            print("22222")
            my_cursor.execute("select triggerID, eventValue, do_this_combi_ID,[conditional],[eventType] from tbl_trigger where triggerID=1")
        self.data_position = my_cursor.fetchall()
        print("self.data_position", self.data_position)
        if self.data_position:
            if self.data_from_tbl_trigger:
                # print(self.data_position, "gggggggggggggggg")
                self.data_position1 = self.data_position[0][1]
                # print(self.data_position1, "dfghjhgfdfghjkjhvhjk")
                self.data_position2 = self.data_position1.split(';', 1)
                self.data_position3 = tuple(self.data_position2)
                self.data_position4 = [self.data_position3]
                # new_data_position = self.data_position[0][1]
                # new_data_conditional = self.data_position[0][3]
                new_data_position_if = self.data_position[0][1]
                new_data_conditional_and = self.data_position[0][3]
                event_type = self.data_position[0][4]
                # print(self.data_position4, "oooooooooo", new_data_position, "gggggg", new_data_conditional)
                # if not new_data_position == " ":
                if len(self.data_position) != 0:
                    self.if_trigger_treeview.delete(*self.if_trigger_treeview.get_children())
                    if not (new_data_position_if.find(" ") == 0 or len(new_data_position_if) == 0):
                        remove_brackets = new_data_position_if.replace("[", "").replace("]", "")
                        split_if_data = remove_brackets.split(";")
                        if event_type.upper() == "SPEED":
                            self.if_trigger_treeview.insert("", END, values=list(
                                (split_if_data[0], f"Speed {split_if_data[3]} {split_if_data[1]} {split_if_data[2]}")))
                        else:
                            self.if_trigger_treeview.insert("", END, values=list((split_if_data[0],
                                                                                  f"Position {split_if_data[1]} {split_if_data[2]} {split_if_data[3]}")))
                        # print(new_data_conditional_and.split(","), "ggggggggggggggggggggggg")
                        if not (new_data_conditional_and.find(" ") == 0 or len(new_data_conditional_and) == 0):
                            list_of_and_condition = new_data_conditional_and.split(",")
                            for item_list in list_of_and_condition:
                                remove_brackets_and = item_list.replace("[", "").replace("]", "")
                                split_and_data = remove_brackets_and.split(";")
                                if split_and_data[1].upper() == "SPEED":
                                    self.if_trigger_treeview.insert("", END, values=list((split_and_data[0],
                                                                                          f"Speed {split_and_data[4]} {split_and_data[2]} {split_and_data[3]}")))
                                else:
                                    self.if_trigger_treeview.insert("", END, values=list((split_and_data[0],
                                                                                          f"Position {split_and_data[2]} {split_and_data[3]} {split_and_data[4]}")))

            my_cursor.execute(f"select triggerPrio from tbl_trigger where triggerID={self.data_position[0][0]}")
            data_prio = my_cursor.fetchall()
            self.available_trigger_entry_priority.delete(0, END)
            self.available_trigger_entry_priority.insert(0, data_prio[0][0])
            self.available_trigger_entry_name.delete(0, END)
            self.available_trigger_entry_name.insert(0, self.Available_combobox_trigger_list.get())
            conn.commit()
            conn.close()
        else:
            self.if_trigger_treeview.delete(*self.if_trigger_treeview.get_children())
        self.show_data_in_position_treeview1()



    def show_data_in_position_treeview1(self):
        print(159)
        ##################################### frame Do Trigger ##########################################
        self.do_main_frame_trigger = LabelFrame(self.trigger_main_frame, relief=RIDGE, text='DO ', bg='snow2',
                                                font=('times new roman', 13, "bold"), fg="red", bd=3)
        self.do_main_frame_trigger.place(x=3, y=277, height=333, width=600)

        #################################### combobox do list ####################################                                                        #
        self.do_combobox_trigger_list = tkinter.ttk.Combobox(self.do_main_frame_trigger, font=("arial", 13, 'bold'),
                                                             width=20)
        self.do_combobox_trigger_list.place(x=5, y=2)
        self.do_combobox_trigger_list.bind("<<ComboboxSelected>>", self.insert_data_do_frame1)
        self.do_combobox_trigger_list_condition = True
        # self.show_data_do_combobox_list()

        ################################# do name label & entry ####################################
        do_trigger_label_name = Label(self.do_main_frame_trigger, font=('arial', 11, 'bold'), bg='snow2',
                                      text="Name : ")
        do_trigger_label_name.place(x=10, y=40)
        self.var_available_trigger_entry_name = StringVar()
        self.do_trigger_entry_name = Entry(self.do_main_frame_trigger, font=('arial', 11, 'bold'),
                                           width=24, textvariable=self.var_available_trigger_entry_name)
        self.do_trigger_entry_name.place(x=100, y=42)


        ##################################### inner frame ###########################################
        self.do_trigger_inner_frame = LabelFrame(self.do_main_frame_trigger, relief=RIDGE,
                                                 font=('times new roman', 13, "bold"), bg='snow2',
                                                 fg="blue", bd=3)
        self.do_trigger_inner_frame.place(x=2, y=70, height=200, width=590)

        def insert_data_do_combobox(event=""):
            print(649)
            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            my_cursor.execute(f"select max(do_this_combi_ID) from do_this_combi")
            max_num_id = my_cursor.fetchall()
            # print()
            my_cursor.execute('''SELECT CASE WHEN MAX([do_this_combi_ID]) = COUNT(*)
                        THEN CAST(NULL AS INTEGER)
                        WHEN MIN([do_this_combi_ID]) > 1
                        THEN 1
                        WHEN MAX([do_this_combi_ID]) <> COUNT(*)
                        THEN (SELECT MIN([do_this_combi_ID])+1
                        FROM do_this_combi
                        WHERE ([do_this_combi_ID]+ 1)
                        NOT IN (SELECT [do_this_combi_ID] FROM do_this_combi))
                        ELSE NULL END
                        FROM do_this_combi''')
            missing_num_id = my_cursor.fetchall()
            # print(missing_num_id, "kkkkkkkkkkkkkkkkkkkk")
            if not missing_num_id[0][0]:
                if max_num_id[0][0]:
                    my_cursor.execute(f"insert into do_this_combi values(?,?)",
                                      (int(max_num_id[0][0]) + 1, self.do_trigger_entry_name.get()))
                else:
                    my_cursor.execute(f"insert into do_this_combi values(?,?)",
                                      (1, self.do_trigger_entry_name.get()))

            else:
                my_cursor.execute(f"insert into do_this_combi values(?,?)",
                                  (int(missing_num_id[0][0]), self.do_trigger_entry_name.get()))
            # try:
            #     display_id = len(self.n) + 1
            # except AttributeError:
            #     display_id = 1
            # my_cursor.execute(f"insert into do_this_combi values(?,?)", (display_id, self.do_trigger_entry_name.get()))
            conn.commit()
            conn.close()
            self.show_data_do_combobox_list()
            self.do_trigger_entry_name.delete(0, END)
            # self.do_trigger_entry_name.config(state='disable')

        ############################### do entry box Enable function ################################
        def do_entry_enable():
            self.do_trigger_entry_name.delete(0, END)

        self.do_trigger_entry_name.bind("<Return>", insert_data_do_combobox)

        ############################################### Do Button new delete ###################################################                          #
        do_trigger_button_new = Button(self.do_main_frame_trigger, text="New", font=('arial', 9, 'bold'), width=5,
                                       height=1, bg="#7C7CFC", fg="white", command=do_entry_enable)
        do_trigger_button_new.place(x=240, y=3)

        do_trigger_button_delete = Button(self.do_main_frame_trigger, text="Delete", font=('arial', 9, 'bold'), width=5,
                                          height=1, bg="#7C7CFC", fg="white", command=self.delete_do_combobox_list)
        do_trigger_button_delete.place(x=320, y=3)

        ########################################### scroll bar in (left journey frame) ############################################                       #
        self.do_trigger_scroll_y = tk.Scrollbar(self.do_trigger_inner_frame, orient=VERTICAL)  #
        self.do_trigger_treeview = tkinter.ttk.Treeview(self.do_trigger_inner_frame, columns=("act", "del", "repe", "inter", "un"),
                                                        yscrollcommand=self.do_trigger_scroll_y.set,
                                                        show="headings", height=11)
        self.do_trigger_scroll_y.pack(side=RIGHT, fill=Y)
        self.do_trigger_scroll_y.config(command=self.do_trigger_treeview.yview)
        self.do_trigger_treeview.heading("act", text="Action")
        self.do_trigger_treeview.column("act", width=195, anchor='c')
        self.do_trigger_treeview.heading("del", text="Delay (sec)")
        self.do_trigger_treeview.column("del", width=92, anchor='c')
        self.do_trigger_treeview.heading("repe", text="Repetitions")
        self.do_trigger_treeview.column("repe", width=92, anchor='c')
        self.do_trigger_treeview.heading("inter", text="Interval")
        self.do_trigger_treeview.column("inter", width=92, anchor='c')
        self.do_trigger_treeview.heading("un", text="Unit")
        self.do_trigger_treeview.column("un", width=92, anchor='c')
        self.do_trigger_treeview.pack()
        self.delete_save_undo_button = []
        self.do_trigger_treeview.bind("<ButtonRelease>", self.do_trigger_treeview_focus_data)
        self.show_data_do_combobox_list()

        ############################################### do remove and add button ####################
        do_remove_action_button = Button(self.do_main_frame_trigger, text="Remove Action",
                                         font=('arial', 10, 'bold'), width=12,
                                         height=1, bg="#7C7CFC", fg="white", command=self.remove_do_delete_data)
        do_remove_action_button.place(x=20, y=275)

        do_add_action_button = Button(self.do_main_frame_trigger, text="Add Action", font=('arial', 10, 'bold'),
                                      width=12, height=1,
                                      bg="#7C7CFC", fg="white", command=self.insert_message_data_in_do_treeview)
        do_add_action_button.place(x=150, y=275)

        ##################################### position and speed box main frame #################################
        ##################################### frame right box1 ###################################
        self.trigger_right_up_frame = LabelFrame(self.trigger_main_frame, relief=RIDGE,
                                                 font=('times new roman', 13, "bold"), bg='snow2',
                                                 fg="blue", bd=3)
        self.trigger_right_up_frame.place(x=610, y=85, height=170, width=580)

        #################################### combobox list1 ####################################
        self.combobox_trigger_up_list1 = tkinter.ttk.Combobox(self.trigger_right_up_frame,
                                                              font=("arial", 10, 'bold'), width=15)
        self.combobox_trigger_up_list1.set("Select")
        self.combobox_trigger_up_list1["values"] = ("IF", "AND")
        self.combobox_trigger_up_list1.place(x=5, y=10)

        #################################### combobox list ####################################
        self.combobox_trigger_up_list2 = tkinter.ttk.Combobox(self.trigger_right_up_frame,
                                                              font=("arial", 10, 'bold'),
                                                              width=15)
        self.combobox_trigger_up_list2.set("ChooseEventype")
        self.combobox_trigger_up_list2["values"] = ("LocationIndexed", "Speed")
        self.combobox_trigger_up_list2.place(x=210, y=10)
        self.combobox_trigger_up_list2.bind("<<ComboboxSelected>>", self.add_position_and_speed)
        self.combobox_trigger_up_list2_true_false = False

        self.up_select_combo_data = Frame(self.trigger_right_up_frame, relief=RIDGE, bg='snow2', bd=4)
        self.up_select_combo_data.place(x=5, y=50, height=110, width=564)

        ##################################### frame middle right side ###################################
        self.message_trigger_middle_right_frame = LabelFrame(self.trigger_main_frame, relief=RIDGE, bg='snow2',
                                                             font=('times new roman', 13, "bold"), fg="blue", bd=3)
        self.message_trigger_middle_right_frame.place(x=610, y=265, height=210, width=580)

        self.message_trigger_combobox_destination = tkinter.ttk.Combobox(self.message_trigger_middle_right_frame,
                                                                         font=('arial', 11, 'bold'), width=22)  #
        self.message_trigger_combobox_destination.place(x=100, y=70)


        resource = ET.parse("projectinfo.xml")
        root = resource.getroot()
        resource_list = []
        resource_list.clear()
        for i in root.findall("resource"):
            resource_name = i.find("name").text
            resource_list.append(resource_name)
            # print(resource_name)
            # self.trigger_audio_table2.insert("", END, values=it)

        self.message_trigger_combobox_destination["values"] = resource_list
        # self.message_trigger_combobox_destination["values"] = (
        #     "Front display left", "Front display right", "Interior display", "Interior Loudspeaker", "Interior LOGO", "Interior Banner", "Interior Video")
        self.message_trigger_combobox_destination.bind("<Return>", self.insert_data_message_combobox)

        self.var_message_trigger_entry_name = StringVar()
        self.message_trigger_entry_name = Entry(self.message_trigger_middle_right_frame, font=('arial', 11, 'bold'), width=33,
                                                textvariable=self.var_message_trigger_entry_name)
        self.message_trigger_entry_name.place(x=100, y=38)
        self.message_trigger_entry_name.bind("<Return>", self.insert_data_message_combobox)

        self.message_combobox_trigger_midd_list = tkinter.ttk.Combobox(self.message_trigger_middle_right_frame,
                                                                       font=("arial", 10, 'bold'), width=25)
        self.message_combobox_trigger_midd_list.place(x=5, y=5)
        self.message_combobox_trigger_midd_list.bind("<<ComboboxSelected>>", self.on_select)
        self.show_data_display_message_combobox()

        ########################################## Enable disable function message entry ################################
        def enable_message_entry():
            self.message_trigger_entry_name.config(state='normal')
            self.message_trigger_entry_name.delete(0, END)
            self.message_combobox_trigger_midd_list.set('')
            self.message_trigger_combobox_destination.set('')
            self.message_trigger_label.config(text='')
            self.repeat_trigger_entry.delete(0, END)
            self.delay_trigger_entry.delete(0, END)
            self.every_trigger_entry.delete(0, END)




        ################################### message button new & delete ###############################################
        message_trigger_button_new = Button(self.message_trigger_middle_right_frame, text="New",
                                            font=('arial', 9, 'bold'), width=5,
                                            height=1, bg="#7C7CFC", fg="white", command=enable_message_entry)
        message_trigger_button_new.place(x=240, y=3)

        self.message_trigger_button_delete = Button(self.message_trigger_middle_right_frame, text="Delete",
                                                    font=('arial', 9, 'bold'),
                                                    width=5, height=1, bg="#7C7CFC", fg="white",
                                                    command=self.delete_data_message_combobox)
        self.message_trigger_button_delete.place(x=320, y=3)

        ################################### message label name and entry widget #########################################
        message_trigger_label_name = Label(self.message_trigger_middle_right_frame, font=('arial', 11, 'bold'),
                                           bg='snow2', text="Name : ")
        message_trigger_label_name.place(x=10, y=38)

        #####################################   destination label and combobox ###########################################
        message_trigger_label_destination = Label(self.message_trigger_middle_right_frame, bg='snow2',
                                                  font=('arial', 11, 'bold'), text="Dest : ")
        message_trigger_label_destination.place(x=10, y=70)

        ###################################  mess label and frame ##################################
        message_trigger_label_mess = Label(self.message_trigger_middle_right_frame, font=('arial', 11, 'bold'),
                                           bg='snow2', text="Mess : ")
        message_trigger_label_mess.place(x=10, y=102)

        self.mess_trigger_frame = Frame(self.message_trigger_middle_right_frame, relief=RIDGE, bd=4)
        self.mess_trigger_frame.place(x=100, y=102, height=70, width=470)
        self.message_trigger_label = Label(self.mess_trigger_frame, font=('arial', 8), bg='yellow', fg="black", wraplength=450)
        self.message_trigger_label.place(x=3, y=4)
        self.message_trigger_label.bind("<Double-Button-1>", self.double_click_mess)
        self.mess_trigger_frame.bind("<Double-Button-1>", self.double_click_mess)

        message_trigger_label_Flush = Label(self.message_trigger_middle_right_frame, bg='snow2', font=('arial', 11, 'bold'), text="Flush : ")
        message_trigger_label_Flush.place(x=10, y=177)

        ###################### click check button then enable disable button function #################
        def toggle_save_cancel():
            print(328)
            # print(self.check_var.get(), "ggjjj")
            # if message_save_button['state'] == 'disabled' and message_cancel_button['state'] == 'disabled':
            #     message_save_button['state'] = 'normal'
            #     message_cancel_button['state'] = 'normal'
            # else:
            #     message_save_button['state'] = 'disabled'
            #     message_cancel_button['state'] = 'disabled'

        self.check_var = tk.IntVar()
        self.message_trigger_check_buttons = tk.Checkbutton(self.message_trigger_middle_right_frame,
                                                            variable=self.check_var, command=toggle_save_cancel, state=DISABLED)
        self.message_trigger_check_buttons.place(x=70, y=177)

        ######################################################### END #######################################################

        ###################################   frame lower right side ###########################################
        self.right_trigger_lower_frame = LabelFrame(self.trigger_main_frame, relief=RIDGE,
                                                    font=('times new roman', 13, "bold"), bg='snow2',
                                                    fg="blue", bd=3)
        self.right_trigger_lower_frame.place(x=610, y=480, height=130, width=580)

        delay_trigger_label = Label(self.right_trigger_lower_frame, font=('arial', 11, 'bold'), bg='snow2',
                                    text="Delay : ")  #
        delay_trigger_label.place(x=10, y=10)
        vcmd = (self.top1.register(self.validate),
                '%d', '%i', '%P', '%s', '%S', '%v', '%V', '%W')
        self.delay_trigger_entry = Entry(self.right_trigger_lower_frame, font=('arial', 11, 'bold'), width=10, validate='key', validatecommand=vcmd)  #
        self.delay_trigger_entry.place(x=100, y=10)

        sec_trigger_label = Label(self.right_trigger_lower_frame, font=('arial', 11, 'bold'), bg='snow2',
                                  text="sec.")  #
        sec_trigger_label.place(x=200, y=10)
        ##############################################################################################################
        repeat_trigger_label = Label(self.right_trigger_lower_frame, font=('arial', 11, 'bold'), bg='snow2',
                                     text="Repeat : ")  #
        repeat_trigger_label.place(x=10, y=50)
        # only in value

        self.repeat_trigger_entry = tk.Entry(self.right_trigger_lower_frame, font=('arial', 11, 'bold'), width=10, validate='key', validatecommand=vcmd)  #
        self.repeat_trigger_entry.place(x=100, y=50)

        times_trigger_label = Label(self.right_trigger_lower_frame, font=('arial', 11, 'bold'), bg='snow2',
                                    text="times(-1 for infinite)")  #
        times_trigger_label.place(x=200, y=50)
        ###############################################################################################################
        every_trigger_label = Label(self.right_trigger_lower_frame, font=('arial', 11, 'bold'), bg='snow2',
                                    text="Every : ")  #
        every_trigger_label.place(x=10, y=90)

        self.every_trigger_entry = Entry(self.right_trigger_lower_frame, font=('arial', 11, 'bold'), width=10, validate='key', validatecommand=vcmd)  #
        self.every_trigger_entry.place(x=100, y=90)

        #################################### combobox list every ####################################
        self.combobox_trigger_every = tkinter.ttk.Combobox(self.right_trigger_lower_frame,
                                                           font=("arial", 10, 'bold'), width=15)
        self.combobox_trigger_every.set("ChooseTimes")
        self.combobox_trigger_every["values"] = ("second(s)", "minutes(m)")
        self.combobox_trigger_every.place(x=200, y=90)
        self.insert_data_do_frame2()

        ######################################## delete data in if treeview box   ###############################
        ######################################## show data in if trigger text box ###############################
    def available_combo_select(self, event=""):
        global num_of_combo_available_global
        self.Available_combobox_trigger_value = True
        self.num_of_combo_available = self.combobox_triggerID()
        self.show_data_in_position_treeview()
        num_of_combo_available_global = self.num_of_combo_available
        self.insert_data_do_frame2()

    def validate(self, action, index, value_if_allowed,
                       prior_value, text, validation_type, trigger_type, widget_name):
        # action=1 -> insert
        if action == '1':
            if text in '-1023456789.INF':
                try:
                    if text == '-' and index == '0' or text == 'N' or text == 'I' or text == 'F':
                        return True
                    float(value_if_allowed)
                    return True
                except ValueError:
                    return False
            else:
                return False
        else:
            return True

    ###################### show data message combobox midd list #############################################


    def add_position_and_speed(self, event=""):
        print(752)
        if self.combobox_trigger_up_list2_true_false:
            if self.combobox_trigger_up_list2.get() == "Speed":
                self.up_inside_select_combo_position.destroy()
            else:
                self.up_inside_select_combo_speed.destroy()
        self.add_position_and_speed1()

    def add_position_and_speed1(self):
        print(752)
        if self.combobox_trigger_up_list2.get() == "LocationIndexed":
            self.up_inside_select_combo_position = Frame(self.up_select_combo_data, relief=RIDGE)
            self.up_inside_select_combo_position.place(x=0, y=0, height=100, width=555)

            self.position_trigger_midd_label = Label(self.up_inside_select_combo_position, font=('arial', 11, 'bold'), bg='snow2',
                                                     text="Position", justify=LEFT, anchor="sw")
            self.position_trigger_midd_label.pack(fill=X)

            self.position_trigger_midd_entry = Entry(self.up_inside_select_combo_position, font=('arial', 11, 'bold'),
                                                     width=15)
            self.position_trigger_midd_entry.insert(0, "0")
            self.position_trigger_midd_entry.place(x=100, y=38)

            self.position_trigger_meter = Label(self.up_inside_select_combo_position, font=('arial', 11, 'bold'), bg='snow2', text="m")
            self.position_trigger_meter.place(x=240, y=38)

            #################################### combobox list every ####################################
            self.combobox_trigger_position = tkinter.ttk.Combobox(self.up_inside_select_combo_position,
                                                                  font=("arial", 10, 'bold'), width=15)
            self.combobox_trigger_position.set("Select Destination")
            self.combobox_trigger_position["values"] = ("after the station", "before the station", "in the station")
            self.combobox_trigger_position.place(x=100, y=70)



            def insert_position():
                print(780)
                z = self.combobox_trigger_up_list1.get()
                c = self.combobox_trigger_up_list2.get()
                e = self.position_trigger_midd_entry.get()
                if self.position_trigger_midd_entry.get() == "":
                    e = "0"
                p = self.combobox_trigger_position.get()
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                # my_cursor.execute(f"select [conditional] from tbl_trigger WHERE triggerID={self.data_position[0][0]}")
                my_cursor.execute(f"select [eventValue] from tbl_trigger WHERE triggerID={self.data_position[0][0]}")
                event_value = my_cursor.fetchall()
                # print(event_value, "ghghghghghhjhbhjhbfhbhbhbvhfbhbf")
                # if event_value[0][0]:
                if not (event_value[0][0].find(" ") == 0 or len(event_value[0][0]) == 0):
                    my_cursor.execute(
                        f"select [conditional] from tbl_trigger WHERE triggerID={self.data_position[0][0]}")
                    event_value1 = my_cursor.fetchall()
                    # print(event_value1, "hhhh")
                    if not (event_value1[0][0].find(" ") == 0 or len(event_value1[0][0]) == 0):
                        my_cursor.execute(f"UPDATE tbl_trigger SET conditional='{event_value1[0][0]},[And;{c};{e};m;{p}]' WHERE triggerID = {self.data_position[0][0]}")
                    else:
                        my_cursor.execute(f"UPDATE tbl_trigger SET conditional='[And;{c};{e};m;{p}]' WHERE triggerID = {self.data_position[0][0]}")
                else:
                    my_cursor.execute(f"UPDATE tbl_trigger SET eventValue='[if;{e};m;{p}]',eventType='{c}' WHERE triggerID = {self.data_position[0][0]}")
                    # print("noooo")

                conn.commit()
                conn.close()
                self.show_data_in_position_treeview()


            trigger_position_button_new1 = Button(self.up_inside_select_combo_position, text="Ok", font=('arial', 9, 'bold'),
                                                  width=5, height=1, bg="#7C7CFC", fg="white", command=insert_position)
            trigger_position_button_new1.place(x=420, y=70)
            self.combobox_trigger_up_list2_true_false = True

            def cancel_position():
                print(816)
                self.up_inside_select_combo_position.destroy()

            trigger_position_button_new2 = Button(self.up_inside_select_combo_position, text="Cancel", command=cancel_position,
                                                  font=('arial', 9, 'bold'), width=5, height=1, bg="#7C7CFC",
                                                  fg="white")
            trigger_position_button_new2.place(x=500, y=70)

        elif self.combobox_trigger_up_list2.get() == "Speed":
            self.up_inside_select_combo_speed = Frame(self.up_select_combo_data, relief=RIDGE)
            self.up_inside_select_combo_speed.place(x=0, y=0, height=100, width=555)

            self.speed_trigger_midd_label = Label(self.up_inside_select_combo_speed, font=('arial', 11, 'bold'), bg='snow2',
                                                  text="Speed", justify=LEFT, anchor="sw")  #
            self.speed_trigger_midd_label.pack(fill=X)

            self.speed_trigger_midd_entry = Entry(self.up_inside_select_combo_speed, font=('arial', 11, 'bold'),
                                                  width=15)
            self.speed_trigger_midd_entry.insert(0, 0)
            self.speed_trigger_midd_entry.place(x=100, y=38)

            self.speed_trigger_meter = Label(self.up_inside_select_combo_speed, font=('arial', 11, 'bold'), bg='snow2', text="m/s")
            self.speed_trigger_meter.place(x=240, y=38)

            self.combobox_trigger_speed = tkinter.ttk.Combobox(self.up_inside_select_combo_speed, font=("arial", 10, 'bold'), width=15)
            self.combobox_trigger_speed.set(">")
            self.combobox_trigger_speed["values"] = (">", "<")
            self.combobox_trigger_speed.place(x=100, y=70)
            self.combobox_trigger_up_list2_true_false = True


            def insert_speed():
                print(845)
                a = self.combobox_trigger_up_list1.get()
                b = self.combobox_trigger_up_list2.get()
                d = self.combobox_trigger_speed.get()
                c = self.speed_trigger_midd_entry.get()
                if self.speed_trigger_midd_entry.get() == "":
                    c = "0"
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute(f"select [eventValue] from tbl_trigger WHERE triggerID={self.data_position[0][0]}")
                event_value = my_cursor.fetchall()
                # print(event_value, "ghghghghghhjhbhjhbfhbhbhbvhfbhbf")
                # if event_value[0][0]:
                # print(f"a={a}=select", f"b={b}=speed", f"c={c}=entry_box", f"d={d}=>")
                if not (event_value[0][0].find(" ") == 0 or len(event_value[0][0]) == 0):
                    my_cursor.execute(
                        f"select [conditional] from tbl_trigger WHERE triggerID={self.data_position[0][0]}")
                    event_value1 = my_cursor.fetchall()
                    # print(event_value1, "hhhh")
                    if not (event_value1[0][0].find(" ") == 0 or len(event_value1[0][0]) == 0):
                        my_cursor.execute(
                            f"UPDATE tbl_trigger SET conditional='{event_value1[0][0]},[And;{b};{c};m;{d}]' WHERE triggerID = {self.data_position[0][0]}")
                    else:
                        my_cursor.execute(
                            f"UPDATE tbl_trigger SET conditional='[And;{b};{c};m;{d}]' WHERE triggerID = {self.data_position[0][0]}")
                else:
                    my_cursor.execute(
                        f"UPDATE tbl_trigger SET eventValue='[if;{c};m;{d}]',eventType='{b}' WHERE triggerID = {self.data_position[0][0]}")
                    # print("noooo")

                conn.commit()
                conn.close()

                self.show_data_in_position_treeview()

            trigger_speed_button_new1 = Button(self.up_inside_select_combo_speed, text="Ok", font=('arial', 9, 'bold'),
                                               width=5, height=1, bg="#7C7CFC", fg="white", command=insert_speed)  #
            trigger_speed_button_new1.place(x=420, y=70)

            def cancel_speed():
                print(881)
                self.up_inside_select_combo_speed.destroy()
            trigger_speed_button_new2 = Button(self.up_inside_select_combo_speed, text="Cancel", command=cancel_speed,
                                               font=('arial', 9, 'bold'), width=5, height=1, bg="#7C7CFC", fg="white")
            trigger_speed_button_new2.place(x=500, y=70)

#################################################################################################################################################
#########################################################  Insert  ##############################################################################
#################################################################################################################################################

    ########################### insert data with new button in available combobox ############################################
    def insert_data_available_combobox(self, event=""):
        print(914)
        if self.available_trigger_entry_name.get() == "":
            messagebox.showerror("Error", "Fill Name First")
        else:
            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            my_cursor.execute(f"select max(triggerID) from tbl_trigger")
            max_id_num = my_cursor.fetchall()
            my_cursor.execute('''SELECT CASE WHEN MAX([triggerID]) = COUNT(*)
            THEN CAST(NULL AS INTEGER)
            WHEN MIN([triggerID]) > 1
            THEN 1
            WHEN MAX([triggerID]) <> COUNT(*)
            THEN (SELECT MIN([triggerID])+1
            FROM tbl_trigger
            WHERE ([triggerID]+ 1)
            NOT IN (SELECT [triggerID] FROM tbl_trigger))
            ELSE NULL END
            FROM tbl_trigger''')
            missing_num = my_cursor.fetchall()
            # print(missing_num, "dfghjuiuytgfguygiuyghuytf7ytgytf")
            if not missing_num[0][0]:
                if max_id_num[0][0]:
                    my_cursor.execute(f"insert into tbl_trigger values(?,?,?,?,?,?,?)",
                                    (int(max_id_num[0][0]) + 1, self.available_trigger_entry_name.get(),
                                      ' ', self.available_trigger_entry_priority.get(), ' ', ' ', 0))
                else:
                    my_cursor.execute(f"insert into tbl_trigger values(?,?,?,?,?,?,?)",
                                      (1, self.available_trigger_entry_name.get(),
                                       ' ', self.available_trigger_entry_priority.get(), ' ', ' ', 0))
            else:
                my_cursor.execute(f"insert into tbl_trigger values(?,?,?,?,?,?,?)",
                                  (int(missing_num[0][0]), self.available_trigger_entry_name.get(),
                                   ' ', self.available_trigger_entry_priority.get(), ' ', ' ', 0))

            conn.commit()
            conn.close()
            self.show_data_if_available_trigger_treeview()
            # self.Available_combobox_trigger_list.set("")
            self.available_trigger_entry_name.delete(0, END)
            self.available_trigger_entry_priority.delete(0, END)
            self.available_combo_select()

       ###########################  insert data in do treeview  ##############################################
    def insert_data_do_frame1(self, event=""):
        self.do_trigger_entry_name.delete(0, END)
        self.do_trigger_entry_name.insert(END, self.do_combobox_trigger_list.get())
        print(695)
        self.insert_data_do_frame2()
        self.count_combobox_do_this = self.combobox_do_this_combiID()
        self.do_combobox_trigger_list_value = False
        def add_combi_id_in_trigger_fun():
            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            my_cursor.execute(f"UPDATE tbl_trigger SET do_this_combi_ID = '{self.count_combobox_do_this}' WHERE triggerID = {self.data_position[0][0]}")
            conn.commit()
            conn.close()
            self.destroy_do_this_save_and_cancel()

        add_combi_id_in_trigger = Button(self.do_main_frame_trigger, text="save", font=('arial', 9, 'bold'), width=5,
                                         height=1, bg="#7C7CFC", fg="white", command=add_combi_id_in_trigger_fun)
        add_combi_id_in_trigger.place(x=440, y=3)
        delete_button_combi_id_in_trigger = Button(self.do_main_frame_trigger, text="cancel", font=('arial', 9, 'bold'), width=5,
                                                   height=1, bg="#7C7CFC", fg="white", command=self.destroy_do_this_save_and_cancel)
        delete_button_combi_id_in_trigger.place(x=520, y=3)
        self.do_this_cancel_button.append(delete_button_combi_id_in_trigger)
        self.do_this_save_button.append(add_combi_id_in_trigger)
        self.insert_data_do_frame2()
        self.do_combobox_trigger_list_condition = False
    def destroy_do_this_save_and_cancel(self):
        # You must know the list of buttons to destroy
        for btn in self.do_this_cancel_button.copy():
            btn.destroy()
            self.do_this_cancel_button.remove(btn)
        for btn in self.do_this_save_button.copy():
            btn.destroy()
            self.do_this_save_button.remove(btn)

    def insert_message_data_in_do_treeview(self):
        print(930)
        self.count_combobox_do_this = self.combobox_do_this_combiID()
        repetition_new_value = self.repeat_trigger_entry.get()
        new_every = self.every_trigger_entry.get()
        if self.repeat_trigger_entry.get() == "-1":
            repetition_new_value = "INF"
        else: # self.repeat_trigger_entry.get() > -1:
            repetition_new_value = self.repeat_trigger_entry.get()
        if self.combobox_trigger_every.get() in "minutes(m)":
            new_every = int(self.every_trigger_entry.get()) * 60
            # print(new_every, "sdfgyuiogfduytfdxd")

        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(
            f"SELECT actionId FROM do_this_combi_item where do_this_combi_ID={int(self.count_combobox_do_this)} and  actionId LIKE '%{self.message_combobox_trigger_midd_list.get()}%'")
        find_lang = my_cursor.fetchall()
        my_cursor.execute(f"select [action_ID],[resource_ID] from [tbl_action] where [action_Name]='{self.message_combobox_trigger_midd_list.get()}'")
        action_resource_ID = my_cursor.fetchall()
        if find_lang:
            messagebox.showinfo("Action", "Action already exists in table", parent=self.top1)
        else:
            my_cursor.execute(
                f"select max(ActionOrder) from do_this_combi_item where do_this_combi_ID={int(self.count_combobox_do_this)}")
            num_id = my_cursor.fetchall()
            num_id_1 = 1
            if num_id[0][0]:
                num_id_1 = int(num_id[0][0]) + 1
            my_cursor.execute(f"insert into do_this_combi_item values(?,?,?,?,?,?,?,?,?,?)", (
                self.count_combobox_do_this,
                self.message_combobox_trigger_midd_list.get(),
                self.delay_trigger_entry.get(),
                repetition_new_value,
                new_every, # self.every_trigger_entry.get(), ##########################
                "second(s)", # self.combobox_trigger_every.get(), #######################
                num_id_1,
                self.check_var.get(),
                action_resource_ID[0][0],
                action_resource_ID[0][1]
            ))
            conn.commit()
            conn.close()
            # print(action_resource_ID, "sdfghjgfdfghjk")
            # self.show_data_do_combobox_list()
            self.insert_data_do_frame2()


    def on_select(self, event=""):
        print(835)
        global global_var
        global global_var1z
        global global_var_action_ID
        # count = self.o1.index(self.message_combobox_trigger_midd_list.get()) + 1
        # print("self.o1", self.o1, self.message_combobox_trigger_midd_list.get())
        count = int(self.o1[self.message_combobox_trigger_midd_list.get()])
        # print(count, "wsdfghjkl;")
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        ######  table_name = [do_this_combi_item], column = [actionDelay], [actionRepetitionCount], [actionRepetitionInterval]
        my_cursor.execute(f"SELECT resource_ID, message_Description FROM tbl_action where action_ID={count}")
        data = my_cursor.fetchall()
        print("data", data)
        self.message_trigger_combobox_destination.set(data[0][0])

        # resource = ET.parse("projectinfo.xml")
        # root = resource.getroot()
        # resource_list = []
        # resource_list.clear()
        # for i in root.findall("resource"):
        #     resource_name_data = i.find("name").text
        #     if resource_name_data.lower() == self.message_trigger_combobox_destination.get().lower():
        #        resource_value = i.find("value").text
        #        global_var[0] = resource_value

        # print("self.message_trigger_combobox_destination.get()", self.message_trigger_combobox_destination.get())
        global_var[0] = self.message_trigger_combobox_destination.get()
        self.message_trigger_entry_name.delete(0, END)
        self.message_trigger_entry_name.insert(0, self.message_combobox_trigger_midd_list.get())
        self.message_trigger_label.config(text=data[0][1])
        global_var1[0] = data[0][1]
        global_var_action_ID[0] = count
        my_cursor.execute(
            f"SELECT [actionDelay], [actionRepetitionCount], [actionRepetitionInterval] FROM [do_this_combi_item] where do_this_combi_ID={int(self.combobox_do_this_combiID())} and [actionId]='{self.message_combobox_trigger_midd_list.get()}'")
        delay_repeat_every = my_cursor.fetchall()
        print("delay_repeat_every", delay_repeat_every)
        # print(delay_repeat_every, "delay_repeat_everydelay_repeat_everydelay_repeat_everydelay_repeat_everydelay_repeat_every")
        delay = ""
        repeat = ""
        every = ""
        if delay_repeat_every:
            delay = str(delay_repeat_every[0][0])
            repeat = delay_repeat_every[0][1]
            every = str(delay_repeat_every[0][2])
        self.delay_trigger_entry.delete(0, END)
        self.repeat_trigger_entry.delete(0, END)
        self.every_trigger_entry.delete(0, END)
        self.delay_trigger_entry.insert(0, delay)
        if repeat == "INF":
            repeat = "-1"
        self.repeat_trigger_entry.insert(0, repeat)
        # self.every_trigger_entry.insert(0, every)
        for item in every[::-1]:
            self.every_trigger_entry.insert(0, item)
        # print(267)
    def insert_data_do_frame2(self):
        print(637)
        self.count_combobox_do_this = self.combobox_do_this_combiID()
        if self.data_position:
            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            print(self.data_position[0][2],"gghghghghg")
            if self.do_combobox_trigger_list_value:
                if self.data_position[0][2]:
                   my_cursor.execute(f"SELECT actionId, actionDelay, actionRepetitionCount, actionRepetitionInterval, IntervalUnit FROM do_this_combi_item where do_this_combi_ID={self.data_position[0][2]} order by ActionOrder")
                else:
                   my_cursor.execute(f"SELECT actionId, actionDelay, actionRepetitionCount, actionRepetitionInterval, IntervalUnit FROM do_this_combi_item where do_this_combi_ID=0 order by ActionOrder")
            else:
                my_cursor.execute(
                    f"SELECT actionId, actionDelay, actionRepetitionCount, actionRepetitionInterval, IntervalUnit FROM do_this_combi_item where do_this_combi_ID={self.count_combobox_do_this} order by ActionOrder")
            data = my_cursor.fetchall()
            # print(self.data_position[0][2], "56787656787656787656789")
            # print(self.count_combobox_do_this, "5678765678987678987678")

            if len(data) != 0:
                self.do_trigger_treeview.delete(*self.do_trigger_treeview.get_children())
                for i in data:
                    self.do_trigger_treeview.insert("", END, values=list(i))
            else:
                self.do_trigger_treeview.delete(*self.do_trigger_treeview.get_children())
            if self.do_trigger_treeview.get_children():
                children = self.do_trigger_treeview.get_children()
                # print("children", children)
                self.do_trigger_treeview.selection_set(children[0])
                self.do_trigger_treeview.focus(children[0])
                self.do_trigger_treeview_focus_data()
            conn.commit()
            conn.close()

            if not data:
                self.message_combobox_trigger_midd_list.set('')
                self.message_trigger_combobox_destination.set('')
                self.message_trigger_entry_name.delete(0, END)
                self.message_trigger_label.config(text='')
                self.delay_trigger_entry.delete(0, END)
                self.repeat_trigger_entry.delete(0, END)
                self.every_trigger_entry.delete(0, END)
                self.message_combobox_trigger_midd_list.set("")
            else:
                self.message_combobox_trigger_midd_list.set(data[0][0])
                self.delay_trigger_entry.delete(0, END)
                self.repeat_trigger_entry.delete(0, END)
                self.every_trigger_entry.delete(0, END)
                new_delay = str(data[0][1])[::-1]
                for item in new_delay:
                    self.delay_trigger_entry.insert(0, item)
                # self.delay_trigger_entry.insert(0, data[0][1])
                new_every = str(data[0][3])[::-1]
                for item in new_every:
                    self.every_trigger_entry.insert(0, item)
                # self.every_trigger_entry.insert(0, data[0][3])
                repeat1 = data[0][2]
                if repeat1 == "INF":
                    repeat1 = "-1"
                self.repeat_trigger_entry.insert(0, repeat1)
                self.combobox_trigger_every.set(data[0][4])

                self.on_select()


    def insert_data_message_combobox(self, event=""):
        # print(725)
        # print(len(self.o1), "nummmmmmmmmmmmmmmmm")
        # print(self.o1)
        try:
            num = len(self.o1)+1
        except AttributeError:
            num = 1
        # print(num, "nummmmmmmmmmmmmmmmm")
        # print(self.message_trigger_entry_name.get(), "rtyuioiuytrtyuio")
        if self.message_trigger_entry_name.get() == "":
            messagebox.showerror("Error", "Fill Name First")
        else:
            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            my_cursor.execute(f"insert into tbl_action values(?,?,?,?)", (
                                      num,
                                      self.message_trigger_entry_name.get(),
                                      ' ',
                                      self.message_trigger_combobox_destination.get()
            ))
            conn.commit()
            conn.close()
            self.show_data_display_message_combobox()
            self.message_trigger_entry_name.delete(0, END)
            self.message_trigger_combobox_destination.delete(0, END)


#################################################################################################################################################
#################################################################################################################################################
#######################################  delete ############################################################################################

    ###################### delete data in available combobox ########################################
    def delete_data_message_combobox(self):
        print(740)
        # count = self.combobox_actionID()
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        sql1 = f"delete from tbl_action where action_Name='{self.message_combobox_trigger_midd_list.get()}'"
        my_cursor.execute(sql1)
        conn.commit()
        conn.close()
        self.show_data_display_message_combobox()
        self.message_combobox_trigger_midd_list.set("")

    ###################### delete data in available combobox ########################################
    def delete_available_list(self):
        print(946)
        # print(self.Available_combobox_trigger_list.get(), "tghijoguytdfguh")
        # print(self.m.index(self.Available_combobox_trigger_list.get()) + 1, "tghijoguytdfguh")
        # self.message_trigger_entry_name.configure(background="red")
        if self.Available_combobox_trigger_list.get() == "":
            messagebox.showerror("Error", "No Data")
        else:
            # print(903)
            selected_items = self.Available_combobox_trigger_list.get()
            self.num_of_combo_available = self.m.index(selected_items) + 1
            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            # my_cursor.execute(f"select max(triggerID) from tbl_trigger")
            # data_max = my_cursor.fetchall()
            # my_cursor.execute(f"select triggerID from tbl_trigger where triggerName='{self.Available_combobox_trigger_list.get()}'")
            # data_current_id = my_cursor.fetchall()
            my_cursor.execute(f"delete from tbl_trigger where triggerName='{self.Available_combobox_trigger_list.get()}'")
            # if data_max:
            #     if data_current_id:
            #         if data_current_id[0][0] == data_max[0][0]:
            #             my_cursor.execute(f"delete from tbl_trigger where triggerID={int(data_current_id[0][0])}")
            #         else:
            #             my_cursor.execute(f"delete from tbl_trigger where triggerID={int(data_current_id[0][0])}")
                        # my_cursor.execute(f"UPDATE tbl_trigger SET triggerName = 'Empty' WHERE triggerID = {int(data_current_id[0][0])}")
            # for i in range(self.num_of_combo_available, len(self.m) + 1):
            #     sql_data = f"UPDATE tbl_trigger SET triggerID = triggerID - 1 WHERE triggerID = {i}"
            # my_cursor.execute(sql_data)
            conn.commit()
            conn.close()
            self.num_of_combo_available = 1
            self.Available_combobox_trigger_value = False
            self.available_trigger_entry_name.delete(0, END)
            self.available_trigger_entry_priority.delete(0, END)
            self.Available_combobox_trigger_list.set("")
            self.show_data_in_position_treeview()
            self.show_data_if_available_trigger_treeview()
            self.show_data_if_available_trigger_treeview()


########################################## delete do combox list data ####################################################
    def delete_do_combobox_list(self):
        print(670)
        selected_items = self.do_combobox_trigger_list.get()
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        sql1 = f"Delete from do_this_combi where do_this_combi_ID={self.count_combobox_do_this}"
        my_cursor.execute(sql1)
        conn.commit()
        conn.close()
        self.show_data_do_combobox_list()
        self.do_combobox_trigger_list.set("")


    ########################### do delete remove button function ##########################
    def remove_do_delete_data(self):
        print(979)
        self.count_combobox_do_this = self.combobox_do_this_combiID()
        if self.do_trigger_treeview.focus() == "":
            self.do_combobox_trigger_list.get()
            messagebox.showerror("Error", "Select the file ", parent=self.top1)
        else:
            try:
                Delete = messagebox.askyesno("Delete", "Are you sure delete the data", parent=self.top1)
                if Delete > 0:
                    conn = sqlite3.connect("triggers_abhay.db")
                    my_cursor = conn.cursor()
                    sql_data = f"delete from do_this_combi_item where actionId= '{self.data5[0]}' and do_this_combi_ID={self.count_combobox_do_this}"
                    my_cursor.execute(sql_data)
                else:
                    if not Delete:
                        return
                conn.commit()
                conn.close()
                self.insert_data_do_frame2()
                self.show_data_do_combobox_list()
                messagebox.showinfo("Delete", "your train data has been deleted", parent=self.top1)
            except Exception as es:
                messagebox.showerror("Error", f"Due To:{str(es)}", parent=self.top1)
################################ delete data in treeview speed and position #######################################################
    def delete_data_if_treeview_trigger(self):
        print(121)
        cursor_row4 = self.if_trigger_treeview.focus()
        content4 = self.if_trigger_treeview.item(cursor_row4)
        data_if_treeview = content4["values"]
        # print(data_if_treeview, "table data")
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        if data_if_treeview[0] == "if":
            my_cursor.execute(f"update tbl_trigger set eventValue=' ', [conditional]=' ' where triggerName='{self.Available_combobox_trigger_list.get()}'")
        elif data_if_treeview[0] == "And":
            my_cursor.execute(f"update tbl_trigger set [conditional]=' ' where triggerName='{self.Available_combobox_trigger_list.get()}'")
        conn.commit()
        conn.close()
        self.show_data_in_position_treeview()

###############################################################################################################################################
#################################################### show data in combobox ######################################################################

    ###################### show_data_if_available_trigger_treeview ###########################################
    def show_data_if_available_trigger_treeview(self):
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        # my_cursor.execute("select triggerName from tbl_trigger where triggerID=1")
        # data_combi = my_cursor.fetchall()
        my_cursor.execute("SELECT triggerID,triggerName FROM tbl_trigger")
        self.data_from_tbl_trigger = my_cursor.fetchall()
        self.m = []
        for j in self.data_from_tbl_trigger:
            p = list(j)
            self.m.append(p[1])
        self.Available_combobox_trigger_list["value"] = self.m
        if self.data_from_tbl_trigger:
            self.Available_combobox_trigger_list.set(self.data_from_tbl_trigger[self.num_of_combo_available-1][1])

 #################################   show data in do combobox list ###########################################################
    def show_data_do_combobox_list(self): # for ** do this combobox
        print(680)
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(f"SELECT do_this_combi_ID, do_this_combi_Name FROM do_this_combi")
        self.data_from_do_this_combi = my_cursor.fetchall()
        # print(self.data_position, "self.data_position")
        if self.data_position:
            if self.data_from_do_this_combi:
                self.n = []
                for j in self.data_from_do_this_combi:
                    p = list(j)
                    self.n.append(p[1])
                self.do_combobox_trigger_list["value"] = self.n
                my_cursor.execute(
                    f"SELECT do_this_combi_Name FROM do_this_combi where do_this_combi_ID={self.data_position[0][2]}")
                self.do_this_combi_id_num = my_cursor.fetchall()
                # print(self.do_this_combi_id_num, "sdfghjikohggiuhgfguiuhgfg")
                if self.do_this_combi_id_num:
                    self.do_combobox_trigger_list.set(self.do_this_combi_id_num[0][0])
                self.do_trigger_entry_name.delete(0, END)
                self.do_trigger_entry_name.insert(END, self.do_combobox_trigger_list.get())
                conn.commit()
                conn.close()
            else:
                self.do_combobox_trigger_list["value"] = []
        else:
            self.do_combobox_trigger_list["value"] = []



        ################################### show data in message combobox list in right frame ##########################
    def show_data_display_message_combobox(self):
        print(712)
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT action_Name, resource_ID FROM tbl_action")
        self.data_tbl_action1 = my_cursor.fetchall()
        my_cursor.execute("SELECT action_Name, resource_ID, action_ID FROM tbl_action")
        self.data_tbl_action = my_cursor.fetchall()
        # print(self.data_tbl_action, "sdfghgfdfghhgfghjhgcghgcfggcgh")
        if self.data_position:
            if self.data_tbl_action:
                self.o1 = {}
                o1_list = []
                for j in self.data_tbl_action:
                    p = list(j)
                    self.o1[p[0]] = p[2]
                    o1_list.append(p[0])

                self.message_combobox_trigger_midd_list["value"] = o1_list
                self.message_combobox_trigger_midd_list.set(o1_list[0])
                self.message_trigger_combobox_destination.set(self.data_tbl_action[0][1])
                self.message_trigger_entry_name.delete(0, END)
                self.message_trigger_entry_name.insert(0, o1_list[0])
            else:
                self.message_combobox_trigger_midd_list["value"] = []
        else:
            self.message_combobox_trigger_midd_list["value"] = []

        # print(self.o1, "listttttttttttttttttt")


    ####################################### do trigger treeview focus data #########################################
    def do_trigger_treeview_focus_data(self, event=""):
        print(960)
        def destroy_function():
            for button_name in self.delete_save_undo_button:
                button_name.destroy()
            self.delete_save_undo_button.clear()
        destroy_function()
        # self.on_select()
        self.cursor_row4 = self.do_trigger_treeview.focus() # I001, I002, I003, ........
        # self.column_row_number = self.do_trigger_treeview.identify_column(event.x)
        self.content5 = self.do_trigger_treeview.item(self.cursor_row4)
        self.data5 = self.content5["values"]
        print("self.data5", self.data5)
        self.message_trigger_entry_name.config(state='normal')
        count = self.combobox_actionID()
        self.message_combobox_trigger_midd_list.delete(0, END)
        self.message_combobox_trigger_midd_list.set(self.data5[0])
        self.message_trigger_entry_name.delete(0, END)
        self.delay_trigger_entry.delete(0, END)
        self.repeat_trigger_entry.delete(0, END)
        self.every_trigger_entry.delete(0, END)
        self.combobox_trigger_every.delete(0, END)
        self.message_trigger_entry_name.insert(0, self.data5[0])
        new_delay = str(self.data5[1])[::-1]
        # new_delay = str(self.data5[1])
        print("new_delay", new_delay)
        for item in new_delay:
            print("item", item)
            self.delay_trigger_entry.insert(0, item)
        # self.delay_trigger_entry.insert(0, self.data5[1])
        new_every = str(self.data5[3])[::-1]
        for item in new_every:
            print("item", item)
            self.every_trigger_entry.insert(0, item)
        # self.every_trigger_entry.insert(0, self.data5[3])
        repeat1 = self.data5[2]
        if repeat1 == "INF":
            repeat1 = "-1"
        self.repeat_trigger_entry.insert(0, repeat1)
        self.combobox_trigger_every.insert(0, self.data5[4])
        self.new_repeat_trigger_data = self.repeat_trigger_entry.get()
        self.new_delay_trigger_data = self.delay_trigger_entry.get()
        self.new_every_trigger_data = self.every_trigger_entry.get()

        def undo_data():
            self.delay_trigger_entry.delete(0, END)
            self.repeat_trigger_entry.delete(0, END)
            self.every_trigger_entry.delete(0, END)
            if self.new_repeat_trigger_data == "INF":
                self.new_repeat_trigger_data = "-1"
            self.repeat_trigger_entry.insert(0, self.new_repeat_trigger_data)
            for item in self.new_delay_trigger_data[::-1]:
                self.delay_trigger_entry.insert(0, item)
            for item in self.new_every_trigger_data[::-1]:
                self.every_trigger_entry.insert(0, item)
            destroy_function()
        def save_in_do_this_combi_item():

            self.new_repeat_trigger_data1 = self.repeat_trigger_entry.get()
            if self.repeat_trigger_entry.get() == "-1":
                self.new_repeat_trigger_data1 = "INF"
            new_every1 = self.every_trigger_entry.get()
            if self.combobox_trigger_every.get() in "minutes(m)":
                new_every1 = int(self.every_trigger_entry.get()) * 60

            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            my_cursor.execute(
                f"UPDATE [do_this_combi_item] SET [actionDelay]={int(self.delay_trigger_entry.get())}, [actionRepetitionCount]='{self.new_repeat_trigger_data1}',[actionRepetitionInterval]={int(new_every1)},[Flush]={int(self.check_var.get())} WHERE do_this_combi_ID={int(self.combobox_do_this_combiID())} and actionId='{self.data5[0]}'")
            conn.commit()
            conn.close()
            self.do_trigger_treeview.set(self.cursor_row4, column="#2", value=self.delay_trigger_entry.get())
            self.do_trigger_treeview.set(self.cursor_row4, column="#3", value=self.new_repeat_trigger_data1)
            self.do_trigger_treeview.set(self.cursor_row4, column="#4", value=new_every1)
            destroy_function()

        def enter_entry(e):
            # print(e)
            message_save_button = tk.Button(self.message_trigger_middle_right_frame, text="Save",
                                            font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=save_in_do_this_combi_item)
            message_save_button.place(x=450, y=175)
            message_cancel_button = tk.Button(self.message_trigger_middle_right_frame, text="Undo",
                                              font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=undo_data)
            message_cancel_button.place(x=520, y=175)
            self.delete_save_undo_button.append(message_save_button)
            self.delete_save_undo_button.append(message_cancel_button)

        self.repeat_trigger_entry.bind("<Key>", enter_entry)
        self.every_trigger_entry.bind("<Key>", enter_entry)
        self.delay_trigger_entry.bind("<Key>", enter_entry)

        self.on_select()

    def double_click_mess(self, event=""):
        print(386)
        self.top1.destroy()
        MainApplication6()
    def on_exit(self):
        self.top1.destroy()
        trigger.MainApplication4()

class Reptile(tk.Frame):
    def __init__(self, parent3):
        tk.Frame.__init__(self)
    @staticmethod
    def print_animal():
        global global_var
        return global_var[0]
    @staticmethod
    def var2():
        global global_var1
        return global_var1[0]
    @staticmethod
    def action_ID_num():
        global global_var_action_ID
        return global_var_action_ID[0]
    @staticmethod
    def return_value():
        global num_of_combo_available_global
        return num_of_combo_available_global



if __name__ == "__main__":
    MainApplication5()
