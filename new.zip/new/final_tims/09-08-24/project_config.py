import tkinter.ttk
from tkinter import *
import tkinter as tk
from customtkinter import CTkButton, CTkCheckBox
import xml.etree.ElementTree as ET
import main
# import shutil
# import pyodbc
# from tkinter import messagebox
# import pygame
# from pathlib import Path
# from tkinter import filedialog as fd
# import os
# Define the class the application
class project_config_class:
    # init method or constructor that call by instance variable
    def __init__(self):
        # tk.Tk is crate a window
        self.project = tk.Tk()
        # write a project title name line
        self.project.title('Station')
        # window frame geometry size (width,height,x-place,y-place)
        self.project.geometry("650x460+150+40")
        self.project.iconbitmap("logo2.ico")
        # the background colour change by config
        self.project.configure(bg="lightsteelblue2", borderwidth="1")
        self.project.protocol("WM_DELETE_WINDOW", self.on_exit)
        # self.project.grab_set()
        # Allowing root window to not change it's size according to user's need
        self.project.resizable(False, False)
        # Fixing the size of the root window No one can now expand the size of the root window than the specified one.
        self.project.maxsize(650, 465)
        self.project.minsize(650, 465)
        general_frame = Frame(self.project, relief=SUNKEN, bg='lightsteelblue1', bd=4)
        general_frame.place(x=10, y=15, height=400, width=304)

        general_frame_label = Label(general_frame, font=("arial", 12, "bold"), bg='blue', fg="white", text='Station Name :',
                                    width=29, anchor=NW)
        general_frame_label.place(x=0, y=0)

        prerecorded_mess = Frame(self.project, relief=SUNKEN, bg='lightsteelblue1', bd=4)
        prerecorded_mess.place(x=330, y=15, height=180, width=304)

        prerecorded_mess_label = Label(prerecorded_mess, font=("arial", 12, "bold"), bg='blue', fg="white",
                                       text='Station Name :', width=29, anchor=NW)
        prerecorded_mess_label.place(x=0, y=0)

        propaganda = Frame(self.project, relief=SUNKEN, bg='lightsteelblue1', bd=4)
        propaganda.place(x=330, y=235, height=180, width=304)

        propaganda_label = Label(propaganda, font=("arial", 12, "bold"), bg='blue', fg="white",
                                 text='Station Name :', width=29, anchor=NW)
        propaganda_label.place(x=0, y=0)

        ########################################## Label ######################################################
        ########################################## Label ######################################################
        ########################################## Label ######################################################

        mp3_delay = Label(general_frame, font=("arial", 10, "bold"), text='MP3 pre-delay(mSec.):', bg="lightsteelblue1")
        mp3_delay.place(x=5, y=40)
        welcome_message = Label(general_frame, font=("arial", 10, "bold"), text='Welcome Message:',
                                        bg="lightsteelblue1")
        welcome_message.place(x=5, y=70)
        mmi_language = Label(general_frame, font=("arial", 10, "bold"), text='MMI Language :',
                                        bg="lightsteelblue1")
        mmi_language.place(x=5, y=145)
        time_zone = Label(general_frame, font=("arial", 10, "bold"), text='Timezone offset (quarters):',
                                        bg="lightsteelblue1")
        time_zone.place(x=5, y=175)

        tachospeed_track = Label(general_frame, font=("arial", 10, "bold"), text='Tachospeed tracking',
                          bg="lightsteelblue1")
        tachospeed_track.place(x=5, y=245)
        max_next_station = Label(general_frame, font=("arial", 10, "bold"), text='Max. next station',
                          bg="lightsteelblue1")
        max_next_station.place(x=5, y=310)
        coupling_delay = Label(general_frame, font=("arial", 10, "bold"), text='Coupling Delay (Sec.):',
                               bg="lightsteelblue1")
        coupling_delay.place(x=5, y=340)

        ########################################### ENTRY Checkbox and listbox ###########################################
        ########################################### ENTRY Checkbox and listbox ###########################################
        ########################################### ENTRY Checkbox and listbox ###########################################
        self.mp3_delay_entry = tk.Entry(general_frame, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.mp3_delay_entry.place(x=215, y=41)
        self.welcome_message_entry = CTkCheckBox(general_frame, font=('arial', 10, 'bold'), bg_color="lightsteelblue1", checkbox_width=20, checkbox_height=20, text="", width=20, border_color="white")
        self.welcome_message_entry.place(x=215, y=71)
        language_from_xml = ET.parse("projectinfo.xml")
        root = language_from_xml.getroot()
        list_language_mmi = []
        for i in root.findall("ImsLanguages"):
            full_name = i.find("Name").text
            code_name = i.find("Code").text
            list_language_mmi.append(code_name)
        self.mmi_language_entry = tkinter.ttk.Combobox(general_frame, font=("arial", 10, 'bold'), width=7, background="light gray", values=list_language_mmi)
        if list_language_mmi:
            self.mmi_language_entry.set(list_language_mmi[0])
        self.mmi_language_entry.place(x=215, y=146)

        self.time_zone_entry = tk.Entry(general_frame, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.time_zone_entry.place(x=215, y=176)
        self.tachospeed_track_entry = CTkCheckBox(general_frame, font=('arial', 10, 'bold'), bg_color="lightsteelblue1", checkbox_width=20, checkbox_height=20, text="", width=20, border_color="white")
        self.tachospeed_track_entry.place(x=215, y=246)
        self.max_next_station_entry = tk.Entry(general_frame, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.max_next_station_entry.place(x=215, y=311)
        self.coupling_delay_entry = tk.Entry(general_frame, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.coupling_delay_entry.place(x=215, y=341)
        ####################################### prerecorded Label ######################################################
        ####################################### prerecorded Label ######################################################
        ####################################### prerecorded Label ######################################################
        language_interval = Label(prerecorded_mess, font=("arial", 10, "bold"), text='Language Interval :', bg="lightsteelblue1")
        language_interval.place(x=5, y=40)
        loop_count = Label(prerecorded_mess, font=("arial", 10, "bold"), text='Loop Count :', bg="lightsteelblue1")
        loop_count.place(x=5, y=75)
        display_line = Label(prerecorded_mess, font=("arial", 10, "bold"), text='Display Line :', bg="lightsteelblue1")
        display_line.place(x=5, y=110)
        graphic_mode = Label(prerecorded_mess, font=("arial", 10, "bold"), text='Graphic mode', bg="lightsteelblue1")
        graphic_mode.place(x=5, y=145)
        ####################################### propaganda Label ######################################################
        ####################################### propaganda Label ######################################################
        ####################################### propaganda Label ######################################################
        language_interval = Label(propaganda, font=("arial", 10, "bold"), text='Interval :',
                                  bg="lightsteelblue1")
        language_interval.place(x=5, y=40)
        loop_count = Label(propaganda, font=("arial", 10, "bold"), text='Repetions :',
                           bg="lightsteelblue1")
        loop_count.place(x=5, y=75)
        display_line = Label(propaganda, font=("arial", 10, "bold"), text='Display Line :',
                             bg="lightsteelblue1")
        display_line.place(x=5, y=110)
        graphic_mode = Label(propaganda, font=("arial", 10, "bold"), text='Graphic mode',
                             bg="lightsteelblue1")
        graphic_mode.place(x=5, y=145)
        ####################################### prerecorded Entry ######################################################
        ####################################### prerecorded Entry ######################################################
        ####################################### prerecorded Entry ######################################################
        self.language_interval_entry = tk.Entry(prerecorded_mess, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.language_interval_entry.place(x=215, y=41)

        self.loop_count_entry = tk.Entry(prerecorded_mess, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.loop_count_entry.place(x=215, y=75)

        self.display_line_entry = tk.Entry(prerecorded_mess, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.display_line_entry.place(x=215, y=110)

        self.graphic_mode_entry = CTkCheckBox(prerecorded_mess, font=('arial', 10, 'bold'), bg_color="lightsteelblue1", checkbox_width=20, checkbox_height=20, text="", width=20, border_color="white")
        self.graphic_mode_entry.place(x=215, y=145)

        ####################################### propaganda Entry ######################################################
        ####################################### propaganda Entry ######################################################
        ####################################### propaganda Entry ######################################################
        self.interval_entry_propaganda = tk.Entry(propaganda, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.interval_entry_propaganda.place(x=215, y=41)

        self.repetions_entry_propaganda = tk.Entry(propaganda, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.repetions_entry_propaganda.place(x=215, y=75)

        self.display_line_entry_propaganda = tk.Entry(propaganda, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
        self.display_line_entry_propaganda.place(x=215, y=110)

        graphic_mode_entry_propaganda = CTkCheckBox(propaganda, font=('arial', 10, 'bold'), bg_color="lightsteelblue1", checkbox_width=20, checkbox_height=20, text="", width=20, border_color="white")
        graphic_mode_entry_propaganda.place(x=215, y=145)
        
        
        select_Import_file = CTkButton(self.project, text="SAVE", font=('arial', 13, 'bold'), text_color="black", width=50, height=10, command=self.update_xml)
        select_Import_file.place(x=10, y=430)
        self.insert_data_from_xml()
        
        self.project.mainloop()
        
    def update_xml(self):
        self.Mp3Delay_update = self.mp3_delay_entry.get()
        self.mmi_language_entry_update = self.mmi_language_entry.get()
        self.coupling_delay_entry_update = self.coupling_delay_entry.get()
        self.language_interval_entry_update = self.language_interval_entry.get()
        self.loop_count_entry_update = self.loop_count_entry.get()
        self.interval_entry_propaganda_update = self.interval_entry_propaganda.get()
        self.repetions_entry_propaganda_update = self.repetions_entry_propaganda.get()
        self.time_zone_entry_update = self.time_zone_entry.get()
        self.display_line_entry_update = self.display_line_entry.get()
        self.display_line_entry_propaganda_update = self.display_line_entry_propaganda.get()
        self.max_next_station_entry_update = self.max_next_station_entry.get()

        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("Configuration"):
            i.find("Mp3Delay").text = self.Mp3Delay_update
            i.find("MmiLanguageCode").text = self.mmi_language_entry_update 
            i.find("CouplingDelay").text = self.coupling_delay_entry_update
            i.find("PrmInterval").text = self.language_interval_entry_update
            i.find("PrmLoopCount").text = self.loop_count_entry_update 
            i.find("PropagandaInterval").text = self.interval_entry_propaganda_update
            i.find("PropagandaLoopcount").text = self.repetions_entry_propaganda_update
            i.find("TimezoneOffset").text = self.time_zone_entry_update
            i.find("PrmDisplayLine").text = self.display_line_entry_update
            i.find("PropagandaDisplayLine").text = self.display_line_entry_propaganda_update
            i.find("MaxNextStations").text = self.max_next_station_entry_update
        my_tr.write("projectinfo.xml")

    def insert_data_from_xml(self):
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("Configuration"):

            self.Mp3Delay = i.find("Mp3Delay").text
            self.mp3_delay_entry.insert(0,self.Mp3Delay)

            self.CouplingDelay = i.find("CouplingDelay").text
            self.coupling_delay_entry.insert(0, self.CouplingDelay)

            self.PrmInterval = i.find("PrmInterval").text
            self.language_interval_entry.insert(0,self.PrmInterval)

            self.PrmLoopCount = i.find("PrmLoopCount").text
            self.loop_count_entry.insert(0,self.PrmLoopCount)

            self.PropagandaInterval = i.find("PropagandaInterval").text
            self.interval_entry_propaganda.insert(0,self.PropagandaInterval)

            self.PropagandaLoopcount = i.find("PropagandaLoopcount").text
            self.repetions_entry_propaganda.insert(0,self.PropagandaLoopcount)

            self.TimezoneOffset = i.find("TimezoneOffset").text
            self.time_zone_entry.insert(0,self.TimezoneOffset)

            self.PrmDisplayLine = i.find("PrmDisplayLine").text
            self.display_line_entry.insert(0,self.PrmDisplayLine)

            self.PropagandaDisplayLine = i.find("PropagandaDisplayLine").text
            self.display_line_entry_propaganda.insert(0,self.PropagandaDisplayLine)

            self.MaxNextStations = i.find("MaxNextStations").text
            self.max_next_station_entry.insert(0,self.MaxNextStations)


    def on_exit(self):
        self.project.destroy()
        main.MainApplication()


if __name__ == "__main__":
    project_config_class()


