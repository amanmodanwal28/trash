import tkinter as tk
from tkinter import ttk
import routes
import stations
import journey
import trigger
import export
import dts_time
import messages
import project_config
from stations import *
from tkinter import filedialog
from PIL import Image, ImageTk
import customtkinter as ctk

# database_name_data1 = ''

bg_main = "#F1D2BA"
fg_color = "#2c2b52"
font = ("dubai medium", 14, "bold")

class MainApplication:
    def __init__(self):
        self.parent = tk.Tk()
        self.parent.title("Information Management System")
        self.parent.geometry("640x500+450+100")
        self.parent.iconbitmap("logo2.ico")
        self.parent.resizable(False, False)
        # self.parent.maxsize(500, 500)
        # self.parent.minsize(500, 500)

        def message_py():
            self.parent.destroy()
            messages.messages_data()
        def configuration():
            self.parent.destroy()
            project_config.project_config_class()
            
        def dts_time_fun():
            self.parent.destroy()
            dts_time.dts_time_class()
            
        
        ############################ Creating Menubar ############################
        # Adding Project Menu and SubMenus
        self.menu = Menu(self.parent)
        # self.menu.configure(bg="blue")
        self.project = tk.Menu(self.menu, tearoff=0, bg='darkseagreen') #tearoff make the menu stick close to the Window
        # SubMenu
        self.project.add_command(label="Create new", command=self.create_new_databse)
        self.project.add_command(label="Delete database", command=self.delete_databse_schema)
        # Menu Project
        self.menu.add_cascade(label="Project", menu=self.project)
        # Adiing Items Menu and SubMenus
        self.items = tk.Menu(self.menu, tearoff=0, bg='darkseagreen')
        # SubMenu
        self.items.add_command(label="Items 1")
        self.items.add_command(label="configuration", command=configuration)
        self.items.add_command(label="messages", command=message_py)
        self.items.add_command(label="DTS", command=dts_time_fun)
        
        # Menu Item
        self.menu.add_cascade(label="Items", menu=self.items)
        # Adding Language Menu and SubMenus
        self.language = tk.Menu(self.menu, tearoff=0, bg='darkseagreen')
        # SubMenu
        self.language.add_command(label="Language 1")
        self.language.add_command(label="Language 2")
        self.language.add_command(label="Language 3")
        # Menu Language
        self.menu.add_cascade(label="Language", menu=self.language)
        # Adding Upload Menu and SubMenus
        self.upload = tk.Menu(self.menu, tearoff=0, bg='darkseagreen')
        # SubMenu
        self.upload.add_command(label="Upload", command=self.open_file)
        #  Menu Upload
        self.menu.add_cascade(label="Upload", menu=self.upload)
        # Displaying Menu used by config to connect
        # IMS.config(menu=self.menu)
        self.parent.config(menu=self.menu)
        ################################### End Menu bar #######################

        ################################### Image For Window ##################
        frame_image = Image.open("station_png_3.png")
        frame_image = frame_image.resize((800, 555))
        self.canvas = Canvas(self.parent, width=700, height=555)
        self.canvas.place(x=0, y=0)
        # Display the resized image
        frame_image = ImageTk.PhotoImage(frame_image)
        self.canvas.create_image(0, -1, image=frame_image, anchor=NW)
        self.canvas.create_text(250, 20, text="", fill="BLACK", font=("Arial", 15, "bold"), anchor=CENTER, tags="file_text")
        ################################## END #################################

        ############################## Station Top #############################
        # This def station_top function will be connected to the top level of the stations
        station_image = Image.open("station_button_2.png")
        station_image = station_image.resize((252, 55))
        station_image = ImageTk.PhotoImage(station_image)

        def station_top():
            self.parent.destroy()
            stations.MainApplication1()
        self.stations_button = tk.Button(self.parent, image=station_image, font=('arial', 12, 'bold'), width=250, height=53,
                                         command=station_top, bd=0, highlightthickness=0)
        # self.stations_button.place(x=52, y=50)
        self.stations_button.place(x=52, y=52)
        ############################### END ####################################

        ############################## Route Top ###############################
        # This def route_top function will be connected to the top level of the stations
        def route_top():
            self.parent.destroy()
            routes.MainApplication2()

        route_image = Image.open("route_png.png")
        route_image = route_image.resize((246, 50))
        route_image = ImageTk.PhotoImage(route_image)
        # Create route Button
        self.routes_button = tk.Button(self.parent, image=route_image, width=244, height=48,
                                       bg="cyan", fg="black", command=route_top, bd=0, highlightthickness=0)
        # Set the position of button on the window.
        self.routes_button.place(x=56, y=167)
        ################################ END ###################################

        ############################# Journey Top ##############################
        def journey_top():
            self.parent.destroy()
            journey.MainApplication3()

        journey_image = Image.open("journey_png.png")
        # journey_image = journey_image.resize((246, 50))
        journey_image = ImageTk.PhotoImage(journey_image)

        self.journeys_button = tk.Button(self.parent, image=journey_image, font=('arial', 12, 'bold'), width=210, height=52, bd=0, highlightthickness=0,
                                         bg="cyan", fg="black", command=journey_top)
        self.journeys_button.place(x=64, y=280)
        ############################## END ####################################

        ############################ Trigger Top ##############################
        def trigger_top():
            self.parent.destroy()
            trigger.MainApplication4()

        trigger_image = Image.open("triggger_png.png")
        # trigger_image = trigger_image.resize((246, 50))
        trigger_image = ImageTk.PhotoImage(trigger_image)

        self.triggers_button = tk.Button(self.parent, image=trigger_image, font=('arial', 12, 'bold'), width=113, height=44, bd=0, highlightthickness=0,
                                         bg="cyan", fg="black", command=trigger_top)
        self.triggers_button.place(x=52, y=390)

        ############################# END #####################################
        
        # ############################ Export Top ###################################
        
        def export_top():
            self.parent.destroy()
            export.MainApplication5()

        export_image = Image.open("export_png.png")
        # trigger_image = export_image.resize((246, 50))
        export_image = ImageTk.PhotoImage(export_image)
        self.export_button = tk.Button(self.parent, image=export_image, width=99, height=46,
                                       bd=0, highlightthickness=0, bg="cyan", fg="black", command=export_top)
        self.export_button.place(x=200, y=390)
        ############################ END ######################################
        self.parent.mainloop()

        
        
    def create_new_databse(self):
        top = tk.Tk()
        top.title("Create New Database")
        top.geometry("350x150")

        database_label = tk.Label(top, text="Database Name :", font=("arial", 12, "bold"))
        database_label.place(x=10, y=10)

        create_database_entry = tk.Entry(top, width=23, font=('arial', 11, 'bold'))
        create_database_entry.place(x=150, y=10)

        selected_source_file_label = tk.Label(top, text="Selected File :", font=("arial", 12, "bold"))
        selected_source_file_label.place(x=10, y=50)

        source_file_entry = tk.Entry(top, width=18, font=('arial', 11, 'bold'))
        source_file_entry.place(x=150, y=53)

        def select_source_file():
            selected_db_log_path = filedialog.askdirectory()
            select_source_file_replace = selected_db_log_path.replace("/", '\\')
            if selected_db_log_path:
                source_file_entry.delete(0, tk.END)
                source_file_entry.insert(0, select_source_file_replace)

        sorce_file_btn = tk.Button(top, text="Select", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=select_source_file)
        # sorce_file_btn.place(x=300, y=53)

        def insert_data():
            database_name = create_database_entry.get()
            file_path = source_file_entry.get()
            server_name = "DP-ANKIT-PTC\MSSQLSERVER01"

            connection_string = "Driver=SQL Server;Server={};Database={};Trusted_Connection=Yes;"
            cnxn = pyodbc.connect(connection_string.format(server_name, "master"), autocommit=True)
            cnxn.cursor().execute(f'''CREATE DATABASE [{database_name}] ON  PRIMARY
                (NAME = N'{database_name}_Data', FILENAME = N'{file_path}\{database_name}_Data.mdf' , SIZE = 167872KB , MAXSIZE = UNLIMITED, FILEGROWTH = 16384KB )
                LOG ON
                ( NAME = N'{database_name}_Log', FILENAME = N'{file_path}\{database_name}_Log.ldf' , SIZE = 2048KB , MAXSIZE = 2048GB , FILEGROWTH = 16384KB )''')
            
            cnxn.close()

            cnxn = pyodbc.connect(connection_string.format(server_name, database_name), autocommit=True)
            cnxn.cursor().execute("""
                CREATE TABLE tbl_station(
                    shortName nvarchar(550) NOT NULL,
                    stationID int NOT NULL,
                    GPSPosX int NOT NULL,
                    GPSPosY int NOT NULL,
                    GPSPosZ int NOT NULL,
                    stationNr nvarchar(550) NOT NULL,
                    defaultLanguageArea nvarchar(550) NOT NULL,
                    isStopArea tinyint NOT NULL,
                    isLanguageBorder tinyint NOT NULL
                )
                CREATE TABLE tbl_stationNames(
                    stationID tinyint NOT NULL,
                    ISOlang nvarchar(550) NOT NULL,
                    stationName nvarchar(550) NOT NULL,
                    stationNameShort nvarchar(550) NOT NULL,
                    stationNameAudio nvarchar(550) NOT NULL,
                    numLanguage tinyint NOT NULL 
                )
                CREATE TABLE tbl_stationDistance(
                    stationID1 tinyint NOT NULL,
                    stationID2 tinyint NOT NULL,
                    distance float NOT NULL
                )
                CREATE TABLE tbl_routes(
                    routeID int NOT NULL,
                    routeName nvarchar(550) NOT NULL
                )
                CREATE TABLE tbl_routeStops(
                    routeID tinyint NOT NULL,
                    routeStopID tinyint NOT NULL,
                    stopOrder tinyint NOT NULL,
                    stationID tinyint NOT NULL,
                    distanceFromPrev nvarchar(550)
                )
                CREATE TABLE tbl_journeys(
                    journeyID tinyint NOT NULL,
                    routeID tinyint NOT NULL,
                    journeyName nvarchar(550) NOT NULL,
                    condition nvarchar(550) NOT NULL,
                    departure nvarchar(550) NOT NULL,
                    serviceType nvarchar(550) NOT NULL,
                    totalCars tinyint NOT NULL,
                    handicapCar tinyint NOT NULL
                )
                CREATE TABLE tbl_journeyStops(
                    journeyID tinyint NOT NULL,
                    routeStopID tinyint NOT NULL,
                    stationNo nvarchar(550) NOT NULL,
                    stationName nvarchar(550) NOT NULL,
                    arrivalTime nvarchar(550) NOT NULL,
                    depactureTime nvarchar(550) NOT NULL,
                    conditional nvarchar(550) NOT NULL,
                    platformNum nvarchar(550) NOT NULL,
                    combiTriggerID nvarchar(550) NOT NULL,
                    languageArea nvarchar(550) NOT NULL,
                    combiTriggerIDn int   
                )
                CREATE TABLE tbl_combiTrigger(
                    combiTriggerID int NOT NULL PRIMARY KEY,
                    combiTriggerName nvarchar(550) NOT NULL
                )
                CREATE TABLE tbl_combiTriggerItems(
                    combiTriggerID tinyint NOT NULL,
                    triggerName nvarchar(550) NOT NULL,
                    trigger_id tinyin NOT NULL
                )
                CREATE TABLE tbl_trigger(
                    triggerID int NOT NULL PRIMARY KEY,
                    triggerName nvarchar(550) NOT NULL,
                    eventType nvarchar(550) NOT NULL,
                    triggerPrio nvarchar(550) NOT NULL,
                    eventValue nvarchar(550) NOT NULL,
                    conditional nvarchar(550) NOT NULL,
                    do_this_combi_ID int NOT NULL
                )
                CREATE TABLE do_this_combi(
                    do_this_combi_ID int NOT NULL PRIMARY KEY,
                    do_this_combi_Name text NOT NULL
                )
                CREATE TABLE do_this_combi_item(
                    do_this_combi_ID tinyint NOT NULL,
                    actionId nvarchar(550) NOT NULL,
                    actionDelay tinyint NOT NULL,
                    actionRepetitionCount nvarchar(550) NOT NULL,
                    actionRepetitionInterval int NOT NULL,
                    IntervalUnit nvarchar(550) NOT NULL,
                    ActionOrder tinyint NOT NULL,
                    Flush tinyint NOT NULL,
                    action_ID_int tinyint NOT NULL,
                    resource_name nvarchar(550) NOT NULL 
                )
                CREATE TABLE tbl_action(
                    action_ID int NOT NULL PRIMARY KEY,
                    action_Name nvarchar(550) NOT NULL,
                    message_Description nvarchar(550) NOT NULL,
                    resource_ID nvarchar(550) NOT NULL
                )
                CREATE TABLE messageA(
                    name nvarchar(550) NOT NULL PRIMARY KEY,
                    description nvarchar(550)
                )
                CREATE TABLE tbl_file(
                    fileExtention nvarchar(550),
                    fileName nvarchar(550),
                    fileDescription nvarchar(550)
                )
                CREATE TABLE fileImport(
                    FullFileName nvarchar(550) NOT NULL,
                    messageName nvarchar(550) NOT NULL
                )
                CREATE TABLE tbl_dts(
                    dts_id int NOT NULL,
                    day nvarchar(550) NOT NULL,
                    offset int NOT NULL
                )
                CREATE TABLE tbl_dts(
                    dts_id int NOT NULL,
                    day nvarchar(550) NOT NULL,
                    offset int NOT NULL
                )
                """)
            cnxn.close()
 
        submit_btn = tk.Button(top, text="Submit", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=insert_data)
        # submit_btn.place(x=150, y=105)
        
    def delete_databse_schema(self):
        self.root = tk.Tk()
        self.root.title("Database Name delete")
        self.root.geometry('300x100')

        self.database_combobox = ttk.Combobox(self.root, width=25, state="readonly")
        self.database_combobox.place(x=60, y=20)
        self.show_database_names()
        
        self.delete_button = tk.Button(self.root, font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white",text="Delete Database", command=self.delete_selected_database)
        # self.delete_button.place(x=100, y=70)

    def show_database_names(self):
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE={};Trusted_Connection=yes;')
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sys.databases")
            database_names = [row[0] for row in cursor.fetchall()]
            self.database_combobox['values'] = database_names

    def delete_selected_database(self):
        selected_database = self.database_combobox.get()
        if not selected_database:
            return
        try:
            server_name = "DP-ANKIT-PTC\MSSQLSERVER01"
            connection_string = "Driver=SQL Server;Server={};Database={};Trusted_Connection=Yes;"
            cnxn = pyodbc.connect(connection_string.format(server_name, "master"), autocommit=True)
            cnxn.cursor().execute(f"DROP DATABASE {selected_database}")
            cnxn.close()
            self.database_combobox.set('')
            self.show_database_names()
        except pyodbc.Error as err:
            print(f"Error: {err}")

      #######################################    uploaded file #############################################   
    def open_file(self):
        # global file_path_upload
        # file_path_upload = filedialog.askopenfilename()
        # file_name = os.path.basename(file_path_upload)
        # self.canvas.itemconfigure("file_text", text=file_name)

        window = tk.Tk()
        window.title("Select Database New Upload")
        window.geometry('200x100')
        
        self.global_combobox_data = []
        
        self.combobox_database_shown_mainframe = ttk.Combobox(window)
        self.combobox_database_shown_mainframe.place(x=30, y=20)

        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE={};Trusted_Connection=yes;')
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sys.databases")
        database_names1 = [row[0] for row in cursor.fetchall()]
        self.combobox_database_shown_mainframe['values'] = database_names1
        
        self.upload_data_button = tk.Button(window, font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white",
                                            text="Upload Database", command=self.select_and_upload_database)
        # self.upload_data_button.place(x=60, y=70)

    def select_and_upload_database(self):
        global database_name_data1
        selected_value = self.combobox_database_shown_mainframe.get()
        self.global_combobox_data.append(selected_value)
        database_name_data1 = self.global_combobox_data

        # print(database_name_data1, 'dfghm,./hdcnvbnm')

        file_name = self.combobox_database_shown_mainframe.get()
        self.canvas.itemconfigure("file_text", text=file_name)
 

class data_from_main_list(tk.Frame):
    def __init__(self, parent):
        tk.Frame.__init__(self)
    @staticmethod
    def main_list():
        global database_name_data1
        # print(database_name_data1,'fghfhkjhkml/;kjlfs3546788')
        return database_name_data1
        

if __name__ == "__main__":
    MainApplication()


# def open():
#     IMS = tk.Tk()
#     IMS.title("Information Management System")
#     IMS.geometry("500x500+450+100")
#     IMS.iconbitmap("logo2.ico")
#     IMS.resizable(False, False)
#     IMS.maxsize(500, 500)
#     IMS.minsize(500, 500)
#     # Create a fullscreen window
#     # IMS.attributes('-fullscreen', True)
#     # transparent window
#     # IMS.attributes('-alpha', 0.5)
#     MainApplication(IMS).pack(side="top", fill="both", expand=True)
#     # IMS mainloop, runs infinitely
#     IMS.mainloop()
# open()
