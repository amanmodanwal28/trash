import main
import tkinter as tk
from tkinter import *
import tkinter.ttk
from tkinter import messagebox
import pyodbc
import sqlite3
import tkinterDnD
class MainApplication2:
    def __init__(self):

        self.destroy_all_list_2 = None
        self.save_data_in_table_dis = []
        self.row_ID = None
        self.save_button = None
        self.route = tkinterDnD.Tk()
        # self.route = tk.Tk()
        self.route.geometry("900x600+230+40")
        self.route.title("Route")
        self.route.iconbitmap("logo2.ico")
        self.route.configure(bg="MediumPurple4")
        self.route.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.route.resizable(False, False)
        self.route.maxsize(900, 600)
        self.route.minsize(900, 600)
        ########################################## style for combobox ##################################################
        self.s = tkinter.ttk.Style(self.route)
        self.s.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        self.s.configure('Treeview.Heading', background="light gray")
        self.data1 = ""
        ################################################################################################################
        ##################################### frames ###################################################################
        self.left_frame = LabelFrame(self.route, bd=4, bg='light gray', relief=RIDGE, padx=2, text='Station List',
                                     font=('times new roman', 13, "bold"), fg="red")
        self.left_frame.place(x=10, y=30, height=540, width=262)

        self.right_frame1 = LabelFrame(self.route, bd=4, bg='light gray', relief=RIDGE, padx=2, text='Route List',
                                       font=('times new roman', 13, "bold"), fg="red")
        self.right_frame1.place(x=330, y=30, height=60, width=480)

        self.right_frame2 = LabelFrame(self.route, bd=4, bg='light gray', relief=RIDGE, padx=2, text='Stop Locations',
                                       font=('times new roman', 13, "bold"), fg="red")
        self.right_frame2.place(x=330, y=105, height=465, width=550)

        ########################################## button for delete and insert ########################################
        self.insert_data_button = Button(self.route, text=" > ", font=('arial', 13, 'bold'),
                                         bg="cyan", fg="black", cursor='hand2', command=self.Insert_data_right_treeview)
        self.insert_data_button.place(x=284, y=77)
        self.delete_data_button = Button(self.route, text=" < ", font=('arial', 13, 'bold'),
                                         bg="cyan", fg="black", command=self.delete_data, cursor='hand2')
        self.delete_data_button.place(x=284, y=127)
        ########################################## right frame combobox ################################################
        self.combobox_route_list = tkinter.ttk.Combobox(self.right_frame1, font=("arial", 13, 'bold'), width=55)
        self.combobox_route_list.bind("<<ComboboxSelected>>", self.data_in_right_treeview)
        self.combobox_route_list.pack()
        # self.show_route_in_combobox()
        ########################################## scroll bar and search (left frame) ########################
        self.search_label = Label(self.left_frame, font=('arial', 11, 'bold'), text="Search : ", bg="white")
        self.search_label.place(x=0, y=0)
        self.search_entry = tkinter.ttk.Entry(self.left_frame, font=('arial', 11, 'bold'), width=22)
        self.search_entry.place(x=69, y=0)
        self.search_entry.bind("<Key>", self.search_items_in_listbox)

        def drag_command(event):
            for selected_item in self.station_table.selection():
                item = self.station_table.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "["+record[0]+"]"

        self.table_station = tk.Frame(self.left_frame)
        self.table_station.place(x=0, y=26, height=490, width=250)
        self.scroll_y = tk.Scrollbar(self.table_station, orient=VERTICAL)
        self.station_table = tkinter.ttk.Treeview(self.table_station, columns="Stat", yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.scroll_y.config(command=self.station_table.yview)
        self.station_table.heading("Stat", text="Station")
        self.station_table.pack(fill=BOTH, expand=1)
        self.station_table["show"] = "headings"
        self.show_data_in_station_table()
        self.station_table.register_drag_source("*")
        self.station_table.bind("<Return>", self.Insert_data_right_treeview)
        self.station_table.bind("<<DragInitCmd>>", drag_command)
    ########################################### scroll bar in (right frame) ############################################
        def scroll_wheel(event):
            return 'break'

        def on_scroll(*args):
            self.stop_location_table.yview(*args)
            # print(*args)
            if self.destroy_all_list_2:
                if self.row_ID:
                    self.column_box_2 = self.stop_location_table.bbox(self.row_ID, self.column)
                    print(self.column_box_2)
                    try:
                        self.destroy_all_list_2.place(x=self.column_box_2[0], y=self.column_box_2[1],
                                                      w=self.column_box_2[2], h=self.column_box_2[3])
                    except IndexError:
                        self.destroy_all_list_2.place_forget()


        self.table_stop_location_frame = tk.Frame(self.right_frame2)
        self.table_stop_location_frame.place(x=0, y=0, height=435, width=520)
        self.stop_scroll_y = tk.Scrollbar(self.right_frame2, orient=VERTICAL, command=on_scroll)
        self.stop_location_table = tkinter.ttk.Treeview(self.right_frame2, columns=("or", "Stat", "des"), yscrollcommand=self.stop_scroll_y.set, show="headings")
        self.stop_scroll_y.pack(side=RIGHT, fill=Y)
        # self.stop_scroll_y.config(command=self.stop_location_table.yview)
        self.stop_location_table.heading("or", text="Order")
        self.stop_location_table.column("or", width=25)
        self.stop_location_table.heading("Stat", text="Station")
        self.stop_location_table.column("Stat", width=25, anchor='c')
        self.stop_location_table.heading("des", text="Distance")
        self.stop_location_table.column("des", width=25, anchor='c')
        self.stop_location_table.pack(fill=BOTH, expand=1)
        self.stop_location_table.bind("<ButtonRelease>", self.get_stop_loc_treeview)
        # self.stop_location_table.bind("<Double-1>", self.double_click_distance)
        self.stop_location_table.bind('<MouseWheel>', scroll_wheel)
        self.stop_location_table.register_drop_target("*")
        self.stop_location_table.bind("<<Drop>>", self.Insert_data_right_treeview)
    ############################################## button for add station journey in combobox #############################
        self.add_journey_in_combobox_button = Button(self.route, font=('arial', 20, 'bold'), bg="cyan", fg="black", text='+', command=self.add_journey_in_combobox, cursor='hand2')
        self.add_journey_in_combobox_button.place(x=830, y=39, height=50)
        self.show_route_in_combobox()
        self.route.mainloop()

    def show_route_in_combobox(self):
        print(91)
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT routeID,routeName FROM tbl_routes")
        self.table_name = my_cursor.fetchall()
        print(self.table_name)
        self.m = []
        for j in self.table_name:
            p = list(j)
            self.m.append(p[1])
        self.combobox_route_list["value"] = self.m
        if self.m:
            self.combobox_route_list.set(self.m[0])
            self.data_in_right_treeview()
        else:
            self.combobox_route_list.set("service")

    def combobox_routeID(self):
        self.routeID = dict(self.table_name)
        # print(self.routeID)
        for i in self.routeID:
            if self.routeID[i] == self.combobox_route_list.get():
                self.routeID_variable = i
                return self.routeID_variable

############################################## get data form combobox in right treeview##################
    def data_in_right_treeview(self, event=""):
        self.save_data_in_table_dis.clear()
        routeID_NUM = self.combobox_routeID()
        print(106)
        if self.destroy_all_list_2:
            self.destroy_all_list_2.destroy()
            self.row_ID = None
            self.destroy_all_list_2 = None
        if self.save_button:
            self.save_button.destroy()
            self.cancel_button.destroy()
            self.save_button = None


        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        sql_query = f'''select r.stopOrder,s.shortName, r.stationID from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={routeID_NUM} order by r.stopOrder'''
        my_cursor.execute(sql_query)
        self.data_tree = my_cursor.fetchall()
        if len(self.data_tree) != 0:
            self.stop_location_table.delete(*self.stop_location_table.get_children())
            for i in range(len(self.data_tree)):
                if i <= len(self.data_tree) - 1:
                    if self.data_tree[i][0] == 1:
                        stop_dis = (self.data_tree[i][0], self.data_tree[i][1], "0.0", self.data_tree[i][2])
                        self.stop_location_table.insert("", END, values=list(stop_dis))
                    else:
                        my_cursor.execute(
                            f"select distance from tbl_stationDistance where stationID1={self.data_tree[i - 1][2]} and stationID2={self.data_tree[i][2]}")
                        data1 = my_cursor.fetchall()
                        print(data1)
                        if len(data1) == 0:
                            my_cursor.execute(
                                f"select distance from tbl_stationDistance where stationID1={self.data_tree[i][2]} and stationID2={self.data_tree[i - 1][2]}")
                            data2 = my_cursor.fetchall()
                            print(data2)
                            if data2:
                                stop_dis = (self.data_tree[i][0], self.data_tree[i][1], data2[0][0], self.data_tree[i][2])
                                self.stop_location_table.insert("", END, values=list(stop_dis))
                            else:
                                stop_dis = (self.data_tree[i][0], self.data_tree[i][1], "0.0", self.data_tree[i][2])
                                self.stop_location_table.insert("", END, values=list(stop_dis))
                        else:
                            stop_dis = (self.data_tree[i][0], self.data_tree[i][1], data1[0][0], self.data_tree[i][2])
                            self.stop_location_table.insert("", END, values=list(stop_dis))
            conn.commit()
        else:
            self.stop_location_table.delete(*self.stop_location_table.get_children())
        conn.close()
    def show_data_in_station_table(self):
        print(122)
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute("select * from tbl_station")
        data = my_cursor.fetchall()
        if len(data) != 0:
            self.station_table.delete(*self.station_table.get_children())
            for i in data:
                self.station_table.insert("", END, values=list(i))
            conn.commit()
        conn.close()
    def search_items_in_listbox(self, event=""):
        print(135)
        if self.search_entry.get() == "":
            self.show_data_in_station_table()
        else:
            try:
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute("select * from tbl_station where shortName LIKE '%" + str(self.search_entry.get()) + "%'")
                data = my_cursor.fetchall()

                if len(data) != 0:
                    self.station_table.delete(*self.station_table.get_children())
                    for i in data:
                        self.station_table.insert("", END, values=list(i))
                    conn.commit()
                conn.close()
            except Exception as es:
                messagebox.showerror("Error", f"Due To:{str(es)}", parent=self.route)

        ################################### get data in entry box from MySql #######################################
    def Insert_data_right_treeview(self, event=""):
        print(156)

        routeID_num = self.combobox_routeID()
        if self.stop_location_table.focus() == "":
            self.cursor_row1 = self.station_table.focus()
            self.content = self.station_table.item(self.cursor_row1)
            self.data = self.content["values"]
            count = int(len(self.stop_location_table.get_children())) + 1
            try:
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute(f"insert into tbl_routeStops values(?,?,?,?,?)",
                                  (routeID_num, count, count, self.data[1], "Empty"))

                my_cursor.execute(f"select journeyID from tbl_journeys where routeID={routeID_num}")
                journeyID_sql = my_cursor.fetchall()
                if len(journeyID_sql) > 0:
                    for i in range(len(journeyID_sql)):
                        my_cursor.execute(f"insert into tbl_journeyStops values(?,?,?,?,?,?,?,?,?,?,?)",
                                          (journeyID_sql[i][0], count, self.data[5], self.data[0], "00:00", "00:00", "-None-", " ", "-None-", "-None-", 0))
                conn.commit()
                conn.close()
                self.data_in_right_treeview()
            except Exception as es:
                print("not saved", f"due to:{str(es)}")
        else:
            self.cursor_row1 = self.station_table.focus()
            self.content = self.station_table.item(self.cursor_row1)
            self.data = self.content["values"]
            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            my_cursor.execute(f"UPDATE tbl_routeStops SET stopOrder = stopOrder + 1, routeStopID = stopOrder + 1 WHERE stopOrder >= {self.data1[0]} and routeID={routeID_num}")
            my_cursor.execute(f"insert into tbl_routeStops values(?,?,?,?,?)",
                              (routeID_num, self.data1[0], self.data1[0], self.data[1], "no distance"))
            my_cursor.execute(f"select journeyID from tbl_journeys where routeID={routeID_num}")
            journeyID_sql = my_cursor.fetchall()
            if len(journeyID_sql) > 0:
                for i in range(len(journeyID_sql)):
                    my_cursor.execute(
                        f"UPDATE tbl_journeyStops SET routeStopID = routeStopID + 1 WHERE routeStopID >= {self.data1[0]} and journeyID={journeyID_sql[i][0]}")
                    my_cursor.execute(f"insert into tbl_journeyStops values(?,?,?,?,?,?,?,?,?,?,?)",
                                      (journeyID_sql[i][0], self.data1[0], self.data[5], self.data[0], "00:00", "00:00",
                                       "-None-", " ", "-None-", "-None-", 0))
            conn.commit()
            conn.close()
            self.data_in_right_treeview()
    def tbl_stationDistance_update_insert(self, event=""):
        for data2, data1, destroy_all_list in self.save_data_in_table_dis:
            conn1 = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn1.cursor()
            my_cursor.execute(
                f"select * from tbl_stationDistance where stationID1 ={data2} and stationID2 = {data1}")
            tbl_stationDistance_data = my_cursor.fetchall()

            # if self.data1[2] == "0.0":
            if not tbl_stationDistance_data:
                conn1 = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn1.cursor()
                my_cursor.execute(f"insert into tbl_stationDistance values(?,?,?)",
                                  (data2, data1, destroy_all_list))
                my_cursor.execute(
                    f"UPDATE tbl_routeStops SET [distanceFromPrev] = {destroy_all_list} WHERE [stationID] = {data1}")
                conn1.commit()
                conn1.close()
            else:
                conn1 = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn1.cursor()
                my_cursor.execute(
                    f"UPDATE tbl_stationDistance SET distance = {destroy_all_list} WHERE stationID1 ={data2} and stationID2 = {data1}")
                my_cursor.execute(
                    f"UPDATE tbl_routeStops SET [distanceFromPrev] = {destroy_all_list} WHERE [stationID] = {data1}")
                conn1.commit()
                conn1.close()
            # self.stop_location_table.set(self.row_ID, column=self.column, value=f"{self.destroy_all_list_2.get()}.0")
        self.save_button.destroy()
        self.cancel_button.destroy()
        self.save_button = None
        self.destroy_all_list_2.destroy()
        self.destroy_all_list_2 = None
        self.save_data_in_table_dis.clear()
        # conn1 = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn1.cursor()
        # my_cursor.execute(
        #     f"select * from tbl_stationDistance where stationID1 ={self.data2[3]} and stationID2 = {self.data1[3]}")
        # tbl_stationDistance_data = my_cursor.fetchall()
        #
        # # if self.data1[2] == "0.0":
        # if not tbl_stationDistance_data:
        #     conn1 = sqlite3.connect("triggers_abhay.db")
        #     my_cursor = conn1.cursor()
        #     my_cursor.execute(f"insert into tbl_stationDistance values(?,?,?)",
        #                       (self.data2[3], self.data1[3], self.destroy_all_list_2.get()))
        #     my_cursor.execute(
        #         f"UPDATE tbl_routeStops SET [distanceFromPrev] = {self.destroy_all_list_2.get()} WHERE [stationID] = {self.data1[3]}")
        #     conn1.commit()
        #     # self.data_in_right_treeview()
        #     conn1.close()
        # else:
        #     conn1 = sqlite3.connect("triggers_abhay.db")
        #     my_cursor = conn1.cursor()
        #     my_cursor.execute(
        #         f"UPDATE tbl_stationDistance SET distance = {self.destroy_all_list_2.get()} WHERE stationID1 ={self.data2[3]} and stationID2 = {self.data1[3]}")
        #     my_cursor.execute(
        #         f"UPDATE tbl_routeStops SET [distanceFromPrev] = {self.destroy_all_list_2.get()} WHERE [stationID] = {self.data1[3]}")
        #     conn1.commit()
        #     # self.data_in_right_treeview()
        #     conn1.close()
        # # self.stop_location_table.set(self.row_ID, column=self.column, value=f"{self.destroy_all_list_2.get()}.0")
        #
        # self.save_button = None
        # # self.destroy_all_list_2.destroy()
        # # self.row_ID = None
        # # self.destroy_all_list_2 = None

    def get_stop_loc_treeview(self, event=""):
        print(189)

        if self.destroy_all_list_2:
            # self.save_data_in_table_dis.append((self.data2[3], self.data1[3], self.destroy_all_list_2.get()))
            if self.destroy_all_list_2.get().count("."):
               self.stop_location_table.set(self.row_ID, column=self.column, value=f"{self.destroy_all_list_2.get()}")
               if not self.save_data_in_table_dis.count((self.data2[3], self.data1[3], self.destroy_all_list_2.get())):
                   self.save_data_in_table_dis.append((self.data2[3], self.data1[3], self.destroy_all_list_2.get()))
            else:
                self.stop_location_table.set(self.row_ID, column=self.column, value=f"{self.destroy_all_list_2.get()}.0")
                if not self.save_data_in_table_dis.count((self.data2[3], self.data1[3], self.destroy_all_list_2.get())):
                    self.save_data_in_table_dis.append((self.data2[3], self.data1[3], self.destroy_all_list_2.get()))
            print(self.save_data_in_table_dis, "hhhhhhhh")
            self.destroy_all_list_2.destroy()
            self.destroy_all_list_2 = None
        self.cursor_row2 = self.stop_location_table.focus()
        if not self.cursor_row2:
            pass
        else:
            self.cursor_row3 = self.stop_location_table.get_children().index(self.cursor_row2) - 1
            # print(self.stop_location_table.get_children()[self.cursor_row3], 33333333333333333333)
            self.content1 = self.stop_location_table.item(self.cursor_row2)
            self.content2 = self.stop_location_table.item(self.stop_location_table.get_children()[self.cursor_row3])
            self.data1 = self.content1["values"]
            self.data2 = self.content2["values"]

        # self.column2 = self.stop_location_table.identify_column(event.x)
        # self.row_ID2 = self.stop_location_table.focus()


        # for item in self.stop_location_table.get_children():
        #     all_name = self.stop_location_table.item(item)
        #     print(all_name["values"])




        if not self.data1:
            pass
        else:
            if self.data1[0] == 1:
                messagebox.showinfo(self.data1[1], "No value can be included in first position ", parent=self.route)
            else:
                self.column = self.stop_location_table.identify_column(event.x)  # #1, #2
                self.row_ID = self.stop_location_table.focus()  # I001, I002
                self.item_data = self.stop_location_table.item(self.row_ID)
                self.item_text_value = self.item_data.get("values")
                # print(self.item_text_value)
                self.column_box = self.stop_location_table.bbox(self.row_ID, self.column)
                if self.column == "#3":
                    # combiTrigger_list = tkinter.ttk.Combobox(self.right_frame2)
                    combiTrigger_list = tkinter.ttk.Entry(self.right_frame2, font=('arial', 11, 'bold'), width=22,
                                                          justify=CENTER)
                    combiTrigger_list.insert(0, self.item_text_value[2])
                    combiTrigger_list.focus_force()
                    # combiTrigger_list.bind('<Return>', self.tbl_stationDistance_update_insert)
                    combiTrigger_list.place(x=self.column_box[0], y=self.column_box[1], w=self.column_box[2],
                                            h=self.column_box[3])
                    self.destroy_all_list_2 = combiTrigger_list
                    # if not self.save_data_in_table_dis.count((self.data2[3], self.data1[3], self.destroy_all_list_2.get())):
                    #     self.save_data_in_table_dis.append((self.data2[3], self.data1[3], self.destroy_all_list_2.get()))

                    if not self.save_button:
                        self.save_button = Button(self.route, text="save", font=('arial', 8, 'bold'),
                                                  bg="cyan", fg="black", cursor='hand2', command=self.tbl_stationDistance_update_insert)
                        self.save_button.place(x=780, y=573)
                        self.cancel_button = Button(self.route, text="cancel", font=('arial', 8, 'bold'),
                                                    bg="cyan", fg="black", cursor='hand2', command=self.data_in_right_treeview)
                        self.cancel_button.place(x=834, y=573)
                    # else:
                    #     self.save_button.destroy()
                    #     self.cancel_button.destroy()
                    #     self.save_button = None
                    #     self.cancel_button = None





        # if self.destroy_all_list_2:
        #     if self.row_ID:
        #         if self.row_ID2 != self.row_ID:
        #             print("get_stop_loc_treeview", self.data2[2], self.data1[2])
        #             print(self.destroy_all_list_2.get())
        #
        #             # if self.data1[2] == "0.0":
        #             #     conn1 = sqlite3.connect("triggers_abhay.db")
        #             #     my_cursor = conn1.cursor()
        #             #     my_cursor.execute(f"insert into tbl_stationDistance values(?,?,?)",
        #             #                       (self.data2[3], self.data1[3], self.destroy_all_list_2.get()))
        #             #     my_cursor.execute(
        #             #         f"UPDATE tbl_routeStops SET [distanceFromPrev] = {self.destroy_all_list_2.get()} WHERE [stationID] = {self.data1[3]}")
        #             #     conn1.commit()
        #             #     self.data_in_right_treeview()
        #             #     conn1.close()
        #             # else:
        #             #     conn1 = sqlite3.connect("triggers_abhay.db")
        #             #     my_cursor = conn1.cursor()
        #             #     my_cursor.execute(
        #             #         f"UPDATE tbl_stationDistance SET distance = {self.destroy_all_list_2.get()} WHERE stationID1 ={self.data2[3]} and stationID2 = {self.data1[3]}")
        #             #     my_cursor.execute(
        #             #         f"UPDATE tbl_routeStops SET [distanceFromPrev] = {self.destroy_all_list_2.get()} WHERE [stationID] = {self.data1[3]}")
        #             #     conn1.commit()
        #             #     self.data_in_right_treeview()
        #             #     conn1.close()
        #             self.destroy_all_list_2.destroy()
        #             self.destroy_all_list_2 = None
        #             self.row_ID = None

        # self.row_ID2 = self.stop_location_table.focus()
        # self.cursor_row2 = self.stop_location_table.focus()
        # # print(self.cursor_row2, "ssssssssssss")
        # if not self.cursor_row2:
        #     pass
        # else:
        #     self.cursor_row3 = self.stop_location_table.get_children().index(self.cursor_row2) - 1
        #     # print(self.stop_location_table.get_children()[self.cursor_row3], 33333333333333333333)
        #     self.content1 = self.stop_location_table.item(self.cursor_row2)
        #     self.content2 = self.stop_location_table.item(self.stop_location_table.get_children()[self.cursor_row3])
        #     self.data1 = self.content1["values"]
        #     self.data2 = self.content2["values"]



    def delete_data(self):
        print(195)
        routeID_num = self.combobox_routeID()
        # print(routeID_num, "routeID")
        # print(self.data1[0], "stopOrder")
        if self.stop_location_table.focus() == "":
            messagebox.showerror("Error", "Select the file ", parent=self.route)
        else:
            conn1 = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn1.cursor()
            my_cursor.execute(f"delete from tbl_routeStops where stopOrder={self.data1[0]} and routeID={routeID_num}")
            my_cursor.execute(
                f"UPDATE tbl_routeStops SET stopOrder = stopOrder - 1, routeStopID = stopOrder - 1 WHERE stopOrder >= {self.data1[0]} and routeID={routeID_num}")
            my_cursor.execute(f"select journeyID from tbl_journeys where routeID={routeID_num}")
            journeyID_sql = my_cursor.fetchall()
            if len(journeyID_sql) > 0:
                for i in range(len(journeyID_sql)):
                    my_cursor.execute(
                        f"delete from tbl_journeyStops where routeStopID={self.data1[0]} and journeyID={journeyID_sql[i][0]}")
                    my_cursor.execute(
                        f"UPDATE tbl_journeyStops SET routeStopID = routeStopID - 1 WHERE routeStopID >= {self.data1[0]} and journeyID={journeyID_sql[i][0]}")
            conn1.commit()
            self.data_in_right_treeview()
            conn1.close()
            messagebox.showinfo("Delete", f"your {self.data1[1]} data has been deleted", parent=self.route)


    def double_click_distance(self, event=""):
        print(221)
        # self.row_ID2 = self.stop_location_table.focus()
        # self.cursor_row2 = self.stop_location_table.focus()
        # # print(self.cursor_row2, "ssssssssssss")
        # if not self.cursor_row2:
        #     pass
        # else:
        #     self.cursor_row3 = self.stop_location_table.get_children().index(self.cursor_row2) - 1
        #     # print(self.stop_location_table.get_children()[self.cursor_row3], 33333333333333333333)
        #     self.content1 = self.stop_location_table.item(self.cursor_row2)
        #     self.content2 = self.stop_location_table.item(self.stop_location_table.get_children()[self.cursor_row3])
        #     self.data1 = self.content1["values"]
        #     self.data2 = self.content2["values"]

        if not self.data1:
            pass
        else:
            if self.data1[0] == 1:
                messagebox.showinfo(self.data1[1], "No value can be included in first position ", parent=self.route)
            else:
                self.column = self.stop_location_table.identify_column(event.x)  # #1, #2
                self.row_ID = self.stop_location_table.focus()  # I001, I002
                self.item_data = self.stop_location_table.item(self.row_ID)
                self.item_text_value = self.item_data.get("values")
                # print(self.item_text_value)
                self.column_box = self.stop_location_table.bbox(self.row_ID, self.column)
                if self.column == "#3":
                    # combiTrigger_list = tkinter.ttk.Combobox(self.right_frame2)
                    combiTrigger_list = tkinter.ttk.Entry(self.right_frame2, font=('arial', 11, 'bold'), width=22, justify=CENTER)
                    combiTrigger_list.insert(0, self.item_text_value[2])
                    combiTrigger_list.focus_force()
                    # combiTrigger_list.bind('<Return>', self.tbl_stationDistance_update_insert)
                    combiTrigger_list.place(x=self.column_box[0], y=self.column_box[1], w=self.column_box[2],
                                            h=self.column_box[3])
                    self.destroy_all_list_2 = combiTrigger_list
                
                # top = Toplevel()
                # top.geometry("300x150+600+300")
                # top.title(f"Distance : {self.data1[1]}")
                # distance_label = Label(top, text="Distance : ", font=("arial", 13, "bold"))
                # distance_label.place(x=10, y=20)
                #
                # def on_exit():
                #     top.destroy()
                #     top.grab_release()
                #
                # top.grab_set()
                # top.protocol("WM_DELETE_WINDOW", on_exit)
                #
                # ##########################################
                # ##### for entry only number value ########
                # def only_numbers(char):  ########
                #     return char.isdigit()  ########
                #     ########
                #
                # validation = top.register(only_numbers)  ###
                # ##########################################
                # distance_entry = tkinter.ttk.Entry(top, font=("arial", 13, "bold"), width=20, validate="key",
                #                                    validatecommand=(validation, '%S'))
                # distance_entry.place(x=100, y=20)
                #
                # def save_distance():
                #     print(242)
                #     if self.data1[2] == "no data":
                #         conn1 = sqlite3.connect("triggers_abhay.db")
                #         my_cursor = conn1.cursor()
                #         my_cursor.execute(f"insert into tbl_stationDistance values(?,?,?)",
                #                           (self.data2[3], self.data1[3], distance_entry.get()))
                #         my_cursor.execute(
                #             f"UPDATE tbl_routeStops SET [distanceFromPrev] = {distance_entry.get()} WHERE [stationID] = {self.data1[3]}")
                #         conn1.commit()
                #         self.data_in_right_treeview()
                #         conn1.close()
                #     else:
                #         conn1 = sqlite3.connect("triggers_abhay.db")
                #         my_cursor = conn1.cursor()
                #         my_cursor.execute(
                #             f"UPDATE tbl_stationDistance SET distance = {distance_entry.get()} WHERE stationID1 ={self.data2[3]} and stationID2 = {self.data1[3]}")
                #         my_cursor.execute(
                #             f"UPDATE tbl_routeStops SET [distanceFromPrev] = {distance_entry.get()} WHERE [stationID] = {self.data1[3]}")
                #         conn1.commit()
                #         self.data_in_right_treeview()
                #         conn1.close()
                #     top.destroy()
                #
                # distance_button_add = Button(top, text=" Add Distance ", font=('arial', 9, 'bold'), bg="#7C7CFC",
                #                              fg="white", command=save_distance)
                # distance_button_add.place(x=100, y=70)
                # top.mainloop()




    def add_journey_in_combobox(self):
        print(254)
        self.route.destroy()
        self.top1 = tk.Tk()
        self.top1.geometry("250x453+600+150")
        self.top1.title("List of Route")
        self.top1.iconbitmap("logo2.ico")
        def on_exit():
            self.top1.destroy()
            MainApplication2()
        self.top1.protocol("WM_DELETE_WINDOW", on_exit)
        ########################################## style for combobox ##################################################
        self.s = tkinter.ttk.Style(self.top1)
        self.s.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        self.s.configure('Treeview.Heading', background="light gray")
        ######################################## done style #################################################
        self.journey_combobox_frame = tk.Frame(self.top1)
        self.journey_combobox_frame.place(x=0, y=0, height=400, width=250)
        self.combobox_scroll_y = tk.Scrollbar(self.journey_combobox_frame, orient=VERTICAL)
        self.journey_combobox_treeview = tkinter.ttk.Treeview(self.journey_combobox_frame, columns="jou", yscrollcommand=self.combobox_scroll_y.set)
        self.combobox_scroll_y.pack(side=RIGHT, fill=Y)
        self.combobox_scroll_y.config(command=self.journey_combobox_treeview.yview)
        self.journey_combobox_treeview.heading("jou", text="Journey")
        self.journey_combobox_treeview.pack(fill=BOTH, expand=1)
        self.journey_combobox_treeview["show"] = "headings"
        ################################################# done ############################################################
        journey_route_label = Label(self.top1, text="Route :", font=("arial", 13, "bold"))
        journey_route_label.place(x=0, y=404)
        journey_route_entry = tkinter.ttk.Entry(self.top1, font=("arial", 13, "bold"), width=18)
        journey_route_entry.place(x=64, y=404)
        ########################################## right frame combobox ################################################

        def combobox_routeID2():
            self.routeID2 = dict(self.table_name)
            if not self.data4:
                pass
            else:
                for i in self.routeID2:
                    if self.routeID2[i] == self.data4[0]:
                        self.routeID_variable2 = i
                        return self.routeID_variable2
            # print(self.routeID)

        def route_journey_focus(event=""):
            print(287)
            self.cursor_row4 = self.journey_combobox_treeview.focus()
            self.content4 = self.journey_combobox_treeview.item(self.cursor_row4)
            self.data4 = self.content4["values"]
            if self.data4:
                self.count_journey_treeview = int(self.data4[1])

        self.journey_combobox_treeview.bind("<ButtonRelease>", route_journey_focus)




        def show_route_list_in_treeview():
            print(297)
            conn_1 = sqlite3.connect("triggers_abhay.db")
            my_cursor_1 = conn_1.cursor()
            my_cursor_1.execute("SELECT routeName, routeID FROM tbl_routes")
            self.table_name_1 = my_cursor_1.fetchall()
            if len(self.table_name_1) != 0:
                self.journey_combobox_treeview.delete(*self.journey_combobox_treeview.get_children())
                for i1 in self.table_name_1:
                    self.journey_combobox_treeview.insert("", END, values=list(i1))
                conn_1.commit()
            else:
                self.journey_combobox_treeview.delete(*self.journey_combobox_treeview.get_children())
            conn_1.close()
        show_route_list_in_treeview()
        ####################################### done ##############################################
        def add_journey_route(event=""):
            print(311)
            count = len(self.journey_combobox_treeview.get_children())+1
            conn1 = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn1.cursor()
            my_cursor.execute("select routeID from tbl_routes order by routeID desc limit 1")
            data = my_cursor.fetchall()
            data_2 = 1
            if data:
                data_2 = data[0][0]
                my_cursor.execute(f"insert into tbl_routes values({data_2+1},'{journey_route_entry.get()}')")
            else:
                my_cursor.execute(f"insert into tbl_routes values({data_2},'{journey_route_entry.get()}')")
            conn1.commit()
            conn1.close()
            journey_route_entry.delete(0, END)
            show_route_list_in_treeview()  # route list treeview fetchall call
            # self.show_route_in_combobox()
        journey_route_entry.bind("<Return>", add_journey_route)
        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()
        self.journey_combobox_treeview.bind("<Button-3>", menu_popup)
        def delete_journey_route(event=""):
            print(388)
            try:
                if not self.count_journey_treeview:
                    pass
                else:
                    conn1 = sqlite3.connect("triggers_abhay.db")
                    my_cursor = conn1.cursor()
                    sql_data = f"select routeID from tbl_routes order by routeID desc limit 1"
                    my_cursor.execute(sql_data)
                    route_id_nim = my_cursor.fetchall()
                    if route_id_nim:
                        if route_id_nim[0][0] == self.count_journey_treeview:
                            # print(route_id_nim[0][0], "dfghjk")
                            sql_data = f"DELETE FROM tbl_routes WHERE routeID={self.count_journey_treeview}"
                            my_cursor.execute(sql_data)
                        else:
                            sql_data = f"update tbl_routes set routeName = 'Empty' WHERE routeID={self.count_journey_treeview}"
                            my_cursor.execute(sql_data)
                    my_cursor.execute(f"DELETE FROM tbl_routeStops WHERE routeID={self.count_journey_treeview}")
                    my_cursor.execute(f"select journeyID from tbl_journeys where routeID={self.count_journey_treeview}")
                    journeyID_sql = my_cursor.fetchall()
                    if len(journeyID_sql) > 0:
                        for i in range(len(journeyID_sql)):
                            my_cursor.execute(f"delete from tbl_journeyStops where journeyID={journeyID_sql[i][0]}")

                    my_cursor.execute(f"delete from tbl_journeys where routeID={self.count_journey_treeview}")

                    conn1.commit()
                    conn1.close()
                    show_route_list_in_treeview()
            except AttributeError:
                pass




        def edit_journey_route():
            print(401)
            if not self.data4:
                pass
            else:
                top_edit = tk.Tk()
                top_edit.geometry("300x150+600+300")
                top_edit.title(f"Edit : {self.data4[0]}")
                edit_label = Label(top_edit, text="Route : ", font=("arial", 13, "bold"))
                edit_label.place(x=10, y=20)
                edit_entry = tkinter.ttk.Entry(top_edit, font=("arial", 13, "bold"), width=20)
                edit_entry.place(x=100, y=20)

                def edit_journey_number_treeview():
                    print(431)
                    conn1 = sqlite3.connect("triggers_abhay.db")
                    my_cursor = conn1.cursor()
                    sql1 = f"update tbl_routes set routeName='{edit_entry.get()}' where routeID={self.count_journey_treeview}"
                    my_cursor.execute(sql1)
                    conn1.commit()
                    conn1.close()
                    show_route_list_in_treeview()
                    top_edit.destroy()

                edit_button_add = Button(top_edit, text=" Edit ", font=('arial', 9, 'bold'), bg="#7C7CFC",
                                         fg="white", command=edit_journey_number_treeview)
                edit_button_add.place(x=100, y=70)
                top_edit.mainloop()

        ######################################## menu bar ###################################################
        self.menu = tk.Menu(self.top1)
        self.Edit = tk.Menu(self.menu, tearoff=0)
        self.Edit.add_command(label="Add")
        self.Edit.add_command(label="Edit", command=edit_journey_route)
        self.Edit.add_command(label="Delete", command=delete_journey_route)
        self.menu.add_cascade(label="Menu", menu=self.Edit)
        self.top1.config(menu=self.menu)
########################################################################################
        popup = Menu(self.top1, tearoff=0)
        popup.add_command(label="Delete", command=delete_journey_route)
        popup.add_command(label="Edit", command=edit_journey_route)
        ##################################################### done ###################################################
        self.top1.mainloop()
    def on_exit(self):
        self.route.destroy()
        main.MainApplication()

if __name__ == "__main__":
    MainApplication2()
