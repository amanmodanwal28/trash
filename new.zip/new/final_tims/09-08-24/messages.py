import tkinter.ttk
from tkinter import *
import shutil
import pyodbc
from tkinter import messagebox
import main
import tkinter as tk
import pygame
from pathlib import Path
from tkinter import filedialog as fd
import xml.etree.ElementTree as ET
import os
from customtkinter import CTkButton
import glob
from tkVideoPlayer import TkinterVideo
import sqlite3

# Define the class the application
class messages_data:
    # init method or constructor that call by instance variable
    def __init__(self):
        # tk.Tk is crate a window
        self.top = tk.Tk()
        # write a top title name line
        self.top.title('Tims : list of messages')
        # window frame geometry size (width,height,x-place,y-place)
        self.top.geometry("1107x570+150+40")
        self.top.iconbitmap("logo2.ico")
        # the background colour change by config
        self.top.configure(bg="lightsteelblue2")
        self.top.protocol("WM_DELETE_WINDOW", self.on_exit)

        ############################# ICO ###################
        #####################################################
        self.file_not_avl = "\u274E"  # ❎
        self.file_avl = "\u2705"  # ✅
        self.play_sound = "\u25B6"  # ▶
        self.play_sound_not_avl = "\u20E0"  # ⃠
        self.number_language = 0
        #####################################################
        #####################################################
        # self.top.grab_set()
        # Allowing root window to not change it's size according to user's need
        self.top.resizable(False, False)
        # Fixing the size of the root window No one can now expand the size of the root window than the specified one.
        self.top.maxsize(1107, 570)
        self.top.minsize(1107, 570)
        self.var_station_name = StringVar()
        self.s = tkinter.ttk.Style(self.top)
        self.s.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        self.s.configure('Treeview.Heading', background="light gray")
        self.message_type = LabelFrame(self.top, relief=RIDGE, bg='azure4', fg="red", bd=4)
        self.message_type.place(x=7, y=10, height=550, width=303)

        self.message_list_Label = Label(self.message_type, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message type :', width=24, anchor=NW)
        self.message_list_Label.place(x=0, y=0)

        self.message_list = LabelFrame(self.top, relief=RIDGE, bg='azure4', fg="red", bd=4)
        self.message_list.place(x=317, y=10, height=550, width=782)
        # self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
        #                                 text='Message list :', width=64, anchor=NW)
        # self.message_list_Label.place(x=0, y=0)

        self.var = IntVar()
        self.var.set(1)
        self.Prerecorded_mess = Radiobutton(self.message_type, variable=self.var, text='Prerecorded messages',
                                            font=('arial', 11, 'bold'), value=1, bg='azure4', activebackground='azure4', command=self.Prerecorded_mess_fun)
        self.Prerecorded_mess.place(x=10, y=50)

        self.text_mess = Radiobutton(self.message_type, variable=self.var, text='Text announcements',
                                     font=('arial', 11, 'bold'), value=2, bg='azure4', activebackground='azure4', command=self.text_announcements)
        self.text_mess.place(x=10, y=90)

        self.Voice_mess = Radiobutton(self.message_type, variable=self.var, text='Voice announcements',
                                      font=('arial', 11, 'bold'), value=3, bg='azure4', activebackground='azure4', command=self.Voice_announcements)
        self.Voice_mess.place(x=10, y=130)

        self.Publicity_mess = Radiobutton(self.message_type, variable=self.var, text='Publicity messages',
                                          font=('arial', 11, 'bold'), value=4, bg='azure4', activebackground='azure4', command=self.Publicity_messages)
        self.Publicity_mess.place(x=10, y=170)

        self.Welcome_mess = Radiobutton(self.message_type, variable=self.var, text='Welcome message',
                                        font=('arial', 11, 'bold'), value=5, bg='azure4', activebackground='azure4', command=self.Welcome_message)
        self.Welcome_mess.place(x=10, y=210)

        self.Jingle_mess = Radiobutton(self.message_type, variable=self.var, text='Jingle',
                                       font=('arial', 11, 'bold'), value=6, bg='azure4', activebackground='azure4', command=self.jingle_fun)
        self.Jingle_mess.place(x=10, y=250)
        self.Video_mess = Radiobutton(self.message_type, variable=self.var, text='Video messages',
                                      font=('arial', 11, 'bold'), value=7, bg='azure4', activebackground='azure4', command=self.Video_messages)
        self.Video_mess.place(x=10, y=290)

        self.Banner_mess = Radiobutton(self.message_type, variable=self.var, text='Banner messages',
                                       font=('arial', 11, 'bold'), value=8, bg='azure4', activebackground='azure4', command=self.Banner_messages)
        self.Banner_mess.place(x=10, y=330)

        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'), bg="cyan", fg="black", cursor='hand2')
        self.Add_new_button.place(x=15, y=380)

        self.Prerecorded_mess_fun()
        self.top.mainloop()
    def save_file_import(self, full_file_name, message_name):
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        # my_cursor.execute(f'''IF EXISTS(select * from [fileImport] where [messageName]='{message_name}')
        # SELECT * From [fileImport]
        # ElSE Insert into [fileImport] values('{full_file_name}','{message_name}')''')
        my_cursor.execute(f"select * from [fileImport] where [messageName]='{message_name}'")
        message_name_data = my_cursor.fetchall()
        if not message_name_data:
            my_cursor.execute(f"Insert into [fileImport] values('{full_file_name}','{message_name}')")
        conn.commit()
        conn.close()
    def text_toplevel(self, item_code="", column_num=-1, for_if=False):
        text_top = tk.Toplevel(self.top)
        text_top.grab_set()
        # text_top.protocol("WM_DELETE_WINDOW", lambda: text_top.destroy())
        text_top.geometry("500x356")
        if for_if:
            text_top.title(f"{item_code}{self.language_list[int(column_num-2)]}")
        else:
            text_top.title(f"{item_code}{self.language_list[int(column_num/3)]}")
        text_top.configure(bg="lightsteelblue2")
        Label(text_top, text="Enter/Modify your text here :", bg='lightsteelblue2', font=('arial', 10, 'bold')).place(x=5, y=5)
        text_fill = Text(text_top, borderwidth=3)
        text_fill.place(x=5, y=30, width=490, height=250)

        def open_text(file_name_path=""):
            if file_name_path:
                text_file = open(file_name_path, "r")
                content = text_file.read()
                text_fill.insert(END, content)
                text_file.close()
        if for_if:
            path_file = f"sqlData\\txt\\{item_code}{self.language_list[int(column_num -2)]}.TXT"
        else:
            path_file = f"sqlData\\txt\\{item_code}{self.language_list[int(column_num / 3)]}.TXT"
        files = glob.glob(path_file)
        # print(path_file, files)
        if len(files) > 0:
            open_text(file_name_path=path_file)
        def save_text():
            # print(item_code, self.language_list[int(column_num/3)])
            if for_if:
                pr_id_and_lang = f"{item_code}{self.language_list[int(column_num-2)]}.TXT"
            else:
                pr_id_and_lang = f"{item_code}{self.language_list[int(column_num/3)]}.TXT"
# print(text_fill.get(1.0, END) if len(text_fill.get(1.0, END)) > 1 else "no data")
            if len(text_fill.get(1.0, END)) > 1:
                self.save_file_import(full_file_name=item_code, message_name=pr_id_and_lang)
                text_file_data = open(f"sqlData/txt/{pr_id_and_lang}", "w")
                text_file_data.write(text_fill.get(1.0, END))
                text_file_data.close()
                text_top.destroy()
                self.language_station_table.set(self.row_ID, column=self.column_number, value="\u2705")

        def select_text_file():
            filetypes = (('TEXT files', '*.txt'), ('All files', '*.*'))
            filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=text_top)
            if filename:
                open_text(filename)
        def close_toplevel():
            text_top.destroy()
        # select_text_file = Button(text_top, text="Import from file ...", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white")
        # select_text_file.place(x=385, y=283)
        select_Import_file = CTkButton(text_top, text="Import from file ...", font=('arial', 15, 'bold'), text_color="black", command=select_text_file)
        select_Import_file.place(x=355, y=286)

        select_save_file = CTkButton(text_top, text="OK", font=('arial', 15, 'bold'), width=65, height=15, text_color="black", command=save_text)
        select_save_file.place(x=355, y=325)

        select_cancel_file = CTkButton(text_top, text="Cancel", font=('arial', 15, 'bold'), width=65, height=15, text_color="black", command=close_toplevel)
        select_cancel_file.place(x=430, y=325)
        text_top.mainloop()

    def Prerecorded_sql_data_treeview(self):
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(f"select * from messageA where name like'%PR%' order by name")
        name_data = my_cursor.fetchall()
        # print("Big{i}\u274E ==  ❎", "\u25B6  ==  ▶", "\u2705 ==  ✅", "\u20E0 ==  ⃠ ")
        list_for_value = ["a", "b"]
        self.language_station_table.delete(*self.language_station_table.get_children())
        for messageA, messageA2 in name_data:
            list_tree = []
            list_tree.clear()
            list_tree.append(messageA)
            list_tree.append(messageA2)
            for language in self.language_list[1::]:
                my_cursor.execute(
                    f"select [messageName] from [fileImport] where [messageName] like'%{messageA}{language}%' order by [FullFileName], [messageName]")
                name_data1 = my_cursor.fetchall()
                # print(name_data1)
                if len(name_data1) == 0:
                    list_tree.append("\u274E")
                    list_tree.append("\u274E")
                    list_tree.append("\u20E0")
                else:
                    for messageName in name_data1[::-1]:
                        if len(name_data1) != 2:
                            if messageName[0].find("MP3") > -1:
                                list_tree.append("\u274E")
                                list_tree.append("\u2705")
                                list_tree.append("\u25B6")
                            elif messageName[0].find("TXT") > -1:
                                list_tree.append("\u2705")
                                list_tree.append("\u274E")
                                list_tree.append("\u20E0")
                        else:
                            list_tree.append("\u2705")
                            if messageName[0].find("MP3") > -1:
                                list_tree.append("\u25B6")

            self.language_station_table.insert("", END, values=list_tree)
        conn.commit()
        conn.close()
    def entry_on_treeview(self, event=""):
        self.column_number = self.language_station_table.identify_column(event.x) ### with #1,#2,#3,....
        self.row_ID = self.language_station_table.focus() ### I001, I002, I003, ........
        # print(self.row_ID, self.column_number, "1111111111111111111111111111111111")
        self.item_data = self.language_station_table.item(self.row_ID)
        self.item_text_value = self.item_data.get("values")
        self.second_column_number = int(self.column_number[1]) - 1
        self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
        def on_focus_out(event):
            if not self.description_treeview.get() == self.item_text_value[self.second_column_number]:
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute(f"update messageA set [description]='{self.description_treeview.get()}' where name='{self.item_text_value[0]}'")
                my_cursor.execute(f"update [tbl_file] set [fileDescription]='{self.description_treeview.get()}' where [fileName]='{self.item_text_value[0]}'")
                conn.commit()
                conn.close()
                # print(self.row_ID, self.column_number, self.description_treeview.get())
                self.language_station_table.set(self.row_ID, column=self.column_number, value=self.description_treeview.get())
            # else:
            #     print("noo")
                # pass
            event.widget.destroy()
            self.scroll_true_and_false = False

        if int(self.column_number[1:]) == 2:
            self.description_treeview = Entry(self.message_list, justify="center", width=self.colum_box[2])
            self.description_treeview.insert(0, self.item_text_value[self.second_column_number]) # ev_value[new_ev]
            self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1]+52, w=self.colum_box[2], h=self.colum_box[3])
            self.description_treeview.focus()
            self.description_treeview.bind("<FocusOut>", on_focus_out)
            self.scroll_true_and_false = True
        elif int(self.column_number[1:]) % 3 == 0 and int(self.column_number[1:]) >= 3:
            self.text_toplevel(self.item_text_value[0], int(self.column_number[1:])) ### TXT FILE

        elif (int(self.column_number[1:])-1) % 3 == 0 and int(self.column_number[1:]) >= 4: ## AUDIO FILE
            # pygame.mixer.music.stop()
            pygame.quit()
            column_number_audio = int((int(self.column_number[1:])-1)/3)
            file_name_id = f"{self.item_text_value[0]}{self.language_list[column_number_audio]}.MP3"
            filetypes = (('mp3 files', '*.mp3'), ('All files', '*.*'))
            filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top)
            if filename:
                self.save_file_import(full_file_name=self.item_text_value[0], message_name=file_name_id)
                self.copy_audio_other_folder(file_name_path=filename, file_ID_name=file_name_id)
                self.language_station_table.set(self.row_ID, column=self.column_number, value="\u2705")
                play_row = int(self.column_number[1:])
                play_row_new = f"#{play_row + 1}"
                self.language_station_table.set(self.row_ID, column=play_row_new, value="\u25B6")
            # print(filename)
        elif (int(self.column_number[1:])-2) % 3 == 0 and int(self.column_number[1:]) >= 5: ### Play AUDIO FILE
            column_number_audio1 = int((int(self.column_number[1:]) - 2) / 3)
            # print("play sound")
            files = glob.glob(f"sqlData\\audio\\{self.item_text_value[0]}{self.language_list[column_number_audio1]}.MP3")
            if len(files) > 0:
                # print(self.item_text_value[self.second_column_number], "ggggggggggggg")
                pygame.mixer.init()
                pygame.mixer.music.load(f"sqlData\\audio\\{self.item_text_value[0]}{self.language_list[column_number_audio1]}.MP3")
                pygame.mixer.music.play(loops=0)
                # # pygame.mixer.music.stop()
                # pygame.quit()
            else:
                print("no data")


    def txt_entry_on_treeview(self, event=""):
        self.column_number = self.language_station_table.identify_column(event.x) ### with #1,#2,#3,....
        self.row_ID = self.language_station_table.focus() ### I001, I002, I003, ........
        self.item_data = self.language_station_table.item(self.row_ID)
        self.item_text_value = self.item_data.get("values")
        self.second_column_number = int(self.column_number[1]) - 1
        self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
        def on_focus_out(event):
            if not self.description_treeview.get() == self.item_text_value[self.second_column_number]:
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute(f"update messageA set [description]='{self.description_treeview.get()}' where name='{self.item_text_value[0]}'")
                my_cursor.execute(f"update [tbl_file] set [fileDescription]='{self.description_treeview.get()}' where [fileName]='{self.item_text_value[0]}'")
                conn.commit()
                conn.close()
                self.language_station_table.set(self.row_ID, column=self.column_number, value=self.description_treeview.get())

            event.widget.destroy()
            self.scroll_true_and_false = False

        if int(self.column_number[1:]) == 2:
            self.description_treeview = Entry(self.message_list, justify="center", width=self.colum_box[2])
            self.description_treeview.insert(0, self.item_text_value[self.second_column_number]) # ev_value[new_ev]
            self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1]+52, w=self.colum_box[2], h=self.colum_box[3])
            self.description_treeview.focus()
            self.description_treeview.bind("<FocusOut>", on_focus_out)
            self.scroll_true_and_false = True
        elif int(self.column_number[1:]) >= 3:
            print(self.item_text_value[0], int(self.column_number[1:]), "fffffffffffffffffffff")
            self.text_toplevel(self.item_text_value[0], int(self.column_number[1:]), True)

    def audio_entry_on_treeview(self, event=""):
        self.column_number = self.language_station_table.identify_column(event.x) ### with #1,#2,#3,....
        self.row_ID = self.language_station_table.focus() ### I001, I002, I003, ........
        # print(self.row_ID, self.column_number, "1111111111111111111111111111111111")
        self.item_data = self.language_station_table.item(self.row_ID)
        self.item_text_value = self.item_data.get("values")
        self.second_column_number = int(self.column_number[1]) - 1
        self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
        def on_focus_out(event):
            if not self.description_treeview.get() == self.item_text_value[self.second_column_number]:
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute(f"update messageA set [description]='{self.description_treeview.get()}' where name='{self.item_text_value[0]}'")
                my_cursor.execute(f"update [tbl_file] set [fileDescription]='{self.description_treeview.get()}' where [fileName]='{self.item_text_value[0]}'")
                conn.commit()
                conn.close()
                # print(self.row_ID, self.column_number, self.description_treeview.get())
                self.language_station_table.set(self.row_ID, column=self.column_number, value=self.description_treeview.get())
            # else:
            #     print("noo")
                # pass
            event.widget.destroy()
            self.scroll_true_and_false = False

        if int(self.column_number[1:]) == 2:
            self.description_treeview = Entry(self.message_list, justify="center", width=self.colum_box[2])
            self.description_treeview.insert(0, self.item_text_value[self.second_column_number]) # ev_value[new_ev]
            self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1]+52, w=self.colum_box[2], h=self.colum_box[3])
            self.description_treeview.focus()
            self.description_treeview.bind("<FocusOut>", on_focus_out)
            self.scroll_true_and_false = True

        elif int(self.column_number[1:]) % 2 != 0 and int(self.column_number[1:]) >= 3: ## AUDIO FILE
            pygame.quit()
            column_number_audio = int((int(self.column_number[1:])-1)/2)
            file_name_id = f"{self.item_text_value[0]}{self.language_list[column_number_audio]}.MP3"
            filetypes = (('mp3 files', '*.mp3'), ('All files', '*.*'))
            filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top)
            if filename:
                self.save_file_import(full_file_name=self.item_text_value[0], message_name=file_name_id)
                self.copy_audio_other_folder(file_name_path=filename, file_ID_name=file_name_id)
                self.language_station_table.set(self.row_ID, column=self.column_number, value="\u2705")
                play_row = int(self.column_number[1:])
                play_row_new = f"#{play_row + 1}"
                self.language_station_table.set(self.row_ID, column=play_row_new, value="\u25B6")



        elif (int(self.column_number[1:])) % 2 == 0 and int(self.column_number[1:]) >= 4: ### Play AUDIO FILE
            column_number_audio1 = int(int(self.column_number[1:]) / 2)-1
            files = glob.glob(f"sqlData\\audio\\{self.item_text_value[0]}{self.language_list[column_number_audio1]}.MP3")
            if len(files) > 0:
                # print(self.item_text_value[self.second_column_number], "ggggggggggggg")
                pygame.mixer.init()
                pygame.mixer.music.load(f"sqlData\\audio\\{self.item_text_value[0]}{self.language_list[column_number_audio1]}.MP3")
                pygame.mixer.music.play(loops=0)
                # pygame.mixer.music.stop()
                # pygame.quit()
            else:
                print("no data")

    def copy_audio_other_folder(self, file_name_path, file_ID_name, file_path='audio'):
        try:
            src = file_name_path
            dst = f"sqlData\\{file_path}\\{file_ID_name}"
            shutil.copy(src, dst)
        except FileNotFoundError:
            pass
########################################################################################################################
########################################################################################################################
########################################################################################################################
    def Prerecorded_mess_fun(self):
        def add_new_data_in_message_tbl():
            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            my_cursor.execute(f"select name from messageA where name like'%PR%' order by name desc limit 1")
            name_data = my_cursor.fetchall()
            if len(name_data) <= 0:
                my_cursor.execute(f"insert into messageA values(?,?)", ("PR0001", "Description"))
                my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", ("TXT", "PR0001", "Description"))
                my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", ("MP3", "PR0001", "Description"))
                list_for_value = ["PR0001", "Description"]
                for i in range(self.number_language):
                    list_for_value.append("\u274E")
                    list_for_value.append("\u274E")
                    list_for_value.append("\u20E0")
                self.language_station_table.insert("", END, values=list_for_value)
                # self.language_station_table.insert("", END, values=(
                #     "PR0001", "", "\u274E", "\u2705", "\u25B6", "\u2705", "\u274E", "\u20E0", "\u274E", "\u2705",
                #     "\u25B6"))
            else:
                item_name = name_data[0][0]
                number_item = str(int(item_name[2:])+1)
                name_number = "PR"+"0"*(4-len(number_item))+number_item
                my_cursor.execute(f"insert into messageA values(?,?)", (name_number, "Description"))
                my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", ("TXT", name_number, "Description"))
                my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", ("MP3", name_number, "Description"))

                list_for_value = [name_number, "Description"]
                for i in range(self.number_language):
                    list_for_value.append("\u274E")
                    list_for_value.append("\u274E")
                    list_for_value.append("\u20E0")
                self.language_station_table.insert("", END, values=list_for_value)

                # self.language_station_table.insert("", END, values=(
                #     name_number, "", "\u274E", "\u2705", "\u25B6", "\u2705", "\u274E", "\u20E0", "\u274E", "\u2705", "\u25B6"))
            conn.commit()
            conn.close()


        self.Add_new_button.destroy()
        self.scroll_true_and_false = False
        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'),
                                     bg="cyan", fg="black", cursor='hand2', command=add_new_data_in_message_tbl)
        self.Add_new_button.place(x=15, y=380)
        for child in self.message_list.winfo_children():
            child.destroy()
        self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message list :', width=64, anchor=NW)
        self.message_list_Label.place(x=0, y=0)
        # self.number_language = 0
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        self.language_list = ["Message"]
        language_list2 = ["Name", "Description"]
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            self.number_language += 1
            # print(it, self.number_language,  "sasdfghjk")
            self.language_list.append(it)
            language_list2.append(f"{it}text")
            language_list2.append(f"{it}audio")
            language_list2.append(f"{it}play")
            # print(it)
        # print(language_list, "dtghghbhuhhuhhhuh")
        def on_scroll(*args):
            self.language_station_table1.xview(*args)
            self.language_station_table.xview(*args)
            if self.scroll_true_and_false:
                self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
                # print(self.colum_box, "fguiyuhghuhuhuiji")
                self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1] + 52, w=self.colum_box[2],
                                                h=self.colum_box[3])


        self.language_scroll_y = tk.Scrollbar(self.message_list, orient=VERTICAL)

        self.language_station_table1 = tkinter.ttk.Treeview(self.message_list, columns=self.language_list, yscrollcommand=self.language_scroll_y.set, selectmode='none')

        self.language_station_table = tkinter.ttk.Treeview(self.message_list, columns=language_list2, yscrollcommand=self.language_scroll_y.set, selectmode='browse')

        self.language_scroll_x = tk.Scrollbar(self.message_list, orient=HORIZONTAL, command=on_scroll)

        self.language_station_table.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_station_table1.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_scroll_x.pack(side=BOTTOM, fill=X)

        popup = Menu(self.message_list, tearoff=0)
        popup.add_command(label="  Delete ", command=self.pop_delete)
        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()
        self.language_station_table.bind("<Button-3>", menu_popup)

        tree_width = 400
        for language_list_item in self.language_list:
            self.language_station_table1.heading(language_list_item, text=language_list_item)
            self.language_station_table1.column(language_list_item, width=tree_width, anchor='c', minwidth=tree_width, stretch=False)
            tree_width = 300
            if language_list_item == "Message":
                self.language_station_table.heading("Name", text="Name")
                self.language_station_table.column("Name", width=150, anchor='c', minwidth=150, stretch=False)

                self.language_station_table.heading("Description", text="Description")
                self.language_station_table.column("Description", width=250, anchor='c', minwidth=250, stretch=False)
            else:
                self.language_station_table.heading(f"{language_list_item}text", text="Text")
                self.language_station_table.column(f"{language_list_item}text", width=100, anchor='c', minwidth=100, stretch=False)

                self.language_station_table.heading(f"{language_list_item}audio", text="Audio")
                self.language_station_table.column(f"{language_list_item}audio", width=100, anchor='c', minwidth=100, stretch=False)

                self.language_station_table.heading(f"{language_list_item}play", text=" ")
                self.language_station_table.column(f"{language_list_item}play", width=100, anchor='c', minwidth=100, stretch=False)

        self.language_station_table1.place(x=0, y=28, height=400, width=756)
        self.language_station_table.place(x=0, y=52, height=472, width=756)
        # self.language_station_table.pack(fill=BOTH, expand=1)
        self.language_station_table["show"] = "headings"
        self.language_station_table1["show"] = "headings"
        # self.language_station_table.bind("<ButtonRelease>", self.entry_on_treeview)
        self.language_station_table.bind("<Double-Button-1>", self.entry_on_treeview)
        self.Prerecorded_sql_data_treeview()



    def text_announcements_sql_data_treeview(self, iid=""):
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(f"select * from messageA where name like'%{iid}%' order by name")
        name_data = my_cursor.fetchall()
        # print("Big{i}\u274E ==  ❎", "\u25B6  ==  ▶", "\u2705 ==  ✅", "\u20E0 ==  ⃠ ")
        list_for_value = ["a", "b"]
        self.language_station_table.delete(*self.language_station_table.get_children())
        for messageA, messageA2 in name_data:
            list_tree = []
            list_tree.clear()
            list_tree.append(messageA)
            list_tree.append(messageA2)
            for language in self.language_list[1::]:
                my_cursor.execute(
                    f"select [messageName] from [fileImport] where [messageName] like'%{messageA}{language}%' order by [FullFileName], [messageName]")
                name_data1 = my_cursor.fetchall()
                if len(name_data1) != 0:
                    list_tree.append("\u2705")

                else:
                    list_tree.append("\u274E")
            self.language_station_table.insert("", END, values=list_tree)
        conn.commit()
        conn.close()
    def video_sql_data_treeview(self, iid=""):
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(f"select * from messageA where name like'%{iid}%' order by name")
        name_data = my_cursor.fetchall()
        # print("Big{i}\u274E ==  ❎", "\u25B6  ==  ▶", "\u2705 ==  ✅", "\u20E0 ==  ⃠ ")
        list_for_value = ["a", "b"]
        self.language_station_table.delete(*self.language_station_table.get_children())
        for messageA, messageA2 in name_data:
            list_tree = []
            list_tree.clear()
            list_tree.append(messageA)
            list_tree.append(messageA2)
            for language in self.language_list[1::]:
                my_cursor.execute(
                    f"select [messageName] from [fileImport] where [messageName] like'%{messageA}{language}%' order by [FullFileName], [messageName]")
                name_data1 = my_cursor.fetchall()
                if len(name_data1) != 0:
                    list_tree.append("\u2705")
                    list_tree.append("\u25B6")

                else:
                    list_tree.append("\u274E")
                    list_tree.append("\u20E0")
            self.language_station_table.insert("", END, values=list_tree)
        conn.commit()
        conn.close()

    def add_new_data_in_message_tbl_save(self, iid=""):
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(f"select name from messageA where name like'%{iid}%' order by name desc limit 1")
        name_data = my_cursor.fetchall()
        if len(name_data) <= 0:
            my_cursor.execute(f"insert into messageA values(?,?)", (f"{iid}0001", "Description"))
            my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", ("TXT", f"{iid}0001", "Description"))
            list_for_value = [f"{iid}0001", "Description"]
            for i in range(self.number_language):
                list_for_value.append("\u274E")
            self.language_station_table.insert("", END, values=list_for_value)
            # self.language_station_table.insert("", END, values=(
            #     "PR0001", "", "\u274E", "\u2705", "\u25B6", "\u2705", "\u274E", "\u20E0", "\u274E", "\u2705",
            #     "\u25B6"))
        else:
            item_name = name_data[0][0]
            number_item = str(int(item_name[2:]) + 1)
            name_number = f"{iid}" + "0" * (4 - len(number_item)) + number_item
            my_cursor.execute(f"insert into messageA values(?,?)", (name_number, "Description"))
            my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", ("TXT", name_number, "Description"))
            # my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", ("MP3", name_number, "Description"))

            list_for_value = [name_number, "Description"]
            for i in range(self.number_language):
                list_for_value.append("\u274E")
            self.language_station_table.insert("", END, values=list_for_value)

            # self.language_station_table.insert("", END, values=(
            #     name_number, "", "\u274E", "\u2705", "\u25B6", "\u2705", "\u274E", "\u20E0", "\u274E", "\u2705", "\u25B6"))
        conn.commit()
        conn.close()

    def video_add_new_data_in_message_tbl_save(self, iid="", file_formate=""):
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(f"select name from messageA where name like'%{iid}%' order by name desc limit 1")
        name_data = my_cursor.fetchall()
        if len(name_data) <= 0:
            my_cursor.execute(f"insert into messageA values(?,?)", (f"{iid}0001", "Description"))
            my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", (file_formate, f"{iid}0001", "Description"))
            list_for_value = [f"{iid}0001", "Description"]
            for i in range(self.number_language):
                list_for_value.append("\u274E")
                list_for_value.append("\u20E0")
            self.language_station_table.insert("", END, values=list_for_value)
            # self.language_station_table.insert("", END, values=(
            #     "PR0001", "", "\u274E", "\u2705", "\u25B6", "\u2705", "\u274E", "\u20E0", "\u274E", "\u2705",
            #     "\u25B6"))
        else:
            item_name = name_data[0][0]
            number_item = str(int(item_name[2:]) + 1)
            name_number = f"{iid}" + "0" * (4 - len(number_item)) + number_item
            my_cursor.execute(f"insert into messageA values(?,?)", (name_number, "Description"))
            my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", (file_formate, name_number, "Description"))
            # my_cursor.execute(f"insert into [tbl_file] values(?,?,?)", ("MP3", name_number, "Description"))
            list_for_value = [name_number, "Description"]
            for i in range(self.number_language):
                list_for_value.append("\u274E")
                list_for_value.append("\u20E0")
            self.language_station_table.insert("", END, values=list_for_value)
        conn.commit()
        conn.close()

    def text_announcements(self):
        self.Add_new_button.destroy()
        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'),
                                     bg="cyan", fg="black", cursor='hand2', command=lambda: self.add_new_data_in_message_tbl_save(iid="TA"))
        self.Add_new_button.place(x=15, y=380)
        for child in self.message_list.winfo_children():
            child.destroy()
        self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message list :', width=64, anchor=NW)
        self.message_list_Label.place(x=0, y=0)
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        language_list = ["Message"]
        language_list2 = ["Name", "Description"]
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            language_list.append(it)
            language_list2.append(f"{it}text")

        def on_scroll(*args):
            self.language_station_table1.xview(*args)
            self.language_station_table.xview(*args)
            if self.scroll_true_and_false:
                self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
                # print(self.colum_box, "fguiyuhghuhuhuiji")
                self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1] + 52, w=self.colum_box[2],
                                                h=self.colum_box[3])
        self.language_scroll_y = tk.Scrollbar(self.message_list, orient=VERTICAL)

        self.language_station_table1 = tkinter.ttk.Treeview(self.message_list, columns=language_list, yscrollcommand=self.language_scroll_y.set, selectmode='none')

        self.language_station_table = tkinter.ttk.Treeview(self.message_list, columns=language_list2, yscrollcommand=self.language_scroll_y.set, selectmode='browse')

        self.language_scroll_x = tk.Scrollbar(self.message_list, orient=HORIZONTAL, command=on_scroll)

        self.language_station_table.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_station_table1.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_scroll_x.pack(side=BOTTOM, fill=X)

        popup = Menu(self.message_list, tearoff=0)
        popup.add_command(label="  Delete ", command=self.pop_delete)

        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()

        self.language_station_table.bind("<Button-3>", menu_popup)

        tree_width = 400
        for language_list_item in language_list:
            self.language_station_table1.heading(language_list_item, text=language_list_item)
            self.language_station_table1.column(language_list_item, width=tree_width, anchor='c', minwidth=tree_width, stretch=False)
            tree_width = 118
            if language_list_item == "Message":
                self.language_station_table.heading("Name", text="Name")
                self.language_station_table.column("Name", width=150, anchor='c', minwidth=150, stretch=False)

                self.language_station_table.heading("Description", text="Description")
                self.language_station_table.column("Description", width=250, anchor='c', minwidth=250, stretch=False)
            else:
                self.language_station_table.heading(f"{language_list_item}text", text="Text")
                self.language_station_table.column(f"{language_list_item}text", width=118, anchor='c', minwidth=118, stretch=False)

        self.language_station_table1.place(x=0, y=28, height=400, width=756)
        self.language_station_table.place(x=0, y=52, height=472, width=756)
        self.language_station_table["show"] = "headings"
        self.language_station_table1["show"] = "headings"
        # self.language_station_table.bind("<ButtonRelease>", self.txt_entry_on_treeview)
        self.language_station_table.bind("<Double-Button-1>", self.txt_entry_on_treeview)
        self.text_announcements_sql_data_treeview(iid="TA")

    def Voice_announcements(self):
        self.Add_new_button.destroy()
        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'),
                                     bg="cyan", fg="black", cursor='hand2', command=lambda: self.video_add_new_data_in_message_tbl_save(iid="AA", file_formate="MP3"))
        self.Add_new_button.place(x=15, y=380)
        for child in self.message_list.winfo_children():
            child.destroy()
        self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message list :', width=64, anchor=NW)
        self.message_list_Label.place(x=0, y=0)
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        language_list = ["Message"]
        language_list2 = ["Name", "Description"]
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            language_list.append(it)
            language_list2.append(f"{it}audio")
            language_list2.append(f"{it}play")
            # print(it)
        def on_scroll(*args):
            # Adjust the yview of both TreeView widgets
            self.language_station_table1.xview(*args)
            self.language_station_table.xview(*args)
            if self.scroll_true_and_false:
                self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
                # print(self.colum_box, "fguiyuhghuhuhuiji")
                self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1] + 52, w=self.colum_box[2],
                                                h=self.colum_box[3])
        self.language_scroll_y = tk.Scrollbar(self.message_list, orient=VERTICAL)

        self.language_station_table1 = tkinter.ttk.Treeview(self.message_list, columns=language_list, yscrollcommand=self.language_scroll_y.set)

        self.language_station_table = tkinter.ttk.Treeview(self.message_list, columns=language_list2,yscrollcommand=self.language_scroll_y.set)

        self.language_scroll_x = tk.Scrollbar(self.message_list, orient=HORIZONTAL, command=on_scroll)

        self.language_station_table.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_station_table1.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_scroll_x.pack(side=BOTTOM, fill=X)

        popup = Menu(self.message_list, tearoff=0)
        popup.add_command(label="  Delete ", command=self.pop_delete)

        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()

        self.language_station_table.bind("<Button-3>", menu_popup)

        tree_width = 400
        for language_list_item in language_list:
            self.language_station_table1.heading(language_list_item, text=language_list_item)
            self.language_station_table1.column(language_list_item, width=tree_width, anchor='c', minwidth=tree_width, stretch=False)
            tree_width = 200
            if language_list_item == "Message":
                self.language_station_table.heading("Name", text="Name")
                self.language_station_table.column("Name", width=150, anchor='c', minwidth=150, stretch=False)

                self.language_station_table.heading("Description", text="Description")
                self.language_station_table.column("Description", width=250, anchor='c', minwidth=250, stretch=False)
            else:
                self.language_station_table.heading(f"{language_list_item}audio", text="Audio")
                self.language_station_table.column(f"{language_list_item}audio", width=100, anchor='c', minwidth=100, stretch=False)

                self.language_station_table.heading(f"{language_list_item}play", text=" ")
                self.language_station_table.column(f"{language_list_item}play", width=100, anchor='c', minwidth=100, stretch=False)

        self.language_station_table1.place(x=0, y=28, height=400, width=756)
        self.language_station_table.place(x=0, y=52, height=472, width=756)
        # self.language_station_table.pack(fill=BOTH, expand=1)
        self.language_station_table["show"] = "headings"
        self.language_station_table1["show"] = "headings"
        self.language_station_table.bind("<Double-Button-1>", self.audio_entry_on_treeview)
        # self.language_station_table.bind("<ButtonRelease>", self.audio_entry_on_treeview)
        self.video_sql_data_treeview(iid="AA")

    def jingle_fun(self):
        self.Add_new_button.destroy()
        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'),
                                     bg="cyan", fg="black", cursor='hand2', command=lambda: self.video_add_new_data_in_message_tbl_save(iid="SJ", file_formate="MP3"))
        self.Add_new_button.place(x=15, y=380)
        for child in self.message_list.winfo_children():
            child.destroy()
        self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message list :', width=64, anchor=NW)
        self.message_list_Label.place(x=0, y=0)
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        language_list = ["Message"]
        language_list2 = ["Name", "Description"]
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            language_list.append(it)
            language_list2.append(f"{it}audio")
            language_list2.append(f"{it}play")
            # print(it)
        def on_scroll(*args):
            # Adjust the yview of both TreeView widgets
            self.language_station_table1.xview(*args)
            self.language_station_table.xview(*args)
            if self.scroll_true_and_false:
                self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
                # print(self.colum_box, "fguiyuhghuhuhuiji")
                self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1] + 52, w=self.colum_box[2],
                                                h=self.colum_box[3])
        self.language_scroll_y = tk.Scrollbar(self.message_list, orient=VERTICAL)

        self.language_station_table1 = tkinter.ttk.Treeview(self.message_list, columns=language_list, yscrollcommand=self.language_scroll_y.set)

        self.language_station_table = tkinter.ttk.Treeview(self.message_list, columns=language_list2,yscrollcommand=self.language_scroll_y.set)

        self.language_scroll_x = tk.Scrollbar(self.message_list, orient=HORIZONTAL, command=on_scroll)

        self.language_station_table.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_station_table1.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_scroll_x.pack(side=BOTTOM, fill=X)

        popup = Menu(self.message_list, tearoff=0)
        popup.add_command(label="  Delete ", command=self.pop_delete)

        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()

        self.language_station_table.bind("<Button-3>", menu_popup)

        tree_width = 400
        for language_list_item in language_list:
            self.language_station_table1.heading(language_list_item, text=language_list_item)
            self.language_station_table1.column(language_list_item, width=tree_width, anchor='c', minwidth=tree_width, stretch=False)
            tree_width = 200
            if language_list_item == "Message":
                self.language_station_table.heading("Name", text="Name")
                self.language_station_table.column("Name", width=150, anchor='c', minwidth=150, stretch=False)

                self.language_station_table.heading("Description", text="Description")
                self.language_station_table.column("Description", width=250, anchor='c', minwidth=250, stretch=False)
            else:
                self.language_station_table.heading(f"{language_list_item}audio", text="Audio")
                self.language_station_table.column(f"{language_list_item}audio", width=100, anchor='c', minwidth=100, stretch=False)

                self.language_station_table.heading(f"{language_list_item}play", text=" ")
                self.language_station_table.column(f"{language_list_item}play", width=100, anchor='c', minwidth=100, stretch=False)

        self.language_station_table1.place(x=0, y=28, height=400, width=756)
        self.language_station_table.place(x=0, y=52, height=472, width=756)
        # self.language_station_table.pack(fill=BOTH, expand=1)
        self.language_station_table["show"] = "headings"
        self.language_station_table1["show"] = "headings"
        self.language_station_table.bind("<Double-Button-1>", self.audio_entry_on_treeview)
        # self.language_station_table.bind("<ButtonRelease>", self.audio_entry_on_treeview)
        self.video_sql_data_treeview(iid="SJ")
    def Publicity_messages(self):
        self.Add_new_button.destroy()
        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'),
                                     bg="cyan", fg="black", cursor='hand2', command=lambda: self.add_new_data_in_message_tbl_save(iid="PU"))
        self.Add_new_button.place(x=15, y=380)
        for child in self.message_list.winfo_children():
            child.destroy()
        self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message list :', width=64, anchor=NW)
        self.message_list_Label.place(x=0, y=0)
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        language_list = ["Message"]
        language_list2 = ["Name", "Description"]
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            language_list.append(it)
            language_list2.append(f"{it}text")

        def on_scroll(*args):
            self.language_station_table1.xview(*args)
            self.language_station_table.xview(*args)
            if self.scroll_true_and_false:
                self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
                # print(self.colum_box, "fguiyuhghuhuhuiji")
                self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1] + 52, w=self.colum_box[2],
                                                h=self.colum_box[3])
        self.language_scroll_y = tk.Scrollbar(self.message_list, orient=VERTICAL)

        self.language_station_table1 = tkinter.ttk.Treeview(self.message_list, columns=language_list, yscrollcommand=self.language_scroll_y.set)

        self.language_station_table = tkinter.ttk.Treeview(self.message_list, columns=language_list2,yscrollcommand=self.language_scroll_y.set)

        self.language_scroll_x = tk.Scrollbar(self.message_list, orient=HORIZONTAL, command=on_scroll)

        self.language_station_table.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_station_table1.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_scroll_x.pack(side=BOTTOM, fill=X)

        popup = Menu(self.message_list, tearoff=0)
        popup.add_command(label="  Delete ", command=self.pop_delete)

        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()

        self.language_station_table.bind("<Button-3>", menu_popup)

        tree_width = 400
        for language_list_item in language_list:
            self.language_station_table1.heading(language_list_item, text=language_list_item)
            self.language_station_table1.column(language_list_item, width=tree_width, anchor='c', minwidth=tree_width, stretch=False)
            tree_width = 118
            if language_list_item == "Message":
                self.language_station_table.heading("Name", text="Name")
                self.language_station_table.column("Name", width=150, anchor='c', minwidth=150, stretch=False)

                self.language_station_table.heading("Description", text="Description")
                self.language_station_table.column("Description", width=250, anchor='c', minwidth=250, stretch=False)
            else:
                self.language_station_table.heading(f"{language_list_item}text", text="Text")
                self.language_station_table.column(f"{language_list_item}text", width=118, anchor='c', minwidth=118, stretch=False)

        self.language_station_table1.place(x=0, y=28, height=400, width=756)
        self.language_station_table.place(x=0, y=52, height=472, width=756)
        self.language_station_table["show"] = "headings"
        self.language_station_table1["show"] = "headings"
        self.language_station_table.bind("<Double-Button-1>", self.txt_entry_on_treeview)
        # self.language_station_table.bind("<ButtonRelease>", self.txt_entry_on_treeview)
        self.text_announcements_sql_data_treeview(iid="PU")

    def Welcome_message(self):
        self.Add_new_button.destroy()
        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'),
                                     bg="cyan", fg="black", cursor='hand2', command=lambda: self.add_new_data_in_message_tbl_save(iid="SP"))
        self.Add_new_button.place(x=15, y=380)
        for child in self.message_list.winfo_children():
            child.destroy()
        self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message list :', width=64, anchor=NW)
        self.message_list_Label.place(x=0, y=0)
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        language_list = ["Message"]
        language_list2 = ["Name", "Description"]
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            language_list.append(it)
            language_list2.append(f"{it}text")

        def on_scroll(*args):
            self.language_station_table1.xview(*args)
            self.language_station_table.xview(*args)
            if self.scroll_true_and_false:
                self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
                # print(self.colum_box, "fguiyuhghuhuhuiji")
                self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1] + 52, w=self.colum_box[2],
                                                h=self.colum_box[3])
        self.language_scroll_y = tk.Scrollbar(self.message_list, orient=VERTICAL)

        self.language_station_table1 = tkinter.ttk.Treeview(self.message_list, columns=language_list, yscrollcommand=self.language_scroll_y.set)

        self.language_station_table = tkinter.ttk.Treeview(self.message_list, columns=language_list2,yscrollcommand=self.language_scroll_y.set)

        self.language_scroll_x = tk.Scrollbar(self.message_list, orient=HORIZONTAL, command=on_scroll)

        self.language_station_table.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_station_table1.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_scroll_x.pack(side=BOTTOM, fill=X)

        popup = Menu(self.message_list, tearoff=0)
        popup.add_command(label="  Delete ", command=self.pop_delete)

        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()

        self.language_station_table.bind("<Button-3>", menu_popup)

        tree_width = 400
        for language_list_item in language_list:
            self.language_station_table1.heading(language_list_item, text=language_list_item)
            self.language_station_table1.column(language_list_item, width=tree_width, anchor='c', minwidth=tree_width, stretch=False)
            tree_width = 118
            if language_list_item == "Message":
                self.language_station_table.heading("Name", text="Name")
                self.language_station_table.column("Name", width=150, anchor='c', minwidth=150, stretch=False)

                self.language_station_table.heading("Description", text="Description")
                self.language_station_table.column("Description", width=250, anchor='c', minwidth=250, stretch=False)
            else:
                self.language_station_table.heading(f"{language_list_item}text", text="Text")
                self.language_station_table.column(f"{language_list_item}text", width=118, anchor='c', minwidth=118, stretch=False)

        self.language_station_table1.place(x=0, y=28, height=400, width=756)
        self.language_station_table.place(x=0, y=52, height=472, width=756)
        self.language_station_table["show"] = "headings"
        self.language_station_table1["show"] = "headings"
        self.language_station_table.bind("<Double-Button-1>", self.txt_entry_on_treeview)
        # self.language_station_table.bind("<ButtonRelease>", self.txt_entry_on_treeview)
        self.text_announcements_sql_data_treeview(iid="SP")

    def Video_messages(self):
        self.Add_new_button.destroy()
        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'),
                                     bg="cyan", fg="black", cursor='hand2',
                                     command=lambda: self.video_add_new_data_in_message_tbl_save(iid="PV", file_formate="MP4"))
        self.Add_new_button.place(x=15, y=380)
        for child in self.message_list.winfo_children():
            child.destroy()
        self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message list :', width=64, anchor=NW)
        self.message_list_Label.place(x=0, y=0)
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        language_list = ["Message"]
        language_list2 = ["Name", "Description"]
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            language_list.append(it)
            language_list2.append(f"{it}Video")
            language_list2.append(f"{it}play")
            # print(it)

        def on_scroll(*args):
            # Adjust the yview of both TreeView widgets
            self.language_station_table1.xview(*args)
            self.language_station_table.xview(*args)
            if self.scroll_true_and_false:
                self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
                # print(self.colum_box, "fguiyuhghuhuhuiji")
                self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1] + 52, w=self.colum_box[2],
                                                h=self.colum_box[3])

        self.language_scroll_y = tk.Scrollbar(self.message_list, orient=VERTICAL)

        self.language_station_table1 = tkinter.ttk.Treeview(self.message_list, columns=language_list,
                                                            yscrollcommand=self.language_scroll_y.set)

        self.language_station_table = tkinter.ttk.Treeview(self.message_list, columns=language_list2,
                                                           yscrollcommand=self.language_scroll_y.set)

        self.language_scroll_x = tk.Scrollbar(self.message_list, orient=HORIZONTAL, command=on_scroll)

        self.language_station_table.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_station_table1.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_scroll_x.pack(side=BOTTOM, fill=X)

        popup = Menu(self.message_list, tearoff=0)
        popup.add_command(label="  Delete ", command=self.pop_delete)

        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()

        self.language_station_table.bind("<Button-3>", menu_popup)

        tree_width = 400
        for language_list_item in language_list:
            self.language_station_table1.heading(language_list_item, text=language_list_item)
            self.language_station_table1.column(language_list_item, width=tree_width, anchor='c', minwidth=tree_width,
                                                stretch=False)
            tree_width = 200
            if language_list_item == "Message":
                self.language_station_table.heading("Name", text="Name")
                self.language_station_table.column("Name", width=150, anchor='c', minwidth=150, stretch=False)

                self.language_station_table.heading("Description", text="Description")
                self.language_station_table.column("Description", width=250, anchor='c', minwidth=250, stretch=False)
            else:
                self.language_station_table.heading(f"{language_list_item}Video", text="Video")
                self.language_station_table.column(f"{language_list_item}Video", width=100, anchor='c', minwidth=100,
                                                   stretch=False)

                self.language_station_table.heading(f"{language_list_item}play", text=" ")
                self.language_station_table.column(f"{language_list_item}play", width=100, anchor='c', minwidth=100,
                                                   stretch=False)

        self.language_station_table1.place(x=0, y=28, height=400, width=756)
        self.language_station_table.place(x=0, y=52, height=472, width=756)
        # self.language_station_table.pack(fill=BOTH, expand=1)
        self.language_station_table["show"] = "headings"
        self.language_station_table1["show"] = "headings"
        self.language_station_table.bind("<Double-Button-1>", self.video_banner_entry_on_treeview)
        # self.language_station_table.bind("<ButtonRelease>", self.video_banner_entry_on_treeview)
        self.video_sql_data_treeview(iid="PV")

    def Banner_messages(self):
        self.Add_new_button.destroy()
        self.Add_new_button = Button(self.message_type, height=1, width=8, text="Add New", font=('arial', 8, 'bold'),
                                     bg="cyan", fg="black", cursor='hand2',
                                     command=lambda: self.video_add_new_data_in_message_tbl_save(iid="PB", file_formate='PNG'))
        self.Add_new_button.place(x=15, y=380)
        for child in self.message_list.winfo_children():
            child.destroy()
        self.message_list_Label = Label(self.message_list, font=("arial", 14, "bold"), bg='black', fg="white",
                                        text='Message list :', width=64, anchor=NW)
        self.message_list_Label.place(x=0, y=0)
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        language_list = ["Message"]
        language_list2 = ["Name", "Description"]
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            language_list.append(it)
            language_list2.append(f"{it}audio")
            language_list2.append(f"{it}play")
            # print(it)

        def on_scroll(*args):
            # Adjust the yview of both TreeView widgets
            self.language_station_table1.xview(*args)
            self.language_station_table.xview(*args)
            if self.scroll_true_and_false:
                self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
                # print(self.colum_box, "fguiyuhghuhuhuiji")
                self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1] + 52, w=self.colum_box[2],
                                                h=self.colum_box[3])

        self.language_scroll_y = tk.Scrollbar(self.message_list, orient=VERTICAL)

        self.language_station_table1 = tkinter.ttk.Treeview(self.message_list, columns=language_list,
                                                            yscrollcommand=self.language_scroll_y.set)

        self.language_station_table = tkinter.ttk.Treeview(self.message_list, columns=language_list2,
                                                           yscrollcommand=self.language_scroll_y.set)

        self.language_scroll_x = tk.Scrollbar(self.message_list, orient=HORIZONTAL, command=on_scroll)

        self.language_station_table.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_station_table1.configure(xscrollcommand=self.language_scroll_x.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.language_scroll_x.pack(side=BOTTOM, fill=X)

        popup = Menu(self.message_list, tearoff=0)
        popup.add_command(label="  Delete ", command=self.pop_delete)

        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()

        self.language_station_table.bind("<Button-3>", menu_popup)

        tree_width = 400
        for language_list_item in language_list:
            self.language_station_table1.heading(language_list_item, text=language_list_item)
            self.language_station_table1.column(language_list_item, width=tree_width, anchor='c', minwidth=tree_width,
                                                stretch=False)
            tree_width = 200
            if language_list_item == "Message":
                self.language_station_table.heading("Name", text="Name")
                self.language_station_table.column("Name", width=150, anchor='c', minwidth=150, stretch=False)

                self.language_station_table.heading("Description", text="Description")
                self.language_station_table.column("Description", width=250, anchor='c', minwidth=250, stretch=False)
            else:
                self.language_station_table.heading(f"{language_list_item}audio", text="Banner")
                self.language_station_table.column(f"{language_list_item}audio", width=100, anchor='c', minwidth=100,
                                                   stretch=False)

                self.language_station_table.heading(f"{language_list_item}play", text=" ")
                self.language_station_table.column(f"{language_list_item}play", width=100, anchor='c', minwidth=100,
                                                   stretch=False)

        self.language_station_table1.place(x=0, y=28, height=400, width=756)
        self.language_station_table.place(x=0, y=52, height=472, width=756)
        # self.language_station_table.pack(fill=BOTH, expand=1)
        self.language_station_table["show"] = "headings"
        self.language_station_table1["show"] = "headings"
        self.language_station_table.bind("<Double-Button-1>", self.video_banner_entry_on_treeview)
        # self.language_station_table.bind("<ButtonRelease>", self.video_banner_entry_on_treeview)
        self.video_sql_data_treeview(iid="PB")

    def video_banner_entry_on_treeview(self, event=""):
        self.column_number = self.language_station_table.identify_column(event.x) ### with #1,#2,#3,....
        self.row_ID = self.language_station_table.focus() ### I001, I002, I003, ........
        # print(self.row_ID, self.column_number, "1111111111111111111111111111111111")
        self.item_data = self.language_station_table.item(self.row_ID)
        self.item_text_value = self.item_data.get("values")
        self.second_column_number = int(self.column_number[1]) - 1
        self.colum_box = self.language_station_table.bbox(self.row_ID, self.column_number)
        def on_focus_out(event):
            if not self.description_treeview.get() == self.item_text_value[self.second_column_number]:
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute(f"update messageA set [description]='{self.description_treeview.get()}' where name='{self.item_text_value[0]}'")
                my_cursor.execute(f"update [tbl_file] set [fileDescription]='{self.description_treeview.get()}' where [fileName]='{self.item_text_value[0]}'")
                conn.commit()
                conn.close()
                self.language_station_table.set(self.row_ID, column=self.column_number, value=self.description_treeview.get())
            event.widget.destroy()
            self.scroll_true_and_false = False

        if int(self.column_number[1:]) == 2:
            self.description_treeview = Entry(self.message_list, justify="center", width=self.colum_box[2])
            self.description_treeview.insert(0, self.item_text_value[self.second_column_number]) # ev_value[new_ev]
            self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1]+52, w=self.colum_box[2], h=self.colum_box[3])
            self.description_treeview.focus()
            self.description_treeview.bind("<FocusOut>", on_focus_out)
            self.scroll_true_and_false = True

        elif int(self.column_number[1:]) % 2 != 0 and int(self.column_number[1:]) >= 3: ## AUDIO FILE
            column_number_audio = int((int(self.column_number[1:])-1)/2)
            if self.item_text_value[0][:2:] == "PV":
                file_name_id = f"{self.item_text_value[0]}{self.language_list[column_number_audio]}.MP4"
                filetypes = (('MP4 files', '*.MP4'), ('All files', '*.*'))
                filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top)
                if filename:
                    self.save_file_import(full_file_name=self.item_text_value[0], message_name=file_name_id)
                    self.copy_audio_other_folder(file_name_path=filename, file_ID_name=file_name_id, file_path="video")
                    self.language_station_table.set(self.row_ID, column=self.column_number, value="\u2705")
                    play_row = int(self.column_number[1:])
                    play_row_new = f"#{play_row + 1}"
                    self.language_station_table.set(self.row_ID, column=play_row_new, value="\u25B6")
            elif self.item_text_value[0][:2:] == "PB":
                file_name_id = f"{self.item_text_value[0]}{self.language_list[column_number_audio]}.PNG"
                filetypes = (('PNG files', '*.PNG'), ('All files', '*.*'))
                filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top)
                if filename:
                    self.save_file_import(full_file_name=self.item_text_value[0], message_name=file_name_id)
                    self.copy_audio_other_folder(file_name_path=filename, file_ID_name=file_name_id, file_path="banner")
                    self.language_station_table.set(self.row_ID, column=self.column_number, value="\u2705")
                    play_row = int(self.column_number[1:])
                    play_row_new = f"#{play_row + 1}"
                    self.language_station_table.set(self.row_ID, column=play_row_new, value="\u25B6")


        elif (int(self.column_number[1:])) % 2 == 0 and int(self.column_number[1:]) >= 4: ### Play AUDIO FILE
            column_number_audio1 = int(int(self.column_number[1:]) / 2)-1
            if self.item_text_value[0][:2:] == "PV":
                files = glob.glob(
                    f"sqlData\\video\\{self.item_text_value[0]}{self.language_list[column_number_audio1]}.MP4")
                if len(files) > 0:
                    # print("video")
                    # from tkvideo import tkvideo

                    # window = tkinter.Toplevel()
                    # window.title("Video PLayer")
                    self.label_frame_video = LabelFrame(self.top, bd=2)
                    self.label_frame_video.place(x=788, y=338, height=200, width=290)
                    def on_exit():
                        window.destroy()

                    def close_video():
                        self.vid.destroy()
                        self.label_frame_video.destroy()

                    self.vid = TkinterVideo(master=self.label_frame_video)
                    self.vid.load(f"sqlData\\video\\{self.item_text_value[0]}{self.language_list[column_number_audio1]}.MP4")
                    self.vid.pack(expand=True, fill="both")
                    self.vid.play()
                    butt = Button(self.label_frame_video, text='X', bg="red", command=close_video)
                    butt.place(x=270, y=0)
                else:
                    print("no data")
            elif self.item_text_value[0][:2:] == "PB":
                files = glob.glob(
                    f"sqlData\\banner\\{self.item_text_value[0]}{self.language_list[column_number_audio1]}.PNG")
                if len(files) > 0:
                    print("banner")
                    # pygame.mixer.init()
                    # pygame.mixer.music.load(
                    #     f"sqlData\\banner\\{self.item_text_value[0]}{self.language_list[column_number_audio1]}.PNG")
                    # pygame.mixer.music.play(loops=0)
                else:
                    print("no data")
    def pop_delete(self):
        self.row_ID1 = self.language_station_table.focus()  ### I001, I002, I003, ........
        # print(self.row_ID, self.column_number, "1111111111111111111111111111111111")
        self.item_data1 = self.language_station_table.item(self.row_ID1)
        self.item_text_value2 = self.item_data1.get("values")
        if not self.item_text_value2:
            print("noooo")
        else:
            print(self.item_text_value2)
            conn1 = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn1.cursor()
            my_cursor.execute(f"DELETE FROM [messageA] WHERE [name]='{self.item_text_value2[0]}'")
            my_cursor.execute(f"DELETE FROM [tbl_file] WHERE [fileName]='{self.item_text_value2[0]}'")
            my_cursor.execute(f"DELETE FROM [fileImport] WHERE [FullFileName]='{self.item_text_value2[0]}'")
            conn1.commit()
            conn1.close()
            selected_item = self.language_station_table.selection()[0]  ## get selected item
            self.language_station_table.delete(selected_item)
            print("done")

    def on_exit(self):
        self.top.destroy()
        main.MainApplication()


if __name__ == "__main__":
    messages_data()
