# import tkinter as tk
# from tkinter import ttk
# import routes
# import stations
# import journey
# import trigger
# import export
# import dts_time
# import messages
# import project_config
# from stations import *
# from tkinter import filedialog
# from PIL import Image, ImageTk
#
# # from customtkinter import CTkButton
#
# # database_name_data1 = ''
#
# bg_main = "#F1D2BA"
# fg_color = "#2c2b52"
# font = ("dubai medium", 14, "bold")
#
#
# class MainApplication:
#     def __init__(self):
#         self.parent = tk.Tk()
#         self.parent.title("Information Management System")
#         self.parent.geometry("640x500+450+100")
#         self.parent.iconbitmap("logo2.ico")
#         self.parent.resizable(False, False)
#
#         # button_exmple = CTkButton(master=self.parent, corner_radius=50)
#         # self.parent.maxsize(500, 500)
#         # self.parent.minsize(500, 500)
#
#         def message_py():
#             self.parent.destroy()
#             messages.messages_data()
#
#         def configuration():
#             self.parent.destroy()
#             project_config.project_config_class()
#
#         def dts_time_fun():
#             self.parent.destroy()
#             dts_time.dts_time_class()
#
#         ############################ Creating Menubar ############################
#         # Adding Project Menu and SubMenus
#         self.menu = Menu(self.parent)
#         # self.menu.configure(bg="blue")
#         self.project = tk.Menu(self.menu, tearoff=0,
#                                bg='darkseagreen')  # tearoff make the menu stick close to the Window
#         # SubMenu
#         self.project.add_command(label="Create new", command=self.create_new_databse)
#         self.project.add_command(label="Delete database", command=self.delete_databse_schema)
#         # Menu Project
#         self.menu.add_cascade(label="Project", menu=self.project)
#         # Adiing Items Menu and SubMenus
#         self.items = tk.Menu(self.menu, tearoff=0, bg='darkseagreen')
#         # SubMenu
#         self.items.add_command(label="Items 1")
#         self.items.add_command(label="configuration", command=configuration)
#         self.items.add_command(label="messages", command=message_py)
#         self.items.add_command(label="DTS", command=dts_time_fun)
#
#         # Menu Item
#         self.menu.add_cascade(label="Items", menu=self.items)
#         # Adding Language Menu and SubMenus
#         self.language = tk.Menu(self.menu, tearoff=0, bg='darkseagreen')
#         # SubMenu
#         self.language.add_command(label="Language 1")
#         self.language.add_command(label="Language 2")
#         self.language.add_command(label="Language 3")
#         # Menu Language
#         self.menu.add_cascade(label="Language", menu=self.language)
#         # Adding Upload Menu and SubMenus
#         self.upload = tk.Menu(self.menu, tearoff=0, bg='darkseagreen')
#         # SubMenu
#         self.upload.add_command(label="Upload", command=self.open_file)
#         #  Menu Upload
#         self.menu.add_cascade(label="Upload", menu=self.upload)
#         # Displaying Menu used by config to connect
#         # IMS.config(menu=self.menu)
#         self.parent.config(menu=self.menu)
#         ################################### End Menu bar #######################
#
#         ################################### Image For Window ##################
#         frame_image = Image.open("station_png_3.png")
#         frame_image = frame_image.resize((800, 555))
#         self.canvas = Canvas(self.parent, width=700, height=555)
#         self.canvas.place(x=0, y=0)
#         # Display the resized image
#         frame_image = ImageTk.PhotoImage(frame_image)
#         self.canvas.create_image(0, -1, image=frame_image, anchor=NW)
#         self.canvas.create_text(250, 20, text="", fill="BLACK", font=("Arial", 15, "bold"), anchor=CENTER,
#                                 tags="file_text")
#         ################################## END #################################
#
#         ############################## Station Top #############################
#         # This def station_top function will be connected to the top level of the stations
#         station_image = Image.open("station_button_2.png")
#         station_image = station_image.resize((252, 55))
#         station_image = ImageTk.PhotoImage(station_image)
#
#         def station_top():
#             self.parent.destroy()
#             stations.MainApplication1()
#
#         self.stations_button = tk.Button(self.parent, image=station_image, font=('arial', 12, 'bold'), width=250,
#                                          height=53,
#                                          command=station_top, bd=0, highlightthickness=0)
#         # self.stations_button.place(x=52, y=50)
#         self.stations_button.place(x=52, y=52)
#
#         ############################### END ####################################
#
#         ############################## Route Top ###############################
#         # This def route_top function will be connected to the top level of the stations
#         def route_top():
#             self.parent.destroy()
#             routes.MainApplication2()
#
#         route_image = Image.open("route_png.png")
#         route_image = route_image.resize((246, 50))
#         route_image = ImageTk.PhotoImage(route_image)
#         # Create route Button
#         self.routes_button = tk.Button(self.parent, image=route_image, width=244, height=48,
#                                        bg="cyan", fg="black", command=route_top, bd=0, highlightthickness=0)
#         # Set the position of button on the window.
#         self.routes_button.place(x=56, y=167)
#
#         ################################ END ###################################
#
#         ############################# Journey Top ##############################
#         def journey_top():
#             self.parent.destroy()
#             journey.MainApplication3()
#
#         journey_image = Image.open("journey_png.png")
#         # journey_image = journey_image.resize((246, 50))
#         journey_image = ImageTk.PhotoImage(journey_image)
#
#         self.journeys_button = tk.Button(self.parent, image=journey_image, font=('arial', 12, 'bold'), width=210,
#                                          height=52, bd=0, highlightthickness=0,
#                                          bg="cyan", fg="black", command=journey_top)
#         self.journeys_button.place(x=64, y=280)
#
#         ############################## END ####################################
#
#         ############################ Trigger Top ##############################
#         def trigger_top():
#             self.parent.destroy()
#             trigger.MainApplication4()
#
#         trigger_image = Image.open("triggger_png.png")
#         # trigger_image = trigger_image.resize((246, 50))
#         trigger_image = ImageTk.PhotoImage(trigger_image)
#
#         self.triggers_button = tk.Button(self.parent, image=trigger_image, font=('arial', 12, 'bold'), width=113,
#                                          height=44, bd=0, highlightthickness=0,
#                                          bg="cyan", fg="black", command=trigger_top)
#         self.triggers_button.place(x=52, y=390)
#
#         ############################# END #####################################
#
#         # ############################ Export Top ###################################
#
#         def export_top():
#             self.parent.destroy()
#             export.MainApplication5()
#
#         export_image = Image.open("export_png.png")
#         # trigger_image = export_image.resize((246, 50))
#         export_image = ImageTk.PhotoImage(export_image)
#         self.export_button = tk.Button(self.parent, image=export_image, width=99, height=46,
#                                        bd=0, highlightthickness=0, bg="cyan", fg="black", command=export_top)
#         self.export_button.place(x=200, y=390)
#         ############################ END ######################################
#         self.parent.mainloop()
#
#
# if __name__ == "__main__":
#     MainApplication()
#


# n = 0
# def number_s():
#     global n
#     n += 1
#     if n == 5:
#         return
#     number_s()
#     print(n)
# number_s()

# b = "ST9990"
# A = int(b[2:])+1
# num_zero = 4 - len(str(A))
# print("ST"+"0"*num_zero+str(A))
# ab = ['MA0001EN.MP3', 'MA0001HI.MP3', 'MA0001MR.MP3', 'MA0002EN.MP3', 'MA0002HI.MP3', 'MA0002MR.MP3']
# if 'MA0001HI.M3' in ab:
#     print("yooo")
# else:
#     print("noo")

# from pysqlcipher3 import dbapi2 as sqlite
# conn = sqlite.connect('triggers_abhay - Copy.db')
# c = conn.cursor()
# c.execute("PRAGMA key='PPS'")
# c.execute("select * from tbl_station")
# data = c.fetchall()
# print(data)
# conn.commit()
# c.close()



# from tkinter import *
# import file_dirprint
# tk = __ab__.TK()
# tk.mainloop()
# import pygame
#
# print (pygame.ver)

# file_path = "sqlData\\audio\\MA0006HI.MP3"
# file_path = "one_sec.mp3"
# from playsound import playsound
# playsound(file_path)
# import pygame.mixer
# pygame.mixer.init()
# # pygame.mixer.music.load(f"sqlData\\audio\\{self.audio_file_Entry.get()}")
# pygame.mixer.music.load(file_path)
# pygame.mixer.music.play(loops=0)


# messages = '[MT0004]<field04>[MT0001]</field04><field03>[MT0002]{endStationLong}[MT0003]</field03>'
# messages = '<field04>[MT0001]</field04><field03>[MT0002]{endStationLong}[MT0003]</field03>'
# text = ""
# list_file = []
# for item in messages:
#     if item in ['<', '[', '{']:
#         text += item
#     elif item in ['>', ']', '}']:
#         text += item
#         list_file.append(text)
#         text = ""
#     else:
#         text += item
# dis_for_elements = {"full": []}
# tag_name = "full"
# for item in list_file:
#     # print(item)
#     if item[1] == "/":
#         tag_name = "full"
#     elif item[0] == "<":
#         tag_name = item
#         dis_for_elements[tag_name] = []
#     elif item[0] == "[":
#         dis_for_elements[tag_name].append(item)
# print(dis_for_elements)

# from tkinter import *
# ab = Tk()
# ab.geometry('200x200')
# label_text = "This line slider calls the slider function to start the animation. Run the program you can see the text has been animated"
# ab.mainloop()

# import tkinter as tk
#
# root = tk.Tk()
# root.geometry('300x300')
#
# # txt = 'Sample'
# txt = "This line slider calls the slider function to start the animation. Run the program you can see the text has been animated"
#
# lbl = tk.Label(root, font='Bell 20 bold', width=100, justify="right")
# lbl.pack(pady=5)
#
# def animate_label(text, n=0):
#     if n < len(text):
#         # not complete yet, schedule next run one second later
#         lbl.after(100, animate_label, text, n+1)
#         if n == len(text)-1:
#             lbl.after(100, animate_label, text, 0)
#     # update the text of the label
#     lbl['text'] = text[60:n+1]
#     print(n, len(text))
# root.after(100, animate_label, txt)
# root.mainloop()


# dist = {1: ["a", 'g', "h"], 2: ['b', 'e', 'w'], 3: ['c','d', 'h']}
# dist[1].append("gk")
# # dist.pop(2)
# print(dist)
# lis = ['a', 'b', 'c', 'd']
# current_st = 'b'
# if 0 < lis.index(current_st):
#     print("PRV : ", lis[lis.index(current_st)-1])
# if lis.index(current_st) < lis.index(lis[-1]):
#     print("NEXT : ", lis[lis.index(current_st)+1])


# lis = ['a', 'b', 'c', 'd']
# current_st = 'a'
#
# # Find the index of the current element and the last element
# current_index = lis.index(current_st)
# last_index = len(lis) - 1
#
# # Print the previous element if it's not the first element
# if current_index > 0:
#     print(lis[current_index - 1])
#
# # Print the next element if it's not the last element
# if current_index < last_index:
#     print(lis[current_index + 1])


# from tkinter import *
#
# # update delay in milliseconds
# UpdateDelay = 100
#
# # the text to display
# # s = 'The quick brown fox jumps over the lazy dog.'
# s = "This line slider calls the slider function to start the animation. Run the program you can see the text has been animated"
#
# # the index of the character to display at left margin of label
# s_index = 0
#
# def update(n=0, space=0):
#     """Update Label text every whenever."""
#     global UpdateDelay
#     display = s
#     print(n, len(display), space)
#     if n <= len(display):
#         l.configure(text=display[0:n])
#         root.after(UpdateDelay, update, n+1)
#     elif n > len(display):
#         l.configure(text=display[0:n]+" "*space)
#         if space == 70:
#             root.after(UpdateDelay+500, update, 0, 0)
#         else:
#             root.after(UpdateDelay, update, n, space+1)
#
# root = Tk()
#
# l = Label(root, bg="red", width=30, justify='right', anchor="e")
# l.pack()
#
# root.after(UpdateDelay, update)         # start the update mechanism
#
# root.mainloop()


lis = ['Amritsar Junction', 'Surat', 'Borivali', 'Mumbai Central']
print(lis[lis.index('Mumbai Central')+1:])