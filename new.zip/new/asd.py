import cv2
# import numpy as np

# # from cv2 import cv2
# cap = cv2.VideoCapture("http://192.168.137.58:8080/video")
# # cap = cv2.VideoCapture("http://192.168.1.10:34567/video")
# # cap = cv2.VideoCapture("rtsp://192.168.0.11:554/avstream/channel=1/stream=0-1.sdp")
# # cap = cv2.VideoCapture(0)

# while(True):
#     ret, frame = cap.read()
#     # if frame is not None:
#     #     cv2.imshow("frame", frame)
#     # q = cv2.waitkey(1)
#     # if q == ord("q"):
#     #     break
#     cv2.imshow('frame', frame)
#     if cv2.waitKey(1) & 0xFF == ord('a'):
#         break

# cap.release()
# cv2.destroyAllWindows()


import cv2

# cap = cv2.VideoCapture("http://192.168.137.32:8080/video")
# cap1 = cv2.VideoCapture("http://192.168.137.250:8080/video")
cap = cv2.VideoCapture("rtsp://192.168.0.11:554/avstream/channel=1/stream=0-1.sdp")
cap1 = cv2.VideoCapture("rtsp://192.168.0.12:554/avstream/channel=1/stream=0-1.sdp")
while True:
    ret, frame = cap.read()
    ret1, frame1 = cap1.read()

    if ret:
        cv2.imshow("Camera 1", frame)

    if ret1:
        cv2.imshow("Camera 2", frame1)

    if cv2.waitKey(1) & 0xFF == ord('a'):
        break

cap.release()
cap1.release()
cv2.destroyAllWindows()
