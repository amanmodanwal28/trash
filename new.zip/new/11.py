
# import datetime
# import calendar

# a = '19/03/2024-06:55:41'
# date, time = a.split('-')
# date_parts = date.split('/')
# time_parts = time.split(':')
# result = ','.join(date_parts + time_parts)
# print(result)
# date_and_time_percentage = datetime.datetime.strptime(result, '%d,%m,%Y,%H,%M,%S')
# change_dec_value = calendar.timegm(date_and_time_percentage.timetuple())
# hex_dec_and_time = format(int(change_dec_value), '02X')
# print(hex_dec_and_time)


# x = frozenset(("apple", "banana", "cherry"))

# #display x:
# print(x)

# #display the data type of x:
# print(type(x))


# l=[1,2,[4],[3,5]]
# print(l[0]+l[1]+l[2][0]+l[3][0]+l[3][1])
# a = 0
# for i in l:
#         if type(i) == type([]):
#                 for j in i:
#                      a += j
#         else:
#                 a += i
# print(a)


# content = "अगला स्टेशन : "
# lis_content = []
# for i in content:
#     content_hex = i.encode('utf-8').hex().upper()[-2:]
#     lis_content.append(content_hex)
# print("".join(lis_content))

# import codecs
# #
# # Example hex values
# hex_values = "5"
# result_string = codecs.decode(hex_values, 'hex').decode('utf-8')
# #
# print(result_string)
# print(type(result_string))

# a = ""
# print(a[:2])

# content = "H1"
# for i in content:
#     content_hex = i.encode('utf-8').hex().upper()[-2:]
#     print(content_hex)

# def decora(a,b):
#     if a < b:
#         a, b = b, a
#
# def add(a, b):
#     decora(a,b)
#     return a-b
#
# print(add(3, 5))

# from sqlalchemy import create_engine

# Create your engine.
# engine = create_engine("sqlite:///:memory:")

# import pandas as pd
# import pyodbc
#
# # cnxn_str = (r'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;AttachDbFileName="C:\Users\PTCS1\Desktop\tims folder\BT_bengali_KGP_MEMU_30072022\DATA\tts_ims_data.MDF";'
# #     r'DRIVER=ODBC Driver 11 for SQL Server;'
# #     r'SERVER=LP-ABHAY-PTC;'
# #     r'Trusted_Connection=yes;'
# #     r'AttachDbFileName="C:\Users\PTCS1\Desktop\tims folder\BT_bengali_KGP_MEMU_30072022\DATA\tts_ims_data.MDF";'
# # )
# cnxn = pyodbc.connect(driver='{SQL Server}', dbq=r'C:\Users\PTCS1\Desktop\tims folder\BT_bengali_KGP_MEMU_30072022\DATA\tts_ims_data.MDF')
# # df = pd.read_sql("SELECT * FROM Table1", cnxn)

# from sqlalchemy import create_engine
#
# # DEFINE THE DATABASE CREDENTIALS
# user = 'root'
# password = 'password'
# host = '127.0.0.1'
# port = 3306
# database = r'C:\Users\PTCS1\Desktop\tims folder\BT_bengali_KGP_MEMU_30072022\DATA\tts_ims_data.MDF'
#
#
# # PYTHON FUNCTION TO CONNECT TO THE MYSQL DATABASE AND
# # RETURN THE SQLACHEMY ENGINE OBJECT
# def get_connection():
#     return create_engine(
#         url="mysql+pymysql://{0}:{1}@{2}:{3}/{4}".format(
#             user, password, host, port, database
#         )
#     )
#
#
# if __name__ == '__main__':
#
#     try:
#
#         # GET THE CONNECTION OBJECT (ENGINE) FOR THE DATABASE
#         engine = get_connection()
#         print(
#             f"Connection to the {host} for user {user} created successfully.")
#     except Exception as ex:
#         print("Connection could not be made due to the following error: \n", ex)

# from asammdf import MDF
# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt

# filename = "tts_ims_data.MDF"
# yop = open(filename, "rb")
# print(str(yop.read()).replace("\\x00", ""))
# for i in yop:
#     print(str(i).replace("\\x00", ""))

# with open(filename, "rb") as file:
#     print(file.read())

# a = [()]
# if a:
#     print("yoo")
# import chardet
#
#
# def detect_encoding(file_path):
#     with open(file_path, 'rb') as file:
#         detector = chardet.universaldetector.UniversalDetector()
#         for line in file:
#             detector.feed(line)
#             if detector.done:
#                 break
#         detector.close()
#     return detector.result['encoding']
#
# file_path = 'MT0014HI.TXT'
# encoding = detect_encoding(file_path)
# ap = open(file=file_path, encoding=encoding)
# # ap = open(file="aa.txt")
# print(ap.read())

# import pyodbc
#
# conn = pyodbc.connect(
#             'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=BT_bengali_KGP_MEMU_30072022;Trusted_Connection=yes;')
# my_cursor = conn.cursor()
# my_cursor.execute(f'''select * from tbl_messages''')
# tbl_messages_data = my_cursor.fetchall()
# lis = []
# num = 0
# for name, description in tbl_messages_data:
#     num += 1
#     lis.append(name)
#
# print(lis)


# lis = ['MA0001', 'MT0011', 'AA0001', 'AA0002', 'AA0003', 'MA001B', 'PR0001', 'AA0004', 'SP0001', 'MT001B', 'MT001C', 'TA0010', 'MA0002', 'MT0015', 'MT0003', 'MT0004', 'MT0005', 'MT0006', 'MT0007', 'SP0101', 'MT0008', 'MT0009', 'MA0003', 'MT000A', 'MT000D', 'MB0003', 'MT0010', 'MT000C', 'MT000E', 'MT000F', "AA0041"]
# new_lis = []
# dict_n = {}
# old_data = {}
# for item in lis:
#     if item[:2] in dict_n.keys():
#         num = dict_n[item[:2]]+1
#         dict_n[item[:2]] = num
#         num_len = 4 - len(str(num))
#     else:
#         dict_n[item[:2]] = 1
#         num = 1
#         num_len = 4 - len(str(num))
#     save_file_name = f"{item[:2]}{'0'*num_len}{num}"
#     # new_lis.append(f"{item[:2]}{'0'*num_len}{num}")
# print(new_lis)

# import os
# path = "slqData\\audio\\"
# path = "sqlData\\audio\\"
# dir_list = os.listdir(path)
# # f = open("demofile2.txt", "a", encoding='utf-8')
# # f.truncate(0)
# # # f.write("aa")
# # f.write("अगला स्टेशन :")
# # f.close()


# import pandas as pd
# # data=pd.read_excel(io='Book1.xlsx' ,dtype={'Roll. No.':int,'Student_Name':object,'English':int,'Maths':int})
# # print(data.)
# # for data_item in data:
# #     print(data_item)

# import csv
#
# with open('example.csv', newline='') as csvfile:
#     reader = csv.reader(csvfile)
#     for row in reader:
#         print(', '.join(row))
# list_data = ["Mumbai CSMT", "Masjid", "Sandhurst Road", "Byculla", "Chinchpokli", "Curry Road", "Parel", "Dadar", "Matunga", "Sion", "Kurla", "Vidyavihar", "Ghatkopar", "Vikhroli", "Kanjur Marg", "Bhandup", "Nahur", "Mulund", "Thane", "Kalwa", "Mumbra", "Diva", "Kopar", "Dombivli", "Thakurli", "Kalyan", "Vithalwadi", "Ulhasnagar", "Ambarnath", "Badlapur", "Vangani", "Shelu", "Neral",  "Bhivpuri", "Karjat", "Palasdhari", "Kelavali", "Dolavali", "Lowjee"]
# list_data2 = ["Masjid", "Sandhurst Road", "Byculla", "Chinchpokli", "Curry Road", "Parel", "Dadar", "Matunga", "Sion", "Kurla", "Vidyavihar", "Ghatkopar", "Vikhroli", "Kanjur Marg", "Bhandup", "Nahur", "Mulund", "Thane", "Kalwa", "Mumbra", "Diva", "Kopar", "Dombivli", "Thakurli", "Kalyan", "Vithalwadi", "Ulhasnagar", "Ambarnath", "Badlapur", "Vangani", "Shelu", "Neral",  "Bhivpuri", "Karjat", "Palasdhari", "Kelavali", "Dolavali", "Lowjee", "Khopoli"]


# list_data = ["Kasara", "Umbermali", "Khardi", "Thansit", "Atgaon", "Asangaon", "Vashind", "Khadavali", "Titwala", "Ambivali", "Shahad", "Kalyan", "Thakurli", "Dombivli", "Kopar", "Diva", "Mumbra", "Kalwa", "Thane", "Ghatkopar", "Kurla", "Dadar", "Byculla"]
# list_data2 = ["Umbermali", "Khardi", "Thansit", "Atgaon", "Asangaon", "Vashind", "Khadavali", "Titwala", "Ambivali", "Shahad", "Kalyan", "Thakurli", "Dombivli", "Kopar", "Diva", "Mumbra", "Kalwa", "Thane", "Ghatkopar", "Kurla", "Dadar", "Byculla", "Mumbai CSMT" ]
# num_lis = [32, 30, 29, 28, 27, 31, 30, 29, 28, 20, 19, 20, 19, 23, 29, 21, 27, 19, 29, 28, 27, 31, 28]
# number = 0
# dis = {}
# for item, item2, item3 in zip(list_data, list_data2, num_lis):
#     # for item2_ in list_data2:
#     dis[f"{item} to {item2}"] = item3
# print(dis)
#
# # ab = {"Mumbai CSMT to Masjid": 3, "Masjid to Sandhurst Road": 1, "Sandhurst Road to Byculla": 19, "Byculla to Chinchpokli": 20, "Chinchpokli to Curry Road": 1,
# #       "Curry Road to Parel": 21, "Parel to Dadar": 22, "Dadar to Matunga": 23, "Matunga to Sion": 19, "Sion to Kurla": 20,
# #       "Kurla to Vidyavihar": 21, "Vidyavihar to Ghatkopar" : 22, "Ghatkopar to Vikhroli": 23, "Vikhroli to Kanjur Marg": 19, "Kanjur Marg to Bhandup": 20, "Bhandup to Nahur": 21}
#
# mix_dist_re = {'Khopoli to Lowjee': 3, 'Lowjee to Dolavali': 27, 'Dolavali to Kelavali': 1, 'Kelavali to Palasdhari': 31,
#                'Palasdhari to Karjat': 30, 'Karjat to Bhivpuri': 29, 'Bhivpuri to Neral': 28, 'Neral to Shelu': 27,
#                'Shelu to Vangani': 31, 'Vangani to Badlapur': 30, 'Badlapur to Ambarnath': 29, 'Ambarnath to Ulhasnagar': 21,
#                'Ulhasnagar to Vithalwadi': 20, 'Vithalwadi to Kalyan': 19, 'Kalyan to Thakurli': 20,
#                'Thakurli to Dombivli': 19, 'Dombivli to Kopar': 23, 'Kopar to Diva': 29, 'Diva to Mumbra': 21,
#                'Mumbra to Kalwa': 27, 'Kalwa to Thane': 19, 'Thane to Mulund': 23, 'Mulund to Nahur': 22,
#                'Nahur to Bhandup': 21, 'Bhandup to Kanjur Marg': 20, 'Kanjur Marg to Vikhroli': 19,
#                'Vikhroli to Ghatkopar': 23, 'Ghatkopar to Vidyavihar': 22, 'Vidyavihar to Kurla': 21, 'Kurla to Sion': 20,
#                'Sion to Matunga': 19, 'Matunga to Dadar': 23, 'Dadar to Parel': 22, 'Parel to Curry Road': 21,
#                'Curry Road to Chinchpokli': 1, 'Chinchpokli to Byculla': 20, 'Byculla to Sandhurst Road': 19,
#                'Sandhurst Road to Masjid': 1, 'Masjid to Mumbai CSMT': 19, 'Kalyan to Dombivli': 27,
#                'Dombivli to Thane': 31, 'Mulund to Ghatkopar': 29, 'Ghatkopar to Kurla': 28, 'Kurla to Dadar': 27,
#                'Dadar to Byculla': 31, 'Byculla to Mumbai CSMT': 28,
#
#                'Kasara to Umbermali': 3, 'Umbermali to Khardi': 30, 'Khardi to Thansit': 29, 'Thansit to Atgaon': 28,
#                'Atgaon to Asangaon': 27, 'Asangaon to Vashind': 31, 'Vashind to Khadavali': 30, 'Khadavali to Titwala': 29,
#                'Titwala to Ambivali': 28, 'Ambivali to Shahad': 20, 'Shahad to Kalyan': 19,
#                'Thane to Ghatkopar': 29,
#                }
#
# new = {"Mumbai CSMT to Dadar": 32, "Dadar to Vikhroli" : 27, "Vikhroli to Bhandup": 19, "Bhandup to Mulund": 21}
#
# print()



# slow = {'Kasara to Umbermali': 32, 'Umbermali to Khardi': 30, 'Khardi to Thansit': 29, 'Thansit to Atgaon': 28,
#         'Atgaon to Asangaon': 27, 'Asangaon to Vashind': 31, 'Vashind to Khadavali': 30, 'Khadavali to Titwala': 29,
#         'Titwala to Ambivali': 28, 'Ambivali to Shahad': 20, 'Shahad to Kalyan': 19, 'Kalyan to Thakurli': 20,
#         'Thakurli to Dombivli': 19, 'Dombivli to Kopar': 23, 'Kopar to Diva': 29, 'Diva to Mumbra': 21,
#         'Mumbra to Kalwa': 27, 'Kalwa to Thane': 19, 'Thane to Ghatkopar': 29, 'Ghatkopar to Kurla': 28,
#         'Kurla to Dadar': 27, 'Dadar to Byculla': 31, 'Byculla to Mumbai CSMT': 28}

# show = {'Kasara to Umbermali': 3, 'Umbermali to Khardi': 30, 'Khardi to Thansit': 29, 'Thansit to Atgaon': 28,
#         'Atgaon to Asangaon': 27, 'Asangaon to Vashind': 31, 'Vashind to Khadavali': 30, 'Khadavali to Titwala': 29,
#         'Titwala to Ambivali': 28, 'Ambivali to Shahad': 20, 'Shahad to Kalyan': 19, 'Kalyan to Thakurli': 20,
#         'Thakurli to Dombivli': 19, 'Dombivli to Kopar': 23, 'Kopar to Diva': 29, 'Diva to Mumbra': 21,
#         'Mumbra to Kalwa': 27, 'Kalwa to Thane': 19, 'Thane to Mulund': 23, 'Mulund to Nahur': 22,
#         'Nahur to Bhandup': 21, 'Bhandup to Kanjur Marg': 20, 'Kanjur Marg to Vikhroli': 19, 'Vikhroli to Ghatkopar': 23,
#         'Ghatkopar to Vidyavihar': 22, 'Vidyavihar to Kurla': 21, 'Kurla to Sion': 20, 'Sion to Matunga': 19,
#         'Matunga to Dadar': 23, 'Dadar to Parel': 22, 'Parel to Curry Road': 21, 'Curry Road to Chinchpokli': 1,
#         'Chinchpokli to Byculla': 20, 'Byculla to Sandhurst Road': 19, 'Sandhurst Road to Masjid': 1, 'Masjid to Mumbai CSMT': 19}




# fast = {'Khopoli to Lowjee': 32, 'Lowjee to Dolavali': 27, 'Dolavali to Kelavali': 1, 'Kelavali to Palasdhari': 31,
#         'Palasdhari to Karjat': 30, 'Karjat to Bhivpuri': 29, 'Bhivpuri to Neral': 28, 'Neral to Shelu': 27,
#         'Shelu to Vangani': 31, 'Vangani to Badlapur': 30, 'Badlapur to Ambarnath': 29, 'Ambarnath to Ulhasnagar': 21,
#         'Ulhasnagar to Vithalwadi': 20, 'Vithalwadi to Kalyan': 19, 'Kalyan to Dombivli': 27, 'Dombivli to Thane': 31,
#         'Thane to Mulund': 23, 'Mulund to Ghatkopar': 29, 'Ghatkopar to Kurla': 28, 'Kurla to Dadar': 27,
#         'Dadar to Byculla': 31, 'Byculla to Mumbai CSMT': 28}







# mix_dist = {'Mumbai CSMT to Masjid': 3, 'Masjid to Sandhurst Road': 1, 'Sandhurst Road to Byculla': 19,
#              'Byculla to Chinchpokli': 20, 'Chinchpokli to Curry Road': 1, 'Curry Road to Parel': 21, 'Parel to Dadar': 22,
#              'Dadar to Matunga': 23, 'Matunga to Sion': 19, 'Sion to Kurla': 20, 'Kurla to Vidyavihar': 21,
#              'Vidyavihar to Ghatkopar': 22, 'Ghatkopar to Vikhroli': 23, 'Vikhroli to Kanjur Marg': 19,
#              'Kanjur Marg to Bhandup': 20, 'Bhandup to Nahur': 21, 'Nahur to Mulund': 22, 'Mulund to Thane': 23,
#              'Thane to Kalwa': 19, 'Kalwa to Mumbra': 27, 'Mumbra to Diva': 21, 'Diva to Kopar': 29,
#              'Dombivli to Thakurli': 19, 'Thakurli to Kalyan': 20, 'Kalyan to Vithalwadi': 19, 'Vithalwadi to Ulhasnagar': 20,
#              'Ulhasnagar to Ambarnath': 21, 'Ambarnath to Badlapur': 29, 'Badlapur to Vangani': 30, 'Vangani to Shelu': 31,
#              'Shelu to Neral': 27, 'Neral to Bhivpuri': 28, 'Bhivpuri to Karjat': 29, 'Karjat to Palasdhari': 30,
#              'Palasdhari to Kelavali': 31, 'Kelavali to Dolavali': 1, 'Dolavali to Lowjee': 27, 'Lowjee to Khopoli': 28,
#              'Kalyan to Shahad': 19, 'Ambivali to Titwala': 28, 'Titwala to Khadavali': 29,
#              'Khadavali to Vashind': 30, 'Vashind to Asangaon': 31, 'Asangaon to Atgaon': 27, 'Atgaon to Thansit': 28,
#              'Thansit to Khardi': 29, 'Khardi to Umbermali': 30, 'Umbermali to Kasara': 31,
#             'Mumbai CSMT to Byculla': 32, 'Byculla to Dadar': 31, 'Dadar to Kurla': 27, 'Kurla to Ghatkopar': 28,
#             'Ghatkopar to Mulund': 29, 'Thane to Dombivli': 31, 'Dombivli to Kalyan': 27,
#             'Ghatkopar to Thane': 29, 'Kopar to Dombivli': 23, 'Shahad to Ambivali': 20,
#             }

# slow_dist = {'Mumbai CSMT to Masjid': 3, 'Masjid to Sandhurst Road': 1, 'Sandhurst Road to Byculla': 19,
#              'Byculla to Chinchpokli': 20, 'Chinchpokli to Curry Road': 1, 'Curry Road to Parel': 21, 'Parel to Dadar': 22,
#              'Dadar to Matunga': 23, 'Matunga to Sion': 19, 'Sion to Kurla': 20, 'Kurla to Vidyavihar': 21,
#              'Vidyavihar to Ghatkopar': 22, 'Ghatkopar to Vikhroli': 23, 'Vikhroli to Kanjur Marg': 19,
#              'Kanjur Marg to Bhandup': 20, 'Bhandup to Nahur': 21, 'Nahur to Mulund': 22, 'Mulund to Thane': 23,
#              'Thane to Kalwa': 19, 'Kalwa to Mumbra': 27, 'Mumbra to Diva': 21, 'Diva to Kopar': 29, 'Kopar to Dombivli': 23,
#              'Dombivli to Thakurli': 19, 'Thakurli to Kalyan': 20, 'Kalyan to Vithalwadi': 19, 'Vithalwadi to Ulhasnagar': 20,
#              'Ulhasnagar to Ambarnath': 21, 'Ambarnath to Badlapur': 29, 'Badlapur to Vangani': 30, 'Vangani to Shelu': 31,
#              'Shelu to Neral': 27, 'Neral to Bhivpuri': 28, 'Bhivpuri to Karjat': 29, 'Karjat to Palasdhari': 30,
#              'Palasdhari to Kelavali': 31, 'Kelavali to Dolavali': 1, 'Dolavali to Lowjee': 27, 'Lowjee to Khopoli': 28,
#              'Kalyan to Shahad': 21, 'Shahad to Ambivali': 22, 'Ambivali to Titwala': 28, 'Titwala to Khadavali': 29,
#              'Khadavali to Vashind': 30, 'Vashind to Asangaon': 31, 'Asangaon to Atgaon': 27, 'Atgaon to Thansit': 28,
#              'Thansit to Khardi': 29, 'Khardi to Umbermali': 30, 'Umbermali to Kasara': 31}
#
#
# fast_dist = {'Mumbai CSMT to Byculla': 32, 'Byculla to Dadar': 31, 'Dadar to Kurla': 27, 'Kurla to Ghatkopar': 28,
#              'Ghatkopar to Mulund': 29, 'Mulund to Thane': 23, 'Thane to Dombivli': 31, 'Dombivli to Kalyan': 27,
#              'Kalyan to Vithalwadi': 19, 'Vithalwadi to Ulhasnagar': 20, 'Ulhasnagar to Ambarnath': 21,
#              'Ambarnath to Badlapur': 29, 'Badlapur to Vangani': 30, 'Vangani to Shelu': 31, 'Shelu to Neral': 27,
#              'Neral to Bhivpuri': 28, 'Bhivpuri to Karjat': 29, 'Karjat to Palasdhari': 30, 'Palasdhari to Kelavali': 31,
#              'Kelavali to Dolavali': 1, 'Dolavali to Lowjee': 27, 'Lowjee to Khopoli': 28,
#              'Ghatkopar to Thane': 29, 'Thane to Kalwa': 19, 'Kalwa to Mumbra': 27, 'Mumbra to Diva': 21, 'Diva to Kopar': 29,
#              'Kopar to Dombivli': 23, 'Dombivli to Thakurli': 19, 'Thakurli to Kalyan': 20, 'Kalyan to Shahad': 19,
#              'Shahad to Ambivali': 20, 'Ambivali to Titwala': 28, 'Titwala to Khadavali': 29, 'Khadavali to Vashind': 30,
#              'Vashind to Asangaon': 31, 'Asangaon to Atgaon': 27, 'Atgaon to Thansit': 28, 'Thansit to Khardi': 29,
#              'Khardi to Umbermali': 30, 'Umbermali to Kasara': 31}


# dist = {"MT001A": "1", "MT0003": "2"}
# aa = "<field00>[MT001A]{endstationlong}[MT0003]</field00>"
# num = len(aa) - 1
# index_num = 0
# for i in aa[-1::-1]:
#     if i == "]":
#         index_num = num
#     elif i == "[":
#         aa =  aa.replace(aa[num+1:index_num], dist[aa[num+1:index_num]])
#     num -= 1
# print(aa)


# from tkinter import *
#
# root = Tk()
# root.geometry('500x500')
# root.title('Good morning :)')
# root.wm_attributes("-transparentcolor", "red")
# frame1 = Frame(root, bg='red', width=200, height=200)
# frame1.place(x=40, y=20)
# def print_hii():
#     print("yooo")
# button1 = Button(frame1, text='Hello', command=print_hii, bg="red", fg="red")
# button1.place(x=90, y=90)
#
# root.mainloop()

# import sqlite3
# import pyodbc
# # a = [(1, 2, 3), [3, 2, 1], [2, 3, 1]]
# # print("yoo" if [1,4,3] in a else "noo")
#
#
# def aliases_dat():
#     # Create the ALIASES.DAT file in the DATA folder
#     # self.aliases_dat_path = os.path.join(self.data_folder, 'ALIASES.DAT')
#     # conn_str = (
#     #     'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
#     # conn = pyodbc.connect(conn_str)
#     conn = sqlite3.connect("triggers_abhay.db")
#     cursor = conn.cursor()
#     conn = (
#         'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=data_555;Trusted_Connection=yes;')
#     # conn = pyodbc.connect(conn)
#     # cursor = conn.cursor()
#
#     # query = 'Select [journeyName] From  [tbl_journeys] Order by case isnumeric([journeyName]) when 1 then cast([journeyName] as int) else 999999999999999 end, [journeyName]'
#     route_tbl = 'SELECT * FROM tbl_routes ORDER BY routeID'
#     # query = 'SELECT [journeyID], [routeID], [journeyName] FROM tbl_journeys ORDER BY CAST(journeyName AS INTEGER),journeyName;'
#
#     cursor.execute(route_tbl)
#     rows_route = cursor.fetchall()
#     list_of_journey_id_aliases_dat = {}
#     all_list_of_journey_id_aliases_dat = {}
#     # list_for_J_stop = []
#     list_for_J_stop_2 = {}
#     list_for_J_stop_3 = []
#     set_j_stop = set()
#     list_repeat_journey = []
#     # list_repeat_journey.count()
#     # list_for_J_stop = []
#     num = 1
#     for ID, name_route in rows_route:
#         cursor.execute(f'SELECT [journeyID], [routeID], [journeyName] FROM tbl_journeys where routeID={ID} ORDER BY journeyID;')
#         rows_journeys = cursor.fetchall()
#         # list_for_J_stop.clear()
#         for journeyID, routeID, journeyName in rows_journeys:
#             # print(ID, journeyID, routeID, journeyName)
#             # cursor.execute(
#                 # f'SELECT [routeStopID],[arrivalTime], [departureTime], [platformNum], [conditional], [combiTriggerID], [languageArea] FROM [tbl_journeyStops] where journeyID={journeyID}')
#             cursor.execute(
#                 f'SELECT [routeStopID],[arrivalTime], [depactureTime], [platformNum], [conditional], [combiTriggerID], [languageArea] FROM [tbl_journeyStops] where journeyID={journeyID}')
#             rows_journey_stops = cursor.fetchall()
#             list_for_J_stop = []
#
#             for routeStopID, arrivalTime, departureTime, platformNum, conditional, combiTriggerID, languageArea in rows_journey_stops:
#                 i = (routeStopID, arrivalTime, departureTime, platformNum, conditional, combiTriggerID, languageArea)
#                 i2 = (journeyName, routeStopID, arrivalTime, departureTime, platformNum, conditional, combiTriggerID, languageArea)
#                 if i not in list_for_J_stop:
#                     list_for_J_stop.append(i)
#
#             if list_for_J_stop not in list_for_J_stop_2.values():
#                 list_for_J_stop_2[journeyName] = list_for_J_stop
#                 print(journeyName, journeyName, journeyID, journeyID)
#                 list_of_journey_id_aliases_dat[journeyName] = journeyID
#                 set_j_stop.add(journeyName)
#                 if not list_repeat_journey.count(journeyID):
#                     list_repeat_journey.append(journeyID)
#
#                 all_list_of_journey_id_aliases_dat[journeyID] = journeyID
#
#
#             elif list_for_J_stop in list_for_J_stop_2.values():
#                 out_put = list(list_for_J_stop_2.keys())[list(list_for_J_stop_2.values()).index(list_for_J_stop)]
#                 print(journeyName, out_put, journeyID, list_of_journey_id_aliases_dat[out_put])
#                 all_list_of_journey_id_aliases_dat[journeyID] = list_of_journey_id_aliases_dat[out_put]
#                 if not list_repeat_journey.count(list_of_journey_id_aliases_dat[out_put]):
#                     list_repeat_journey.append(list_of_journey_id_aliases_dat[out_put])
#
#                 set_j_stop.add(out_put)
#             # num += 1
#             # print(journeyName, list_for_J_stop)
#             # print(list_for_J_stop_2)
#         list_for_J_stop_2 = {}
#         print(list_for_J_stop_2.keys())
#     print(set_j_stop)
#     print(list_repeat_journey)
#     print(len(list_repeat_journey))
#     print(all_list_of_journey_id_aliases_dat)
#         # break
#     # cursor.execute(query)
#     # try:
#     #     # with open(self.aliases_dat_path, 'w', encoding='utf-8') as gps_dat_file:
#     #         for row in rows:
#     #             journey_name = row[0]
#     #             num = 8
#     #             journey_name_value = f"{journey_name}{' ' * (num - len(journey_name))}"
#     #             # journey_name_value_back = f"{' ' * (num - len(journey_name))}{journey_name}"
#     #             print(f"{journey_name_value}{journey_name_value}\n")
#     #             # gps_dat_file.write(f"{journey_name_value}{journey_name_value}\n")
#     #
#     # except Exception as e:
#     #     print(f"An error occurred while exporting GPS data2222: {e}")
#     # finally:
#     cursor.close()
#     conn.close()
# aliases_dat()
#
#









# import sqlite3
#
# conn = sqlite3.connect("triggers_abhay.db")
# cursor = conn.cursor()
#
# query = 'SELECT [routeID],[routeStopID],[stationID],[distanceFromPrev] FROM [tbl_routeStops] order by routeID, routeStopID'
# cursor.execute(query)
# rows = cursor.fetchall()
# length_of_rstops = {}
# length_of_rstops_new = {}
# # data_set = set()
# try:
#     number_of_point = 1
#     for row in rows:
#         routestops_id = row[0]
#         routestopsorder_id = row[1]
#         routestops_station_id = row[2]
#         routestops_distance_preview = row[3]
#         # query = 'SELECT [routeID],[routeStopID],[stationID],[distanceFromPrev] FROM [tbl_routeStops] order by routeID, routeStopID'
#         # cursor.execute(query)
#         # print(routestops_id)
#
#         len_data = 22 * number_of_point
#
#         if int(row[0]) != rows[number_of_point][0]:
#             length_of_rstops[rows[number_of_point][0]] = len_data
#             if rows[number_of_point][0] == rows[-1][0]:
#                 break
#         elif len(length_of_rstops) < 1:
#             length_of_rstops[rows[number_of_point][0]] = 0
#
#         print(row[0], rows[number_of_point][0])
#
#         number_of_point += 1
#
#         hex_value_routestops_id = format(int(routestops_id), '04X')
#
#         hex_value_routestopsorder_id = format(int(routestopsorder_id), '04X')
#
#         hex_value_routestops_station_id = format(int(routestops_station_id), '04X')
#         if routestops_distance_preview and routestops_distance_preview != 'Empty':
#             hex_value_routestops_distance_preview = hex(int(routestops_distance_preview))[2:].upper().zfill(8)
#         else:
#             hex_value_routestops_distance_preview = '00000000'
#
#         # rstops_dat_file.write(f"{hex_value_routestops_id}{hex_value_routestopsorder_id}{hex_value_routestops_station_id}{hex_value_routestops_distance_preview}\n")
#         # print((f"{hex_value_routestops_id}{hex_value_routestopsorder_id}{hex_value_routestops_station_id}{hex_value_routestops_distance_preview}\n"))
# except Exception as e:
#     print(f"An error occurred while exporting GPS data111000: {e}")
# finally:
#     cursor.close()
#     conn.close()
#     print("self.length_of_rstops_new", length_of_rstops_new)
#     print("self.length_of_rstops", length_of_rstops)
#
# import xml.etree.ElementTree as ET
# my_tr = ET.parse("projectinfo.xml")
# root = my_tr.getroot()
# for i in root.findall("ImsLanguages"):
#     it = i.find("Code").text
#
#     it1 = i.find("uni_sub").text
#     it2 = i.find("add").text
#     print(it, it2, it1)
#     break

# MYPORT = 8000
# MYGROUP_4 = '224.0.0.1'
# MYTTL = 1 # Increase to reach other networks
#
# import time
# import struct
# import socket
# import sys
#
# def main():
#     group = MYGROUP_6 if "-6" in sys.argv[1:] else MYGROUP_4
#
#     if "-s" in sys.argv[1:]:
#         sender(group)
#     else:
#         receiver(group)
#
#
# def sender(group):
#     addrinfo = socket.getaddrinfo(group, None)[0]
#
#     s = socket.socket(addrinfo[0], socket.SOCK_DGRAM)
#
#     # Set Time-to-live (optional)
#     ttl_bin = struct.pack('@i', MYTTL)
#     if addrinfo[0] == socket.AF_INET: # IPv4
#         s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl_bin)
#     else:
#         s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_MULTICAST_HOPS, ttl_bin)
#
#     while True:
#         data = repr(time.time())
#         data = repr(time.time())
#         s.sendto(data + '\0', (addrinfo[4][0], MYPORT))
#         time.sleep(1)
#
#
# def receiver(group):
#     # Look up multicast group address in name server and find out IP version
#     addrinfo = socket.getaddrinfo(group, None)[0]
#
#     # Create a socket
#     s = socket.socket(addrinfo[0], socket.SOCK_DGRAM)
#
#     # Allow multiple copies of this program on one machine
#     # (not strictly needed)
#     s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#
#     # Bind it to the port
#     s.bind(('', MYPORT))
#
#     group_bin = socket.inet_pton(addrinfo[0], addrinfo[4][0])
#     # Join group
#     if addrinfo[0] == socket.AF_INET: # IPv4
#         mreq = group_bin + struct.pack('=I', socket.INADDR_ANY)
#         s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
#     else:
#         mreq = group_bin + struct.pack('@I', 0)
#         s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_JOIN_GROUP, mreq)
#
#     # Loop, printing any data we receive
#     while True:
#         data, sender = s.recvfrom(1500)
#         while data[-1:] == '\0': data = data[:-1] # Strip trailing \0's
#         print(str(sender) + '  ' + repr(data))
#
# # receiver("'224.0.0.1'")
# if __name__ == '__main__':
#     main()

#
# # import hashlib
# # file_name = 'MV0011RE.MP4'
# file_name = 'python_vi.MP4'
# # m = hashlib.md5()
# # for line in open(file_name, 'rb'):
# #     m.update(line)
# # print(m.hexdigest())
#
# import zlib
# import crcmod.predefined
# def crc32(fileName):
#     with open(fileName, 'rb') as fh:
#         hash = 0
#         while True:
#             s = fh.read(65536)
#             if not s:
#                 break
#             hash = zlib.crc32(s, hash)
#         return "%08X" % (hash & 0xFFFFFFFF)
# print(crc32(file_name))
# #FDC1DD59
# crc_func = crcmod.predefined.mkCrcFun('crc-32')
# with open(file_name, 'rb') as file:
#     crc_value = crc_func(file.read())
#
# crc_formatted = f"{crc_value}"
# # crc_formatted = f"{crc_value:08X}"
# print(crc_formatted, "hhhh")


# 185251

# 180 GB



# import sqlite3
# conn = sqlite3.connect("triggers_abhay.db")
# cursor = conn.cursor()
# cursor.execute(f"SELECT * from tbl_routes")
# data = cursor.fetchall()
# dict_all = {}
# for item in data:
#     cursor.execute(f"SELECT routeID, stopOrder, stationID from tbl_routeStops where routeID")
#     data_2 = cursor.fetchall()
#     if data_2:
#         if data_2 in dict_all.values():
#             print(item)
#         dict_all[item[0]] = [data_2]
# # print(dict_all)
# conn.commit()
# conn.close()


# print(hex(ord("क")))
# print(hex(0x0900 + 0xB0+ord("क")))

# for i in range(3):
#     for j in "abh":
#         if j == "b":
#             continue
#         print(j)
#     print(i)

# import os, shutil
# print(os.path.isdir("C:/Users/PTCS1/Documents/EXPORT"))
# shutil.rmtree("C:/Users/PTCS1/Documents/EXPORT")

# a = "abcdefgh"[5:: -1]
# print(a)
# for i in range(5):
#     print(i)

# my_tr1 = ET.parse("projectinfo.xml")
# root1 = my_tr1.getroot()
# list_lang = []
# markupCode_feild_list = []
# for i in root1.findall("markupCode"):
#     it = i.find("group").text
# lis = ["12", "13"]
# def route(number=""):
#     if lis.count(number):
#         print("Okk")
#     else:
#         print("no route found")
# route("122")
# a = "x44x41x4Cx47x41x4Fx4E".replace("x", "")
# new_a = bytes.fromhex(a).decode('unicode-escape')
# print(new_a)

# from tkinter import ttk
# import tkinter as tk
# # from sqlalchemy import create_engine
# # my_conn = create_engine("mysql+mysqldb://userid:pw@localhost/my_db")
# # Creating tkinter my_w
# my_w = tk.Tk()
# my_w.geometry("400x280")
# my_w.title("www.plus2net.com")
# # Using treeview widget
# trv = ttk.Treeview(my_w, selectmode ='browse')
# trv.grid(row=1,column=1,padx=20,pady=20)
#
# # number of columns
# trv["columns"] = ("1", "2", "3","4","5")
#
# # Defining heading
# trv['show'] = 'headings'
#
# # width of columns and alignment
# trv.column("1", width = 30, anchor ='c')
# trv.column("2", width = 80, anchor ='c')
# trv.column("3", width = 80, anchor ='c')
# trv.column("4", width = 80, anchor ='c')
# trv.column("5", width = 80, anchor ='c')
# # Headings
# # respective columns
# trv.heading("1", text ="id")
# trv.heading("2", text ="Name")
# trv.heading("3", text ="Class")
# trv.heading("4", text ="Mark")
# trv.heading("5", text ="Gender")
# # getting data from MySQL student table
# # r_set=my_conn.execute('''SELECT * from student LIMIT 0,10''')
# for dt in range(5):
#     trv.insert("", 'end', text=dt,
#                values =(dt,dt))
# my_w.mainloop()

# from tkinter import ttk
# import tkinter as tk
# my_w = tk.Tk()
# my_w.geometry("450x380")  # width and height of window
# my_w.title("www.plus2net.com")  # title of the window
# i=0
# def my_move(direction):
#     global i
#     if(direction=='Up'): # Up button is clicked
#         i=int(i)-1
#     else:
#         i=int(i)+1
#     trv.selection_set(i)
# bt1=tk.Button(my_w,text='Up',command=lambda:my_move('Up'))
# bt1.grid(row=1,column=0,padx=5,pady=10)
# bt2=tk.Button(my_w,text='Down',command=lambda:my_move('Down'))
# bt2.grid(row=1,column=1,padx=5,pady=10)
#
# trv=ttk.Treeview(my_w,selectmode='browse',show='headings')
# trv.grid(row=2,column=0,columnspan=3,padx=30,pady=10)
# # column identifiers
# trv["columns"] = ("1", "2","3","4")
# trv.column("1", width = 50, anchor ='w')
# trv.column("2", width = 150, anchor ='c')
# trv.column("3", width = 100, anchor ='c')
# trv.column("4", width = 70, anchor ='c')
#
# trv.heading(1, text ="id",anchor='w')
# trv.heading(2, text ="Name",anchor='c')
# trv.heading(3, text ="Class",anchor='c')
# trv.heading(4, text ="Mark",anchor='c')
#
# trv.insert("",'end',iid=1,values=(1,'Alex1','Four',78))
# trv.insert("",'end',iid=2,values=(2,'Alex2','Four',80))
# trv.insert("",'end',iid=3,values=(4,'Alex3','Four',78))
# trv.insert("",'end',iid=4,values=(5,'Alex4','Five',80))
# trv.insert("",'end',iid=5,values=(6,'Alex5','Sixr',40))
# trv.insert("",'end',iid=6,values=(7,'Alex6','Four',70))
# trv.insert("",'end',iid=7,values=(8,'Alex7','Three',50))
#
# #trv.selection_set('b')
# #p_id=trv.selection()[0]
# #print(p_id)
# def data_collect(*args):
#     global i
#     i=trv.selection()[0] #iid value of the selection
#     print(i)
# # trv.bind("<>",data_collect) # On select event or row
#
# my_w.mainloop()


# import tkinter as tk
# from tkinter import *
# from tkinter import ttk
#
#
# root = Tk()
# root.title("Move Row UP and DOWN")
#
# frame_container = tk.Frame(root, padx=10, pady=10, bg='#badc58')
# frame_fields = tk.Frame(frame_container, bg='#badc58')
#
# # create treeview
# trv = ttk.Treeview(frame_container, columns=(1,2,3,4), show='headings')
#
# trv.column(1, anchor='center', width=100)
# trv.column(2, anchor='center', width=100)
# trv.column(3, anchor='center', width=100)
# trv.column(4, anchor='center', width=100)
#
# trv.heading(1, text='ID')
# trv.heading(2, text='Name')
# trv.heading(3, text='Quantity')
# trv.heading(4, text='Price')
#
# # add items to the treeview
# trv.insert("",'end', iid=1, values=(1,"Product 1",100, 10))
# trv.insert("",'end', iid=2, values=(2,"Product 2",200, 20))
# trv.insert("",'end', iid=3, values=(3,"Product 3",300, 30))
# trv.insert("",'end', iid=4, values=(4,"Product 4",400, 400))
# trv.insert("",'end', iid=5, values=(5,"Product 5",500, 50))
# trv.insert("",'end', iid=6, values=(6,"Product 6",600, 60))
#
# # create a function to move the selected row up
# def moveUp():
#     leaves = trv.selection()
#     for i in leaves:
#         trv.move(i, trv.parent(i), trv.index(i)-1)
#
# # create a function to move the selected row down
# def moveDown():
#     leaves = trv.selection()
#     for i in reversed(leaves):
#         trv.move(i, trv.parent(i), trv.index(i)+1)


# btn_up = tk.Button(frame_fields, text='UP', command=moveUp)
# btn_down = tk.Button(frame_fields, text='DOWN', command=moveDown)
#
# btn_up.grid(row=0, column=0, padx=10, pady=10, sticky='e')
# btn_down.grid(row=0, column=1)
#
#
# trv.pack()
# frame_container.pack()
# frame_fields.pack()
#
# root.mainloop()
# import time
#
# j = 15483
# journey_list_xml = ["dl", "jun", "bbs", "rmp"]
#
# station_name_list_xml = {"dl": ("delhi", "x", "y", "z"), "jun": ("jounpur", "x", "y", "z"), "bbs": ("varanasi", "x", "y", "z"), "rmp": ("rampur", "x", "y", "z")}
#
# for item in journey_list_xml:
#     priv_station = "no station"
#     station_info = station_name_list_xml[item]
#     last_station = station_name_list_xml[journey_list_xml[-1]][0]
#     start_station = station_name_list_xml[journey_list_xml[0]][0]
#     if journey_list_xml.index(item) > 0:
#         priv_station = journey_list_xml.index(item) - 1
#         priv_station = station_name_list_xml[journey_list_xml[priv_station]]
#         # print()
#     print(station_info, f"start station = {start_station}", f"Last station = {last_station}", f"priv station = {priv_station}")
#
#     time.sleep(2)


# dic_lis = {1: "a", 2: "b", 3: "c", 4: "d"}
# dic_lis[4] = "j"
# dic_lis[5] = "d"
# dic_lis[6] = "/j"
# for i in dic_lis.values():
#     print(i)

# print(dic_lis)

#
# from tkinter import *
#
#
# def printbutton(btn):
#     print(btn)
#     print(btn["text"])
#
#
# root = Tk()
# root.geometry('500x500')
#
# r, c = 0, 0
# width = 21
#
# for x in range(1, 100):
#     b = Button(root, text=str(x))
#     b.grid(row=r, column=c, sticky=N + S + E + W)  # use grid system
#     b["command"] = lambda b=b: printbutton(
#         b)  # now b is defined, so add command attribute to b, where you attach your button's scope within a lambda function
#     # printbutton(b) is the function that passes in the button itself
#     c += 1
#     if c == width:
#         r += 1
#         c = 0
#
# root.mainloop()
# dic_a = {1: "a", 2: "b"}
# # dic_a = [1,2,3,4,5,6,7]
# dic_a.pop(1)
# # print(dic_a)
# abc = "1234567"
# # for item in abc[::-1]:
# for item in list(dic_a)[::-1]:
#     print(item)


# a = "abcdefgh"
#
# print(("true" if a[0] == "a" else "false"))
# import glob
# dir_list = glob.glob("sqlData/txt/MT0001EN.TXT", recursive=True)
# print(dir_list)
# print("\u26A0") # ⚠
# # importing required module
# from playsound import playsound
# from tkinter import *
# import shutil
# import pygame
# from tkVideoPlayer import TkinterVideo
#
# root = Tk()
# root.title('sound player')  # giving the title for our window
# root.geometry("500x400")
#
# pygame.mixer.init()
# # making function
# label_frame_video = ""
# def play():
#     global label_frame_video
#     label_frame_video = LabelFrame(root, text="Video Play")
#     label_frame_video.place(x=0, y=20, height=200, width=290)
#     vid = TkinterVideo(master=label_frame_video)
#     vid.load("MV0011RE.MP4")
#     vid.pack(expand=True, fill="both")
#     vid.play()
#
# def copy_file():
#
#     # pygame.mixer.music.unload()
#     shutil.copy("MV0012EN.MP4", "MV0011RE.MP4")
# def destroy_frame():
#     global label_frame_video
#     label_frame_video.destroy()
#
# # title on the screen you can modify it
# title = Label(root, text="play", bd=9, relief=GROOVE,
#               font=("times new roman", 50, "bold"), bg="white", fg="green")
# title.pack(side=TOP, fill=X)
#
# # making a button which trigger the function so sound can be playeed
# play_button = Button(root, text="Play Song", font=("Helvetica", 15),
#                      relief=GROOVE, command=play)
# play_button.pack(pady=20)
#
# play_button = Button(root, text="copy", font=("Helvetica", 15),
#                      relief=GROOVE, command=copy_file)
# play_button.pack(pady=20)
#
# play_button = Button(root, text="X", font=("Helvetica", 15), bg="red",
#                      relief=GROOVE, command=destroy_frame)
# play_button.pack(pady=20)
#
#
# info = Label(root, text="Click on the button above to play song ",
#              font=("times new roman", 10, "bold")).pack(pady=20)
# root.mainloop()


# lis = ['<field02>', '{carcount}', '{servicetype}', '</field02>', '<hi>', '<field01>', '{endstationlong}', '</field01>', '</hi>', '[MT0007]']
# for val in lis:
#     print(val)
# hh = "dfy6"
#
# num = 3
#   #
#  # #
# # # #
# for i in range(num):
#     a = ""
#     for j in range(num+2):
#         print(j)
#         # print(i)
#         # if i == 0:
#         #     a = "  #  "
#         #     break
#         # elif i == 1:
#         #     a = " # # "
#         #     break
#         # elif i == 2:
#         #     a = "# # #"
#         #     break
#     # print(a)
#



# print("\u233e")  # ᅘ == "\u1158" : ᅇ == \u1147 : ⌾ == \u233e

# a = "0001000536846532884F438A36492"
# print(len(a))
# if len(a)== 29:
#     pass
# id_j = a[0:4]
# id_r = a[4:8]
# print(id_j, id_r)





# store_all = {"full":[]}
# ab = ["<field01>", "[MT0001]", "[MT0006]", "</field01>", "<field00>", "[MV0001]", "</field00>", "[MV0002]", "[MV0003]"]
# # ab = ["<field01>", "[MT0001]", "[MT0006]", "</field01>", "<field00>", "[MV0001]", "</field00>"]
# tag_name = "full"
# for item in ab:
#     # print(item)
#     if item[1] == "/":
#         tag_name = "full"
#     elif item[0] == "<":
#         tag_name = item
#         store_all[tag_name] = []
#     elif item[0] == "[":
#         store_all[tag_name].append(item)
# print(store_all)


# import tkinter as tk
#
# root = tk.Tk()
# #root.geometry('300x300')
#
# txt = 'Sample Text'
#
# lbl = tk.Label(root, font='Bell 36 bold', width=len(txt))
# lbl.pack(pady=5)
#
# def animate_label(text, n=0):
#     list_n = ["next1", "next2", "next3"]
#     print(len(list_n))
#     print(text, n)
#     if n == len(list_n)-1:
#         lbl['text'] = list_n[n]
#         lbl.after(1000, animate_label, text, 0)
#     else:
#         lbl['text'] = list_n[n]
#         lbl.after(1000, animate_label, text, n+1)
#
#     # lbl.after(1000, animate_label, text, n + 1)
#     # lbl['text'] = text[:n+1]
#
# # start the "after loop" one second later
# root.after(1000, animate_label, txt)
# root.mainloop()


# import tkinter as tk
# import tkinter.ttk as ttk
#
# root = tk.Tk()
# mainframe = tk.Frame(root)
#
# # Model
#
# input = tk.DoubleVar(value=0.)
#
# spin = tk.Spinbox(mainframe, textvariable=input, wrap=True, width=10)
# slide = ttk.Scale(mainframe, variable=input, orient='horizontal', length=200)
# spin['to'] = 1.0
# spin['from'] = 0.0
# spin['increment'] = 0.01
# slide['to'] = 1.0
# slide['from'] = 0.0
# # slide['digits'] = 4
# # slide['resolution'] = 0.01
#
# # Layout
#
# weights = {'spin': 1, 'slide': 100}
#
# mainframe.grid_rowconfigure(0, weight=1)
# mainframe.grid_columnconfigure(0, weight=weights['spin'])
# mainframe.grid_columnconfigure(1, weight=weights['slide'])
# spin.grid(row=0, column=0, sticky='news')
# slide.grid(row=0, column=1, sticky='news')
#
# root.grid_rowconfigure(0, weight=1)
# root.grid_columnconfigure(0, weight=1)
# mainframe.grid(row=0, column=0)
#
# root.mainloop()







# import tkinter as tk
# from tkinter import ttk
# from ttkwidgets import TickScale
#
# # def set_img_color(img, color):
# #     """Change color of PhotoImage img."""
# #     pixel_line = "{" + " ".join(color for i in range(img.width())) + "}"
# #     pixels = " ".join(pixel_line for i in range(img.height()))
# #     img.put(pixels)
#
# root = tk.Tk()
# # create images used for the theme
# slider_width = 30
# slider_height = 15
# # normal slider
#
# # img_slider = tk.PhotoImage('img_slider', width=slider_width, height=slider_height, master=root)
# # set_img_color(img_slider, "red")
# # # active slider
# # img_slider_active = tk.PhotoImage('img_slider_active', width=slider_width, height=slider_height, master=root)
# # set_img_color(img_slider_active, '#1065BF')
#
# style = ttk.Style(root)
# style.theme_use('clam')
# # create scale element
# # style.element_create('custom.Horizontal.Scale.slider', 'image', img_slider,
# #                      ('active', img_slider_active))
# # create custom layout
# # style.layout('custom.Horizontal.TScale',
# #              [('Horizontal.Scale.trough',
# #                {'sticky': 'nswe',
# #                 'children': [('custom.Horizontal.Scale.slider',
# #                               {'side': 'left', 'sticky': ''})]})])
# style.configure('custom.Horizontal.TScale', background='gray', foreground='black',
#                 troughcolor='#73B5FA')
# style.configure('custom.Vertical.TScale', background='gray', foreground='black',
#                 troughcolor='#73B5FA')
# scale = TickScale(root, from_=0, to=1001, tickinterval=100, orient="horizontal",
#                   style='custom.Horizontal.TScale')
# scal = TickScale(root, from_=0, to=100, tickinterval=100, orient="vertical",
#                   style='custom.Vertical.TScale')
# scale.pack(fill='x')
# scal.pack(fill='x')
# root.mainloop()

# items = {1: "a", 2: "b", 4: "b"}
# print(items)
# items = ["a", "b"]
# import  sqlite3
# conn = sqlite3.connect("triggers_abhay.db")
# cursor = conn.cursor()
# query = "SELECT [messageName] FROM [fileImport] WHERE [messageName] LIKE '%.txt'"
# cursor.execute(query)
# rows = cursor.fetchall()
# print(rows)

# from tkinter import *
#
# root = Tk()
# root.geometry("400x400")
# frame = LabelFrame(root, text="1", width=400, height=400)
# frame.place(x=0, y=0)
# frame_2 = LabelFrame(root, text="2", width=400, height=400)
# frame_2.place(x=0, y=0)
# frame.lift()
# root.mainloop()


# import platform
# print(platform.uname().node)
# print(platform.uname())
# print(platform.node())
# d = ['currenttimeshort', 'MT0001', 'nextstationlong', 'MT0002', 'MT0022', 'endstationlong', 'MT0002', 'MT0015', '']
# d.append("कोविड-19 पासून संरक्षण दोन गजाचे अंतर मास्क वापरा निरंतर ")
# a = ",rfe,sf,"
#
# print(a[1:])
# d.remove("")
# print(d)


# import tkinter as tk
# from tkinter import ttk
#
# screen = tk.Tk()
# screen.title('This One')
# screen.geometry('890x400')
# style = ttk.Style()
# style.theme_use("clam")
# screen.grid_rowconfigure(1, weight=1)
# screen.grid_columnconfigure(0, weight=1)
#
# cols = ('TOKEN', 'F-500', 'F-250', 'F-100', 'F-24', 'POS','NEG')
# box = ttk.Treeview(screen, columns=cols, show='headings')
# for col in cols:
#     # if col == 'TOKEN':
#     box.heading(col, text=col, command =lambda: print(col))
#     box.grid(row=1, column=0, columnspan=2,sticky='nsew')
#
#
# box.column("TOKEN", width=95)
# box.column("F-500", width=85, anchor='e')
# box.column("F-250", width=85, anchor='e')
# box.column("F-100", width=85, anchor='e')
# box.column("F-24", width=85, anchor='e')
# box.column("POS", width=75, anchor='center')
# box.column("NEG", width=75, anchor='center')
#
#
#
# closeButton = tk.Button(screen, text="Close", width=15, command=exit).grid(row=10, column=0)
#
# screen.mainloop()

# def full_pyramid(n):
#     for i in range(1, n + 1):
#         # Print leading spaces
#         # print(i)
#         for j in range(n - i):
#             # print(j)
#             print(" ", end="")
#
#         # Print asterisks for the current row
#         # print(i)
#         for k in range(1, 2 * i):
#             print("*", end="")
#         # break
#         print()
# full_pyramid(5)


# class ab:
#     company = "apple"
#     def show(self):
#         print(f"its {self.name} and my company is {self.company}")
#     @classmethod
#     def change_company_name(cls, com_name):
#         cls.company = com_name
#
# a = ab()
# a.name = "abhay"
# a.show()
# a.change_company_name("yoo")
# a.show()
# print(ab.company)

num = 5
#aaaaa*aaaaa
#aaaa*a*aaaa
#aaa*a*a*aaa
#aa*a*a*a*aa
#a*a*a*a*a*a
#*a*a*a*a*a*
# for i in range(1, num+1):
#     a = ""
#     for j in range(1, (num*2)):
#         # if i
#         if j % 2 == 0:
#             a = " " + a
#         elif j % 2 == 1:
#             a = "*" + a
#     print(a)
# for i in range(1, num+1):
#     print(" "*(num-i)+"* "*i)
# for i in range(num):
#     print(" "*(num-i-1)+"* ")
# if i >= 1:
#     print(" " * (2 * i - 1) + "* ", end="")


# n = 5
# for i in range(n):
#     print(" "*(n-i-1)+" *", end="")
#     if i >= 1:
#        print(" "*(2*i-1)+" *", end="")
#     print()
# import file_dir as file_name
# print(file_name.a)
# print(file_name.add(2, 6))
from file_dir import *
import sqlite3

print(GUI_ICON().gui_icon_file)
# print(add_number(2,4).add_data)
# print(sub(36, 46))
# print(sub(36, 46).list_data())
# print(set(Person("Abhay", "24")))
print(File_Path().Audio_Path)
print(SQL_QUERY(f"select * from tbl_field").QUERY_COMMAND())
print(SQL_QUERY(f"select * from tbl_station where shortName LIKE '%su%'").QUERY_COMMAND())
# SQL_QUERY().QUERY_COMMAND()
def sql_command(sql_query):
      conn = sqlite3.connect("triggers_abhay.db")
      my_cursor = conn.cursor()
      my_cursor.execute(sql_query)
      if sql_query.find("Select") > -1 or sql_query.find("SELECT") > -1 or sql_query.find("select") > -1:
          data = my_cursor.fetchall()
          conn.commit()
          conn.close()
          return data
      else:
          conn.commit()
          conn.close()
          return "Done"


print(sql_command("select actionRepetitionCount , sum(ActionOrder) from do_this_combi_item group by actionRepetitionCount"), "dddddd")
'''update mytable set mydate = sysdate 
where mydate in (select mydate from mytable where mydate is null)'''

print(sql_command("update do_this_combi_item set ActionOrder = ActionOrder + 1 where do_this_combi_ID=1 and action_ID_int=2"))
# print(sql_command("update do_this_combi_item set ActionOrder = ActionOrder + 1 where do_this_combi_ID=1 and ActionOrder > (select ActionOrder from do_this_combi_item where do_this_combi_ID=1 and action_ID_int=1)"))
# print(sql_command("select ActionOrder from do_this_combi_item where do_this_combi_ID=1 and ActionOrder > 2"))
