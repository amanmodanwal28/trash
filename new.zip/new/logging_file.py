import logging

# Configure logging
logging.basicConfig(
    filename='app.log',            # Log file name
    filemode='a',                  # Append mode
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.DEBUG             # Log level
)

def main():
    logging.info("Program started")

    try:
        # Simulate some operations
        logging.debug("Performing a calculation...")
        result = 10 / 2
        logging.info(f"Calculation result: {result}")

        # Simulate an operation that raises an error
        logging.debug("Attempting to divide by zero...")
        result = 10 / 0  # This will raise an exception

    except ZeroDivisionError as e:
        logging.error("Error occurred: Division by zero", exc_info=True)

    logging.info("Program ended")

if __name__ == '__main__':
    main()
