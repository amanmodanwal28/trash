import sqlite3

conn1 = sqlite3.connect("triggers_abhay.db")
my_cursor = conn1.cursor()
# my_cursor.execute(f"select distance from tbl_stationDistance where stationID1={self.data_tree[i - 1][2]} and stationID2={self.data_tree[i][2]}")
# my_cursor.execute(f"UPDATE tbl_routeStops SET [distanceFromPrev] = {distance_entry.get()} WHERE [stationID] = {self.data1[3]}")
my_cursor.execute(f"select * from tbl_routes order by routeID")
route_data = my_cursor.fetchall()
for route_id, name_route in route_data:
    my_cursor.execute(f"select stationID, stopOrder from tbl_routeStops where routeID={route_id} order by stopOrder")
    route_stop_data = my_cursor.fetchall()
    print(name_route)
    old_num = 0
    for stationID_data, stopOrder_data in route_stop_data:
        if old_num > 0:
            my_cursor.execute(
                f"select distance from tbl_stationDistance where stationID1={old_num} and stationID2={stationID_data}")
            distance_data = my_cursor.fetchall()
            if distance_data:
                print("distance_data", distance_data[0][0])


                my_cursor.execute(
                    f"UPDATE tbl_routeStops SET [distanceFromPrev] = {distance_data[0][0]} WHERE [stationID] = {stationID_data} and routeID={route_id} and stopOrder={stopOrder_data}")

            else:
                my_cursor.execute(
                    f"select distance from tbl_stationDistance where stationID1={stationID_data} and stationID2={old_num}")
                distance_data2 = my_cursor.fetchall()
                if distance_data2:
                   print("distance_data ####################", distance_data2[0][0], stationID_data, stopOrder_data)


                   my_cursor.execute(
                     f"UPDATE tbl_routeStops SET [distanceFromPrev] = {distance_data2[0][0]} WHERE [stationID] = {stationID_data} and routeID={route_id} and stopOrder={stopOrder_data}")


            old_num = stationID_data

        else:
            old_num = stationID_data
            print("First Station = ", stationID_data)

conn1.commit()
conn1.close()
