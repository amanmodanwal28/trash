# import binascii
# def change(data_item=""):
#     variable = data_item
#     hex_pairs = variable.split()
#     pair_lengths = [1,1,1,1,1,1,1,1,1,1,5,3,3,1,1,1,1,1,3]

#     hex_dict = {}

#     index = 0

#     for i , length in enumerate(pair_lengths):
#         key = f"pair_{i + 1}"
#         value =hex_pairs[index:index +length]
#         hex_dict[key] = value
#         index +=length

#     if index < len(hex_pairs):
#         key = f"pair_{len(pair_lengths) + 1}"
#         value = hex_pairs[index:]
#         hex_dict[key] = value


#     pair_11_value = ''.join(hex_dict['pair_11'])
#     print(binascii.unhexlify(pair_11_value).decode('utf-8'))

#     # print(hex_dict['pair_20'][:-2])
#     for name_data in hex_dict['pair_20'][:-2]:
#         try:
#             print(binascii.unhexlify(name_data).decode('utf-8'),end="")
#         except UnicodeDecodeError:
#             print(".", end='')
#         # print(i)
# change("AA CC 00 32 01 FF 15 81 03 01 31 32 32 35 37 00 00 00 00 00 00 33 01 02 03 09 0A 0A 0D 3B 27 6B 6F 61 72 69 71 6A 20 74 61 2D 09 64 A8 50 70 71 6F 73 79 68 84 99")



    # print(binascii.unhexlify(i).decode('utf-8'))
# print(binascii.unhexlify("A8").decode('utf-8'))
# print(binascii.unhexlify(pair_20_value[:-4]).decode('utf-8'))






MYPORT = 8000
MYGROUP_4 = '224.0.0.1'
import struct
import socket
import sys
import binascii


def receiver(group):
    addrinfo = socket.getaddrinfo(group, None)[0]
    print(addrinfo)
    s = socket.socket(addrinfo[0], socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
    s.bind(('', MYPORT))
    group_bin = socket.inet_pton(addrinfo[0], addrinfo[4][0])
    mreq = group_bin + struct.pack('=I', socket.INADDR_ANY)
    s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    # if addrinfo[0] == socket.AF_INET: # IPv4
    #     mreq = group_bin + struct.pack('=I', socket.INADDR_ANY)
    #     s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    # else:
    #     mreq = group_bin + struct.pack('@I', 0)
    #     s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_JOIN_GROUP, mreq)
    num = 1
    while True:
        print(num, "Reading..........")
        num += 1
        data, sender = s.recvfrom(1500)
        hex_str = ' '.join(format(byte, '02x') for byte in data).upper()
        print(hex_str)

receiver(MYGROUP_4)




import socket
import struct

MCAST_GRP = '224.0.0.1'
MCAST_PORT = 8000
IS_ALL_GROUPS = True
# IS_ALL_GROUPS = False

sock = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
if IS_ALL_GROUPS:
    # on this port, receives ALL multicast groups
    sock.bind(('', MCAST_PORT))
else:
    # on this port, listen ONLY to MCAST_GRP
    sock.bind((MCAST_GRP, MCAST_PORT))
mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)

sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

while True:
  # For Python 3, change next line to "print(sock.recv(10240))"
  print (sock.recv(10240))
