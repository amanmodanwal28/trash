from tkinter import *
from tkinter import ttk
import shutil
import pyodbc
import main
import tkinter as tk
from tkinter import filedialog
import tkinter.ttk
import os
import glob
import crcmod.predefined
import struct
import binascii
import xml.etree.ElementTree as ET
import datetime
import calendar
from customtkinter import CTkButton, CTkCheckBox
import sqlite3

class MainApplication5:
    def __init__(self): 
        self.add_new = tk.Tk()
        self.add_new.geometry("260x150+300+300")
        self.add_new.title("Export Data")
        self.add_new.protocol("WM_DELETE_WINDOW", self.on_exit)
        
        self.e = tkinter.ttk.Style(self.add_new)
        self.e.theme_use('clam')

        self.export_path = "C:/Users/PTCS1/Documents/EXPORT"
        self.export_path_create = "C:/Users/PTCS1/Documents"
        # storing_audio_list
        self.all_audio_file_station = set()   # all audio files using in dat file
        self.all_audio_file_other = set()   # all audio files using in dat file
        self.all_audio_file_video = set()   # all audio files using in dat file

        
        # Create the version Combobox
        self.version_combobox = ttk.Combobox(self.add_new, values=[str(i) for i in range(11)], width=5)
        self.version_combobox.place(x=30, y=30)
        self.version_combobox.set(1)

        self.version_combobox1 = ttk.Combobox(self.add_new, values=[str(i) for i in range(11)], width=5)
        self.version_combobox1.place(x=100, y=30)
        self.version_combobox1.set(3)

        self.version_combobox2 = ttk.Combobox(self.add_new, values=[str(i) for i in range(11)], width=5)
        self.version_combobox2.place(x=170, y=30)
        self.version_combobox2.set(2)
        
        
        self.export_data = tk.Button(self.add_new, text="OK", font=('arial', 10, 'bold'),width=5,
                                     bg="cyan", fg="black", command=self.export_data_all)
        self.export_data.place(x=100, y=70)
        
        self.length_of_jstops = {1: 0}
        self.length_of_jstops_ID_len = {1: 0}
        self.length_of_rstops = {1: 0}
        self.length_of_rstops_new = {1: 0}
        self.list_for_J_stop_2 = {}
        self.set_j_stop = set()
        self.list_repeat_journey = []
        self.list_of_journey_id_aliases_dat = {}
        self.all_list_of_journey_id_aliases_dat = {}
        self.add_new.mainloop()
      
    def export_data_all(self):
        global version
        self.all_audio_file_station.clear()  # all audio files using in station.dat file
        self.all_audio_file_other.clear() # all audio files using in message.dat file
        self.all_audio_file_video.clear()

        self.selected_version = self.version_combobox.get()
        self.selected_version1 = self.version_combobox1.get()
        self.selected_version2 = self.version_combobox2.get()

        my_tr = ET.parse("version.xml")
        root = my_tr.getroot()
        for i in root.findall("Data"):
            i.find("Major").text = self.selected_version
            i.find("Minor").text = self.selected_version1
            i.find("Build").text = self.selected_version2
        my_tr.write("version.xml")

        # export_folder = filedialog.askdirectory(title='Select Export Folder')
        if os.path.isdir(self.export_path):
            shutil.rmtree(self.export_path)
        export_folder = self.export_path_create

        if not os.path.exists(export_folder):
            os.makedirs(export_folder)

        # Create the version folder
        self.version_folder = os.path.join(export_folder, f'EXPORT')
        if not os.path.exists(self.version_folder):
            os.makedirs(self.version_folder)
            # Create the subfolders for audio, video, banner, logo, and text
            self.audio_folder = os.path.join(self.version_folder, 'AUDIO')
            self.video_folder = os.path.join(self.version_folder, 'VIDEOS')
            self.banner_folder = os.path.join(self.version_folder, 'BANNER')
            self.logo_folder = os.path.join(self.version_folder, 'LOGO')
            self.text_folder = os.path.join(self.version_folder, 'TEXT', 'MESSAGES')
            self.data_folder = os.path.join(self.version_folder, 'DATA')


            # Create the subfolders if they don't exist
            if not os.path.exists(self.audio_folder):
                os.makedirs(self.audio_folder)
            if not os.path.exists(self.video_folder):
                os.makedirs(self.video_folder)
            if not os.path.exists(self.banner_folder):
                os.makedirs(self.banner_folder)
            if not os.path.exists(self.logo_folder):
                os.makedirs(self.logo_folder)
            if not os.path.exists(self.text_folder):
                os.makedirs(self.text_folder)
            if not os.path.exists(self.data_folder):
                os.makedirs(self.data_folder)

            self.action_dat()
            self.aliases_dat()
            self.aud_msg_dat()
            self.combitrig_dat()
            self.config_dat()
            self.dts_dat()
            self.gps_dat()
            self.rstops_dat()
            self.jstops_dat()
            self.journey_dat()
            self.messages_dat()
            self.prm_msg_dat()
            self.pub_msg_dat()
            self.spt_msg_dat()
            self.stations_dat()
            self.trigger_data()
            self.txt_msg_dat()
            self.version_dat()

            # Create the index.txt file heading
            # print("self.all_audio_file_station", self.all_audio_file_station)
            # print("self.all_audio_file_station", self.all_audio_file_other)
            index_file_path = os.path.join(self.version_folder, 'INDEX.SYS')
            with open(index_file_path, 'w', encoding='utf-8') as index_file:
                index_file.write("     CRC     SIZE FILENAME\n")

            # Export audio files
            path = "sqlData\\audio"
            audio_files = glob.glob(os.path.join(path, '*MA*.mp3')) + glob.glob(os.path.join(path, '*ST*.mp3'))
            print("audio_files", audio_files)

            storing_audio_list = []
            conn = sqlite3.connect("triggers_abhay.db")
            cursor = conn.cursor()
            # print("self.all_audio_file_station", self.all_audio_file_station)
            for station_ID in self.all_audio_file_station:
                query = f"SELECT stationNameAudio from tbl_stationNames where stationID='{station_ID}'"
                cursor.execute(query)
                rows = cursor.fetchall()
                for row in rows:
                    storing_audio_list.append(row[0])
            for other_ID in self.all_audio_file_other:
                query = f"SELECT messageName from fileImport where FullFileName='{other_ID}'"
                cursor.execute(query)
                rows = cursor.fetchall()
                for row in rows:
                    storing_audio_list.append(row[0])

            # query = "SELECT stationNameAudio from tbl_stationNames union select messageName from fileImport WHERE messageName LIKE '%MP3%'"
            # query = "SELECT stationNameAudio from tbl_stationNames"
            # cursor.execute(query)
            # rows = cursor.fetchall()

            for row in rows:
                storing_audio_list.append(row[0])
            # print("storing_audio_list", storing_audio_list)
            for file in audio_files:
                file_name = os.path.basename(file)
                # print(file_name)
                # if storing_audio_list.count(file_name)
                if file_name in storing_audio_list:
                    source_path = os.path.join(path, file_name)

                    if 'ST' in file_name:
                        destination_folder = os.path.join(self.audio_folder, "STATIONS")
                    else:
                        destination_folder = os.path.join(self.audio_folder, "MESSAGES")

                    if not os.path.exists(destination_folder):
                        os.makedirs(destination_folder)

                    destination_path = os.path.join(destination_folder, file_name)
                    remove_destination_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]

                    if os.path.exists(source_path):
                        shutil.copyfile(source_path, destination_path)
                else:
                    continue

                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())

                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9-len(str(file_size))
                new_file_size = f"{' '*num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    # index_file.write(f"{crc_formatted}     \t{file_size}     \t{remove_destination_path}\n")
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path}\n")

            # Export video files



            path_video = "sqlData\\video"
            # video_files = glob.glob(os.path.join(path_video, '*MV*.mp4'))
            video_files = []

            if self.all_audio_file_video:
                for other_ID in self.all_audio_file_video:
                    query = f"SELECT messageName from fileImport where FullFileName='{other_ID}'"
                    cursor.execute(query)
                    rows = cursor.fetchall()
                    for row in rows:
                        video_files.append(row[0])

            for file in video_files:
                if not file.find("MP4") > -1:
                    continue
                # file_name = os.path.basename(file)
                file_name = file
                source_path = os.path.join(path_video, file_name)
                destination_folder = os.path.join(self.video_folder, "MESSAGES")
                # print(destination_folder, file_name)
                if not os.path.exists(destination_folder):
                    os.makedirs(destination_folder)

                destination_path = os.path.join(destination_folder, file_name)
                remove_destination_path_video = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]

                if os.path.exists(source_path):
                    shutil.copyfile(source_path, destination_path)

                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())

                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path_video}\n")

            # Export banner files
            path_banner = "sqlData\\banner"
            banner_files = glob.glob(os.path.join(path_banner, '*MB*.png'))

            for file in banner_files:
                file_name = os.path.basename(file)
                source_path = os.path.join(path_banner, file_name)
                destination_path = os.path.join(self.banner_folder, file_name)
                remove_destination_path_banner = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]

                if os.path.exists(source_path):
                    shutil.copyfile(source_path, destination_path)

                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())

                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path_banner}\n")

            # Export logo files
            path_logo = "sqlData\\logo"
            logo_files = glob.glob(os.path.join(path_logo, '*ML*.ico'))

            for file in logo_files:
                file_name = os.path.basename(file)
                source_path = os.path.join(path_logo, file_name)
                destination_path = os.path.join(self.logo_folder, file_name)
                remove_destination_path_logo = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]

                if os.path.exists(source_path):
                    shutil.copyfile(source_path, destination_path)

                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())

                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path_logo}\n")

            ##################################################################################################################################################

            # Export Action.DAT path files
            for file in self.actions_dat_path:
                destination_path = os.path.join(self.actions_dat_path)
                remove_destination_path_action = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path_action}\n")
                    break

            # Export Aliases.DAT path  files
            for file in self.aliases_dat_path:
                destination_path = os.path.join(self.aliases_dat_path)
                remove_destination_path_aliases = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path_aliases}\n")
                    break

            # Export Aud_msg_path.DAT path  files
            for file in self.aud_msg_dat_path:
                destination_path = os.path.join(self.aud_msg_dat_path)
                remove_destination_path_aud_msg = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path_aud_msg}\n")
                    break


            # Export combitriger_dat_path.DAT path  files
            for file in self.combtrig_dat_path:
                destination_path = os.path.join(self.combtrig_dat_path)
                remove_combitriger_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_combitriger_dat_path}\n")
                    break

            # Export config_dat_path.DAT path  files
            for file in self.config_dat_path:
                destination_path = os.path.join(self.config_dat_path)
                remove_config_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_config_dat_path}\n")
                    break

            # Export dts_dat_path.DAT path  files
            for file in self.dts_dat_path:
                destination_path = os.path.join(self.dts_dat_path)
                remove_dts_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_dts_dat_path}\n")
                    break


            # Export gps_dat_path.DAT path  files
            for file in self.gps_dat_path:
                destination_path = os.path.join(self.gps_dat_path)
                remove_gps_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_gps_dat_path}\n")
                    break


            # Export journey_dat_path.DAT path  files
            for file in self.journey_dat_path:
                destination_path = os.path.join(self.journey_dat_path)
                remove_journey_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_journey_dat_path}\n")
                    break


            # Export jstops_dat_path.DAT path  files
            for file in self.jstops_dat_path:
                destination_path = os.path.join(self.jstops_dat_path)
                remove_jstops_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_jstops_dat_path}\n")
                    break


            # Export message_dat_path.DAT path  files
            for file in self.messages_dat_path:
                destination_path = os.path.join(self.messages_dat_path)
                remove_message_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_message_dat_path}\n")
                    break


            # Export prm_msg_dat_path.DAT path  files
            for file in self.prm_msg_dat_path:
                destination_path = os.path.join(self.prm_msg_dat_path)
                remove_prm_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_prm_dat_path}\n")
                    break


            # Export pub_msg_dat_path.DAT path  files
            for file in self.pub_msg_dat_path:
                destination_path = os.path.join(self.pub_msg_dat_path)
                remove_pub_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_pub_dat_path}\n")
                    break

            # Export rstops_path.DAT path  files
            for file in self.rstops_dat_path:
                destination_path = os.path.join(self.rstops_dat_path)
                remove_rstops_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_rstops_dat_path}\n")
                    break


            # Export spt_msg_path.DAT path  files
            for file in self.spt_msg_path:
                destination_path = os.path.join(self.spt_msg_path)
                remove_spt_msg_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_spt_msg_dat_path}\n")
                    break


            # Export station_path.DAT path  files
            for file in self.station_path:
                destination_path = os.path.join(self.station_path)
                remove_station_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)
                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_station_dat_path}\n")
                    break

            # Export trigger_path.DAT path  files
            for file in self.trigger_path:
                destination_path = os.path.join(self.trigger_path)
                remove_trigger_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_trigger_dat_path}\n")
                    break

                    # Export txt_msg_path.DAT path  files
            for file in self.txt_msg_path:
                destination_path = os.path.join(self.txt_msg_path)
                remove_txt_msg_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_txt_msg_dat_path}\n")
                    break

                # # Append CRC, file size, and filename to index.txt
                # with open(index_file_path, 'a', encoding='utf-8') as index_file:
                #     index_file.write(f"{crc_formatted}     \t{file_size}             \t{remove_txt_msg_dat_path}\n")
                #     break

                # Export version_path.DAT path  files
            for file in self.version_path:
                destination_path = os.path.join(self.version_path)
                remove_version_dat_path = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                # Calculate CRC and file size
                crc_func = crcmod.predefined.mkCrcFun('crc-32')
                with open(destination_path, 'rb') as file:
                    crc_value = crc_func(file.read())
                # Format the CRC value as crc_value:08X
                crc_formatted = f"{crc_value:08X}"
                file_size = os.path.getsize(destination_path)

                num_space = 9 - len(str(file_size))
                new_file_size = f"{' ' * num_space}{file_size}"

                # Append CRC, file size, and filename to index.txt
                with open(index_file_path, 'a', encoding='utf-8') as index_file:
                    index_file.write(f"{crc_formatted}{new_file_size} {remove_version_dat_path}\n")
                    break


            path_text = "sqlData\\txt"
            text_files = [file for file in glob.glob(os.path.join(path_text, '*.txt')) if not os.path.basename(file).startswith('MT')]
            # print(text_files,"vvvvvvvvvvv")

            conn = sqlite3.connect("triggers_abhay.db")
            cursor = conn.cursor()
            # query = "SELECT [messageName] FROM [fileImport] WHERE [messageName] LIKE '%.txt' AND [messageName] NOT LIKE 'MT%.txt'"
            query = "SELECT [messageName] FROM [fileImport] WHERE [messageName] LIKE '%.txt'"
            cursor.execute(query)
            rows = cursor.fetchall()
            # print(rows, "dddddddddddddddd")
            storing_text_list = []
            for row in rows:
                storing_text_list.append(row[0])
            # print(storing_text_list, "storing_text_list")

            for file in text_files:
                # print("file", file)
                file_name = os.path.basename(file)
                # print(file_name, "gggggggg")
                if file_name in storing_text_list:
                    source_path = os.path.join(path_text, file_name)
                    destination_path = os.path.join(self.text_folder, file_name)
                    remove_destination_path_txt = destination_path[destination_path.find('EXPORT'):].replace('EXPORT', "").replace("\\", "/")[0::]
                    # print(remove_destination_path_txt, "remove_destination_path_txt")
                    if os.path.exists(source_path):
                        shutil.copyfile(source_path, destination_path)
                        # Calculate CRC and file size
                        crc_func = crcmod.predefined.mkCrcFun('crc-32')
                        with open(destination_path, 'rb') as file:
                            crc_value = crc_func(file.read())

                        # Format the CRC value as crc_value:08X
                        crc_formatted = f"{crc_value:08X}"
                        file_size = os.path.getsize(destination_path)

                        num_space = 9 - len(str(file_size))
                        new_file_size = f"{' ' * num_space}{file_size}"

                        # Append CRC, file size, and filename to index.txt
                        with open(index_file_path, 'a', encoding='utf-8') as index_file:
                            print(f"{crc_formatted}{new_file_size} {remove_destination_path_txt}\n")
                            index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path_txt}\n")

                # # Calculate CRC and file size
                # crc_func = crcmod.predefined.mkCrcFun('crc-32')
                # with open(destination_path, 'rb') as file:
                #     crc_value = crc_func(file.read())
                #
                # # Format the CRC value as crc_value:08X
                # crc_formatted = f"{crc_value:08X}"
                # file_size = os.path.getsize(destination_path)
                #
                # num_space = 9 - len(str(file_size))
                # new_file_size = f"{' ' * num_space}{file_size}"
                #
                # # Append CRC, file size, and filename to index.txt
                # with open(index_file_path, 'a', encoding='utf-8') as index_file:
                #     print(f"{crc_formatted}{new_file_size} {remove_destination_path_txt}\n")
                #     index_file.write(f"{crc_formatted}{new_file_size} {remove_destination_path_txt}\n")


                    # Create the index.txt file heading
            index_file_path = os.path.join(self.version_folder, 'ACTIONS.SYS')
            with open(index_file_path, 'w', encoding='utf-8') as index_file:
                index_file.write("DATE 0\n")

    def action_dat(self):
        # Create the ACTIONS.DAT file in the DATA folder
        self.actions_dat_path = os.path.join(self.data_folder, 'ACTIONS.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()
        query = 'SELECT [do_this_combi_ID],[ActionOrder],[actionDelay],[actionRepetitionCount],[actionRepetitionInterval],[action_ID_int],[resource_name],[Flush],[resource_name] FROM [do_this_combi_item] order by [do_this_combi_ID],[ActionOrder]'
        cursor.execute(query)
        rows = cursor.fetchall()
        with open(self.actions_dat_path, 'w', encoding='utf-8') as action_dat_file:
            for row in rows:
                try:
                    combiactionid = row[0]       # 1
                    actionorder = row[1]         # 2
                    actiondelay = row[2]         # 3
                    actionrepetition = row[3]    # 4
                    actioninterval = row[4]      # 5
                    actionid = row[5]            # 6
                    actionresource = row[6]      # 7
                    actionflush = row[7]         # 8
                    actionresource1 = row[8]     # 9

                    query = f'SELECT FlushResource FROM tbl_action where action_ID={actionid}'
                    cursor.execute(query)
                    FlushResource_data = cursor.fetchall()
                    if FlushResource_data:
                        actionflush = FlushResource_data[0][0]

                    hex_value_combiactionid = format(int(combiactionid), '04X')

                    hex_value_actionorder = format(int(actionorder), '02X')

                    hex_value_actiondelay = format(int(actiondelay), '02X')

                    output = ''
                    if actionrepetition == 'INF':
                        output += 'FF'
                    elif isinstance(actionrepetition, int):
                        output += format(actionrepetition + 1, '02X')
                    else:
                        try:
                            int_repetition = int(actionrepetition)
                            output += format(int_repetition + 1, '02X')
                        except ValueError:
                            pass

                    hex_value_actioninterval = format(int(actioninterval), '04X')[-2:]

                    hex_value_actionid = format(int(actionid), '04X')

                    my_tr = ET.parse("projectinfo.xml")
                    root = my_tr.getroot()
                    k = actionresource
                    hex_value_journeystops_condition = 00
                    if k is not None:
                        for i in root.findall("resource"):
                            it = i.find("name").text
                            it1 = i.find("value").text
                            if it == k:
                                hex_value_journeystops_condition = format(int(it1), '02X')
                                print(it1, it, "==", hex_value_journeystops_condition)

                    hex_value_actionflush = format(int(actionflush), '02X')

                    my_tr1 = ET.parse("projectinfo.xml")
                    root1 = my_tr1.getroot()
                    k1 = actionresource1
                    hex_value_journeystops_condition1 = 00000000
                    if k1 is not None:
                        for i in root1.findall("resource"):
                            it = i.find("name").text
                            it1 = i.find("value").text
                            if it == k1:
                                hex_value_journeystops_condition1 = format(int(it1), '08X')

                    hex_value_messagetype = format(int(00), '02X')

                    action_dat_file.write(f"{hex_value_combiactionid}{hex_value_actionorder}{hex_value_actiondelay}{output}{hex_value_actioninterval}{hex_value_actionid}{hex_value_journeystops_condition}{hex_value_actionflush}{hex_value_journeystops_condition1}{hex_value_messagetype}\n")
                except Exception as e:
                    print(f"An error occurred while exporting action_dat : {e}")
        cursor.close()
        conn.close()


    def aliases_dat(self):
        # Create the ALIASES.DAT file in the DATA folder
        self.aliases_dat_path = os.path.join(self.data_folder, 'ALIASES.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()
        route_tbl = 'SELECT * FROM tbl_routes ORDER BY routeID'
        cursor.execute(route_tbl)
        rows_route = cursor.fetchall()

        aliases_dic = {}
        aliases_dic_int = []
        aliases_order_dis = {}
        aliases_order_lis = []

        with open(self.aliases_dat_path, 'w', encoding='utf-8') as gps_dat_file:
            for ID, name_route in rows_route:
                try:
                    cursor.execute(
                        f'SELECT [journeyID], [routeID], [journeyName] FROM tbl_journeys where routeID={ID} ORDER BY journeyID;')
                    rows_journeys = cursor.fetchall()
                    for journeyID, routeID, journeyName in rows_journeys:
                        cursor.execute(
                            f'SELECT [routeStopID],[arrivalTime], [depactureTime], [platformNum], [conditional], [combiTriggerID], [languageArea] FROM [tbl_journeyStops] where journeyID={journeyID}')
                        rows_journey_stops = cursor.fetchall()
                        list_for_J_stop = []
                        for routeStopID, arrivalTime, departureTime, platformNum, conditional, combiTriggerID, languageArea in rows_journey_stops:
                            i = (routeStopID, arrivalTime, departureTime, platformNum, conditional, combiTriggerID,
                                 languageArea)
                            i2 = (journeyName, routeStopID, arrivalTime, departureTime, platformNum, conditional,
                                  combiTriggerID, languageArea)
                            if i not in list_for_J_stop:
                                list_for_J_stop.append(i)
                        if list_for_J_stop not in self.list_for_J_stop_2.values():
                            self.list_for_J_stop_2[journeyName] = list_for_J_stop
                            self.list_of_journey_id_aliases_dat[journeyName] = journeyID
                            self.all_list_of_journey_id_aliases_dat[journeyID] = journeyID

                            journey_name = journeyName
                            aliases_dic[journey_name] = journey_name
                            if type(1) == type(journey_name):
                                aliases_dic_int.append(journey_name)
                            else:
                                aliases_dic_int.append(journey_name)
                            journey_name_value = f"{journey_name}{' ' * (8 - len(journey_name))}"
                            # gps_dat_file.write(f"{journey_name_value}{journey_name_value}\n")
                            aliases_order_dis[journey_name_value] = journey_name_value
                            aliases_order_lis.append(journey_name_value)
                            self.set_j_stop.add(journeyName)
                            if not self.list_repeat_journey.count(journeyID):
                                self.list_repeat_journey.append(journeyID)

                        elif list_for_J_stop in self.list_for_J_stop_2.values():
                            out_put = list(self.list_for_J_stop_2.keys())[
                                list(self.list_for_J_stop_2.values()).index(list_for_J_stop)]
                            self.all_list_of_journey_id_aliases_dat[journeyID] = self.list_of_journey_id_aliases_dat[
                                out_put]

                            journey_name_value = f"{journeyName}{' ' * (8 - len(journeyName))}"
                            journey_name_value_out_put = f"{out_put}{' ' * (8 - len(out_put))}"
                            # gps_dat_file.write(f"{journey_name_value}{journey_name_value_out_put}\n")
                            aliases_order_dis[journey_name_value] = journey_name_value_out_put
                            aliases_order_lis.append(journey_name_value)

                            aliases_dic[journeyName] = out_put
                            if type(1) == type(journeyName):
                                aliases_dic_int.append(journeyName)
                            else:
                                aliases_dic_int.append(journeyName)
                            if not self.list_repeat_journey.count(self.list_of_journey_id_aliases_dat[out_put]):
                                self.list_repeat_journey.append(self.list_of_journey_id_aliases_dat[out_put])

                            self.set_j_stop.add(out_put)
                    self.list_for_J_stop_2 = {}
                except Exception as e:
                    print(f"An error occurred while exporting aliases_dat: {e}")
            aliases_order_lis.sort()
            for journey_ali in aliases_order_lis:
                gps_dat_file.write(f"{journey_ali}{aliases_order_dis[journey_ali]}\n")
        cursor.close()
        conn.close()

    def aud_msg_dat(self):
        # Create the AUD_MSG.DAT file in the DATA folder
        self.aud_msg_dat_path = os.path.join(self.data_folder, 'AUD_MSG.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        query = 'SELECT [name],[description] FROM [messageA]'
        cursor.execute(query)
        rows = cursor.fetchall()

        try:
            with open(self.aud_msg_dat_path, 'w', encoding='utf-8') as aud_msg_dat_file:
                for row in rows:
                    aud_msg_name = row[0]
                    aud_msg_description = row[1]

                    if "AA" in aud_msg_name:
                        aud_msg_name1 = aud_msg_name

                        hex_value_aud_aa = aud_msg_name1.encode('utf-8').hex().upper()

                        hex_value_aud_msg_name_len = (len(hex_value_aud_aa))
                        hex_value_aud_msg_name_len_border = hex_value_aud_msg_name_len //2
                        hex_value_aud_msg_name_len_border_output = format(hex_value_aud_msg_name_len_border, '04X')

                        hex_value_aud_msg_description = aud_msg_description.encode('utf-8').hex().upper()

                        hex_value_aud_msg_description_len = (len(hex_value_aud_msg_description))
                        hex_value_aud_msg_description_len_border = hex_value_aud_msg_description_len //2
                        hex_value_aud_msg_description_len_border_output = format(hex_value_aud_msg_description_len_border, '02X')

                        aud_msg_dat_file.write(f"{hex_value_aud_msg_name_len_border_output}{hex_value_aud_aa}{hex_value_aud_msg_description_len_border_output}{hex_value_aud_msg_description}\n")
        except Exception as e:
            print(f"An error occurred while exporting aud_msg_dat : {e}")
        finally:
            cursor.close()
            conn.close()

    def combitrig_dat(self):
        # Create the COMBTRIG.DAT file in the DATA folder
        self.combtrig_dat_path = os.path.join(self.data_folder, 'COMBTRIG.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()
        query = 'SELECT [combiTriggerID],[trigger_id] FROM [tbl_combiTriggerItems] order by [combiTriggerID]'
        cursor.execute(query)
        rows = cursor.fetchall()
        with open(self.combtrig_dat_path, 'w', encoding='utf-8') as combi_dat_file:
            for row in rows:
                try:
                    combi_trigger_id = row[0]
                    trigger_id = row[1]
                    combi_trigger_hex = format(int(combi_trigger_id), '04X')
                    trigger_id_hex = format(int(trigger_id), '04X')

                    combi_dat_file.write(f"{combi_trigger_hex}{trigger_id_hex}\n")

                except Exception as e:
                    print(f"An error occurred while exporting combitrig_dat : {e}")

        cursor.close()
        conn.close()

    def config_dat(self):
        # Create the CONFIG.DAT file in the DATA folder
        self.config_dat_path = os.path.join(self.data_folder, 'CONFIG.DAT')
        with open(self.config_dat_path, 'w', encoding='utf-8') as config_dat_file:
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            for i in root.findall("Configuration"):
                it = i.find("EmulateGPS").text
                it1 = i.find("Mp3Delay").text
                it2 = i.find("CouplingDelay").text
                it3 = i.find("TriggerBetweenSpeed").text
                it4 = i.find("TriggerBetweenDistance").text
                it5 = i.find("TriggerBetweenInterval").text
                it6 = i.find("DisplayInterval").text
                it7 = i.find("PrmInterval").text
                it8 = i.find("PrmLoopCount").text
                it9 = i.find("PropagandaInterval").text
                it10 = i.find("PropagandaLoopcount").text
                it11 = i.find("MmiLanguageCode").text
                it12 = i.find("TimezoneOffset").text
                it13 = i.find("WheelpulseDistance").text
                it14 = i.find("PrmDisplayLine").text
                it15 = i.find("PropagandaDisplayLine").text
                it16 = i.find("Flags").text
                it17 = i.find("BeforeTime").text
                it18 = i.find("MaxNextStations").text

                hex_it = format(int(it), '02X')
                hex_it1 = format(int(it1), '04X')
                hex_it2 = format(int(it2), '02X')

                binary_string = struct.pack('d', float(it3))
                hex_it3 = binary_string.hex().upper()

                hex_it4 = format(int(it4), '04X')
                hex_it5 = format(int(it5), '02X')
                hex_it6 = format(int(it6), '04X')
                hex_it7 = format(int(it7), '02X')
                hex_it8 = format(int(it8), '02X')
                hex_it9 = format(int(it9), '02X')
                hex_it10 = format(int(it10), '02X')
                hex_it11 = it11.upper().encode('utf-8').hex().upper()
                hex_it12 = format(int(it12), '02X')
                hex_it13 = format(int(it13), '02X')
                hex_it14 = format(int(it14), '02X')
                hex_it15 = format(int(it15), '02X')
                hex_it16 = format(int(it16), '04X')
                hex_it16 = format(int(it16), '04X')
                hex_it17 = format(int(it17), '04X')
                hex_it18 = format(int(it18), '02X')

                config_dat_file.write(
                    f"{hex_it}{hex_it1}{hex_it2}{hex_it3}{hex_it4}{hex_it5}{hex_it6}{hex_it7}{hex_it8}{hex_it9}{hex_it10}{hex_it11}{hex_it12}{hex_it13}{hex_it14}{hex_it15}{hex_it16}{hex_it17}{hex_it18}\n")

    def dts_dat(self):
        # Create the DTS.DAT file in the DATA folder
        self.dts_dat_path = os.path.join(self.data_folder, 'DTS.DAT')

        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        # Select the required columns from the table
        cursor.execute("SELECT [day], [offset] FROM [tbl_dts]")
        rows = cursor.fetchall()
        with open(self.dts_dat_path, 'w', encoding='utf-8') as dts_dat_file:
            if rows:
                try:
                    for row in rows:
                        date_time = row[0]
                        offset = row[1]

                        date, time = date_time.split('-')
                        date_parts = date.split('/')
                        time_parts = time.split(':')
                        result = ','.join(date_parts + time_parts)
                        date_and_time_percentage = datetime.datetime.strptime(result, '%d,%m,%Y,%H,%M,%S')
                        change_dec_value = calendar.timegm(date_and_time_percentage.timetuple())
                        hex_dec_and_time = format(int(change_dec_value), '02X')

                        dict_1 = {1: 0, 2: 15, 3: 30, 4: 45, 5: 60}
                        for k, v in dict_1.items():
                            if v == offset:
                                hex_offset = format(int(k), '02X')

                        dts_dat_file.write(f"{hex_dec_and_time}{hex_offset}\n")

                except Exception as e:
                    print(f"An error occurred while exporting DTS : {e}")
                finally:
                    cursor.close()
                    conn.close()


    def gps_dat(self):
        # Create the GPS.DAT file in the DATA folder
        self.gps_dat_path = os.path.join(self.data_folder, 'GPS.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        # Select the required columns from the table
        query = "SELECT [stationID], [GPSPosX], [GPSPosY], [GPSPosZ], [defaultLanguageArea], [isLanguageBorder] FROM [tbl_station]"
        cursor.execute(query)
        rows = cursor.fetchall()

        with open(self.gps_dat_path, 'w', encoding='utf-8') as gps_dat_file:
            for row in rows:
                try:
                    station_id = row[0]
                    gps_pos_x = row[1]
                    gps_pos_y = row[2]
                    gps_pos_z = row[3]
                    name_audio = row[4]
                    language_border = row[5]

                    text_lang = name_audio
                    name_lang = ""
                    if text_lang:
                        if text_lang[-1] == ",":
                            text_lang = text_lang[:-1]
                        values = []
                        if text_lang:
                            values = text_lang.split(',')
                            # values.remove("")
                        count = len(values)
                        name_lang = binascii.hexlify(''.join(values).encode()).decode().upper()
                    else:
                        count = 0

                    if count <= 5:
                        name_lang += '0000' * (5 - count)

                    hex_value = format(int(station_id), '04X')
                    x = float(gps_pos_x)
                    output = struct.pack('d', x)
                    gps_x = output.hex().upper()

                    y = float(gps_pos_y)
                    output = struct.pack('d', y)
                    gps_y = output.hex().upper()

                    z = float(gps_pos_z)
                    output = struct.pack('d', z)
                    gps_z = output.hex().upper()

                    count_lang_border = language_border
                    lang_boder_text = f"0{count_lang_border}"

                    gps_dat_file.write(f"{hex_value}{gps_x}{gps_y}{gps_z}{name_lang}{lang_boder_text}\n")
                except Exception as e:
                    print(f"An error occurred while exporting gps_dat: {e}")
        cursor.close()
        conn.close()

    def journey_dat(self):
        # Create the JOURNEY.DAT file in the DATA folder
        self.journey_dat_path = os.path.join(self.data_folder, 'JOURNEY.DAT')
        # conn_str = ('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        # conn = pyodbc.connect(conn_str)
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()
        list_of_journey_id_aliases_dat_new_2 = []
        for items_id in self.list_of_journey_id_aliases_dat.values():
            list_of_journey_id_aliases_dat_new_2.append(items_id)
        # Select the required columns from the table
        query = 'SELECT [journeyID],[routeID],[journeyName],[condition],[serviceType],[totalCars],[handicapCar] FROM [tbl_journeys] order by journeyID'
        cursor.execute(query)
        rows = cursor.fetchall()
        try:
            with open(self.journey_dat_path, 'w', encoding='utf-8') as journey_dat_file:
                list_num = 0
                for row in rows:
                    if not list_of_journey_id_aliases_dat_new_2.count(int(row[0])):
                        continue
                    journey_id = row[0]
                    route_id = row[1]
                    journey_set_off_jstop = self.all_list_of_journey_id_aliases_dat[journey_id]
                    journey_set_off_jstop = self.length_of_jstops[journey_set_off_jstop]
                    journey_set_off_rstop = self.length_of_rstops[route_id]

                    journey_name = row[2]
                    journey_condition = row[3]
                    service_type = row[4]
                    total_cars = row[5]
                    handi_cars = row[6]

                    hex_value_journey_id = format(int(journey_id), '04X')

                    hex_value_route_id = format(int(route_id), '04X')
                    hex_journey_set_off_jstop = format(int(journey_set_off_jstop), '08X')
                    hex_journey_set_off_rstop = format(int(journey_set_off_rstop), '08X')

                    num_len = len(journey_name)
                    byte_value = journey_name.encode("utf-8")
                    journey_output = byte_value.hex().upper()

                    # if num_len < 8:
                    len_name = (16 - len(journey_output))//2
                    journey_output = journey_output+"20"*len_name

                    my_tr = ET.parse("projectinfo.xml")
                    root = my_tr.getroot()
                    j = journey_condition
                    hex_value_condition = 00
                    if journey_condition == "-None-":
                        hex_value_condition = format(int("127"), '02X') + '2020202020202020'
                    else:
                        for i in root.findall("timeConditional"):
                            it = i.find("name").text
                            it1 = i.find("value").text
                            if it == j:
                                hex_value_condition = format(int(it1), '02X') + '2020202020202020'

                    if service_type == "Fast":
                        service_output_value = "01"
                    elif service_type == "Slow":
                        service_output_value = "02"
                    elif service_type == "Both":
                        service_output_value = "03"
                    else:
                        service_output_value = "00"

                    total_cars_output = format(int(total_cars), '02X')

                    handi_cars_output = format(int(handi_cars), '02X')

                    journey_dat_file.write(f"{hex_value_journey_id}{hex_value_route_id}{journey_output}{hex_value_condition}{service_output_value}{total_cars_output}{handi_cars_output}{hex_journey_set_off_jstop}{hex_journey_set_off_rstop}\n")
        except Exception as e:
            print(f"An error occurred while exporting journey_dat: {e}")
        finally:
            cursor.close()
            conn.close()

    def jstops_dat(self):
        # Create the JSTOPS.DAT file in the DATA folder
        self.jstops_dat_path = os.path.join(self.data_folder, 'JSTOPS.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()
        list_of_journey_id_aliases_dat_new = []
        for items_id in self.list_of_journey_id_aliases_dat.values():
            list_of_journey_id_aliases_dat_new.append(items_id)

        # Select the required columns from the table
        query = 'SELECT [journeyID],[routeStopID],[arrivalTime],[depactureTime],[conditional],[combiTriggerIDn],[languageArea],[platformNum] FROM [tbl_journeyStops] order by journeyID, routeStopID'
        # query = 'SELECT [journeyID],[routeStopID],[arrivalTime],[depactureTime],[conditional],[combiTriggerIDn],[languageArea],[platformNum] FROM [tbl_journeyStops]'
        cursor.execute(query)
        rows = cursor.fetchall()
        not_in_list = set()
        in_list = set()
        with open(self.jstops_dat_path, 'w', encoding='utf-8') as jstops_dat_file:
            num = 0
            old_num = 0
            for row in rows:
                try:
                    if not list_of_journey_id_aliases_dat_new.count(int(row[0])):
                        not_in_list.add(row[0])
                        # num += 1
                        continue
                    in_list.add(row[0])
                    journeystops_id = row[0]
                    journeystopsorder_id = row[1]
                    journeystops_arrival = row[2]
                    journeystops_departure = row[3]
                    journeystops_condition = row[4]
                    journeystops_condition_combitrigger_id = row[5]
                    journeystops_language = row[6]
                    platform_number = row[7]

                    len_data = 46 * num
                    # if journeystops_id == 326:
                    # if int(row[0]) != rows[num][0]:

                    if old_num != journeystops_id:
                        # self.length_of_jstops[rows[num][0]] = len_data
                        self.length_of_jstops[journeystops_id] = len_data
                        old_num = journeystops_id
                        # if rows[num][0] == rows[-1][0]:
                        #     break

                    num += 1
                    hex_value_journeystops_id = format(int(journeystops_id), '04X')
                    hex_value_journeystoporder_id = format(int(journeystopsorder_id), '04X')

                    journeystops_arrival_var = journeystops_arrival
                    journeystops_arrival_output = str(journeystops_arrival_var).replace(':', '')

                    journeystops_departure_var = journeystops_departure
                    journeystops_departure_output = journeystops_departure_var.replace(':', '')

                    my_tr = ET.parse("projectinfo.xml")
                    root = my_tr.getroot()
                    k = journeystops_condition
                    hex_value_journeystops_condition = 00
                    if journeystops_condition == "-None-":
                        hex_value_journeystops_condition = format(int('127'), '02X')
                    else:
                        for i in root.findall("timeConditional"):
                            it = i.find("name").text
                            it1 = i.find("value").text
                            if it == k:
                                hex_value_journeystops_condition = format(int(it1), '02X')
                    if not journeystops_condition_combitrigger_id:
                        journeystops_condition_combitrigger_id = 0

                    try:
                        hex_value_journeystoporder_combitriggerid = format(int(journeystops_condition_combitrigger_id), '04X')
                    except ValueError:
                        hex_value_journeystoporder_combitriggerid = format(int(0), '04X')

                    text_lang = journeystops_language
                    values = text_lang.split(',')
                    count = len(values)
                    if values[0] == "-None-":
                        name_lang = '0000' * 5
                    else:
                        name_lang = binascii.hexlify(''.join(values).encode()).decode().upper()
                        if count <= 5:
                            name_lang += '0000' * (5 - count)

                    if platform_number == "Left" or platform_number == "1":
                        platform_output_value = "01"
                    elif platform_number == "Right" or platform_number == "2":
                        platform_output_value = "02"
                    elif platform_number == "Both" or platform_number == "3":
                        platform_output_value = "03"
                    elif type(platform_number) == type(1):
                        platform_output_value = int(platform_number)
                    else:
                        platform_output_value = "00"
                    jstops_dat_file.write(
                        f"{hex_value_journeystops_id}{hex_value_journeystoporder_id}{journeystops_arrival_output}{journeystops_departure_output}{hex_value_journeystops_condition}{hex_value_journeystoporder_combitriggerid}{name_lang}{platform_output_value}\n")
                except Exception as e:
                    print(f"An error occurred while exporting jstops_dat: {e}")
        cursor.close()
        conn.close()

    def messages_dat(self):
        # Create the MESSAGES.DAT file in the DATA folder
        self.messages_dat_path = os.path.join(self.data_folder, 'MESSAGES.DAT')

        my_tr1 = ET.parse("projectinfo.xml")
        root1 = my_tr1.getroot()
        list_lang = []
        markupCode_feild_list = []
        for i in root1.findall("markupCode"):
            it = i.find("group").text
            if it == "3":
                it2 = i.find("name").text
                if it2 != "**":
                    list_lang.append(it2)
            else:
                it2 = i.find("name").text
                markupCode_feild_list.append(it2)
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()
        cursor.execute(f"SELECT  action_ID_int, do_this_combi_ID FROM [do_this_combi_item] order by [do_this_combi_ID] , [ActionOrder]")
        do_this_combi_item = cursor.fetchall()

        self.list_language_data_2 = {}
        self.list_language_data_3 = {}
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("ImsLanguages"):
            Code = i.find("Code").text
            subtract = i.find("subtract").text
            uni_sub = i.find("uni_sub").text
            add = i.find("add").text
            Size = i.find("Size").text
            self.list_language_data_2[Code] = (uni_sub, add)
            self.list_language_data_3[uni_sub] = (Code, add, subtract, Size)
        try:
            with open(self.messages_dat_path, 'w', encoding='utf-8') as message_dat_file:
                for action_ID_int, do_this_combi_ID in do_this_combi_item:
                    cursor.execute(
                        f"SELECT  [message_Description] ,[action_ID] FROM [tbl_action] where [action_ID]={action_ID_int}")
                    message_description = cursor.fetchall()
                    print("message_description", message_description)

                    for tag in message_description:
                        list_item = []
                        list_lang_new = []
                        text = ''
                        not_file_found = False
                        for i in tag[0]:
                            if i.isalpha() or i.isalnum() or i == ' ' or i == '_' or i == '/':
                                text = text + i
                            else:
                                if i == '>' or i == '}' or i == ']':
                                    list_item.append(text)
                                    text = ''

                        field_name = 'field00'
                        number_of_segement = 0
                        set_list_lang_new = list_lang
                        set_list_lang_new_2 = set()

                        for new_lang in list_lang:
                            if list_item.count(new_lang):
                                list_item.remove(new_lang)
                                list_item.remove(f"/{new_lang}")
                                set_list_lang_new_2.add(new_lang)

                        if set_list_lang_new_2:
                            # set_list_lang_new.clear()
                            set_list_lang_new = set_list_lang_new_2
                        for language_data in set_list_lang_new:
                            new_list = []
                            xml_type = "00"
                            for text_mt_ml in list_item:
                                if text_mt_ml[:2] == "MA":
                                    file_exist = glob.glob(f"sqlData/audio/{text_mt_ml}{language_data.upper()}.MP3",
                                                           recursive=True)
                                    if not file_exist:
                                        # print("Failed", text_mt_ml, language_data.upper())
                                        not_file_found = True
                                        continue
                                    xml_type = "00"
                                    break
                                elif text_mt_ml[:2] == "MT":
                                    xml_type = "02"
                                    break
                                else:
                                    xml_type = "02"
                                    break
                            for tag_item in list_item:
                                # print("tag_item", tag_item)
                                if tag_item == language_data or tag_item == f'/{language_data}':
                                    pass
                                elif markupCode_feild_list.count(tag_item):
                                    field_name = tag_item
                                elif markupCode_feild_list.count(tag_item.replace("/", "")):
                                    field_name = 'field00'
                                elif tag_item[:3:] == 'fie':
                                    field_name = tag_item
                                elif tag_item[:3:] == '/fi':
                                    field_name = 'field00'
                                else:
                                    # print(field_name, tag_item, "field.............................................30")
                                    if tag_item[:2:] == 'MT':
                                        file_exist = glob.glob(f"sqlData/txt/{tag_item}{language_data.upper()}.TXT",
                                                               recursive=True)
                                        if not file_exist:
                                            not_file_found = True
                                            continue
                                        text_item = open(f"sqlData/txt/{tag_item}{language_data.upper()}.TXT", "r",
                                                         encoding="utf-8")
                                        content = text_item.read()

                                        lis_content = []

                                        for char in content:
                                            for char_2 in self.list_language_data_3.keys():
                                                if int(char_2, 16) <= ord(char) <= (int(char_2, 16) + 0x7f):
                                                    len_num = int(self.list_language_data_3[char_2][3])
                                                    value = hex(ord(char) - (int(self.list_language_data_3[char_2][2], 16)) + (
                                                        int(self.list_language_data_3[char_2][1], 16))).replace("0x", "")
                                                    add_byte = len_num * 2 - len(value)
                                                    lis_content.append("0" * add_byte + value.upper())

                                        res = "".join(lis_content)

                                        content_hex1 = str(res)

                                        hex_value_size = int(len(content))
                                        hex_length = format(int(hex_value_size), '02X')
                                        new_list.append('02')
                                        new_list.append(hex_length)
                                        new_list.append(content_hex1)

                                        my_tr = ET.parse("projectinfo.xml")
                                        root = my_tr.getroot()
                                        for i in root.findall("markupCode"):
                                            it_name = i.find("name").text
                                            if it_name == field_name:
                                                mask_xml = i.find("mask").text
                                                hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
                                                new_list.append(hex_value_journeystops_condition)

                                    elif tag_item[:2:] == "MA":
                                        self.all_audio_file_other.add(tag_item)
                                        file_exist = glob.glob(f"sqlData/audio/{tag_item}{language_data.upper()}.MP3",
                                                               recursive=True)
                                        if not file_exist:
                                            # print("Failed", tag_item, language_data.upper())
                                            not_file_found = True
                                            continue
                                        content = f"{tag_item}{language_data.upper()}.MP3"
                                        content_length = (len(content))
                                        hex_length = format(int(content_length), '02X')
                                        hex_value_journeystops_condition = f"{content.encode('utf-8').hex().upper()}"
                                        new_list.append('00')
                                        new_list.append(hex_length)
                                        new_list.append(hex_value_journeystops_condition)
                                        my_tr = ET.parse("projectinfo.xml")
                                        root = my_tr.getroot()
                                        for i in root.findall("markupCode"):
                                            it = i.find("name").text
                                            # print(field_name, it, "field.............................................30")
                                            if it == field_name:
                                                mask_xml = i.find("mask").text
                                                hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
                                                new_list.append(hex_value_journeystops_condition)

                                    elif tag_item[:2:] == "MV":
                                        self.all_audio_file_video.add(tag_item)
                                        content = f"{tag_item}{language_data.upper()}.MP4"
                                        content_length = (len(content))
                                        hex_length = format(int(content_length), '02X')
                                        hex_value_journeystops_condition = f"{content.encode('utf-8').hex().upper()}"
                                        new_list.append('03')
                                        new_list.append(hex_length)
                                        new_list.append(hex_value_journeystops_condition)
                                        my_tr = ET.parse("projectinfo.xml")
                                        root = my_tr.getroot()
                                        for i in root.findall("markupCode"):
                                            it = i.find("name").text
                                            # print(field_name, it, "field.............................................30")
                                            if it == field_name:
                                                mask_xml = i.find("mask").text
                                                hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
                                                new_list.append(hex_value_journeystops_condition)

                                        my_tr = ET.parse("projectinfo.xml")
                                        root = my_tr.getroot()
                                        for i in root.findall("markupCode"):
                                            it = i.find("name").text
                                            # print(field_name, it, "field.............................................58")
                                            if it == field_name:
                                                mask_xml = i.find("mask").text
                                                hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
                                                new_list.append(hex_value_journeystops_condition)

                                    elif tag_item[:2:] == "ML":
                                        self.all_audio_file_other.add(tag_item)
                                        content = f"{tag_item}{language_data.upper()}.ICO"
                                        content_length = (len(content))
                                        hex_length = format(int(content_length), '02X')
                                        hex_value_journeystops_condition = f"{content.encode('utf-8').hex().upper()}"
                                        new_list.append('03')
                                        new_list.append(hex_length)
                                        new_list.append(hex_value_journeystops_condition)

                                        my_tr = ET.parse("projectinfo.xml")
                                        root = my_tr.getroot()
                                        for i in root.findall("markupCode"):
                                            it = i.find("name").text
                                            # print(field_name, it, "field.............................................77")
                                            if it == field_name:
                                                mask_xml = i.find("mask").text
                                                hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
                                                new_list.append(hex_value_journeystops_condition)

                                    elif tag_item[:2:] == "MB":
                                        self.all_audio_file_other.add(tag_item)
                                        content = f"{tag_item}{language_data.upper()}.PNG"
                                        # content = f"{tag_item}{language_data.upper()}.DLE"
                                        file_exist = glob.glob(f"sqlData/logo/{tag_item}{language_data.upper()}.PNG",
                                                               recursive=True)
                                        if not file_exist:
                                            not_file_found = True
                                            break
                                        content_length = (len(content))
                                        hex_length = format(int(content_length), '02X')
                                        hex_value_journeystops_condition = f"{content.encode('utf-8').hex().upper()}"
                                        new_list.append('03')
                                        new_list.append(hex_length)
                                        new_list.append(hex_value_journeystops_condition)

                                        my_tr = ET.parse("projectinfo.xml")
                                        root = my_tr.getroot()
                                        for i in root.findall("markupCode"):
                                            it = i.find("name").text
                                            # print(field_name, it, "field.............................................96")
                                            if it == field_name:
                                                mask_xml = i.find("mask").text
                                                hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
                                                new_list.append(hex_value_journeystops_condition)

                                        text_item.close()

                                    else:
                                        new_list.append(xml_type)
                                        new_list.append('02')
                                        my_tr = ET.parse("projectinfo.xml")
                                        root = my_tr.getroot()
                                        for i in root.findall("stationCode"):
                                            it = i.find("name").text.lower()
                                            if it == tag_item.lower():
                                                mask_xml = i.find("code").text
                                                hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
                                                new_list.append(hex_value_journeystops_condition)

                                        # new_list.append(content_hex)

                                        my_tr = ET.parse("projectinfo.xml")
                                        root = my_tr.getroot()
                                        for i in root.findall("markupCode"):
                                            it = i.find("name").text
                                            # print(field_name, "field.............................................22")
                                            if it == field_name:
                                                mask_xml = i.find("mask").text
                                                hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
                                                new_list.append(hex_value_journeystops_condition)
                                    number_of_segement += 1
                                    if not_file_found:
                                        continue
                            if not_file_found:
                                not_file_found = False
                                continue
                            new_list.insert(0, f"{format(int(tag[1]), '04X')}")
                            language_data_hex = language_data.upper().encode('utf-8').hex().upper()
                            new_list.insert(1, language_data_hex)
                            segment_number_hex = f"{format(int(number_of_segement), '02X')}"
                            new_list.insert(2, segment_number_hex)
                            number_of_segement = 0
                            message_description_all_vallue = (''.join(new_list))
                            message_dat_file.write(f"{message_description_all_vallue}\n")

        except Exception as e:
            print(f"An error occurred while exporting messages_dat : {e}")
        finally:
            cursor.close()
            conn.close()


    def prm_msg_dat(self):
        # Create the PRM_MSG.DAT file in the DATA folder
        self.prm_msg_dat_path = os.path.join(self.data_folder, 'PRM_MSG.DAT')
        # conn_str = ('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        # conn = pyodbc.connect(conn_str)
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        query = 'SELECT [name],[description] FROM [messageA]'
        cursor.execute(query)
        rows = cursor.fetchall()
        try:
            with open(self.prm_msg_dat_path, 'w', encoding='utf-8') as prm_msg_dat_file:
                for row in rows:
                    prm_msg_name = row[0]
                    prm_msg_description = row[1]

                    if "PR" in prm_msg_name:
                        prm_msg_name1 = prm_msg_name

                        hex_value_prm_aa = prm_msg_name1.encode('utf-8').hex().upper()

                        hex_value_prm_msg_name_len = (len(hex_value_prm_aa))
                        hex_value_prm_msg_name_len_border  = hex_value_prm_msg_name_len //2
                        hex_value_prm_msg_name_len_border_output = format(hex_value_prm_msg_name_len_border, '04X')

                        hex_value_prm_msg_description = prm_msg_description.encode('utf-8').hex().upper()

                        hex_value_prm_msg_description_len = (len(hex_value_prm_msg_description))
                        hex_value_prm_msg_description_len_border  = hex_value_prm_msg_description_len //2
                        hex_value_prm_msg_description_len_border_output = format(hex_value_prm_msg_description_len_border, '02X')

                        prm_msg_dat_file.write(f"{hex_value_prm_msg_name_len_border_output}{hex_value_prm_aa}{hex_value_prm_msg_description_len_border_output}{hex_value_prm_msg_description}\n")
        except Exception as e:
            print(f"An error occurred while exporting prm_msg_dat : {e}")
        finally:
            cursor.close()
            conn.close()

    def pub_msg_dat(self):
        # Create the PUB_MSG.DAT file in the DATA folder
        self.pub_msg_dat_path = os.path.join(self.data_folder, 'PUB_MSG.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        query = 'SELECT [name],[description] FROM [messageA]'
        cursor.execute(query)
        rows = cursor.fetchall()
        try:
            with open(self.pub_msg_dat_path, 'w', encoding='utf-8') as pub_msg_dat_file:
                for row in rows:
                    pub_msg_name = row[0]
                    pub_msg_description = row[1]

                    if "PU" in pub_msg_name:
                        pub_msg_name1 = pub_msg_name

                        hex_value_pub_aa = pub_msg_name1.encode('utf-8').hex().upper()

                        hex_value_pub_msg_name_len = (len(hex_value_pub_aa))
                        hex_value_pub_msg_name_len_border  = hex_value_pub_msg_name_len //2
                        hex_value_pub_msg_name_len_border_output = format(hex_value_pub_msg_name_len_border, '04X')

                        hex_value_pub_msg_description = pub_msg_description.encode('utf-8').hex().upper()

                        hex_value_pub_msg_description_len = (len(hex_value_pub_msg_description))
                        hex_value_pub_msg_description_len_border = hex_value_pub_msg_description_len //2
                        hex_value_pub_msg_description_len_border_output = format(hex_value_pub_msg_description_len_border, '02X')

                        pub_msg_dat_file.write(f"{hex_value_pub_msg_name_len_border_output}{hex_value_pub_aa}{hex_value_pub_msg_description_len_border_output}{hex_value_pub_msg_description}\n")
        except Exception as e:
            print(f"An error occurred while exporting pub_msg_dat : {e}")
        finally:
            cursor.close()
            conn.close()

    def rstops_dat(self):
        # Create the RSTOPS.DAT file in the DATA folder
        self.rstops_dat_path = os.path.join(self.data_folder, 'RSTOPS.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        query = 'SELECT [routeID],[stopOrder],[stationID],[distanceFromPrev] FROM [tbl_routeStops] order by routeID, stopOrder'
        cursor.execute(query)
        rows = cursor.fetchall()

        with open(self.rstops_dat_path, 'w', encoding='utf-8') as rstops_dat_file:
            number_of_point = 1
            print(rows,"dddddddddddddddd")
            for row in rows:
                try:
                    routestops_id = row[0]
                    routestopsorder_id = row[1]
                    routestops_station_id = row[2]
                    routestops_distance_preview = float(row[3])
                    # print("routestops_station_id", routestops_station_id)
                    self.all_audio_file_station.add(routestops_station_id)
                    len_data = 22 * number_of_point
                    #######################
                    try:
                        if int(row[0]) != rows[number_of_point][0]:
                            self.length_of_rstops[rows[number_of_point][0]] = len_data
                            # if rows[number_of_point][0] == rows[-1][0]:
                            #     break
                        elif len(self.length_of_rstops) < 1:
                            self.length_of_rstops[rows[number_of_point][0]] = 0
                    except IndexError:
                        pass
                    number_of_point += 1

                    hex_value_routestops_id = format(int(routestops_id), '04X')

                    hex_value_routestopsorder_id = format(int(routestopsorder_id), '04X')

                    hex_value_routestops_station_id = format(int(routestops_station_id), '04X')
                    if routestops_distance_preview and routestops_distance_preview != 'Empty':
                        hex_value_routestops_distance_preview = hex(int(routestops_distance_preview))[2:].upper().zfill(
                            8)
                    else:
                        hex_value_routestops_distance_preview = '00000000'
                    rstops_dat_file.write(
                        f"{hex_value_routestops_id}{hex_value_routestopsorder_id}{hex_value_routestops_station_id}{hex_value_routestops_distance_preview}\n")
                except Exception as e:
                    print(f"An error occurred while exporting rstops_dat: {e}")
        cursor.close()
        conn.close()

    def spt_msg_dat(self):
        # Create the SPT_MSG.DAT file in the DATA folder
        self.spt_msg_path = os.path.join(self.data_folder, 'SPT_MSG.DAT')
        # conn_str = ('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        # conn = pyodbc.connect(conn_str)
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        # Select the required columns from the table
        query = 'SELECT [name],[description] FROM [messageA]'
        cursor.execute(query)
        rows = cursor.fetchall()
        try:
            with open(self.spt_msg_path, 'w', encoding='utf-8') as spt_msg_dat_file:
                for row in rows:
                    spt_msg_name = row[0]
                    spt_msg_description = row[1]

                    if "SP" in spt_msg_name:
                        spt_msg_name1 = spt_msg_name

                        hex_value_spt_aa = spt_msg_name1.encode('utf-8').hex().upper()

                        hex_value_spt_msg_name_len = (len(hex_value_spt_aa))
                        hex_value_spt_msg_name_len_border = hex_value_spt_msg_name_len //2
                        hex_value_spt_msg_name_len_border_output = format(hex_value_spt_msg_name_len_border, '04X')

                        hex_value_spt_msg_description = spt_msg_description.encode('utf-8').hex().upper()

                        hex_value_spt_msg_description_len = (len(hex_value_spt_msg_description))
                        hex_value_spt_msg_description_len_border = hex_value_spt_msg_description_len //2
                        hex_value_spt_msg_description_len_border_output = format(hex_value_spt_msg_description_len_border, '02X')

                        spt_msg_dat_file.write(f"{hex_value_spt_msg_name_len_border_output}{hex_value_spt_aa}{hex_value_spt_msg_description_len_border_output}{hex_value_spt_msg_description}\n")
        except Exception as e:
            print(f"An error occurred while exporting GPS data1,1,1,1: {e}")
        finally:
            cursor.close()
            conn.close()


    def stations_dat(self):
        # Create the STATIONS.DAT file in the DATA folder
        self.station_path = os.path.join(self.data_folder, 'STATIONS.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()
        # Select the required columns from the table
        query = "SELECT [ISOlang], [stationNameAudio], [stationName], [stationNameShort], [stationID] FROM [tbl_stationNames] order by stationID, numLanguage"
        cursor.execute(query)
        rows = cursor.fetchall()

        with open(self.station_path, 'w', encoding='utf-8') as station_file:
            list_language_data = {}
            list_language_data_2 = {}
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            for i in root.findall("ImsLanguages"):
                Code = i.find("Code").text
                subtract = i.find("subtract").text
                uni_sub = i.find("uni_sub").text
                add = i.find("add").text
                Size = i.find("Size").text
                it3 = i.find("graphics").text

                list_language_data[Code] = (uni_sub, add)
                list_language_data_2[uni_sub] = (Code, add, subtract, Size)

            for row in rows:
                try:
                    if list_language_data.get(row[0]):
                        hex_value_station_en = format(int(row[4]), '04X')
                        name_lang_station_en = binascii.hexlify(''.join(row[0]).encode()).decode().upper()
                        station_data_get_en = hex_value_station_en + name_lang_station_en

                        unicode_text = row[2]
                        unicode_text_short = row[3]
                        add_and_subtract = list_language_data.get(row[0])
                        subtract = add_and_subtract[0]
                        add = add_and_subtract[1]

                        lis_content = []

                        for char in unicode_text:
                            for char_2 in list_language_data_2.keys():
                                if int(char_2, 16) <= ord(char) <= (int(char_2, 16) + 0x7f):
                                    len_num = int(list_language_data_2[char_2][3])
                                    value = hex(ord(char) - (int(list_language_data_2[char_2][2], 16)) + (
                                        int(list_language_data_2[char_2][1], 16))).replace("0x", "")
                                    add_byte = len_num * 2 - len(value)
                                    lis_content.append("0" * add_byte + value.upper())

                        output = "".join(lis_content)

                        pairs_output = [output[i:i + 2] for i in range(0, len(output), 2)]
                        count_output = len(pairs_output)
                        hex_value_len = format(int(count_output), '02X')

                        lis_content_short = []
                        for char in unicode_text_short:
                            for char_2 in list_language_data_2.keys():
                                if int(char_2, 16) <= ord(char) <= (int(char_2, 16) + 0x7f):
                                    len_num = int(list_language_data_2[char_2][3])
                                    value = hex(ord(char) - (int(list_language_data_2[char_2][2], 16)) + (
                                        int(list_language_data_2[char_2][1], 16))).replace("0x", "")
                                    add_byte = len_num * 2 - len(value)
                                    lis_content_short.append("0" * add_byte + value.upper())

                        output_short = ''.join(lis_content_short)

                        pairs_output_short = [output_short[i:i + 2] for i in range(0, len(output_short), 2)]
                        count_output_short = len(pairs_output_short)
                        hex_value_len_short = format(int(count_output_short), '02X')

                        station_file.write(
                            f"{station_data_get_en}{it3}{hex_value_len_short}{output_short}{it3}{hex_value_len}{output}\n")


                except Exception as e:
                    print(f"An error occurred while exporting Station : {e}")
    def trigger_data(self):
        # Create the TRIGGER.DAT file in the DATA folder
        self.trigger_path = os.path.join(self.data_folder, 'TRIGGER.DAT')
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        query = "SELECT [triggerID],[do_this_combi_ID],[triggerPrio],[eventValue],[conditional], [eventType] FROM [tbl_trigger] order by triggerID"
        cursor.execute(query)
        rows = cursor.fetchall()

        with open(self.trigger_path, 'w', encoding='utf-8') as trigger_dat_file:

            for row in rows:
                try:
                    if not row[1]:
                        continue
                    if not row[3]:
                        continue
                    trigger_ID = row[0]
                    combi_action_id = row[1]
                    trigger_priority = row[2]
                    eventvalue = row[3]
                    conditonal = row[4]
                    event_type = row[5]

                    trigger_id_hex = format(int(trigger_ID), '04X')
                    combi_action_id_hex = format(int(combi_action_id), '04X')
                    trigger_priority_hex = format(int(trigger_priority), '02X')
                    all_event_value = ""
                    if not (eventvalue.find(" ") == 0 or len(eventvalue) == 0):
                        remove_brackets = eventvalue.replace("[", "").replace("]", "")
                        split_if_data = remove_brackets.split(";")
                        my_tr = ET.parse("projectinfo.xml")
                        root = my_tr.getroot()
                        event_value_1 = ""
                        event_value_1_number = ""
                        if event_type.upper() == "SPEED":
                            for i in root.findall("Speed"):
                                if split_if_data[3] == ">":
                                    it = i.find("name").text
                                    it2 = i.find("value").text
                                    if it == "SPEED_LARGER":
                                        event_value_1 = format(int(it2), '02X')
                                        event_value_1_number = format(int(split_if_data[1]), '02X')[-2:]
                                        all_event_value = f"{all_event_value}{event_value_1}{event_value_1_number}"
                                elif split_if_data[3] == "<":
                                    it = i.find("name").text
                                    it2 = i.find("value").text
                                    if it == "SPEED_LESSER":
                                        event_value_1 = format(int(it2), '02X')
                                        event_value_1_number = format(int(split_if_data[1]), '02X')[-2:]
                                        all_event_value = f"{all_event_value}{event_value_1}{event_value_1_number}"
                        else:
                            for i in root.findall("locationIndexed"):
                                it = i.find("name").text
                                it2 = i.find("value").text
                                if it == split_if_data[3]:
                                    event_value_1 = format(int(it2), '02X')
                                    event_value_1_number = format(int(split_if_data[1]), '04X')
                                    all_event_value = f"{all_event_value}{event_value_1}{event_value_1_number}"
                    if not (conditonal.find(" ") == 0 or len(conditonal) == 0):
                        list_of_and_condition = conditonal.split(",")
                        event_value_2 = ""
                        event_value_2_number = ""
                        for item_list in list_of_and_condition:
                            remove_brackets_and = item_list.replace("[", "").replace("]", "")
                            split_and_data = remove_brackets_and.split(";")
                            if split_and_data[1].upper() == "SPEED":
                                for i in root.findall("Speed"):
                                    if split_and_data[4] == ">":
                                        it = i.find("name").text
                                        it2 = i.find("value").text
                                        if it == "SPEED_LARGER":
                                            event_value_2 = format(int(it2), '02X')
                                            event_value_2_number = format(int(split_if_data[2]), '02X')[-2:]
                                            all_event_value = f"{all_event_value}{event_value_2}{event_value_2_number}"
                                    elif split_and_data[4] == "<":
                                        it = i.find("name").text
                                        it2 = i.find("value").text
                                        if it == "SPEED_LESSER":
                                            event_value_2 = format(int(it2), '02X')
                                            event_value_2_number = format(int(split_and_data[2]), '02X')[-2:]
                                            all_event_value = f"{all_event_value}{event_value_2}{event_value_2_number}"
                            else:
                                for i in root.findall("locationIndexed"):
                                    it = i.find("name").text
                                    it2 = i.find("value").text
                                    if it == split_and_data[4]:
                                        event_value_2 = format(int(it2), '02X')
                                        event_value_2_number = format(int(split_and_data[2]), '02X')[-2:]
                                        all_event_value = f"{all_event_value}{event_value_2}{event_value_2_number}"

                    lenth_of_all_event = format(int(len(all_event_value) / 2) + 1, '02X')
                    trigger_dat_file.write(
                        f"{trigger_id_hex}{combi_action_id_hex}{trigger_priority_hex}{lenth_of_all_event}{all_event_value}\n")
                except Exception as e:
                    print(f"An error occurred while exporting trigger.dat : {e}")
        cursor.close()
        conn.close()

    def txt_msg_dat(self):
        # Create the TXT_MSG.DAT file in the DATA folder
        self.txt_msg_path = os.path.join(self.data_folder, 'TXT_MSG.DAT')
        # conn_str = ('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        # conn = pyodbc.connect(conn_str)
        conn = sqlite3.connect("triggers_abhay.db")
        cursor = conn.cursor()

        # Select the required columns from the table
        query = 'SELECT [name],[description] FROM [messageA]'
        cursor.execute(query)
        rows = cursor.fetchall()
        try:
            with open(self.txt_msg_path, 'w', encoding='utf-8') as txt_msg_dat_file:
                for row in rows: 
                    txt_msg_name = row[0]
                    txt_msg_description = row[1]

                    if "TA" in txt_msg_name:
                        txt_msg_name1 = txt_msg_name
                        
                        hex_value_txt_aa = txt_msg_name1.encode('utf-8').hex().upper()
                        
                        hex_value_txt_msg_name_len = (len(hex_value_txt_aa))
                        hex_value_txt_msg_name_len_border = hex_value_txt_msg_name_len // 2

                        hex_value_txt_msg_name_len_border_output = format(hex_value_txt_msg_name_len_border, '04X')
                        
                        hex_value_txt_msg_description = txt_msg_description.encode('utf-8').hex().upper()
                        
                        hex_value_txt_msg_description_len = (len(hex_value_txt_msg_description))
                        hex_value_txt_msg_description_len_border  = hex_value_txt_msg_description_len //2
                        hex_value_txt_msg_description_len_border_output = format(hex_value_txt_msg_description_len_border, '02X')
                            
                        txt_msg_dat_file.write(f"{hex_value_txt_msg_name_len_border_output}{hex_value_txt_aa}{hex_value_txt_msg_description_len_border_output}{hex_value_txt_msg_description}\n")
        except Exception as e:
            print(f"An error occurred while exporting txt_msg_dat: {e}")
        finally:
            cursor.close()
            conn.close()

    def version_dat(self):
        # Create the VERSION.DAT file in the DATA folder
        self.version_path = os.path.join(self.data_folder, 'VERSION.DAT')
        with open(self.version_path, 'w', encoding='utf-8') as version_file:
            my_tr = ET.parse("version.xml")
            root = my_tr.getroot()
            for i in root.findall("Data"):
                it = i.find("Major").text
                it1 = i.find("Minor").text
                it2 = i.find("Build").text
                it3 = i.find("UTC").text

                hex_major = format(int(it), '02X')
                hex_minor = format(int(it1), '02X')
                hex_build = format(int(it2), '04X')
                hex_utc = format(int(it3), '02X')

            version_file.write(f"{hex_major}{hex_minor}{hex_build}{hex_utc}")
            
            
    def on_exit(self):
        self.add_new.destroy()
        main.MainApplication()

if __name__ == "__main__":
    MainApplication5()
