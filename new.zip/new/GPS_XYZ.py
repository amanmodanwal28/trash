# for algoritm see https://en.wikipedia.org/wiki/Geographic_coordinate_conversion#From_geodetic_to_ECEF_coordinates
# for values of a and b see https://en.wikipedia.org/wiki/Earth_radius#Radius_of_curvature


# from math import *

from math import sin, cos, sqrt, pi, atan2

def latlonhtoxyzwgs84(lat,lon,h):

    a = 6378137.0             #radius a of earth in meters cfr WGS84
    b = 6356752.3             #radius b of earth in meters cfr WGS84
    e2 = 1-(b**2/a**2)

    latr = lat/90*0.5*pi      #latitude in radians
    lonr = lon/180*pi         #longituede in radians

    Nphi = a/sqrt(1-e2*sin(latr)**2)

    x = (Nphi+h)*cos(latr)*cos(lonr)
    y = (Nphi+h)*cos(latr)*sin(lonr)
    z = (b**2/a**2*Nphi+h)*sin(latr)
    return([x,y,z])
print(latlonhtoxyzwgs84(float("-26.4047"), float("90.2723"), float("110")))



# reverse

from math import atan2, sqrt, pi, sin, cos

def xyyzwtolatlonh(x, y, z):
    a = 6378137.0            # semi-major axis in meters (WGS84)
    b = 6356752.3            # semi-minor axis in meters (WGS84)
    e2 = 1 - (b**2 / a**2)   # square of eccentricity
    ep2 = (a**2 / b**2) - 1  # second eccentricity squared

    # Calculate longitude
    lon = atan2(y, x) * 180 / pi

    # Iterative solution for latitude
    p = sqrt(x**2 + y**2)
    theta = atan2(z * a, p * b)
    lat = atan2(z + ep2 * b * sin(theta)**3, p - e2 * a * cos(theta)**3) * 180 / pi

    # Calculate height
    Nphi = a / sqrt(1 - e2 * sin(lat * pi / 180)**2)
    h = p / cos(lat * pi / 180) - Nphi

    return [lat, lon, h]

# Example usage
# x, y, z = latlonhtoxyzwgs84(-26.4047, 90.2723, 110)
# print(xyyzwtolatlonh(x, y, z))
print(xyyzwtolatlonh(-27168.0, 5716558.0, -2819340.0))



import struct
print("\x41 \x3b")
def hex_to_float(hex_str):
    # Ensure the hexadecimal string is in the correct format (length of 16 characters)
    if len(hex_str) != 16:
        raise ValueError("Hexadecimal string must be 16 characters long")

    # Convert the hexadecimal string to bytes
    byte_data = bytes.fromhex(hex_str)
    print(byte_data)
    # Unpack the bytes into a double-precision float
    float_value = struct.unpack('d', byte_data)[0]
    return float_value

# Example usage
hex_str = '00000000B9183B41'  # Example hex string (corresponds to the float 3.141592653589793)
original_float = hex_to_float(hex_str)
print(original_float)  # Output: 3.141592653589793
