# # # import tkinter as tk
# # #
# # # l = []
# # # def retrieve_values():
# # #     for entry in entry_list:
# # #         # print(entry)
# # #         value = entry.get()
# # #         l.append(value)
# # #         # print(value)
# # #         print(l)
# # #
# # #
# # # root = tk.Tk()
# # # root.title("Multiple Entry Example")
# # #
# # # num_entries = 5
# # # entry_list = []
# # #
# # # def add_entry():
# # #     entry = tk.Entry(root)
# # #     entry.pack()
# # #     entry_list.append(entry)
# # #
# # # retrieve_button = tk.Button(root, text="Retrieve Values", command=retrieve_values)
# # # retrieve_button.pack()
# # # retrieve_button = tk.Button(root, text="Add", command=add_entry)
# # # retrieve_button.pack()
# # # root.mainloop()
# #
# #
# # import tkinter.ttk
# # from tkinter import *
# # import shutil
# # import pyodbc
# # from tkinter import messagebox
# # import main
# # import tkinter as tk
# # import pygame
# # from pathlib import Path
# # from tkinter import filedialog as fd
# # import xml.etree.ElementTree as ET
# # # Define the class the application
# # class MainApplication1:
# #     # init method or constructor that call by instance variable
# #     def __init__(self):
# #         self.full_name_xml = []
# #         self.code_name_xml = [""]
# #         self.language_from_xml = ET.parse("projectinfo.xml")
# #         root = self.language_from_xml.getroot()
# #         for i in root.findall("ImsLanguages"):
# #             full_name = i.find("Name").text
# #             code_name = i.find("Code").text
# #             self.full_name_xml.append(full_name)
# #             self.code_name_xml.append(full_name)
# #             # print(full_name)
# #             # print(code_name)
# #         self.new_data = tk.Tk()
# #         self.new_data.title("Trigger")
# #         self.new_data.geometry("600x460+390+90")
# #         self.new_data.iconbitmap("logo2.ico")
# #         self.new_data.config(bg='gray75')
# #         # self.top1.protocol("WM_DELETE_WINDOW", self.on_exit)
# #         self.LabelFrame_new = LabelFrame(self.new_data, height=400, width=590, bd=5, bg='gray85')
# #         self.LabelFrame_new.place(x=5, y=20)
# #         self.GPS_coordinates = LabelFrame(self.LabelFrame_new, text="GPS coordinates", height=150, width=560, bd=2, bg='gray85', fg="blue")
# #         self.GPS_coordinates.place(x=10, y=90)
# #         self.language_area = LabelFrame(self.LabelFrame_new, text="Language Area", height=70, width=560, bd=2,
# #                                         bg='gray85', fg="blue")
# #         self.language_area.place(x=10, y=270)
# #         ######################################################################################
# #         ###################################  Label #############################################
# #         ######################################################################################
# #         self.station_Number_label = Label(self.LabelFrame_new, font=("arial", 12, "bold"), bg='gray85',
# #                                           text='Station Number :')
# #         self.station_Number_label.place(x=40, y=15)
# #
# #         self.station_name_label = Label(self.LabelFrame_new, font=("arial", 12, "bold"), bg='gray85',
# #                                         text='Station Name :')
# #         self.station_name_label.place(x=40, y=50)
# #
# #         self.coordinates_X_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg='gray85',
# #                                          text='coordinates_X :')
# #         self.coordinates_X_label.place(x=40, y=10)
# #
# #         self.coordinates_Y_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg='gray85',
# #                                          text='coordinates_Z :')
# #         self.coordinates_Y_label.place(x=40, y=50)
# #
# #         self.coordinates_Z_label = Label(self.GPS_coordinates, font=("arial", 12, "bold"), bg='gray85',
# #                                          text='coordinates_Z :')
# #         self.coordinates_Z_label.place(x=40, y=90)
# #         ######################################################################################
# #         ######################################################################################
# #         ######################################################################################
# #         #####                                 Entry                                       ####
# #         ######################################################################################
# #         ######################################################################################
# #         self.station_Number_new_Entry = tkinter.ttk.Entry(self.LabelFrame_new, font=('arial', 9, 'bold'), width=26)
# #         self.station_Number_new_Entry.place(x=260, y=15)
# #
# #         self.station_name_new_Entry = tkinter.ttk.Entry(self.LabelFrame_new, font=('arial', 9, 'bold'), width=26)
# #         self.station_name_new_Entry.place(x=260, y=50)
# #
# #         self.coordinates_X_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=26)
# #         self.coordinates_X_Entry.place(x=250, y=10)
# #
# #         self.coordinates_y_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=26)
# #         self.coordinates_y_Entry.place(x=250, y=50)
# #
# #         self.coordinates_Z_Entry = tkinter.ttk.Entry(self.GPS_coordinates, font=('arial', 9, 'bold'), width=26)
# #         self.coordinates_Z_Entry.place(x=250, y=90)
# #         ######################################################################################
# #         ######################################################################################
# #         ####                                   combobox                                   ####
# #         ######################################################################################
# #         ######################################################################################
# #         self.language_area_1 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
# #         self.language_area_1.place(x=20, y=20)
# #
# #         self.language_area_2 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
# #         self.language_area_2.place(x=130, y=20)
# #
# #         self.language_area_3 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
# #         self.language_area_3.place(x=240, y=20)
# #
# #         self.language_area_4 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
# #         self.language_area_4.place(x=350, y=20)
# #
# #         self.language_area_5 = tkinter.ttk.Combobox(self.language_area, font=("arial", 10, 'bold'), width=8)
# #         self.language_area_5.place(x=450, y=20)
# #         self.language_area_1_list = {}
# #         self.language_area_1["value"] = self.code_name_xml
# #         # self.language_area_1.bind("<<ComboboxSelected>>", )
# #         self.language_area_2["value"] = self.code_name_xml
# #         # self.language_area_2.bind("<<ComboboxSelected>>", )
# #         self.language_area_3["value"] = self.code_name_xml
# #         # self.language_area_3.bind("<<ComboboxSelected>>", )
# #         self.language_area_4["value"] = self.code_name_xml
# #         # self.language_area_4.bind("<<ComboboxSelected>>", )
# #         self.language_area_5["value"] = self.code_name_xml
# #         # self.language_area_5.bind("<<ComboboxSelected>>", )
# #
# #         ######################################################################################
# #         ######################################################################################
# #         #####                               Button                                       #####
# #         ######################################################################################
# #         ######################################################################################
# #         self.english_play_button = Button(self.new_data, text="SAVE", width=13, font=('arial', 8, 'bold'),
# #                                           bg="cyan", fg="black", cursor='hand2', command=self.count_table)
# #         self.english_play_button.place(x=365, y=430)
# #         self.english_play_button = Button(self.new_data, text="CANCEL", width=13, font=('arial', 8, 'bold'),
# #                                           bg="cyan", fg="black", cursor='hand2')
# #         self.english_play_button.place(x=475, y=430)
# #         #####################################################################################
# #         ######################################################################################
# #         ######################################################################################
# #         self.new_data.mainloop()
# #     def count_table(self):
# #         list_1 = []
# #         list_2 = []
# #         list_1.append(self.language_area_1.get())
# #         list_1.append(self.language_area_2.get())
# #         list_1.append(self.language_area_3.get())
# #         list_1.append(self.language_area_4.get())
# #         list_1.append(self.language_area_5.get())
# #         for i in list_1:
# #             if i == "":
# #                 pr = None
# #             else:
# #                 list_2.append(i)
# #         print(",".join(list_2))
# # if __name__ == "__main__":
# #     MainApplication1()
#
#
# import os
#
# # Get the list of all files and directories
# path = "D:\\abhay\\ab\\sir soft\\New folder"
# dir_list = os.listdir(path)
#
# # print("Files and directories in '", path, "' :")
#
# # prints all files
# # print(dir_list)
# # print(dir_list.index("ST0001EN.MP3.mp3"))
# import tkinter as tk
#
# # Create the main window
# window = tk.Tk()
# window.geometry("300x200")
# window.title("PythonExamples.org")
#
# # Create a variable to hold the selected option
# radio_var = tk.StringVar()
#
# # Create Radiobuttons
# radio_button1 = tk.Radiobutton(window, text="Option 1", variable=radio_var, value="Option 111")
# radio_button2 = tk.Radiobutton(window, text="Option 2", variable=radio_var, value="Option 222")
# radio_button3 = tk.Radiobutton(window, text="Option 3", variable=radio_var, value="Option 333")
#
# # Pack the Radiobuttons
# radio_button1.pack()
# radio_button2.pack()
# radio_button3.pack()
#
# def get_selected_option():
#     selected_option = radio_var.get()
#     print(radio_button1.cget("text"))
#     print(f"Selected option : {selected_option}")
#
# # Button widget
# clear_button = tk.Button(window, text="Get Selected Option", command=get_selected_option)
# clear_button.pack()
#
# # Start the Tkinter event loop
# window.mainloop()


# import mdfreader
# # loads whole mdf file content in yop mdf object.
# yop = mdfreader.Mdf('tts_ims_data.MDF')
# # you can print file content in ipython with a simple:
# print(yop)

# import mdf2sqlite
#
# # Convert the .mdf file to an SQLite database
# mdf_file = 'tts_ims_data.MDF'
# sqlite_database = 'output.sqlite'
#
# mdf2sqlite.convert(mdf_file, sqlite_database)


# import pyodbc
#
# conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
# my_cursor = conn.cursor()
# # sql_query = '''select r.stopOrder,s.shortName, r.stationID from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID=3 order by r.stopOrder'''
# sql_query = "SELECT name ,description FROM messageA"
# my_cursor.execute(sql_query)
# data = my_cursor.fetchall()
# # print(data)
# for i, j in data:
#     print(i, j)
#     b = i[0:2]
#     print(b)
#     if b == "MA":
#         my_cursor.execute("insert into tbl_file values(?,?,?)",
#                           ("MP3", i, j))
#     elif b == "MT":
#         my_cursor.execute("insert into tbl_file values(?,?,?)",
#                           ("TEXT", i, j))
#     elif b == "MV":
#         my_cursor.execute("insert into tbl_file values(?,?,?)",
#                           ("MP4", i, j))
#     elif b == "MB":
#         my_cursor.execute("insert into tbl_file values(?,?,?)",
#                           ("PNG", i, j))
#     elif b == "ML":
#         my_cursor.execute("insert into tbl_file values(?,?,?)",
#                           ("ICO", i, j))
# print(data, len(data))
# for i in range(len(data)):
#     # print(i,j,k)
#     # k = int(i) + 1
#     # print(data[i][2], "aa")
#     if i < len(data)-1:
#         # print(data[i+1][2], "bb", i+1)
#         my_cursor.execute(f"select distance from tbl_stationDistance where stationID1={data[i-1][2]} and stationID2={data[i][2]}")
#         data1 = my_cursor.fetchall()
#         if len(data1) == 0:
#             stop_dis = (data[i][0], data[i][1], "no data")
#             print(stop_dis)
#         else:
#             stop_dis = (data[i][0], data[i][1], data1[0][0])
#             print(stop_dis)
# conn.commit()
# conn.close()
#

# # Define a decorator function
# def frr_decorator(func):
#     def wrapper():
#         print("Before calling the original function")
#         func()
#         print("After calling the original function")
#         func()
#         print("jaa re chu")
#     return wrapper
#
# # Apply the decorator to a function
# @frr_decorator
# def my_function():
#     print("yoo")
#
# # Call the decorated function
# my_function()
#
# a = "MV1114"
# b = a[2:7]
# print(a[0:2])
# print(int(b))

# def ar(*m, **kn):
#     ac = 0
#     for i in kn.values():
#         ac += i
#     print(kn)
#     return ac, sum(m)
#     # print(*m)
#     # return sum(m)
#     # return ac
#
# Spelling mistakes should be fixed to ensure that people are able to understand the meaning being what is being written. The ten most commonly misspelled words are: accommodate, millennium, separate, calendar, argument, definite, cemetery, fluorescent, necessary, and pronunciation.
# print(ar(1, 2, 3, 4, 5, 6, 8, rm=5, rj=5))


# from textblob import TextBlob
#
# a = "Spelling mistekes should be fixed to ensure that peaple are able to undarstand the meanwing being what is being wretten. The ten most commonly misspelled words are: accomodate, millennium, separate, calandar, argument, definite, cemetary, fluorescant, nececsary, and pronsnciation."
#
# new_text = a.split()
# #
# # print(new_text)
# # print("original text: "+str(a))
#
# # b = TextBlob(a)
# #
# # # prints the corrected spelling
# # print("corrected text: "+str(b.correct()))
# list_text = []
# for i in new_text:
#     text1 = TextBlob(i)
#     text2 = str(text1.correct())
#     list_text.append(text2)
#     # print(text1)
# print("my text:- ", " ".join(new_text))
# print("correct text:- ", " ".join(list_text))
# num = [1000, 2, 6, 5, 0, 10, 25, 65, 70]
# a = 0
# for i in num:
#     if a < i:
#         a = i
# print(i)
# print(i for i in num if a < i)


# a = [('MB0038EN.png',), ('MB0038HI.png',), ('MB0038RE.png',)]





# import tkinter as tk
# from tkvideo import tkvideo
# import pygame
# import os
#
#
#
# def get_audio(file):
#     from moviepy.editor import VideoFileClip
#
#     # Load the MP4 file
#     video = VideoFileClip(file + ".mp4")
#
#     # Extract the audio
#     audio = video.audio
#
#     # Save the audio as an MP3 file
#     audio.write_audiofile(file + ".mp3")
#
#
# def start(file):
#     if not file + ".mp3" in os.listdir("."):
#         get_audio(file)
#     pygame.init()
#     pygame.mixer.init()
#     pygame.mixer.music.load(file + ".mp3")
#     root = tk.Tk()
#     # root.geometry("640x480")
#
#     videoPlayer = tk.Label(root)
#     videoPlayer.pack()
#     video = tkvideo(file + ".mp4", videoPlayer, loop=1, size=(640,480))
#     video.play()
#     pygame.mixer.music.play()
#     root.mainloop()
#
#
# start("vid1")






# import cv2
#
# from ffpyplayer.player import MediaPlayer
# file = "vid1.mp4"
#
# video = cv2.VideoCapture(file)
# player = MediaPlayer(file)
# while True:
#    ret, frame = video.read()
#    audio_frame, val = player.get_frame()
#
#    if not ret:
#       print("End of video")
#       break
#    if cv2.waitKey(1) == ord("q"):
#       break
#    cv2.imshow("Video", frame)
#    if val != 'eof' and audio_frame is not None:
#       #audio
#       img, t = audio_frame
# # video.release()
# # cv2.destroyAllWindows()

# language = ["HI", "EN", "MR"]
# language_data = ["A", "B", "C", "D", "E", "F", "G", "H"]
# lenth1 = len(language)
# lenth2 = len(language_data)
# num = 0
# num2 = 0
# def run_lan():
#     global num
#     global num2
#     # print(num2, language_data[num2], language[num])
#     # if language_data[num2] == language_data[-1]:
#     if num < lenth1:
#         if num2 < lenth2:
#             print(num2, language_data[num2], language[num])
#             num2 += 1
#         else:
#             num2 = 0
#             num += 1
#
#     # if language[num] == language[-1]:
#     elif not num < lenth1:
#         # num = 0
#         # num2 = 0
#         # pass
#         print("yoooo")
#
#
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()
# run_lan()


# lan = [('EN,HI,MR',)]
# # lan_fina = None
# for lan_item in lan:
#     lan_data = lan_item[0]
#     lan_final = lan_data.split(",")
# print(lan_final)

# list_1 = ["hi", "en", "mr", "dk"]
# len_data = len(list_1)
# num = 0
# def add_lan():
#     global num
#     if num < len_data:
#         # print("yoo")
#         print(list_1[num])
#         num += 1
#     else:
#         print("no")
#         num = 0
# add_lan()
# add_lan()
# add_lan()
# add_lan()
# add_lan()
# add_lan()
# add_lan()
# add_lan()
# add_lan()


