import tkinter.ttk
from tkinter import *
import shutil
import pyodbc
from tkinter import messagebox
import main
import tkinter as tk
import pygame
from pathlib import Path
from tkinter import filedialog as fd
import xml.etree.ElementTree as ET
import os
import sqlite3
import chardet


# Define the class the application
class MainApplication1:
    # init method or constructor that call by instance variable
    def __init__(self):
        self.station_dict_id_old_id_new = {}
        self.route_id_dict = {}
        self.journey_id_dict = {}
        self.stations_name_Nr = {}
        self.combiTrigger_id = {}
        self.Trigger_id_name = {}
        self.action_ID_name = {}
        self.tbl_messages_old_data = {}
        self.tbl_messageA_dist = {}
        # self.tbl_messageA_distitem_name = {}

        self.tbl_messages()
        # self.station_and_station_name_tbl()
        # self.route_and_stop()
        self.trigger_and_combi()
        # self.jStop_journey_tbl()
    def station_and_station_name_tbl(self): # tbl_station and tbl_stationNames and tbl_stationDistance
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_station order by stationID''')
        stn_left_table = my_cursor.fetchall()
        station_id_sql = 0
        for station_data in stn_left_table:
            # print("\n")
            station_id_sql += 1
            len_station_id = 4 - len(str(station_id_sql))
            stationNr_new = "ST"+"0"*len_station_id+str(station_id_sql)
            stationID, stationNr, GPSPosX, GPSPosY, GPSPosZ, shortName, isStopArea, defaultLanguageArea, isLanguageBorder = station_data[0], station_data[1], station_data[2], station_data[3], station_data[4], station_data[5], station_data[6], station_data[7], station_data[8]
            # print(shortName, station_id_sql, type(int(GPSPosX)), GPSPosY, GPSPosZ, stationNr_new, defaultLanguageArea, type(isStopArea), 0 if not isLanguageBorder else isLanguageBorder)  # tbl_station
            save_tbl_station = shortName, station_id_sql, GPSPosX, GPSPosY, GPSPosZ, stationNr_new, defaultLanguageArea, isStopArea, 0 if not isLanguageBorder else isLanguageBorder

            # print(save_tbl_station)
            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f"insert into tbl_station values(?,?,?,?,?,?,?,?,?)", (shortName, station_id_sql, int(GPSPosX) if GPSPosX else 0, int(GPSPosY) if GPSPosY else 0, int(GPSPosZ) if GPSPosZ else 0, stationNr_new, defaultLanguageArea, 1 if isStopArea else 0, 0 if not isLanguageBorder else 0))
            conn_sqlite.commit()
            # conn_sqlite.close()

            my_cursor.execute(f'''select * from tbl_stationNames where stationID={stationID}''')
            station_name = my_cursor.fetchall()
            self.station_dict_id_old_id_new[stationID] = station_id_sql
            self.stations_name_Nr[stationID] = (stationNr, shortName.replace("\xa0", " "), station_id_sql)
            language_num = 0
            for station_language in station_name:
                language_num += 1
                stationID_name, ISOlang, stationName, stationNameShort, stationNameAudio, mainLanguage = station_language[0], station_language[1], station_language[2], station_language[3], station_language[4], station_language[5]
                stationNameAudio_new = stationNr_new+ISOlang+".MP3"
                try:
                  # shutil.copyfile(f'C:\\Users\\PTCS1\\Desktop\\tims folder\\Ayodhya route MEMU\\VCSAUDIO\\STATIONS\\{stationNameAudio}', f'sqlData/audio/{stationNameAudio_new}')
                  shutil.copyfile(f'C:\\Users\\PTCS1\\Desktop\\sql new folder_ankit _sqlite\\tims_data\\GP194\\VCSAUDIO\\STATIONS\\{stationNameAudio}', f'sqlData/audio/{stationNameAudio_new}')
                except FileNotFoundError:
                    # print(stationNameAudio)
                    # print("\n")
                    pass
                save_station_name = station_id_sql, ISOlang, stationName, stationNameShort, stationNameAudio_new, language_num
                # conn_sqlite = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn_sqlite.cursor()
                my_cursor_sqlite.execute(f"insert into tbl_stationNames values(?,?,?,?,?,?)", (
                    station_id_sql, ISOlang, stationName, stationNameShort, stationNameAudio_new, language_num))
                conn_sqlite.commit()
                # print(station_id_sql, ISOlang, stationName, stationNameShort, stationNameAudio_new, language_num)
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_stationDistance''')
        distance_station = my_cursor.fetchall()
        for stationID1, stationID2, distance in distance_station:
            save_tbl_stationDistance = self.station_dict_id_old_id_new[stationID1], self.station_dict_id_old_id_new[stationID2], distance
            # print("\n", self.station_dict_id_old_id_new[stationID1], self.station_dict_id_old_id_new[stationID2], distance)
            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            # print(self.station_dict_id_old_id_new[stationID1], self.station_dict_id_old_id_new[stationID2], distance)
            my_cursor_sqlite.execute(f"insert into tbl_stationDistance values(?,?,?)", (
                self.station_dict_id_old_id_new[stationID1], self.station_dict_id_old_id_new[stationID2], distance if distance else 0.0))
            conn_sqlite.commit()


    def route_and_stop(self): # tbl_routes and tbl_routeStops
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_routes order by routeID''')
        tbl_routes = my_cursor.fetchall()
        num_route_id = 0
        for routeID, routeName in tbl_routes:
            num_route_id += 1
            self.route_id_dict[routeID] = num_route_id
            # print("\n")
            # print(num_route_id, routeName)
            save_tbl_routes = num_route_id, routeName

            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f"insert into tbl_routes values({num_route_id},'{routeName}')")
            conn_sqlite.commit()

            my_cursor.execute(f'''select * from tbl_routeStops where routeID={routeID} order by stopOrder''')
            tbl_routes_stop = my_cursor.fetchall()
            for tbl_routes_stop_data in tbl_routes_stop:
                routeID, routeStopID, stopOrder, stationID, distanceFromPrev, isVia = tbl_routes_stop_data[0], tbl_routes_stop_data[1], tbl_routes_stop_data[2], tbl_routes_stop_data[3], tbl_routes_stop_data[4], tbl_routes_stop_data[5]
                # print(num_route_id, routeStopID, stopOrder, self.station_dict_id_old_id_new[stationID], 0 if not distanceFromPrev else distanceFromPrev)
                save_tbl_routeStops = num_route_id, routeStopID, stopOrder, self.station_dict_id_old_id_new[stationID], 0 if not distanceFromPrev else distanceFromPrev

                conn_sqlite = sqlite3.connect("triggers_abhay.db")
                my_cursor_sqlite = conn_sqlite.cursor()
                my_cursor_sqlite.execute(f"insert into tbl_routeStops values(?,?,?,?,?)", (num_route_id, routeStopID, stopOrder, self.station_dict_id_old_id_new[stationID], 0 if not distanceFromPrev else distanceFromPrev))
                conn_sqlite.commit()


    def jStop_journey_tbl(self): # tbl_journey and tbl_journeyStops
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_journeys order by journeyID''')
        tbl_journey = my_cursor.fetchall()
        journey_id_num = 0
        # print(self.stations_name_Nr)
        for journeyID, routeID, journeyName, conditional, relation, serviceType, totalCars, handicapCar in tbl_journey:
            # print("\n")
            journey_id_num += 1
            self.journey_id_dict[journeyID] = journey_id_num

            save_data_journey = journey_id_num, self.route_id_dict[routeID], journeyName, "-None-" if not conditional else conditional, relation if relation else "", serviceType, totalCars, 0 if not handicapCar else handicapCar
            print(save_data_journey, handicapCar)
            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)', (journey_id_num, self.route_id_dict[routeID], journeyName, "-None-" if not conditional else conditional, relation if relation else "", serviceType if serviceType else 'Slow', totalCars if totalCars else 0, 0 if not handicapCar else handicapCar))
            conn_sqlite.commit()


        tbl_journeys_name_1 = {}

        my_cursor.execute("select journeyID,[routeID] from tbl_journeys order by [routeID]")
        tbl_journeys = my_cursor.fetchall()

        for journeyID1, journeyName in tbl_journeys:
            tbl_journeys_name_1[journeyName] = journeyID1

        my_cursor.execute(f"SELECT * FROM tbl_routes order by routeID")
        tbl_route = my_cursor.fetchall()
        for routeID, routeName in tbl_route:
            my_cursor.execute(
                f"select [routeID],[routeStopID],[stopOrder],[stationID] from tbl_routeStops where routeID={routeID} order by routeID, stopOrder")
            data_tbl_routeStops = my_cursor.fetchall()
            forward_list_1 = []
            if_num_2 = 0
            num_order = 1
            for routeID_1, routeStopID, stopOrder, stationID in data_tbl_routeStops:
                try:
                    tbl_journeys_name_1[routeID_1]
                except KeyError:
                    continue
                my_cursor.execute(f"select journeyID,[routeID] from tbl_journeys where routeID={routeID_1}")
                j_stop_data_item_all = my_cursor.fetchall()

                for journey_id_new, route_id_new in j_stop_data_item_all:
                    my_cursor.execute(
                        f"select * from tbl_journeyStops where journeyID={journey_id_new} and routeStopID={routeStopID}")
                    # data_tbl_routeStops = my_cursor.fetchall()
                    j_stop_data = my_cursor.fetchall()
                    my_cursor.execute(f"select [shortName] from [tbl_station] where [stationID]={stationID}")
                    data_station = my_cursor.fetchall()
                    # print(j_stop_data, "ffffff")
                    if not j_stop_data:
                        continue

                    journeyID2, routeStopID, arrivalTime, departureTime, platformNum, conditional, combiTriggerID, languageArea = \
                        j_stop_data[0][0], j_stop_data[0][1], j_stop_data[0][2], j_stop_data[0][3], j_stop_data[0][4], \
                        j_stop_data[0][5], j_stop_data[0][6], j_stop_data[0][7]
                    # get_j_stop = self.journey_id_dict[journeyID2], routeStopID
                    # get_j_stop = self.journey_id_dict[self.journey_id_dict[journeyID2]], routeStopID
                    my_cursor.execute(
                        f'''select [stationID] from tbl_routeStops where [routeID]={routeID} and [routeStopID] = {routeStopID}''')
                    station_name_Nr1 = my_cursor.fetchall()
                    # print(station_name_Nr)
                    name_and_nr = self.stations_name_Nr[station_name_Nr1[0][0]]
                    # journey_stop_data = journeyID2, routeStopID, name_and_nr[0], name_and_nr[1], "00:00" if not arrivalTime else arrivalTime, "00:00" if not departureTime else departureTime, "-None-" if not conditional else conditional, "" if not platformNum else platformNum, self.combiTrigger_id[combiTriggerID][0], languageArea, self.combiTrigger_id[combiTriggerID][1]
                    # print(journey_stop_data)
                    conn_sqlite = sqlite3.connect("triggers_abhay.db")
                    my_cursor_sqlite = conn_sqlite.cursor()
                    try:
                        combiTrigger_id_new = self.combiTrigger_id[combiTriggerID][1]
                        combiTrigger_id_new_2 = self.combiTrigger_id[combiTriggerID][0]
                    except KeyError:
                        combiTrigger_id_new = " "
                        combiTrigger_id_new_2 = " "
                    print(self.journey_id_dict[journeyID2], num_order,
                          name_and_nr[0].replace(" ", "") if name_and_nr[0] else "", name_and_nr[1],
                          "00:00" if not arrivalTime else arrivalTime, "00:00" if not departureTime else departureTime,
                          "-None-" if not conditional else conditional, "" if not platformNum else platformNum,
                          combiTrigger_id_new, languageArea, combiTrigger_id_new_2)

                    my_cursor_sqlite.execute(f"insert into tbl_journeyStops values(?,?,?,?,?,?,?,?,?,?,?)", (
                        self.journey_id_dict[journeyID2], num_order,
                        name_and_nr[0].replace(" ", "") if name_and_nr[0] else "", name_and_nr[1],
                        "00:00" if not arrivalTime else arrivalTime, "00:00" if not departureTime else departureTime,
                        "-None-" if not conditional else conditional, "" if not platformNum else platformNum,
                        combiTrigger_id_new, languageArea if languageArea else "", combiTrigger_id_new_2))
                    conn_sqlite.commit()
                num_order += 1

    def trigger_and_combi(self): # tbl_combiTrigger and tbl_combiTriggerItems and tbl_combiAction and tbl_trigger
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_combiTrigger order by combiTriggerID''')
        tbl_combiTrigger_data = my_cursor.fetchall()
        combiTriggerID_num = 0
        for combiTriggerID, combiTriggerName in tbl_combiTrigger_data:
            # print("\n")
            combiTriggerID_num += 1
            self.combiTrigger_id[combiTriggerID] = combiTriggerID_num, combiTriggerName
            save_tbl_combiTrigger = combiTriggerID_num, combiTriggerName
            # print(save_tbl_combiTrigger)
            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f"insert into tbl_combiTrigger values({combiTriggerID_num},'{combiTriggerName}')")
            conn_sqlite.commit()


#########################  tbl_combiAction   ##########################
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_combiAction order by combiActionID''')
        tbl_combiAction_data = my_cursor.fetchall()
        # combiAction_ID_num1 = 0
        for combiActionID, combiActionName in tbl_combiAction_data:
            if combiActionID == -1:
                continue
            # combiAction_ID_num1 += 1
            save_tbl_combiAction = combiActionID, combiActionName
            # print(save_tbl_combiAction)
            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f"insert into do_this_combi values(?,?)",
                                     (combiActionID, combiActionName))
            conn_sqlite.commit()


  #####################   tbl_trigger   ############
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_trigger order by triggerID''')
        tbl_trigger_data = my_cursor.fetchall()
        # trigger_ID_num = 0
        for triggerID, triggerName, eventType, triggerPrio, eventValue, conditional, combiActionID in tbl_trigger_data:
            # trigger_ID_num += 1
            # print(type(eventValue))
            self.Trigger_id_name[triggerID] = triggerName

            new_eventValue = eventValue
            if eventValue:
                new_eventValue = eventValue.replace("[", "[if")
            save_tbl_trigger = triggerID, triggerName, eventType, triggerPrio, new_eventValue, conditional, combiActionID
            # print(save_tbl_trigger)

            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f"insert into tbl_trigger values(?,?,?,?,?,?,?)", (
                triggerID, triggerName, eventType if eventType else "", triggerPrio, new_eventValue if new_eventValue else "", conditional if conditional else "", combiActionID if combiActionID else ""))
            conn_sqlite.commit()

            # break

        my_cursor.execute(f'''select * from tbl_combiTriggerItems order by [combiTriggerID], [triggerOrder]''')
        tbl_combiTriggerItems_data = my_cursor.fetchall()
        for combiTrigger_ID1, triggerID, triggerOrder in tbl_combiTriggerItems_data:
            save_tbl_combiTrigger_Items = self.combiTrigger_id[combiTrigger_ID1][0], self.Trigger_id_name[triggerID], triggerID, triggerOrder
            # print(save_tbl_combiTrigger_Items, "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh")
            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f"insert into tbl_combiTriggerItems values(?,?,?)", (self.combiTrigger_id[combiTrigger_ID1][0], self.Trigger_id_name[triggerID], triggerID))
            conn_sqlite.commit()

        my_cursor.execute(f'''select * from tbl_action order by actionID''')
        tbl_tbl_action_data = my_cursor.fetchall()
        for actionID, actionName, messageDescription, resourceID, flushResource in tbl_tbl_action_data:
            if actionID == -1:
                continue
            self.action_ID_name[actionID] = (actionName, resourceID)
            # print(messageDescription)
            if messageDescription:
                messageDescription_change = messageDescription.replace("{", "?").replace("}", "&").replace("[", "{").replace("]", "}").replace("?", "[").replace("&", "]")
                num = len(messageDescription_change) - 1
                index_num = 0
                # print(messageDescription_change)
                for i in messageDescription_change[-1::-1]:
                    if i == "]":
                        index_num = num
                    elif i == "[":
                        # print(messageDescription_change[num + 1:index_num], self.tbl_messages_old_data[messageDescription_change[num + 1:index_num]], "kkkkkk")
                        try:
                            messageDescription_change = messageDescription_change.replace(
                                messageDescription_change[num + 1:index_num],
                                self.tbl_messages_old_data[messageDescription_change[num + 1:index_num]])
                        except KeyError:
                            print(f"{messageDescription_change[num + 1:index_num]} File is Not in Data")
                    num -= 1
            else:
                messageDescription_change = messageDescription

            print(self.tbl_messages_old_data, "11111")
            save_tbl_combiActionItems_Items = actionID, actionName, messageDescription_change, resourceID
            # print(save_tbl_combiActionItems_Items)
            # print(actionID, actionName, messageDescription_change, resourceID)
            flush = 0
            if flushResource == "True":
                flush = 1


            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f"insert into tbl_action values(?,?,?,?,?)", (actionID, actionName, messageDescription_change if messageDescription_change else "", resourceID, flush))
            conn_sqlite.commit()


        my_cursor.execute(f'''select * from [tbl_combiActionItems] order by combiActionID ,actionOrder''')
        # my_cursor.execute(f'''select * from [tbl_combiActionItems]''')
        tbl_combiActionItems_data = my_cursor.fetchall()
        old = 0
        num = 1
        for combiActionID, actionID, actionOrder, actionDelay, actionRepetitionCount, actionRepetitionInterval, intervalUnit in tbl_combiActionItems_data:
            if combiActionID == -1:
                continue

            new_num = combiActionID
            if old != new_num:
                old = new_num
                num = 1
            actionID_id_name = self.action_ID_name[actionID]
            save_tbl_combiActionItems_Items = combiActionID, actionID_id_name[0], actionDelay if actionDelay else 0, 0 if not actionRepetitionCount else actionRepetitionCount.replace(" ", ""), 0 if not actionRepetitionInterval else actionRepetitionInterval, "second(s)" if not intervalUnit else intervalUnit, actionOrder, 0, actionID, actionID_id_name[1]
            # print(save_tbl_combiActionItems_Items)

            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute(f"insert into do_this_combi_item values(?,?,?,?,?,?,?,?,?,?)", (
                combiActionID, actionID_id_name[0], actionDelay if actionDelay else 0, 0 if not actionRepetitionCount else actionRepetitionCount.replace(" ", ""), 0 if not actionRepetitionInterval else actionRepetitionInterval, "second(s)" if not intervalUnit else intervalUnit, num, 0, actionID, actionID_id_name[1]))
            conn_sqlite.commit()
            num += 1

    def tbl_messages(self): # tbl_messages
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_messages order by [name]''')
        tbl_messages_data = my_cursor.fetchall()
        messages_data_num = 0
        dict_n = {}
        for item_name, description in tbl_messages_data:
            if item_name[:2] in dict_n.keys():
                num = dict_n[item_name[:2]] + 1
                dict_n[item_name[:2]] = num
                num_len = 4 - len(str(num))

            else:
                dict_n[item_name[:2]] = 1
                num = 1
                num_len = 4 - len(str(num))
            save_file_name = f"{item_name[:2]}{'0' * num_len}{num}", description
            self.tbl_messages_old_data[item_name] = f"{item_name[:2]}{'0' * num_len}{num}"
            print(save_file_name)

            conn_sqlite = sqlite3.connect("triggers_abhay.db")
            my_cursor_sqlite = conn_sqlite.cursor()
            my_cursor_sqlite.execute("insert into [messageA] values(?,?)", (
                f"{item_name[:2]}{'0' * num_len}{num}", description))
            conn_sqlite.commit()

            # print(item_name, f"{item_name[:2]}{'0' * num_len}{num},        oooooooooooooooooooooooooo")
            # self.tbl_messageA_dist[item_name] = f"{item_name[:2]}{'0' * num_len}{num}"


        print(self.tbl_messages_old_data, "222222")
        # print(self.tbl_messages_old_data)

        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from tbl_file order by fileName''')
        tbl_file_data = my_cursor.fetchall()
        # print(self.tbl_messages_old_data)
        # print("\n")
        for fileExtension, fileName, fileDescription in tbl_file_data:
            if fileName[:2] == "ST":
                continue
            else:
                if fileName in self.tbl_messages_old_data:
                    save_tbl_file_data = fileExtension.replace(" ", ""), self.tbl_messages_old_data[fileName], fileDescription, fileName
                    print(self.tbl_messages_old_data[fileName], fileName)

                    conn_sqlite = sqlite3.connect("triggers_abhay.db")
                    my_cursor_sqlite = conn_sqlite.cursor()
                    my_cursor_sqlite.execute("insert into tbl_file values(?,?,?)", (
                        fileExtension.replace(" ", ""), self.tbl_messages_old_data[fileName], fileDescription))
                    conn_sqlite.commit()

            # messages_data_num += 1
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=GP194;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select * from [tbl_fileImport] order by fullFileName''')
        tbl_fileImport_data = my_cursor.fetchall()
        num = 0
        for fullFileName, bAdd, bDelete in tbl_fileImport_data:
            num += 1
            if fullFileName[:2] == "ST":
                continue
            else:
                if fullFileName[:6] in self.tbl_messages_old_data:
                    save_tbl_fileImport_data = self.tbl_messages_old_data[fullFileName[:6]], self.tbl_messages_old_data[fullFileName[:6]]+fullFileName[6:], fullFileName
                    if fullFileName[-3:] == "MP3":
                        try:
                            # shutil.copyfile(
                            #     f'C:\\Users\\PTCS1\\Desktop\\tims folder\\Ayodhya route MEMU\\VCSAUDIO\\MESSAGES\\{fullFileName}',
                            #     f'sqlData/audio/{self.tbl_messages_old_data[fullFileName[:6]] + fullFileName[6:]}')

                            shutil.copyfile(
                                f'C:\\Users\\PTCS1\\Desktop\\sql new folder_ankit _sqlite\\tims_data\\GP194\\VCSAUDIO\\MESSAGES\\{fullFileName}',
                                f'sqlData/audio/{self.tbl_messages_old_data[fullFileName[:6]]+fullFileName[6:]}')
                        except FileNotFoundError:
                            pass
                            # print(fullFileName)
                    elif fullFileName[-3:] == "TXT":
                        try:
                            file_path = f'C:\\Users\\PTCS1\\Desktop\\sql new folder_ankit _sqlite\\tims_data\\GP194\\VCSTEXT\\MESSAGES\\{fullFileName}'
                            encoding = self.detect_encoding(file_path)
                            ap = open(file=file_path, encoding=encoding)
                            # print(ap.read())
                            # print(f"{fullFileName},111 kkkkkkkkkkkkkkkkkkkkkk")
                            # print(f"{self.tbl_messages_old_data[fullFileName[:6]]+fullFileName[6:]}, 222 kkkkkkkkkkkkkkkkkkkkkk")
                            file_read_data = ap.read()
                            ap.close()
                            file_create = open(f"sqlData/txt/{self.tbl_messages_old_data[fullFileName[:6]]+fullFileName[6:]}", "a", encoding='utf-8')
                            # print(f"{file_read_data}")
                            file_create.truncate(0)
                            file_create.write(f"{file_read_data}")
                            file_create.close()
                            # shutil.copyfile(
                            #     f'C:\\Users\\PTCS1\\Desktop\\tims folder\\1. GP194_CR_040302024\\data\\VCSTEXT\\MESSAGES\\{fullFileName}',
                            #     f'sqlData/txt/{self.tbl_messages_old_data[fullFileName[:6]]+fullFileName[6:]}')
                        except FileNotFoundError:
                            pass
                            # print(fullFileName)

                    # print(save_tbl_fileImport_data, num)
                    conn_sqlite = sqlite3.connect("triggers_abhay.db")
                    my_cursor_sqlite = conn_sqlite.cursor()
                    my_cursor_sqlite.execute(f"insert into fileImport (FullFileName, messageName) values('{self.tbl_messages_old_data[fullFileName[:6]]}','{self.tbl_messages_old_data[fullFileName[:6]]+fullFileName[6:]}')")
                    conn_sqlite.commit()

    def detect_encoding(self, file_path):
        with open(file_path, 'rb') as file:
            detector = chardet.universaldetector.UniversalDetector()
            for line in file:
                detector.feed(line)
                if detector.done:
                    break
            detector.close()
        return detector.result['encoding']
    def on_exit(self):
        self.top.destroy()
        # main.MainApplication()


if __name__ == "__main__":
    MainApplication1()
