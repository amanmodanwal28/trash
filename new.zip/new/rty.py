from sdfrty import one

class three:
    def four(self):
        obj = one()
        obj.test()
        
obj = three()
obj.four()