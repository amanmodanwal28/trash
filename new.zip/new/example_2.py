import socket
import struct
MCAST_GRP = '224.0.0.1'
MCAST_PORT = 8000
IP='192.168.0.8'

# try:
#     s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#     s.connect(('8.8.8.8', 1))
#     IP = s.getsockname()[0]
#     print(IP)
#     s.close()
#
# except:
#     print("Could not get IP")
#     s.close()
#
# try:
#     udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
#     udp_socket.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
#     udp_socket.sendto(IP, (MCAST_GRP, MCAST_PORT))
#     udp_socket.close()
#     print("Multicast Message sent.")
#
# except:
#     print("Message not sent")
#     udp_socket.close()

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
# sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, True)
sock.bind(("", 8000))
# sock.sendto("hello world", ("255.255.255.255", 1337))
while True:
    data, addr = sock.recvfrom(0x100)
    print("received from {0}: {1!r}".format(addr, data))
