
# from distutils.core import setup
# import py2exe
# from tkinter import *
#
# setup(console=['gui.py'])
# ab = Tk()
# mainloop()
import socket_connection_file
print(socket.gethostname())