# test_dict = {'Gfg': 1, 'is': 12, 'best': 3, 'for': 14, 'geeks': 5}
#
# # printing original dictionary
# print("The original dictionary is : " + str(test_dict))
# # l = {1: "q", 3: "a", "eee": 'r', 5: 'rf'}
# # initializing swap indices
# i = 1
# j = i+1
# # conversion to tuples
# tups = list(test_dict.items())
# location = tups.index(("is", 12))
# tups.insert(1, (33, "rrr"))
# location1 = tups.index(("is", 12))
# tups.insert(3, (333, "/rrr"))
#
# print(location1)
#
# test_dict.clear()
# # print(tups)
# # tups = []
# for i in tups:
#     test_dict[i[0]] = i[1]
#     print(test_dict)
    # print(i[0])
    # print(i[1])

# print(tups, "333333333333")
# swapping by indices
# tups[i], tups[j] = tups[j], tups[i]
# # tups[i] = tups[j]
# print(tups, "333333333333")
# # converting back
# res = dict(tups)
# test_dict.clear()
# test_dict = dict(tups)
# # printing result
# print("The swapped dictionary : ", test_dict)
#
#
#
#
# # Python3 code to demonstrate working of
# # Key index in Dictionary
# # Using list comprehension + enumerate()
#
# # initializing dictionary
# test_dict = {'all' : 1, 'food' : 2, 'good' : 3, 'have' : 4}
#
# # initializing search key string
# search_key = 'good'
#
# # printing original dictionary
# print("The original dictionary is : " + str(test_dict))
#
# # Using list comprehension + enumerate()
# # Key index in Dictionary
# temp = list(test_dict.items())
# res = [idx for idx, key in enumerate(temp) if key[0] == search_key]
#
# # printing result
# print("Index of search key is : " + str(res))
# from tkinter import *
# y = 1
# # global y
# ab = Tk()
# def change():
#     global y
#     if y == 1:
#         but.config(bg="yellow")
#         y = 0
#     else:
#         but.config(bg="red")
#         y = 1
#
# but = Button(ab, text="rrrrr", bg="red", command=change)
# but.pack()
#
# ab.mainloop()

# l = {1: "q", 3: "a", "eee": 'r', 5: 'rf'}
# l[4] = "gggg"
# # for i in l:
#     # print(i)
# # print(len(l))
# print(l)
# ind = list(l).index("eee")
# print(ind)


# test_dict = {'all': 1, 'food': 2, 'good': 3, 'have': 4}
# test_dict["all"], test_dict["food"] = test_dict["food"], test_dict["all"]
# print(test_dict)
# l = [1, 2, 3, 4, 5]
# l.insert(0, "a")
# print(l)
# l = list(test_dict.items())
# print(l)
# l[0], l[1] = l[1], l[0]
# test_dict.clear()
# for i in l:
#     test_dict[i[0]] = i[1]
# test_dict1 = dict(l)
# print(test_dict1)
# s = "<text>,</text>"
# print(s.find("<"))
# k = s.split(",")
# print(k)


# a = '4D4130303634454E2E4D5033'
# decoded_string = bytes.fromhex(a).decode('utf-8')
# print(decoded_string)


# file_name = 'MA0004MR.MP3'
# hex_string = file_name.encode('utf-8').hex().upper()
# print(hex_string)
# # print('4D4130303032454E2E4D5033')


# a = [('MA0001EN.MP3',), ('MA0001HI.MP3',), ('MA0001MR.MP3',),('MA0002MR.MP3',)]
# language_count = {'EN': 0, 'HI': 0, 'MR': 0}  # Initialize a dictionary to store the count of each language

# # Iterate through the list and count the occurrences of each language
# for item in a:
#     for language in language_count:
#         if language in item[0]:
#             language_count[language] += 1

# print(language_count)



# a = [('MA0002HI.MP3',)]

# len_code = len(a)
# if len_code == 3:
#     output = [file[0][6:-4] for file in a]
#     formatted_output = '[' + ', '.join(output) + ']'
#     print(formatted_output,'888888')
# elif len_code == 2:
#     native_value = a[0][0][6:8]
#     output = [file[0][6:-4] for file in a]
#     output.insert(2, native_value)
#     formatted_output = '[' + ', '.join(output) + ']'
#     print(formatted_output,'999')
# else:
#     output = [file[0][6:-4] for file in a]
#     output = [output[0]] * 3
#     formatted_output = '[' + ', '.join(output) +']'
#     print(formatted_output,'777')



# import glob
# # files = glob.glob(f"MT000***.TXT")
# # print(files)
# import re
# xml_l = ["EN", "HI", "MR", "**"]
# # a = "[MT0001][MA0003]"
# a = "<hi>[MT0001][MA0003]</hi>"
# lis = []
# if a.count("<hi>"):
#     lis.append("HI")
#     lis.append("HI")
#     lis.append("HI")
# else:
#     for item in xml_l:
#         lis.append(item)
# for item2 in lis:
#     name = re.findall(r"\[([A-Z0-9]+)\]", a)
#     final_data = ""
#     for item3 in name:
#         if item3[:2:] == "MT":
#             # print(f"{item3}{item2}.TXT")
#             files = glob.glob(f"{item3}{item2}.TXT")
#             # print(files)
#             if len(files) ==1:
#                 final_data = final_data+f'0TTTTTTTTT0{item2}'
#         elif item3[:2:] == "MA":
#             files = glob.glob(f"{item3}{item2}.MP3")
#             if len(files) == 1:
#                 final_data = final_data + f'0AAAAAAAAA0{item2}'
#     print(final_data)



# a = [('MA0002HI.MP3',)]
# len_code = len(a)
# if len_code == 3:
#     output = [file[0][6:-4] for file in a]
#     formatted_output = '[' + ', '.join(output) + ']'
#     print(formatted_output,'888888')
# elif len_code == 2:
#     native_value = a[0][0][6:8]
#     output = [file[0][6:-4] for file in a]
#     output.insert(2, native_value)
#     formatted_output = '[' + ', '.join(output) + ']'
#     print(formatted_output,'999')
# else:
#     output = [file[0][6:-4] for file in a]
#     output = [output[0]] * 3
#     formatted_output = '[' + ', '.join(output) +']'
#     print(formatted_output,'777')


# a = '<field02>[MT0005]{MA0006}</field02><hi><field01>[MT0007]</field01></hi>'


# # import re

# # text = a
# # pattern = r'[\[<{][^\[<{]*?[\]\}>]'

# # matches = re.findall(pattern, text)
# # for i in matches:
# #    print(i[1:-1:])
# print(a.count("hi44"))

# a = [1,2,3,4]
# b = a
# b.append(000)
# print(a)



# import xml.etree.ElementTree as ET
# my_tr1 = ET.parse("projectinfo.xml")
# root1 = my_tr1.getroot()
# list_lang = []
# for i in root1.findall("markupCode"):
#     it = i.find("group").text
#     if it == "3":
#         it2 = i.find("name").text
#         print(it2)
#         list_lang.append(it2)
# tag = '<field02>[MT0005]{MA0006}</field02><hi><field01>{current_station}</field01></hi>'
# # tag = '[language_id]{current_station}{Next_station}'
# list_item = []
# text = ''
# for i in list_lang:
#     pass
# for i in tag:
#     if i.isalpha() or i.isalnum() or i==' ' or i == '_' or i == '/':
#         text = text+i
#     else:
#         if i =='>' or  i == '}' or i == ']':
#             list_item.append(text)
#             text = ''
# # print(list_item)
# field_name = 'field00'
# new_list = []
# for tag_item in list_item:
#     if tag_item[:3:] == 'fie':
#         field_name = tag_item
#     elif tag_item[:3:] == '/fi':
#         field_name = 'field00'
#     else:
#         new_list.append(tag_item)
#         new_list.append(field_name)
# print(new_list)


# import xml.etree.ElementTree as ET
# import pyodbc
# my_tr1 = ET.parse("projectinfo.xml")
# root1 = my_tr1.getroot()
# list_lang = []
# for i in root1.findall("markupCode"):
#     it = i.find("group").text
#     if it == "3":
#         it2 = i.find("name").text
#         if it2 != "**":
#             # print(it2)
#             list_lang.append(it2)
            
            
# conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
# my_cursor = conn.cursor()
# my_cursor.execute(f"SELECT  [message_Description] , [action_ID] FROM [tbl_action] order by [action_ID]")
# message_description = my_cursor.fetchall()
# conn.commit()
# conn.close()
# for tag in message_description:
#     list_item = []
#     list_lang_new = []
#     text = ''
#     for i in tag[0]:
#         if i.isalpha() or i.isalnum() or i == ' ' or i == '_' or i == '/':
#             text = text+i
#         else:
#             if i == '>' or i == '}' or i == ']':
#                 list_item.append(text)
#                 text = ''
#     # print(list_item)
#     for i in list_lang:
#         if tag[0].count(f'</{i}>'):
#             list_lang_new.clear()
#             for j in range(len(list_lang)):
#                 list_lang_new.append(i)
#             break
#         else:
#             list_lang_new.append(i)
#     # print(list_item)
#     field_name = 'field00'
#     number_of_segement = 0
#     for language_data in list_lang_new:
#         new_list = []
#         for tag_item in list_item:
#             if tag_item[:3:] == 'fie':
#                 field_name = tag_item
#             elif tag_item[:3:] == '/fi':
#                 field_name = 'field00'
#             elif tag_item == language_data or tag_item == f'/{language_data}':
#                 pass
#             else:
#                 if tag_item[:2:] == 'MT':
#                     text_item = open(f"sqlData/txt/{tag_item}{language_data.upper()}.TXT", "r", encoding="utf-8")
#                     content = text_item.read()
#                     content_hex = decoded_string = content.encode('utf-8').hex().upper()
#                     hex_value_size = int(len(content))
#                     hex_length = format(int(hex_value_size), '02X')
#                     # print(hex, content_hex)
#                     new_list.append('02')
#                     new_list.append(hex_length)
#                     new_list.append(content_hex)
                    
#                     my_tr = ET.parse("projectinfo.xml")
#                     root = my_tr.getroot()
#                     for i in root.findall("markupCode"):
#                         it = i.find("name").text
#                         if it == field_name:
#                             mask_xml = i.find("mask").text
#                             hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
#                             new_list.append(hex_value_journeystops_condition)
                            
#                 elif tag_item[:2:] == "MA": 
#                     content = f"{tag_item}{language_data.upper()}.MP3"
#                     content_length = (len(content))
#                     hex_length= format(int(content_length), '02X')
#                     hex_value_journeystops_condition = f"{content.encode('utf-8').hex().upper()}"
#                     new_list.append('00')
#                     new_list.append(hex_length)
#                     new_list.append(hex_value_journeystops_condition)
                    
#                 elif tag_item[:2:] == "MV": 
#                     content = f"{tag_item}{language_data.upper()}.MP4"
#                     content_length = (len(content))
#                     hex_length= format(int(content_length), '02X')
#                     hex_value_journeystops_condition = f"{content.encode('utf-8').hex().upper()}"
#                     new_list.append('03')
#                     new_list.append(hex_length)
#                     new_list.append(hex_value_journeystops_condition)
                    
#                     my_tr = ET.parse("projectinfo.xml")
#                     root = my_tr.getroot()
#                     for i in root.findall("markupCode"):
#                         it = i.find("name").text
#                         if it == field_name:
#                             mask_xml = i.find("mask").text
#                             hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
#                             new_list.append(hex_value_journeystops_condition)
                
#                 elif tag_item[:2:] == "ML": 
#                     content = f"{tag_item}{language_data.upper()}.ICO"
#                     content_length = (len(content))
#                     hex_length= format(int(content_length), '02X')
#                     hex_value_journeystops_condition = f"{content.encode('utf-8').hex().upper()}"
#                     new_list.append('03')
#                     new_list.append(hex_length)
#                     new_list.append(hex_value_journeystops_condition)
                    
#                     my_tr = ET.parse("projectinfo.xml")
#                     root = my_tr.getroot()
#                     for i in root.findall("markupCode"):
#                         it = i.find("name").text
#                         if it == field_name:
#                             mask_xml = i.find("mask").text
#                             hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
#                             new_list.append(hex_value_journeystops_condition)
                    
#                 elif tag_item[:2:] == "MB": 
#                     content = f"{tag_item}{language_data.upper()}.PNG"
#                     content_length = (len(content))
#                     hex_length= format(int(content_length), '02X')
#                     hex_value_journeystops_condition = f"{content.encode('utf-8').hex().upper()}"
#                     new_list.append('03')
#                     new_list.append(hex_length)
#                     new_list.append(hex_value_journeystops_condition)
                    
#                     my_tr = ET.parse("projectinfo.xml")
#                     root = my_tr.getroot()
#                     for i in root.findall("markupCode"):
#                         it = i.find("name").text
#                         if it == field_name:
#                             mask_xml = i.find("mask").text
#                             hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
#                             new_list.append(hex_value_journeystops_condition)
                            
#                     text_item.close()
                    
#                 else:                  
#                     new_list.append('02')
#                     new_list.append('04')
#                     my_tr = ET.parse("projectinfo.xml")
#                     root = my_tr.getroot()
#                     for i in root.findall("stationCode"):
#                         it = i.find("name").text
#                         if it == tag_item:
#                             mask_xml = i.find("code").text
#                             hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
#                             new_list.append(hex_value_journeystops_condition)
                    
#                     # new_list.append(content_hex)
                    
#                     my_tr = ET.parse("projectinfo.xml")
#                     root = my_tr.getroot()
#                     for i in root.findall("stationCode"):
#                         it = i.find("name").text
#                         if it == field_name:
#                             mask_xml = i.find("mask").text
#                             hex_value_journeystops_condition = f"{format(int(mask_xml), '04X')}"
#                             new_list.append(hex_value_journeystops_condition)
#                 number_of_segement += 1
            
                
#         new_list.insert(0,str(tag[1]))
#         language_data_hex = language_data.upper().encode('utf-8').hex().upper()
#         new_list.insert(1,language_data_hex)
#         segment_number_hex = f"{format(int(number_of_segement), '02X')}"
#         new_list.insert(2,segment_number_hex)
#         number_of_segement = 0
#         message_description_all_vallue = (''.join(new_list))
#         print(message_description_all_vallue)

            
            


# # Import Required Library
# from tkinter import *
# from tkcalendar import Calendar
 
# # Create Object
# root = Tk()
 
# # Set geometry
# root.geometry("400x400")
 
# # Add Calendar
# cal = Calendar(root, selectmode = 'day',year = 2020, month = 5,day = 22)
# cal.pack(pady = 20)
 
# def grad_date():
#     date.config(text = "Selected Date is: " + cal.get_date())
 
# # Add Button and Label
# Button(root, text = "Get Date",
#        command = grad_date).pack(pady = 20)
 
# date = Label(root, text = "")
# date.pack(pady = 20)
 
# # Execute Tkinter
# root.mainloop()

# print('48E17A14AEC74B40')
# import struct

# a = '55.56'
# binary_string = struct.pack('d', float(a))
# hexadecimal_output = binary_string.hex().upper()

# print(hexadecimal_output)


# dict_1 = {1: 0, 2: 15, 3: 30, 4: 45, 5: 60}
# for k, v in dict_1.items():
#     if v == 15:
#         print(k)

# a = []
# user_input = input("Please enter a name: ")
# a.extend(user_input)
# print(a)

# user_input = input("Please enter a name: ")
# b = list(user_input)
# print(b)



# aa ="அக்கம்பேட்டா"
# aa ="अक्कंपेटा"
# aa ="Akkampeta"
# for i in aa:
#     print(ord(i))
import re
import xml.etree.ElementTree as ET
import binascii

# initializing string
# test_str = 'அக்கம்பேட்டா'
# test_str = 'अक्कंपेटा'
# test_str = 'Akkampeta'
# test_str = 'எதற்காக வரிசையில் நிற்க வேண்டும், UTS MOBILE APP ஐப் பயன்படுத்தி உங்கள் மொபைலில் முன்பதிவு செய்யப்படாத டிக்கெட், சீசன் டிக்கெட் மற்றும் பிளாட்பார்ம் டிக்கெட்டைப் பெறுங்கள்.'
# test_str = 'कतार में क्यों खड़े हों, यूटीएस मोबाइल ऐप का उपयोग करें और अपने मोबाइल में अनारक्षित टिकट, सीजन टिकट और प्लेटफॉर्म टिकट प्राप्त करें।'
# test_str = 'अ எத a कतार में क्यों खड़े हों, यूटीएस मोबाइल ऐप का उपयोग करें और अपने मोबाइल में अनारक्षित टिकट, सीजन टिकट और प्लेटफॉर्म टिकट प्राप्त करें।'
# test_str = '''எதற்காக வரிசையில் நிற்க வேண்டும், UTS MOBILE APP ஐப் பயன்படுத்தி உங்கள் மொபைலில் முன்பதிவு செய்யப்படாத டிக்கெட், சீசன் டிக்கெட் மற்றும் பிளாட்பார்ம் டிக்கெட்டைப் பெறுங்கள்.'''
test_str = "सॅडहस्‍​र्ट रोड"

# add = "80"
# subtract = "00"
# add = "80"
# subtract = "900"
# printing original String
# print("The original string is : " + str(test_str))

# text_item = open(f"sqlData/txt/MT0029MR.TXT", "r", encoding="utf-8")
# content = text_item.read()

new_data = {'0000': ('EN', '00', '0000', "1"), '0900': ('HI', '80', "0900", "1"), '0B8 0': ('MR', '00', "0000", "1")}
# print(hex(int("0B80", 16) + 0x7f))

for char in test_str:
    for char_2 in new_data.keys():
        if int(char_2, 16) <= ord(char) <= (int(char_2, 16) + 0x7f):
            len_num = int(new_data[char_2][3])
            value = hex(ord(char)-(int(new_data[char_2][2], 16))+(int(new_data[char_2][1], 16))).replace("0x", "")
            add_byte = len_num*2 - len(value)
            print("0"*add_byte+value)



    # print(hex(ord(char)))

# list_data = [] #0x0900 + 0x80
# for char in test_str:
#     if ord(u'\u0900') <= ord(char) <= (ord(u'\u0900') + int("80", 16)):
#         output = hex(ord(char)+(int(add, 16)))[-2:].upper()
#         list_data.append(output)
#         print(char, output)
#
#     if ord(u'\u0900') <= ord(char) <= (ord(u'\u0900') + int("80", 16)):
#         output = hex(ord(char) + (int(add, 16)))[-2:].upper()
#         list_data.append(output)
#         print(char, output)
#
#     else:
#         output = hex(ord(char)).replace("0x", "")[-2:].upper()
#         if len(output) == 1:
#             output = f"0{output}"
#         list_data.append(output)
#         print(char, output)
# print(" ".join(list_data))


# res = ' '.join("20" if ord(chr) == 32 else r'\{:04X}'.format(ord(chr)+(int(add, 16))-(int(subtract, 16)))[-2:] for chr in test_str)

# printing result
# print(str(res2))
# print(str(res))

# content = test_str
# # print(content, "contentttttttttt")
# lis_content = []

# # res = ''.join(r'\{:02X}'.format(ord(chr))[-2:] for chr in content)
# for i in content:
#     content_hex = i.encode('utf-8').hex().upper()[-3:]
#     # print(content_hex)
#     # print(int(content_hex, 16), int("995", 16))
#     # print(hex(int(content_hex, 16) - int("995", 16)))
#     lis_content.append(content_hex)
# content_hex1 = "".join(lis_content)
# # print(content_hex1)
# # content_hex1 = str(res)
# # print(content_hex, "contentttttttttt_hex")
#
# # def change_hex():
# #     list_language_data = {}
# #     my_tr = ET.parse("projectinfo.xml")
# #     root = my_tr.getroot()
# #     for i in root.findall("ImsLanguages"):
# #         it = i.find("Code").text
# #         it1 = i.find("uni_sub").text
# #         it2 = i.find("add").text
# #         it3 = i.find("graphics").text
# #         list_language_data[it] = (it1, it2)
# #     for row in rows:
# #         if list_language_data.get(row[0]):
# #             hex_value_station_en = format(int(row[4]), '04X')
# #             name_lang_station_en = binascii.hexlify(''.join(row[0]).encode()).decode().upper()
# #             station_data_get_en = hex_value_station_en + name_lang_station_en
# #
# #             unicode_text = row[2]
# #             unicode_text_short = row[3]
# #             add_and_subtract = list_language_data.get(row[0])
# #             subtract = add_and_subtract[0]
# #             add = add_and_subtract[1]
# #
# #             result = []
# #             for character in unicode_text:
# #                 code_point = ord(character)
# #                 # print(character, "character")
# #                 if code_point == 32:
# #                     hex_code = "20"
# #                 else:
# #                     if subtract == "00":
# #                         hex_1_add = code_point - int(subtract, 16)
# #                         if len(str(hex_1_add)) >= 2:
# #                             hex_2 = hex_1_add + int(add, 16)
# #                             # print(hex_2, "oooooooooffffff")
# #                             hex_code = hex(hex_2)[2:].upper().zfill(4)[-2:]
# #                         else:
# #                             hex_2 = hex_1_add + int(add, 16)
# #                             hex_code = hex(hex_2)[2:].upper()
# #                     elif subtract == "01":
# #                         hex_1_add = code_point - int(subtract, 16) + 1
# #                         hex_2 = hex_1_add + int(add, 16)
# #                         hex_code = hex(hex_2)[2:].upper().zfill(4)[-2:]
# #                     else:
# #                         hex_code = hex(code_point - int(subtract, 16) + int(add, 16))[2:].upper()
# #                 result.append(hex_code)
# #             output = ''.join(result)
# # change_hex()
#
