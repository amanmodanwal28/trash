# import serial
# ser = serial.Serial()
# ser.port = 'COM5'
# ser.open()
# data = ser.readline()
# print(data)

import serial
from threading import Thread

serialPort = serial.Serial(port='COM5', baudrate=9600)

class Receiver(Thread):
    def __init__(self, serialPort):
        Thread.__init__(self)
        self.serialPort = serialPort

    def run(self):
        text = ""
        while (text != "exit\n"):
            text = serialPort.readline()
            print(text)

class Sender(Thread):
    def __init__(self, serialPort):
        Thread.__init__(self)
        self.serialPort = serialPort

    def run(self):
        text = ""
        self.serialPort.write(b"hhhhhh\n")
        # while(text != "exit\n"):
        #     # text = input("$:")
        #     self.serialPort.write(b"hhhhhh\n")

send = Sender(serialPort)
receive = Receiver(serialPort)
send.start()
receive.start()