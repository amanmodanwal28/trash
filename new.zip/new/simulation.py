import journey, tkinter.ttk, pyautogui, time, os, sqlite3
import tkinter as tk
from tkinter import ttk
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
import xml.etree.ElementTree as ET
from tkVideoPlayer import TkinterVideo
from ffpyplayer.player import MediaPlayer
# import pygame
from playsound import playsound
from threading import *
import sqlite3
from file_dir import File_Path, SQL_QUERY

class MainApplicationSimulate:
    def __init__(self):
        self.simulate = tk.Tk()
        self.simulate.title("Simulate")
        self.simulate.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.simulate.geometry("1200x600+70+40")
        self.data_from_journey_tbl = journey.data_from_route_list(tk.Frame)
        print("self.data_from_journey_tbl", self.data_from_journey_tbl)
        self.data_from_journey_tbl2 = self.data_from_journey_tbl.journey_list()
        print("self.data_from_journey_tbl2", self.data_from_journey_tbl2)

        ############################## help ###########################
        menu = tk.Menu(self.simulate)
        Edit = tk.Menu(menu, tearoff=0)
        Edit.add_command(label="Help now")
        menu.add_cascade(label="Help", menu=Edit)
        self.simulate.config(menu=menu)
        ############################## style for combobox ##################################
        z = tkinter.ttk.Style(self.simulate)
        z.theme_use('clam')
        z.configure('Treeview.Heading', background="light gray")

        ################################ main frame ############################################
        simulate_main_frame = Frame(self.simulate, relief=RIDGE, background='light gray', bd=4)
        simulate_main_frame.place(x=0, y=0, height=600, width=1200)

        ##################################### Up frame #####################################
        up_frame = Frame(self.simulate, simulate_main_frame, width=1190, height=40, relief=RIDGE, background='light gray', bd=4)
        up_frame.place(x=5, y=4)

        journey_label = Label(up_frame, text="Journey :- ", font=('times new roman', 12, "bold"), fg='black',
                              bg='light gray')
        journey_label.place(x=0, y=3)

        journey_entry = Entry(up_frame, font=('arial', 8, 'bold'))
        journey_entry.place(x=100, y=6)
        journey_entry.bind("<Key>", DISABLED)

        #################################### route ##################################

        route_label = Label(up_frame, text="Route :- ", font=('times new roman', 12, "bold"), fg='black',
                            bg='light gray')
        route_label.place(x=250, y=3)

        route_entry = Entry(up_frame, font=('arial', 8, 'bold'))
        route_entry.place(x=330, y=6)
        route_entry.bind("<Key>", DISABLED)

        #################################### condition ##################################

        condition_label = Label(up_frame, text="Condition :- ", font=('times new roman', 12, "bold"), fg='black',
                                bg='light gray')
        condition_label.place(x=490, y=3)

        condition_entry = Entry(up_frame, font=('arial', 8, 'bold'))
        condition_entry.place(x=600, y=6)
        condition_entry.bind("<Key>", DISABLED)

        if self.data_from_journey_tbl2:
            journey_entry.insert(END, self.data_from_journey_tbl2[1])
            route_entry.insert(END, self.data_from_journey_tbl2[0][2])
            condition_entry.insert(END, self.data_from_journey_tbl2[0][3])

        ##################################### Up frame 1 #####################################
        up_frame1 = Frame(self.simulate, simulate_main_frame, bd=10, width=1190, height=150, relief=RIDGE, bg='light gray')
        up_frame1.place(x=5, y=45)

        self.img = (Image.open("UIFILES/sta.png"))
        self.resized_image = self.img.resize((60, 55), Image.ADAPTIVE)
        self.new_image = ImageTk.PhotoImage(self.resized_image)
        # Label(win, image=new_image).pack()

        frame1 = Frame(self.simulate, highlightbackground="black", highlightthickness=1, height=110, width=120, bg='light gray')
        frame1.place(x=20, y=60)
        frame2 = Frame(self.simulate, highlightbackground="black", highlightthickness=1, height=110, width=120,
                       bg='light gray')
        frame2.place(x=340, y=60)
        frame3 = Frame(self.simulate, highlightbackground="black", highlightthickness=1, height=110, width=120,
                       bg='light gray')
        frame3.place(x=660, y=60)

        old_station_image = Label(frame1, image=self.new_image)
        old_station_image.place(x=25, y=17)
        self.old_station_name = Label(frame1, font=('times new roman', 7, "bold"), fg='black',
                                      bg='light gray')
        self.old_station_name.place(x=5, y=75)
        old_station_sep = tkinter.ttk.Separator(self.simulate, orient='horizontal')
        old_station_sep.place(x=141, y=110, relwidth=.165, relheight=0.01)

        current_station_image = Label(frame2, image=self.new_image)
        current_station_image.place(x=25, y=17)
        #  n, ne, e, se, s, sw, w, nw, or center
        self.current_station_name = Label(frame2, font=('times new roman', 7, "bold"), fg='black', bg='light gray', anchor="se")
        self.current_station_name.place(x=5, y=75)

        current_station_sep = tkinter.ttk.Separator(self.simulate, orient='horizontal')
        current_station_sep.place(x=461, y=110, relwidth=.165, relheight=0.01)

        next_station_image = Label(frame3, image=self.new_image)
        next_station_image.place(x=25, y=17)

        self.next_station_name = Label(frame3, font=('times new roman', 7, "bold"), fg='black',
                                       bg='light gray', anchor="se")
        self.next_station_name.place(x=5, y=75)
#####################################################################################################
#####################################################################################################
#####################################################################################################

        self.station_language_1 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_1.place(x=10, y=91)
        self.station_language_2 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_2.place(x=29, y=91)
        self.station_language_3 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_3.place(x=48, y=91)
        self.station_language_4 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_4.place(x=67, y=91)
        self.station_language_5 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_5.place(x=86, y=91)
        self.location_side = Label(self.simulate, font=('arial', 8), fg='black', bg='red')

        self.list_of_language = [self.station_language_1, self.station_language_2, self.station_language_3, self.station_language_4, self.station_language_5]

#####################################################################################################
#####################################################################################################
#####################################################################################################

        Front_Left = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text="Front Left :", bg='light gray')
        Front_Left.place(x=240, y=215)
        Front_right = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text="Front Right :", bg='light gray')
        Front_right.place(x=240, y=257)
        Interior_Display = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text="Interior Display :", bg='light gray')
        Interior_Display.place(x=240, y=299)
        Interior_Display = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text="TFT :", bg='light gray')
        Interior_Display.place(x=240, y=354)

        self.field_resolution_list = {"full": [0, 0, 798, 28], "<field01>": [91, 1, 700, 28], "<field02>": [0, 1, 90, 28], "<field03>": [91, 1, 608, 28], "<field04>": [0, 1, 90, 28], "<field05>": [700, 1, 93, 28], "<field06>": [0, 1, 800, 28], } # where [x, y, width, height]

        # self.Front_Left_entry = Entry(self.simulate, font=('times new roman', 11, 'bold'), bd=3)
        self.Front_Left_Frame = Frame(self.simulate, relief=RIDGE, background='white', bd=3)
        self.Front_Left_Frame.place(x=390, y=210, height=35, width=800)
        self.Front_Left_Frame.bind("<Key>", "break")

        # self.Front_Right_entry = Entry(self.simulate, font=('times new roman', 11, 'bold'), bd=3)
        self.Front_Right_Frame = Frame(self.simulate, relief=RIDGE, background='white', bd=3)
        self.Front_Right_Frame.place(x=390, y=252, height=35, width=800)
        self.Front_Right_Frame.bind("<Key>", "break")

        # self.Interior_Display_entry = Entry(self.simulate, font=('times new roman', 11, 'bold'), bd=3)
        self.Interior_Display_Frame = Frame(self.simulate, relief=RIDGE, background='white', bd=3)
        self.Interior_Display_Frame.place(x=390, y=294, height=35, width=800)
        self.Interior_Display_Frame.bind("<Key>", "break")

        self.Bit_IMG_BANNER_VIDEO_frame = Frame(self.simulate, height=185, width=800, relief=RIDGE, background='gray52', bd=4)
        self.Bit_IMG_BANNER_VIDEO_frame.place(x=390, y=354)

        # lbl = Label(self.Front_Left_Frame, font='Bell 14 bold', text="12904", bg="blue")
        # lbl.place(x=700, y=1, width=93, height=28)
        # lbl = Label(self.Front_Left_Frame, font='Bell 14 bold', text="12904", bg="red")
        # lbl.place(x=91, y=1, width=608, height=28)

        self.dist_of_device_frame = {"32": self.Front_Left_Frame, "64": self.Front_Right_Frame, "4": self.Interior_Display_Frame, "16": self.Bit_IMG_BANNER_VIDEO_frame, "8": "sound"}
        self.dist_of_device_label_tem = {}

        self.Forward_button_add = Button(simulate_main_frame, text="Forward", font=('arial', 11, 'bold'), bg="#7C7CFC",
                                         fg="white")
        self.Forward_button_add.place(x=240, y=555)

        self.var_value = IntVar()
        def threading():
            # Call work function
            if self.var_value.get() == 1:
                self.Forward_button_add.configure(state=DISABLED, bg="white", fg="black")
                # t1 = Thread(target=self.auto_run)
                # t1.start()
            elif self.var_value.get() == 0:
                self.Forward_button_add.configure(state=NORMAL, bg="#7C7CFC", fg="white")
                self.a_run = 0

        self.check_box = Checkbutton(simulate_main_frame, text="run", command=threading, offvalue=0, onvalue=1, variable=self.var_value, bg="light gray")
        self.check_box.place(x=370, y=555)

        self.combobox_time_sec = tkinter.ttk.Combobox(simulate_main_frame, font=("arial", 8, 'bold'), width=2, background="light gray",
                                                      values=(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
        self.combobox_time_sec.set(1)
        self.combobox_time_sec.place(x=430, y=557)

        #################################### station table ###################################
        table_station = Frame(simulate_main_frame)
        table_station.place(x=0, y=193, height=397, width=230)
        scroll_y = Scrollbar(table_station, orient=VERTICAL)
        self.station_table = tkinter.ttk.Treeview(table_station, yscrollcommand=scroll_y.set)
        scroll_y.pack(side=RIGHT, fill=Y)
        scroll_y.config(command=self.station_table.yview)
        self.station_table.heading('#0', text='Station')
        self.station_table.pack(fill=BOTH, expand=1)

        ###### value store variables ######
        self.current_station_for_change = ""
        self.current_language_for_change = ""

        self.station_tbl_journeyStops = {}
        # self.station_dist_details_in_order = {}
        self.station_list_in_order = []
        self.store_field_lbl = {}


        self.simulate_data_sql_tbl_tree()
        self.station_table.bind("<ButtonRelease>", self.select_tree)
        self.a_run = 1

        self.simulate.mainloop()

    def simulate_data_sql_tbl_tree(self):
        print(468)
        self.current_station_for_change = ""
        if self.data_from_journey_tbl2:
            sql_query1 = f'''select combiTriggerID, stationName, languageArea, stationNo from tbl_journeyStops where journeyID={self.data_from_journey_tbl2[0][0]}'''
            data6 = SQL_QUERY(sql_query1).QUERY_COMMAND()
            self.num = 1
            # station_order_num = 1
            if data6:
                self.station_table.delete(*self.station_table.get_children())
                for i in data6:
                    self.station_tbl_journeyStops[self.num] = {"Station_data": [i[1], i[2], i[3]],
                                                               "eventValue": [],
                                                               "Device_type": [],
                                                               "message": []}
                    # self.station_dist_details_in_order[i[1]] = [station_order_num, i[2], i[3]]
                    self.station_list_in_order.append(i[1])
                    # station_order_num += 1
                    self.station_table.insert("", 'end', text=i[1], iid=self.num, open=True)
                    sql_query2 = f"select combiTriggerID from tbl_combiTrigger where combiTriggerName='{i[0]}'"
                    data8 = SQL_QUERY(sql_query2).QUERY_COMMAND()
                    fix_num = self.num
                    self.num += 1
                    if data8:
                        sql_query3 = f'''select triggerName from tbl_combiTriggerItems where combiTriggerID={data8[0][0]}'''
                        data7 = SQL_QUERY(sql_query3).QUERY_COMMAND()
                        for j in data7:
                            self.station_table.insert("", 'end', text=j[0], iid=self.num, open=True)
                            self.station_table.move(self.num, fix_num, self.num)
                            sql_query4 = f"select do_this_combi_ID, eventValue from  tbl_trigger where triggerName='{j[0]}'"
                            data9 = SQL_QUERY(sql_query4).QUERY_COMMAND()
                            if data9:

                                self.station_tbl_journeyStops[self.num] = {"Station_data": [i[1], i[2], i[3]],
                                                                           "eventValue": [data9[0][1]],
                                                                           "Device_type": [],
                                                                           "message": []}
                                sql_query5 = f"select actionId, resource_name, action_ID_int from do_this_combi_item where do_this_combi_ID='{data9[0][0]}' order by ActionOrder"
                                data10 = SQL_QUERY(sql_query5).QUERY_COMMAND()
                                fix_num2 = self.num
                                self.num += 1
                                for k in data10:
                                    sql_query6 = f"select message_Description, resource_ID from tbl_action where action_ID={k[2]} "
                                    Action_data = SQL_QUERY(sql_query6).QUERY_COMMAND()
                                    self.station_table.insert("", 'end', text=k[0], iid=self.num, open=True)
                                    self.station_table.move(self.num, fix_num2, self.num)
                                    self.station_tbl_journeyStops[self.num] = {"Station_data": [i[1], i[2], i[3]],
                                                                               "eventValue": [data9[0][1]],
                                                                               "Device_type": [k[1]],
                                                                               "message": [Action_data[0][0]]}
                                    self.num += 1

            else:
                self.station_table.delete(*self.station_table.get_children())
            if data8: # Select First column in table
                self.station_table.focus(1)
                self.station_table.selection_set(1)
                self.select_tree()
        print(self.station_tbl_journeyStops)

    def select_tree(self, event=""):
        ####### For Station data #######
        Tree_iid = self.station_table.focus()
        if int(Tree_iid) in self.station_tbl_journeyStops:
            # print(self.station_tbl_journeyStops[int(Tree_iid)])
            if self.station_tbl_journeyStops[int(Tree_iid)]["Station_data"]:
                self.type_language = self.station_tbl_journeyStops[int(Tree_iid)]["Station_data"][1].split(",")
                for language, num in zip(self.type_language, range(len(self.type_language))): # Set language in label
                    self.list_of_language[num].configure(text=language)
                    if num == 0:
                        self.list_of_language[num].configure(bg="red")
                        self.current_language_for_change = language
                if self.current_station_for_change != self.station_tbl_journeyStops[int(Tree_iid)]["Station_data"][0]:
                    self.current_station_for_change = self.station_tbl_journeyStops[int(Tree_iid)]["Station_data"][0]
                    self.current_station_name.configure(text=self.current_station_for_change)
                    self.old_station_name.configure(text="")
                    self.next_station_name.configure(text="")
                    if 0 < self.station_list_in_order.index(self.current_station_for_change):
                        self.old_station_name.configure(text=self.station_list_in_order[self.station_list_in_order.index(self.current_station_for_change) - 1])
                        # print("PRV : ", self.station_list_in_order[self.station_list_in_order.index(self.current_station_for_change) - 1])
                    if self.station_list_in_order.index(self.current_station_for_change) < self.station_list_in_order.index(self.station_list_in_order[-1]):
                        self.next_station_name.configure(text=self.station_list_in_order[self.station_list_in_order.index(self.current_station_for_change) + 1])
                        # print("NEXT : ", self.station_list_in_order[self.station_list_in_order.index(self.current_station_for_change) + 1])



                    # for language in self.list_of_language:
                    #     if language.cget('text') == "EN":
                    #         language.configure(bg="red")
                    #     else:
                    #         language.configure(bg="light gray")

            if self.station_tbl_journeyStops[int(Tree_iid)]["eventValue"]:
                event_value = self.station_tbl_journeyStops[int(Tree_iid)]["eventValue"][0]
                if event_value.find("after the station") > -1:
                    self.location_side.configure(text="after the station")
                    # self.location_side.place(x=189, y=100)
                    self.location_side.place(x=498, y=100)
                elif event_value.find("before the station") > -1:
                    self.location_side.configure(text="before the station")
                    # self.location_side.place(x=498, y=100)
                    self.location_side.place(x=189, y=100)
                elif event_value.find("in the station") > -1:
                    self.location_side.configure(text="in the station")
                    self.location_side.place(x=363, y=171)
            else:
                self.location_side.place_forget()
                # print("eventValue ok")
            # if self.station_tbl_journeyStops[int(Tree_iid)]["Device_type"]:
            #     print("Device_type ok")
            if self.station_tbl_journeyStops[int(Tree_iid)]["message"]:
                message = self.station_tbl_journeyStops[int(Tree_iid)]["message"][0]
                text = ""
                list_message = []
                for item in message: #filter message
                    if item in ['<', '[', '{']:
                        text += item
                    elif item in ['>', ']', '}']:
                        text += item
                        list_message.append(text)
                        text = ""
                    else:
                        text += item

                device_type = self.station_tbl_journeyStops[int(Tree_iid)]["Device_type"][0]

                my_tr = ET.parse("projectinfo.xml")
                root = my_tr.getroot()
                device_value = ""
                for i in root.findall("resource"): # find device type
                    device_name = i.find("name").text
                    if device_name.upper() == device_type.upper():
                        device_value = i.find("value").text
                if device_value:
                    self.message_filter(list_message, device_value)
                # print("message ok")
        else:
            print(f"Tree IID Mismatch: {Tree_iid}")
    def message_filter(self, text="", device=""):
        # print(text)
        # self.dist_of_device_frame = {32: self.Front_Left_Frame, 64: self.Front_Right_Frame, 4: self.Interior_Display_Frame, 16: self.Bit_IMG_BANNER_VIDEO_frame, 8: "sound"}
        if device in ['32', '64', '4']:
            # lbl = tk.Label(self.field_size_frame[field_name], font='Bell 15 bold', bg="sky blue")
            # ,wraplength=int(scale_x_width))
            dis_for_elements = {"full": []}
            tag_name = "full"
            for item in text:
                # print(item)
                if item[1] == "/":
                    tag_name = "full"
                elif item[0] == "<":
                    tag_name = item
                    dis_for_elements[tag_name] = []
                elif item[0] in ["[", "{"]:
                    dis_for_elements[tag_name].append(item)
            # print(dis_for_elements, "gghjkhghjghjvghghj", device)
            if device in self.dist_of_device_label_tem:
                for destroy_item in self.dist_of_device_label_tem[device]:
                    destroy_item.destroy()
                self.dist_of_device_label_tem.pop(device)
            for device_data in dis_for_elements:
                # print(device_data, dis_for_elements[device_data])
                text_for_display = ""
                list_of_lbl = []
                for item in dis_for_elements[device_data]:
                    if item[0] == '[':
                        text_replace = item.replace("[", "").replace("]", '')
                        # print(item.replace("[", "").replace("]", ''))
                        dst_path = File_Path().TEXT_Path
                        open_file = open(f"{dst_path}{text_replace}{self.current_language_for_change}.TXT", encoding="utf-8")
                        text_for_display += open_file.read()+" "

                    elif item[0] == '{':
                        text_replace = item.replace("{", "").replace("}", '')
                        text_for_display += self.action_trigger(text_replace) + " "
                        return_text = "def function(text_replace)"
                        # print(self.station_dist_details_in_order, self.current_station_for_change, self.current_language_for_change)
                        print(self.station_list_in_order, self.current_station_for_change, self.current_language_for_change)
                        # print(item)

                if dis_for_elements[device_data]: # To Create label for field
                    UpdateDelay = 100

                    def update(n=0, space=0):
                        """Update Label text every whenever."""
                        display = text_for_display
                        print(n, len(display), space)
                        if n <= len(display):
                            lbl.configure(text=display[0:n])
                            lbl.after(UpdateDelay, update, n + 1)
                        elif n > len(display):
                            lbl.configure(text=display[0:n] + " " * space)
                            if space == lbl_place[2]//5:
                                lbl.after(UpdateDelay, update, 0, 0)
                            else:
                                lbl.after(UpdateDelay, update, n, space + 1)


                    lbl_place = self.field_resolution_list[device_data]
                    lbl = Label(self.dist_of_device_frame[device], font='Bell 14 bold')
                    lbl.place(x=lbl_place[0], y=lbl_place[1], width=lbl_place[2], height=lbl_place[3])
                    list_of_lbl.append(lbl)
                    if len(text_for_display) > 65:
                        lbl.configure(justify='right', anchor="e")
                        lbl.after(UpdateDelay, update)
                    else:
                        lbl.configure(text=text_for_display)

                # print(text_for_display)
            self.dist_of_device_label_tem[device] = list_of_lbl

            # print("device type")
            # print(self.dist_of_device_label_tem, "hhhhhh")
        elif device == '8':
            print("sound")
            pass
    def action_trigger(self, action_item):
        rank = ""
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for country in root.findall('stationCode'):
            name = country.find('name').text
            if name.upper() == action_item.upper():
                rank = country.find('code').text
        if rank:
            if rank == "37187" or rank == "37186":  # current_station
                return self.current_station_for_change
                pass
            elif rank == "37185" or rank == "37184":  # previous_station
                previous_st = ""
                if 0 < self.station_list_in_order.index(self.current_station_for_change):
                    previous_st = self.station_list_in_order[
                        self.station_list_in_order.index(self.current_station_for_change) - 1]
                    # print("PRV : ", self.station_list_in_order[self.station_list_in_order.index(self.current_station_for_change) - 1])
                return previous_st
            elif rank == "37189" or rank == "37188":  # Next_Station
                next_st = ""
                if self.station_list_in_order.index(self.current_station_for_change) < self.station_list_in_order.index(
                        self.station_list_in_order[-1]):
                    next_st = self.station_list_in_order[
                        self.station_list_in_order.index(self.current_station_for_change) + 1]

                return next_st
            elif rank == "37191" or rank == "37190":  # allNextStations
                all_next_list_st = self.station_list_in_order[self.station_list_in_order.index(self.current_station_for_change)+1:]

                return " ".join(all_next_list_st)
            elif rank == "37193" or rank == "37192":  # start_station
                return self.station_list_in_order[0]

            elif rank == "37195" or rank == "37194":  # End_Station
                return self.station_list_in_order[-1]

            elif rank == "37261":  # Carcount, 37261
                pass
            elif rank == "37263":  # serviceType , 37263
                pass


    # def destroy_lbl(self):
    #     for device in self.dist_of_device_label_tem:
    #         for destroy_item in self.dist_of_device_label_tem[device]:
    #             destroy_item.destroy()
            # self.dist_of_device_label_tem.pop(device)
    def on_exit(self):
        try:
            self.player.close_player()
        except AttributeError:
            pass
        self.simulate.destroy()
        journey.MainApplication3()


# MainApplicationSimulate()