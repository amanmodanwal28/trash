import tkinter as tk
import math


average_flow = ""
peak_factor = ""
average_metercube_perhours = ""
average_metercube_persecond = ""
peak_flow = ""
peak_metercube_perhours = ""
peak_metercube_persecond = ""
Operational_Time_of_WWTP = ""
present_average_flow_1_DWF = ""
pump_capacity_provided = ""
average_flow_1_dWF_2_nos = ""
no_of_working_pumps = ""
no_of_standby_pumps = ""
pumping_hours  = ""
pump_head = ""

window = tk.Tk()
window.geometry("800x700")

def onFrameConfigure(canvas):
    canvas.configure(scrollregion=canvas.bbox("all"))
    canvas.itemconfigure(wrapFrame, width=canvas.winfo_width())

outerFrame = tk.Frame(window)
canvas = tk.Canvas(outerFrame, highlightthickness=0)
frame = tk.Frame(canvas)
vsb = tk.Scrollbar(outerFrame, orient="vertical", command=canvas.yview)
canvas.config(yscrollcommand=vsb.set)

outerFrame.place(x=0, y=0, width=800, height=700)
vsb.pack(side="right", fill="y")
canvas.pack(fill="both", expand=1, anchor="nw")
wrapFrame = canvas.create_window((0,0), window=frame, anchor="nw", width=700, height=2200)
canvas.bind("<Configure>", lambda event, canvas=canvas: onFrameConfigure(canvas))

# Function to handle button click event
def flow_calculate():
    global average_flow
    global peak_factor
    global average_metercube_perhours
    global average_metercube_persecond
    global peak_flow
    global peak_metercube_perhours
    global peak_metercube_persecond
    global Operational_Time_of_WWTP
    global present_average_flow_1_DWF
    global pump_capacity_provided
    global average_flow_1_dWF_2_nos
    global no_of_working_pumps
    global no_of_standby_pumps
    global pumping_hours 
    global pump_head
    # Get the input values from the entry widgets
    average_flow = float(entry_average_flow.get())
    peak_factor = float(entry_peak_factor.get())

    # Perform the calculations
    average_metercube_perhours = average_flow / 24
    average_metercube_persecond = average_metercube_perhours / 3600
    peak_flow = average_flow * peak_factor
    peak_metercube_perhours = peak_flow / 24
    peak_metercube_persecond = peak_metercube_perhours / 3600
    Operational_Time_of_WWTP = 24
    present_average_flow_1_DWF = int(average_metercube_perhours)
    pump_capacity_provided = ''
    average_flow_1_dWF_2_nos = average_metercube_perhours
    no_of_working_pumps = 1
    no_of_standby_pumps = 1
    pumping_hours  = 24
    pump_head = 10

    # Update the result labels
    list_Average_Metercube_Perhours.delete(0, tk.END)
    list_Average_Metercube_Perhours.insert(tk.END, f'{average_metercube_perhours} m3/hr')
    
    list_Average_Metercube_Persecond.delete(0, tk.END)
    list_Average_Metercube_Persecond.insert(tk.END, f'{average_metercube_persecond} m3/s')
    
    list_Peak_Flow.delete(0, tk.END)
    list_Peak_Flow.insert(tk.END, f'{peak_flow} kLD')
    
    list_Peak_Meter_Cube_per_Hour.delete(0, tk.END)
    list_Peak_Meter_Cube_per_Hour.insert(tk.END, f' {peak_metercube_perhours} m3/hr')
    
    list_Peak_Meter_Cube_per_Second.delete(0, tk.END)
    list_Peak_Meter_Cube_per_Second.insert(tk.END, f' {peak_metercube_persecond} m3/s')
    
    list_Operational_Time_of_WWTP.delete(0, tk.END)
    list_Operational_Time_of_WWTP.insert(tk.END, f'{Operational_Time_of_WWTP} Hr')
    
    list_Present_Average_Flow_1_DWF.delete(0, tk.END)
    list_Present_Average_Flow_1_DWF.insert(tk.END, f'{present_average_flow_1_DWF} m3/hr')
    
    list_Pump_Capacity_provided.delete(0, tk.END)
    list_Pump_Capacity_provided.insert(tk.END, f'{pump_capacity_provided}')
    
    list_Average_Flow_1_DWF_2_Nos.delete(0, tk.END)
    list_Average_Flow_1_DWF_2_Nos.insert(tk.END, f'{average_flow_1_dWF_2_nos} m3/hr')
    
    list_No_of_Working_Pumps.delete(0, tk.END)
    list_No_of_Working_Pumps.insert(tk.END, f'{no_of_working_pumps} No')
    
    list_No_of_Standby_Pumps.delete(0, tk.END)
    list_No_of_Standby_Pumps.insert(tk.END, f'{no_of_standby_pumps} No')
    
    list_Pumping_hours.delete(0, tk.END)
    list_Pumping_hours.insert(tk.END, f'{pumping_hours} hr')
    
    list_Pump_Head.delete(0, tk.END)
    list_Pump_Head.insert(tk.END, f'{pump_head} m')

flow_frame = tk.LabelFrame(frame, text='1.1 Flow', font=('times new roman', 13, "bold"),
                                             fg="red", bd=4)
flow_frame.place(x=3, y=0, height=295, width=780)

# Create the input entry widgets
label_average_flow = tk.Label(flow_frame, text='Average Flow number :')
label_average_flow.place(x=160, y=10)
entry_average_flow = tk.Entry(flow_frame)
entry_average_flow.place(x=350, y=10)

label_peak_factor = tk.Label(flow_frame, text='Peak Factor for STP :')
label_peak_factor.place(x=160, y=40)
entry_peak_factor = tk.Entry(flow_frame)
entry_peak_factor.place(x=350, y=40)

label_Average_Meter_Cube_per_Hour=tk.Label(flow_frame, text='-: ')
label_Average_Meter_Cube_per_Hour.place(x=250, y=120)

label_Average_Meter_Cube_per_Second=tk.Label(flow_frame, text='--: ')
label_Average_Meter_Cube_per_Second.place(x=250, y=145)

label_Peak_Flow =tk.Label(flow_frame, text='Peak Flow: ')
label_Peak_Flow .place(x=250, y=170) 

label_Peak_Meter_Cube_per_Hour=tk.Label(flow_frame, text='---: ')
label_Peak_Meter_Cube_per_Hour.place(x=250, y=195)

label_Peak_Meter_Cube_per_Second=tk.Label(flow_frame, text='----:')
label_Peak_Meter_Cube_per_Second.place(x=250, y=220)

label_Operational_Time_of_WWTP=tk.Label(flow_frame, text='Operational Time of WWTP : ')
label_Operational_Time_of_WWTP.place(x=250, y=245)


# Create the calculate button
button_calculate = tk.Button(flow_frame, text='Flow Calc', command=flow_calculate, fg='white', bg='blue')
button_calculate.place(x=320, y=80)

# Create the result labels

list_Average_Metercube_Perhours = tk.Listbox(flow_frame,width=30, height= 1)
list_Average_Metercube_Perhours.place(x=440, y=120)

list_Average_Metercube_Persecond = tk.Listbox(flow_frame,width=30, height= 1)
list_Average_Metercube_Persecond.place(x=440, y=145)

list_Peak_Flow = tk.Listbox(flow_frame,width=30, height= 1)
list_Peak_Flow.place(x=440, y=170)

list_Peak_Meter_Cube_per_Hour = tk.Listbox(flow_frame,width=30, height= 1)
list_Peak_Meter_Cube_per_Hour.place(x=440, y=195)

list_Peak_Meter_Cube_per_Second= tk.Listbox(flow_frame,width=30, height= 1)
list_Peak_Meter_Cube_per_Second.place(x=440, y=220)

list_Operational_Time_of_WWTP = tk.Listbox(flow_frame,width=30, height= 1)
list_Operational_Time_of_WWTP.place(x=440, y=245)


label_frame_RAW_SEWAGE_TRANSFER_PUMPS = tk.LabelFrame(frame, text='2 RAW SEWAGE TRANSFER PUMPS', font=('times new roman', 13, "bold"),
                                             fg="red", bd=4)
label_frame_RAW_SEWAGE_TRANSFER_PUMPS.place(x=3, y=515, height=250, width=780)

label_Present_Average_Flow_1_DWF=tk.Label(label_frame_RAW_SEWAGE_TRANSFER_PUMPS, text='Present Average Flow (1 DWF): ')
label_Present_Average_Flow_1_DWF.place(x=200, y=10)

label_Pump_Capacity_provided=tk.Label(label_frame_RAW_SEWAGE_TRANSFER_PUMPS, text='Pump Capacity provided: ')
label_Pump_Capacity_provided.place(x=200, y=40)

label_Average_Flow_1_DWF =tk.Label(label_frame_RAW_SEWAGE_TRANSFER_PUMPS, text='Average Flow (1 DWF): 2 Nos: ')
label_Average_Flow_1_DWF .place(x=200, y=70) 

label_No_of_Working_Pumps=tk.Label(label_frame_RAW_SEWAGE_TRANSFER_PUMPS, text='No. of Working Pumps:')
label_No_of_Working_Pumps.place(x=200, y=100)

label_No_of_Standby_Pumps=tk.Label(label_frame_RAW_SEWAGE_TRANSFER_PUMPS, text='No. of Standby Pumps:')
label_No_of_Standby_Pumps.place(x=200, y=130)

label_Pumping_hours=tk.Label(label_frame_RAW_SEWAGE_TRANSFER_PUMPS, text='Pumping hours :  ')
label_Pumping_hours.place(x=200, y=160)

label_Pump_Head=tk.Label(label_frame_RAW_SEWAGE_TRANSFER_PUMPS, text='Pump Head: ')
label_Pump_Head.place(x=200, y=190)

list_Present_Average_Flow_1_DWF = tk.Listbox(label_frame_RAW_SEWAGE_TRANSFER_PUMPS,width=30, height= 1)
list_Present_Average_Flow_1_DWF.place(x=440, y=10)

list_Pump_Capacity_provided = tk.Listbox(label_frame_RAW_SEWAGE_TRANSFER_PUMPS,width=30, height= 1)
list_Pump_Capacity_provided.place(x=440, y=40)

list_Average_Flow_1_DWF_2_Nos = tk.Listbox(label_frame_RAW_SEWAGE_TRANSFER_PUMPS,width=30, height= 1)
list_Average_Flow_1_DWF_2_Nos.place(x=440, y=70)

list_No_of_Working_Pumps = tk.Listbox(label_frame_RAW_SEWAGE_TRANSFER_PUMPS,width=30, height= 1)
list_No_of_Working_Pumps.place(x=440, y=100)

list_No_of_Standby_Pumps= tk.Listbox(label_frame_RAW_SEWAGE_TRANSFER_PUMPS,width=30, height= 1)
list_No_of_Standby_Pumps.place(x=440, y=130)

list_Pumping_hours = tk.Listbox(label_frame_RAW_SEWAGE_TRANSFER_PUMPS,width=30, height= 1)
list_Pumping_hours.place(x=440, y=160)

list_Pump_Head= tk.Listbox(label_frame_RAW_SEWAGE_TRANSFER_PUMPS,width=30, height= 1)
list_Pump_Head.place(x=440, y=190)


def grit_calculate():
    global average_flow
    global peak_factor
    global average_metercube_perhours
    global average_metercube_persecond
    global peak_flow
    global peak_metercube_perhours
    global peak_metercube_persecond
    global Operational_Time_of_WWTP
    global present_average_flow_1_DWF
    global pump_capacity_provided
    global average_flow_1_dWF_2_nos
    global no_of_working_pumps
    global no_of_standby_pumps
    global pumping_hours 
    global pump_head

    No_of_Grit_Chamber = float(entry_No_of_Grit_Chamber.get())
    retention_time = 60
    daily_flow_per_grit_chamber = average_flow
    pre_treatment_metercube_persec = average_metercube_persecond 
    pre_treatment_metercube = float(retention_time * pre_treatment_metercube_persec)
    sludge_to_be_handled_per_day = int(daily_flow_per_grit_chamber)
    assumed_amount_of_grit_in_feacal_sludge = sludge_to_be_handled_per_day * 0.05
    volume_provided = 11.25
     
    no_of_units =1
    design_flow = 'Peak Flow'
    peak_fow_settler = peak_flow
    settler_metercube_perhours = peak_fow_settler/ 24
    settler_metercube_persecond = settler_metercube_perhours / 3600
    inlet_BOD_settler = 300
    bOD_removed_settler = 0.35
    outlet_bOD_settler = (inlet_BOD_settler-(bOD_removed_settler*inlet_BOD_settler))
    inlet_cOD_settler = float(entry_COD_number_inlet.get())
    cOD_removed_settler = 0.56
    outlet_cOD_settler = (inlet_cOD_settler*cOD_removed_settler)
    inlet_tSS_settler = float(entry_TSS_number_inlet.get())
    tSS_removed_settler = 0.50
    outlet_tSS_settler = (inlet_tSS_settler*tSS_removed_settler)
    #####
    tube_pack_data_design_characteristics_settler = ' '
    shape_settler = 'Hexagonal-Chevron'
    hydraulic_radius_settler = 0.015
    settling_area_60_deg_slope_settler = 11
    settling_area_55_deg_slope_settler = 13
    vertical_space_between_tubes_settler = 0.044
    angle_of_inclination_settler = 55
    select_settling_rate_on_the_horizontal_projected_area_of_tube_pack_settler = 1
    unknow_3_settler = 1
    revised_settling_rate_on_the_horizontal_projected_area_of_tube_pack_settler = 0.7
    selected_vertical_depth_of_tube_pack_settler = 2.5
    plan_area_of_the_tube_settler =  (settler_metercube_perhours/revised_settling_rate_on_the_horizontal_projected_area_of_tube_pack_settler)
    volume_of_tube_deck_media_provided_settler = (plan_area_of_the_tube_settler*selected_vertical_depth_of_tube_pack_settler)
    loss_of_volume_of_tube_media_on_account_of_inclination_settler = ((volume_of_tube_deck_media_provided_settler**0.5)/1.428)
    effective_volume_of_tube_media_settler = (volume_of_tube_deck_media_provided_settler - loss_of_volume_of_tube_media_on_account_of_inclination_settler)
    settling_area_of_tube_pack_corresponding_to_inclination_settler = (effective_volume_of_tube_media_settler * settling_area_55_deg_slope_settler)
    actual_settling_rate_on_the_horizontal_projected_area_of_tube_deck = (settler_metercube_perhours/settling_area_of_tube_pack_corresponding_to_inclination_settler)
    unknow_4_settler = actual_settling_rate_on_the_horizontal_projected_area_of_tube_deck

    
    list_Retention_Time.delete(0, tk.END)
    list_Retention_Time.insert(tk.END, f'{retention_time} Seconds')
    
    list_Daily_Flow_per_Grit_Chamber.delete(0, tk.END)
    list_Daily_Flow_per_Grit_Chamber.insert(tk.END, f'{daily_flow_per_grit_chamber} KLD')
    
    list_grit_chamber_unknown_1.delete(0, tk.END)
    list_grit_chamber_unknown_1.insert(tk.END, f'{pre_treatment_metercube_persec} m3/sec')
    
    list_grit_chamber_unknown_2.delete(0, tk.END)
    list_grit_chamber_unknown_2.insert(tk.END, f'{pre_treatment_metercube} m3')
    
    list_Sludge_to_be_handled_per_day.delete(0, tk.END)
    list_Sludge_to_be_handled_per_day.insert(tk.END, f'{sludge_to_be_handled_per_day} m3')
    
    list_Assumed_Amount_of_Grit_in_Feacal_Sludge.delete(0, tk.END)
    list_Assumed_Amount_of_Grit_in_Feacal_Sludge.insert(tk.END, f'{assumed_amount_of_grit_in_feacal_sludge} m3')
    
    list_Volume_Provided.delete(0, tk.END)
    list_Volume_Provided.insert(tk.END, f'{volume_provided} m3')

    
    list_No_of_Units_settler.delete(0, tk.END)
    list_No_of_Units_settler.insert(tk.END, f'{no_of_units} No')
    
    list_Design_Flow_settler.delete(0, tk.END)
    list_Design_Flow_settler.insert(tk.END, f'{design_flow}')
    
    list_Peak_Flow_settler.delete(0, tk.END)
    list_Peak_Flow_settler.insert(tk.END, f'{peak_fow_settler} kLD')
    
    list_settler_unknown1.delete(0, tk.END)
    list_settler_unknown1.insert(tk.END, f'{settler_metercube_perhours} m3/hr')
    
    list_settler_unknown2.delete(0, tk.END)
    list_settler_unknown2.insert(tk.END, f'{settler_metercube_persecond} m3/sec')
    
    list_Inlet_BOD_settler.delete(0, tk.END)
    list_Inlet_BOD_settler.insert(tk.END, f'{inlet_BOD_settler} mg/lt')
    
    list_BOD_Removed_settler.delete(0, tk.END)
    bOD_removed_settler_percentage = (bOD_removed_settler*100)
    list_BOD_Removed_settler.insert(tk.END, f'{bOD_removed_settler_percentage} %')
    
    
    list_Outlet_BOD_settler.delete(0, tk.END)
    list_Outlet_BOD_settler.insert(tk.END, f'{outlet_bOD_settler} mg/lt')
    
    list_Inlet_COD_settler.delete(0, tk.END)
    list_Inlet_COD_settler.insert(tk.END, f'{inlet_cOD_settler }')
    
    list_COD_Removed_settler.delete(0, tk.END)
    cOD_removed_settler_percentage = (cOD_removed_settler*100)
    list_COD_Removed_settler.insert(tk.END, f'{cOD_removed_settler_percentage} %')
    
    list_Outlet_COD_settler.delete(0, tk.END)
    list_Outlet_COD_settler.insert(tk.END, f'{outlet_cOD_settler} mg/lt')
    
    list_Inlet_TSS.delete(0, tk.END)
    list_Inlet_TSS.insert(tk.END, f'{inlet_tSS_settler}')
    
    list_TSS_Removed_settler.delete(0, tk.END)
    tSS_removed_settler_percentage = (tSS_removed_settler*100)
    list_TSS_Removed_settler.insert(tk.END, f'{tSS_removed_settler_percentage} %')
    
    list_Outlet_TSS_settler.delete(0, tk.END)
    list_Outlet_TSS_settler.insert(tk.END, f'{outlet_tSS_settler} mg/lt')
    
    ######################################
    
    list_Tube_Pack_Data_Design_Characteristics_settler.delete(0, tk.END)
    list_Tube_Pack_Data_Design_Characteristics_settler.insert(tk.END, f'{tube_pack_data_design_characteristics_settler}')
    
    list_shape_settler.delete(0, tk.END)
    list_shape_settler.insert(tk.END, f'{shape_settler}')
    
    list_Hydraulic_radius_settler.delete(0, tk.END)
    list_Hydraulic_radius_settler.insert(tk.END, f'{hydraulic_radius_settler} m')
    
    list_Settling_Area_60_deg_slope_settler.delete(0, tk.END)
    list_Settling_Area_60_deg_slope_settler.insert(tk.END, f'{settling_area_60_deg_slope_settler} m2/m3')
    
    list_Settling_Area_55_deg_slope_settler.delete(0, tk.END)
    list_Settling_Area_55_deg_slope_settler.insert(tk.END, f'{settling_area_55_deg_slope_settler} m2/m3')
    
    list_Vertical_Space_between_Tubes_settler.delete(0, tk.END)
    list_Vertical_Space_between_Tubes_settler.insert(tk.END, f'{vertical_space_between_tubes_settler} m')
    
    list_Angle_of_inclination_settler.delete(0, tk.END)
    list_Angle_of_inclination_settler.insert(tk.END, f'{angle_of_inclination_settler} deg')
    
    list_Select_Settling_rate_on_the_horizontal_projected_area_of_Tube_Pack_settler.delete(0, tk.END)
    list_Select_Settling_rate_on_the_horizontal_projected_area_of_Tube_Pack_settler.insert(tk.END, f'{select_settling_rate_on_the_horizontal_projected_area_of_tube_pack_settler} m3/m2/h')
    
    list_settler_unknown_3.delete(0, tk.END)
    list_settler_unknown_3.insert(tk.END, f'{unknow_3_settler}')
    
    list_Revised_Settling_rate_on_the_horizontal_projected_area_of_Tube_Pack_settler.delete(0, tk.END)
    list_Revised_Settling_rate_on_the_horizontal_projected_area_of_Tube_Pack_settler.insert(tk.END, f'{revised_settling_rate_on_the_horizontal_projected_area_of_tube_pack_settler} m3/m2/h')
    
    list_Selected_vertical_depth_of_Tube_Pack_settler.delete(0, tk.END)
    list_Selected_vertical_depth_of_Tube_Pack_settler.insert(tk.END, f'{selected_vertical_depth_of_tube_pack_settler} m')
    
    list_Plan_area_of_the_Tube_Settler.delete(0, tk.END)
    list_Plan_area_of_the_Tube_Settler.insert(tk.END, f'{plan_area_of_the_tube_settler} m2')
    
    
    list_Volume_of_Tube_Deck_media_provided_settler.delete(0, tk.END)
    list_Volume_of_Tube_Deck_media_provided_settler.insert(tk.END, f'{volume_of_tube_deck_media_provided_settler} m3')
    
    list_Loss_of_volume_of_tube_media_on_account_of_inclination_settler.delete(0, tk.END)
    list_Loss_of_volume_of_tube_media_on_account_of_inclination_settler.insert(tk.END, f'{loss_of_volume_of_tube_media_on_account_of_inclination_settler} m3')
    
    list_Effective_Volume_of_Tube_Media_settler.delete(0, tk.END)
    list_Effective_Volume_of_Tube_Media_settler.insert(tk.END, f'{effective_volume_of_tube_media_settler} m3')
    
    list_Settling_area_of_Tube_Pack_corresponding_to_inclination_settler.delete(0, tk.END)
    list_Settling_area_of_Tube_Pack_corresponding_to_inclination_settler.insert(tk.END, f'{settling_area_of_tube_pack_corresponding_to_inclination_settler} m2')
    
    list_Actual_Settling_rate_on_the_horizontal_projected_area_of_tube_deck_settler.delete(0, tk.END)
    list_Actual_Settling_rate_on_the_horizontal_projected_area_of_tube_deck_settler.insert(tk.END, f'{actual_settling_rate_on_the_horizontal_projected_area_of_tube_deck}m3/m2/h')
    
    if unknow_4_settler < 0.7:
        list_Unknown_4_settler.delete(0, tk.END)
        list_Unknown_4_settler.insert(tk.END, 'Hence OK, m3/m2/h')
    else:
        list_Unknown_4_settler.delete(0, tk.END)
        list_Unknown_4_settler.insert(tk.END, 'Size out of index , m3/m2/h')
    
Integrated_screen_fog_and_grit_seprating_mechanism = tk.LabelFrame(frame, text='3 Integrated screen, fog and grit seprating mechanism', font=('times new roman', 13, "bold"),
                                             fg="red", bd=4)
Integrated_screen_fog_and_grit_seprating_mechanism.place(x=3, y=770, height=310, width=780)

label_No_of_Grit_Chamber=tk.Label(Integrated_screen_fog_and_grit_seprating_mechanism, text='No. of Grit Chamber : ')
label_No_of_Grit_Chamber.place(x=200, y=10)
entry_No_of_Grit_Chamber = tk.Entry(Integrated_screen_fog_and_grit_seprating_mechanism )
entry_No_of_Grit_Chamber.place(x=350, y=10)

button_No_of_Grit_Chamber= tk.Button(Integrated_screen_fog_and_grit_seprating_mechanism, text='Grit Calc', command=grit_calculate, fg='white', bg='blue')
button_No_of_Grit_Chamber.place(x=350, y=40)

label_Retention_Time =tk.Label(Integrated_screen_fog_and_grit_seprating_mechanism, text='Retention Time : ')
label_Retention_Time .place(x=200, y=80)

label_Daily_Flow_per_Grit_Chamber=tk.Label(Integrated_screen_fog_and_grit_seprating_mechanism, text='Daily Flow per Grit Chamber : ')
label_Daily_Flow_per_Grit_Chamber.place(x=200, y=110)

label_grit_chamber_unknown_1 =tk.Label(Integrated_screen_fog_and_grit_seprating_mechanism, text='-: ')
label_grit_chamber_unknown_1 .place(x=200, y=140) 

label_grit_chamber_unknown_2=tk.Label(Integrated_screen_fog_and_grit_seprating_mechanism, text='--:')
label_grit_chamber_unknown_2.place(x=200, y=170)

label_Sludge_to_be_handled_per_day=tk.Label(Integrated_screen_fog_and_grit_seprating_mechanism, text='Sludge to be handled per day:')
label_Sludge_to_be_handled_per_day.place(x=200, y=200)

label_Assumed_Amount_of_Grit_in_Feacal_Sludge=tk.Label(Integrated_screen_fog_and_grit_seprating_mechanism, text='Assumed Amount of Grit in Feacal Sludge:  ')
label_Assumed_Amount_of_Grit_in_Feacal_Sludge.place(x=200, y=230)

label_Volume_Provided=tk.Label(Integrated_screen_fog_and_grit_seprating_mechanism, text='Volume Provided : ')
label_Volume_Provided.place(x=200, y=260)


list_Retention_Time = tk.Listbox(Integrated_screen_fog_and_grit_seprating_mechanism,width=30, height= 1)
list_Retention_Time.place(x=440, y=80)

list_Daily_Flow_per_Grit_Chamber = tk.Listbox(Integrated_screen_fog_and_grit_seprating_mechanism,width=30, height= 1)
list_Daily_Flow_per_Grit_Chamber.place(x=440, y=110)

list_grit_chamber_unknown_1 = tk.Listbox(Integrated_screen_fog_and_grit_seprating_mechanism,width=30, height= 1)
list_grit_chamber_unknown_1.place(x=440, y=140)

list_grit_chamber_unknown_2 = tk.Listbox(Integrated_screen_fog_and_grit_seprating_mechanism,width=30, height= 1)
list_grit_chamber_unknown_2.place(x=440, y=170)

list_Sludge_to_be_handled_per_day= tk.Listbox(Integrated_screen_fog_and_grit_seprating_mechanism,width=30, height= 1)
list_Sludge_to_be_handled_per_day.place(x=440, y=200)

list_Assumed_Amount_of_Grit_in_Feacal_Sludge = tk.Listbox(Integrated_screen_fog_and_grit_seprating_mechanism,width=30, height= 1)
list_Assumed_Amount_of_Grit_in_Feacal_Sludge.place(x=440, y=230)

list_Volume_Provided= tk.Listbox(Integrated_screen_fog_and_grit_seprating_mechanism,width=30, height= 1)
list_Volume_Provided.place(x=440, y=260)


label_frame_1_2 = tk.LabelFrame(frame, text='1.2 DESIGN INLET PARAMETERS OF RAW', font=('times new roman', 13, "bold"),
                                             fg="red", bd=4)
label_frame_1_2.place(x=3, y=295, height=220, width=370)

label_BOD5_number_inlet  = tk.Label(label_frame_1_2, text='BOD5 INLET: ' ,fg='blue')
label_BOD5_number_inlet .place(x=2, y=10)
label_BOD5_number_inlet_mg  = tk.Label(label_frame_1_2, text='mg/l', fg='#f00')
label_BOD5_number_inlet_mg .place(x=260, y=10)
entry_BOD5_number_inlet  = tk.Entry(label_frame_1_2)
entry_BOD5_number_inlet .place(x=130, y=10)

label_COD_number_inlet = tk.Label(label_frame_1_2, text='COD INLET: ',fg='blue')
label_COD_number_inlet.place(x=2, y=40)
label_COD_number_inlet_mg = tk.Label(label_frame_1_2, text='mg/l', fg='#f00')
label_COD_number_inlet_mg.place(x=260, y=40)
entry_COD_number_inlet = tk.Entry(label_frame_1_2)
entry_COD_number_inlet.place(x=130, y=40)

label_TSS_number_inlet = tk.Label(label_frame_1_2, text='TSS INLET: ',fg='blue')
label_TSS_number_inlet.place(x=2, y=70)
label_TSS_number_inlet_mg = tk.Label(label_frame_1_2, text='mg/l', fg='#f00')
label_TSS_number_inlet_mg.place(x=260, y=70)
entry_TSS_number_inlet = tk.Entry(label_frame_1_2)
entry_TSS_number_inlet.place(x=130, y=70)

label_TKN_as_n_inlet = tk.Label(label_frame_1_2, text='TKN (as N) INLET: ',fg='blue')
label_TKN_as_n_inlet.place(x=2, y=100)
label_TKN_as_n_inlet_mg = tk.Label(label_frame_1_2, text='mg/l', fg='#f00')
label_TKN_as_n_inlet_mg.place(x=260, y=100)
entry_TKN_as_n_inlet = tk.Entry(label_frame_1_2)
entry_TKN_as_n_inlet.place(x=130, y=100)

label_TP_as_po4_inlet = tk.Label(label_frame_1_2, text='TP (as PO4) INLET: ',fg='blue')
label_TP_as_po4_inlet.place(x=2, y=130)
label_TP_as_po4_inlet_mg = tk.Label(label_frame_1_2, text='mg/l', fg='#f00')
label_TP_as_po4_inlet_mg.place(x=260, y=130)
entry_TP_as_po4_inlet = tk.Entry(label_frame_1_2)
entry_TP_as_po4_inlet.place(x=130, y=130)


label_frame_1_3 = tk.LabelFrame(frame, text='1.3 DESIGN OUTLET PARAMETERS OF TREATED', font=('times new roman', 13, "bold"),
                                             fg="red", bd=4)
label_frame_1_3.place(x=375, y=295, height=220, width=405)

label_BOD5_20o_C_outlet  = tk.Label(label_frame_1_3, text='BOD5 @ 20o C OUTLET: ',fg='blue')
label_BOD5_20o_C_outlet.place(x=2, y=10)
label_BOD5_20o_C_outlet_mg  = tk.Label(label_frame_1_3, text='mg/l', fg='#f00')
label_BOD5_20o_C_outlet_mg.place(x=330, y=10)
entry_BOD5_20o_C_outlet = tk.Entry(label_frame_1_3)
entry_BOD5_20o_C_outlet.place(x=190, y=10)

label_COD_number_outlet = tk.Label(label_frame_1_3, text='BOD5 COD OUTLET: ',fg='blue')
label_COD_number_outlet.place(x=2, y=40)
label_COD_number_outlet_mg = tk.Label(label_frame_1_3, text='mg/l', fg='#f00')
label_COD_number_outlet_mg.place(x=330, y=40)
entry_COD_number_outlet = tk.Entry(label_frame_1_3)
entry_COD_number_outlet.place(x=190, y=40)

label_TSS_number_outlet = tk.Label(label_frame_1_3, text='BOD5 TSS OUTLET: ',fg='blue')
label_TSS_number_outlet.place(x=2, y=70)
label_TSS_number_outlet_mg = tk.Label(label_frame_1_3, text='mg/l', fg='#f00')
label_TSS_number_outlet_mg.place(x=330, y=70)
entry_TSS_number_outlet = tk.Entry(label_frame_1_3)
entry_TSS_number_outlet.place(x=190, y=70)

label_NH3N_as_N_number_outlet = tk.Label(label_frame_1_3, text='NH3-N (as N) OUTLET: ',fg='blue')
label_NH3N_as_N_number_outlet.place(x=2, y=100)
label_NH3N_as_N_number_outlet_mg = tk.Label(label_frame_1_3, text='mg/l', fg='#f00')
label_NH3N_as_N_number_outlet_mg.place(x=330, y=100)
entry_NH3N_as_N_number_outlet = tk.Entry(label_frame_1_3)
entry_NH3N_as_N_number_outlet.place(x=190, y=100)

label_TN_as_N_number_outlet = tk.Label(label_frame_1_3, text='TN (as N) OUTLET: ',fg='blue')
label_TN_as_N_number_outlet.place(x=2, y=130)
label_TN_as_N_number_outlet_mg = tk.Label(label_frame_1_3, text='mg/l', fg='#f00')
label_TN_as_N_number_outlet_mg.place(x=330, y=130)
entry_TN_as_N_number_outlet = tk.Entry(label_frame_1_3)
entry_TN_as_N_number_outlet.place(x=190, y=130)

label_TP_as_PO4_number_outlet = tk.Label(label_frame_1_3, text='TP (as PO4) OUTLET: ',fg='blue')
label_TP_as_PO4_number_outlet.place(x=2, y=160)
label_TP_as_PO4_number_outlet_mg = tk.Label(label_frame_1_3, text='mg/l', fg='#f00')
label_TP_as_PO4_number_outlet_mg.place(x=330, y=160)
entry_TP_as_PO4_number_outlet = tk.Entry(label_frame_1_3)
entry_TP_as_PO4_number_outlet.place(x=190, y=160)


PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER = tk.LabelFrame(frame, text='4 PRIMARY TREATMENT UNIT - TUBE DECK SETTLER', font=('times new roman', 13, "bold"),
                                             fg="red", bd=4)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER.place(x=3, y=1080, height=1000, width=780)

label_No_of_Units_settler =tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='No. of Units : ')
label_No_of_Units_settler .place(x=20, y=10)

label_Design_Flow_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Design Flow : ')
label_Design_Flow_settler.place(x=20, y=40)

label_Peak_Flow_settler =tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Peak Flow: ')
label_Peak_Flow_settler .place(x=20, y=70) 

label_settler_unknown_1=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='-:')
label_settler_unknown_1.place(x=20, y=100)

label_settler_unknown_2=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='--:')
label_settler_unknown_2.place(x=20, y=130)

label_Inlet_BOD_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Inlet BOD:  ')
label_Inlet_BOD_settler.place(x=20, y=160)

label_BOD_Removed_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='BOD Removed : ')
label_BOD_Removed_settler.place(x=20, y=190)

label_Outlet_BOD_settler =tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Outlet BOD : ')
label_Outlet_BOD_settler .place(x=20, y=220)

label_Inlet_COD_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Inlet COD : ')
label_Inlet_COD_settler.place(x=20, y=250)

label_COD_Removed_settler =tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='COD Removed: ')
label_COD_Removed_settler.place(x=20, y=280)

label_Outlet_COD_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Outlet COD:')
label_Outlet_COD_settler.place(x=20, y=310)

label_Inlet_TSS_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Inlet TSS:')
label_Inlet_TSS_settler.place(x=20, y=340)

label_TSS_Removed_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='TSS Removed:  ')
label_TSS_Removed_settler.place(x=20, y=370)

label_Outlet_TSS_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Outlet TSS : ')
label_Outlet_TSS_settler.place(x=20, y=400)


label_Tube_Pack_Data_Design_Characteristics_settler =tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Tube Pack Data (Design Characteristics) : ', fg='blue')
label_Tube_Pack_Data_Design_Characteristics_settler.place(x=20, y=430)

label_Shape_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Shape : ')
label_Shape_settler.place(x=20, y=460)

label_Hydraulic_radius_settler =tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Hydraulic radius : ')
label_Hydraulic_radius_settler.place(x=20, y=490) 

label_Settling_Area_deg_slope_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Settling Area :60 deg slope :')
label_Settling_Area_deg_slope_settler.place(x=20, y=520)

label_Settling_Area_deg_slope_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Settling Area : 55 deg slope :')
label_Settling_Area_deg_slope_settler.place(x=20, y=550)

label_Vertical_Space_between_Tubes_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Vertical Space between Tubes :  ')
label_Vertical_Space_between_Tubes_settler.place(x=20, y=580)

label_Angle_of_inclination_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Angle of inclination : ')
label_Angle_of_inclination_settler.place(x=20, y=610)

label_Select_Settling_rate_on_the_horizontal_projected_area_Tube_Pack_settler =tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Select, Settling rate on the horizontal projected area of Tube Pack : ')
label_Select_Settling_rate_on_the_horizontal_projected_area_Tube_Pack_settler .place(x=20, y=640)

label_unknown_3_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='--- : ')
label_unknown_3_settler.place(x=20, y=670)

label_Revised_horizontal_projected_area_of_Tube_Pack_settler =tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Revised Settling rate on the horizontal projected area of Tube Pack: ')
label_Revised_horizontal_projected_area_of_Tube_Pack_settler.place(x=20, y=700)

label_Selected_vertical_depth_of_Tube_Pack_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Selected vertical depth of Tube Pack :')
label_Selected_vertical_depth_of_Tube_Pack_settler.place(x=20, y=730)

label_Plan_area_of_the_Tube_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Plan area of the Tube Settler :')
label_Plan_area_of_the_Tube_settler.place(x=20, y=760)

label_Volume_of_Tube_Deck_media_provided_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Volume of Tube Deck media provided :  ')
label_Volume_of_Tube_Deck_media_provided_settler.place(x=20, y=790)

label_Loss_volume_tube_media_on_account_of_inclination_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Loss of volume of tube media on account of inclination : ')
label_Loss_volume_tube_media_on_account_of_inclination_settler.place(x=20, y=820)

label_Effective_Volume_of_Tube_Media_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Effective Volume of Tube Media :')
label_Effective_Volume_of_Tube_Media_settler.place(x=20, y=850)

label_Settling_area_of_Tube_Pack_corresponding_inclination_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Settling area of Tube Pack corresponding to inclination :')
label_Settling_area_of_Tube_Pack_corresponding_inclination_settler.place(x=20, y=880)

label_Actual_Settling_horizontal_projected_area_tube_deck_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='Actual Settling rate on the horizontal projected area of tube deck :  ')
label_Actual_Settling_horizontal_projected_area_tube_deck_settler.place(x=20, y=910)

label_unknown_4_settler=tk.Label(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER, text='---- : ')
label_unknown_4_settler.place(x=20, y=940)

list_No_of_Units_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_No_of_Units_settler.place(x=440, y=10)

list_Design_Flow_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Design_Flow_settler.place(x=440, y=40)

list_Peak_Flow_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Peak_Flow_settler.place(x=440, y=70)

list_settler_unknown1 = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_settler_unknown1.place(x=440, y=100)

list_settler_unknown2= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_settler_unknown2.place(x=440, y=130)

list_Inlet_BOD_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Inlet_BOD_settler.place(x=440, y=160)

list_BOD_Removed_settler= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_BOD_Removed_settler.place(x=440, y=190)

list_Outlet_BOD_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Outlet_BOD_settler.place(x=440, y=220)

list_Inlet_COD_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Inlet_COD_settler.place(x=440, y=250)

list_COD_Removed_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_COD_Removed_settler.place(x=440, y=280)

list_Outlet_COD_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Outlet_COD_settler.place(x=440, y=310)

list_Inlet_TSS= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Inlet_TSS.place(x=440, y=340)

list_TSS_Removed_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_TSS_Removed_settler.place(x=440, y=370)

list_Outlet_TSS_settler= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Outlet_TSS_settler.place(x=440, y=400)

#####################

list_Tube_Pack_Data_Design_Characteristics_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Tube_Pack_Data_Design_Characteristics_settler.place(x=440, y=430)

list_shape_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_shape_settler.place(x=440, y=460)

list_Hydraulic_radius_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Hydraulic_radius_settler.place(x=440, y=490)

list_Settling_Area_60_deg_slope_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Settling_Area_60_deg_slope_settler.place(x=440, y=520)

list_Settling_Area_55_deg_slope_settler= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Settling_Area_55_deg_slope_settler.place(x=440, y=550)

list_Vertical_Space_between_Tubes_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Vertical_Space_between_Tubes_settler.place(x=440, y=580)

list_Angle_of_inclination_settler= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Angle_of_inclination_settler.place(x=440, y=610)

list_Select_Settling_rate_on_the_horizontal_projected_area_of_Tube_Pack_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Select_Settling_rate_on_the_horizontal_projected_area_of_Tube_Pack_settler.place(x=440, y=640)

list_settler_unknown_3 = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_settler_unknown_3.place(x=440, y=670)

list_Revised_Settling_rate_on_the_horizontal_projected_area_of_Tube_Pack_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1) 
list_Revised_Settling_rate_on_the_horizontal_projected_area_of_Tube_Pack_settler.place(x=440, y=700)

list_Selected_vertical_depth_of_Tube_Pack_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Selected_vertical_depth_of_Tube_Pack_settler.place(x=440, y=730)

list_Plan_area_of_the_Tube_Settler= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Plan_area_of_the_Tube_Settler.place(x=440, y=760)

list_Volume_of_Tube_Deck_media_provided_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Volume_of_Tube_Deck_media_provided_settler.place(x=440, y=790)

list_Loss_of_volume_of_tube_media_on_account_of_inclination_settler= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Loss_of_volume_of_tube_media_on_account_of_inclination_settler.place(x=440, y=820)

list_Effective_Volume_of_Tube_Media_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Effective_Volume_of_Tube_Media_settler.place(x=440, y=850)

list_Settling_area_of_Tube_Pack_corresponding_to_inclination_settler= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Settling_area_of_Tube_Pack_corresponding_to_inclination_settler.place(x=440, y=880)

list_Actual_Settling_rate_on_the_horizontal_projected_area_of_tube_deck_settler = tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Actual_Settling_rate_on_the_horizontal_projected_area_of_tube_deck_settler.place(x=440, y=910)

list_Unknown_4_settler= tk.Listbox(PRIMARY_TREATMENT_UNIT_TUBE_DECK_SETTLER,width=30, height= 1)
list_Unknown_4_settler.place(x=440, y=940)

window.mainloop()
