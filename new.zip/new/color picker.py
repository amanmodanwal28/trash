import tkinter as tk
from tkinter import colorchooser


# color_hex = "#ecd1b9"
color_hex = "#DDD0C8"

def pick_color():
    color = colorchooser.askcolor()[1]  # Ask the user to choose a color and get the hex code
    if color:
        color_label.config(foreground=color)  # Set the foreground color of the Label
        root.configure(bg=color)
        print(color)

# Create the main window
root = tk.Tk()
root.title("Color Picker")

# Create a Label widget
color_label = tk.Label(root, text="Change the foreground color", font=("Helvetica", 18), bg="#323232")
color_label.pack(pady=20)

# Create a button to open the color dialog
color_button = tk.Button(root, text="Pick a Color", command=pick_color, bg="#323232", foreground="white", activeforeground="white",
                         activebackground="black")
color_button.pack()

# Start the Tkinter main loop
root.mainloop()
