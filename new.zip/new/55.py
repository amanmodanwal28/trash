# from tkinter import *
# ab = Tk()
#
# text_var = StringVar()
# text = []
# # print(len(text))
# # def only_numbers(char):
# #     lenth = len(text)
# #     print(lenth, 1111)
# #     text.append(char)
# #     print(len(text), 2222)
# #     print(char)
# #     if keysym == "BackSpace":
# #         text.append(char)
# #         print("done")
# #     print("".join(text))
# #     return char
# def only_numbers1(ev):
#     # print(ip_code_change.get())
#     en = str(ev)
#     print(en.find("char="))
#     if en.find("BackSpace") == 70:
#         text.append(char)
#         print("done")
#     else:
#         text.append("")
#         print("done")
#     print("".join(text))
#     print(ev)
# # validation = ab.register(only_numbers)
# # ip_code_change = Entry(ab, font=('arial', 11, 'bold'), width=24, justify=RIGHT, validate="key", validatecommand=(validation, '%S'))
# ip_code_change = Entry(ab, font=('arial', 11, 'bold'), width=24, justify=RIGHT)
# ip_code_change.place(x=0, y=0)
# ip_code_change.bind("<Key>", only_numbers1)
# # ip_code_change.bind("<BackSpace>", only_numbers1)
#
# ab.mainloop()
#
# f = "wehjgiklfe"
# print(f.find("we"))
#
#
#
#
#
#
# # Python program to
# # Illustrate Separator
# # widget
#
#
# # # Import required modules
# # from tkinter import *
# # from tkinter import ttk
# #
# #
# # # Main tkinter window
# # x = Tk()
# # x.geometry("400x300")
# #
# #
# # # Label Widget
# # # b = Label(x, bg="#f5f5f5", bd=4, relief=RAISED, text="With Separator")
# # # b.place(relx=0.03, rely=0.1, relheight=0.8, relwidth=0.4)
# #
# #
# # # Separator object
# # separator = Separator(x, orient=HORIZONTAL )
# # separator.place(x=3, y=30, relheight=0.8, relwidth=0.4)
# #
# #
# # # Label Widget
# # # a = Label(x, bg="#f5f5f5", bd=4, relief=RAISED, text="With Separator")
# # # a.place(relx=0.5, rely=0.1, relheight=0.8, relwidth=0.4)
# #
# #
# # mainloop()

