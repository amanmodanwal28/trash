from main import *
from tkinter import *
import tkinter.ttk
from tkinter import messagebox
import pyodbc
import tkinter as tk
import trigger1
import xml.etree.ElementTree as ET
import tkinterDnD
from tkinter import filedialog as fd
import shutil
import os
from playsound import playsound
from PIL import Image, ImageTk
from tkVideoPlayer import TkinterVideo
import sqlite3
# from tkvideo import tkvideo

num_of_combo_available_global_actionMess = 1

class MainApplication6:
    def __init__(self):
        global num_of_combo_available_global_actionMess
        self.top = tkinterDnD.Tk()
        self.top.title("Create Message")
        self.top.geometry("900x600+200+40")
        self.top.resizable(False, False)
        self.top.iconbitmap("logo2.ico")
        self.top.protocol("WM_DELETE_WINDOW", self.on_exit)
        animal = trigger1.Reptile(tk.Frame)
        num_of_combo_available_global_actionMess = animal.return_value()
        # call class method
        self.aa = animal.print_animal()
        self.message_dis = animal.var2()
        self.action_ID = animal.action_ID_num()
        ################################### message type frame ##############################
        self.message_type_frame = LabelFrame(self.top, relief=RIDGE, text='Message Type', font=('times new roman', 13, "bold"),
                                             fg="red", bd=4)
        self.message_type_frame.place(x=0, y=0, height=80, width=900)

        self.var = IntVar(self.message_type_frame)
        self.var_video = 0
        self.True_var = 1
        # self.var.set(0)
        self.audio_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Audio', font=('arial', 11, 'bold'), command=self.audio_radio_button_select, value=1)
        self.audio_mess.place(x=20, y=10)

        self.text_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Text', font=('arial', 11, 'bold'), command=self.text_radio_button_select, value=2)
        self.text_mess.place(x=150, y=10)

        self.video_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Video', font=('arial', 11, 'bold'), command=self.video_radio_button_select, value=3)
        self.video_mess.place(x=280, y=10)

        self.banner_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Image', font=('arial', 11, 'bold'), command=self.banner_radio_button_select, value=4)
        self.banner_mess.place(x=410, y=10)

        # self.logo_mess = Radiobutton(self.message_type_frame, variable=self.var, text='Logo', font=('arial', 11, 'bold'), command=self.logo_radio_button_select, value=5)
        # self.logo_mess.place(x=540, y=10)

        ################################### message type frame ##############################
        ######################### two label frame  in mai window frame ################################
        self.universal_main_frame = LabelFrame(self.top, relief=RIDGE)
        self.universal_main_frame.place(x=0, y=85, height=335, width=900)

        self.universal_mess_main_frame = LabelFrame(self.top, relief=RIDGE)
        self.universal_mess_main_frame.place(x=0, y=422, height=176, width=900)
        self.data_fix_mess = []
        self.video_radio = False
        self.text_radio = False
        self.audio_radio = False
        self.logo_radio = False
        self.banner_radio = False

        # self.var.set(value=2)
        # if self.aa == "front display right" or self.aa == "front display left":
        if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":
            self.video_radio_button_select()
            self.video_radio = True
            self.var_video = 1
            self.var.set(value=3)
        elif (self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or
              self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left" or self.aa == "32"):
            self.text_radio_button_select()
            self.text_radio = True
            self.var.set(value=2)
        elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
            self.audio_radio_button_select()
            self.audio_radio = True
            self.var.set(value=1)

        elif self.aa == "Interior Banner" or self.aa == "interior Banner":
            self.banner_radio_button_select()
            self.banner_radio = True
            self.var.set(value=4)
        # elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
        #     self.logo_radio_button_select()
        #     self.logo_radio = True
        #     self.var.set(value=5)

        self.top.mainloop()

    @staticmethod
    def sql_data(sql_query):
        print(101)
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(sql_query)
        if sql_query.find("Select") > -1 or sql_query.find("SELECT") > -1 or sql_query.find("select") > -1:
            data = my_cursor.fetchall()
            conn.commit()
            conn.close()
            return data
        else:
            conn.commit()
            conn.close()
    def audio_radio_button_select(self):
        print(114)
        self.text_mess.configure(state=DISABLED)
        self.video_mess.configure(state=DISABLED)
        self.banner_mess.configure(state=DISABLED)
        # self.logo_mess.configure(state=DISABLED)

        self.audio_mess_upper_frame = LabelFrame(self.universal_main_frame, relief=RIDGE)
        self.audio_mess_upper_frame.place(x=2, y=2, height=327, width=892)
        #################################################################################
        #################################################################################
        #################################################################################
        def drag_command(event):
            print(126)
            for selected_item in self.trigger_audio_table.selection():
                item = self.trigger_audio_table.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "["+record[0]+"]"

        self.audio_language1 = LabelFrame(self.audio_mess_upper_frame, relief=RIDGE, text='Fixed Message Part', font=('times new roman', 13, "bold"),
                                          fg="red", bd=4)
        self.audio_language1.place(x=0, y=0, height=290, width=290)
        self.scroll_y_audio = Scrollbar(self.audio_language1, orient=VERTICAL)
        self.trigger_audio_table = tkinter.ttk.Treeview(self.audio_language1, columns="trigg",
                                                        yscrollcommand=self.scroll_y_audio.set)
        self.scroll_y_audio.pack(side=RIGHT, fill=Y)
        self.scroll_y_audio.config(command=self.trigger_audio_table.yview)
        self.trigger_audio_table.heading("trigg", text="Fixed Message Part")
        self.trigger_audio_table.pack(fill=BOTH, expand=1)
        self.trigger_audio_table.register_drag_source("*")
        self.trigger_audio_table.bind("<<DragInitCmd>>", drag_command)
        self.trigger_audio_table["show"] = "headings"

        def focus_fix_treeview(event=""):
            print(147)
            self.cursor_row = self.trigger_audio_table.focus()
            self.content = self.trigger_audio_table.item(self.cursor_row)
            self.data_fix_mess = self.content["values"]
        self.trigger_audio_table.bind("<ButtonRelease>", focus_fix_treeview)

        def treeview_data_tbl():
            print(154)
            data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MA%'")
            if len(data) != 0:
                self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
                for i in data:
                    self.trigger_audio_table.insert("", END, values=list(i))
            else:
                self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
        treeview_data_tbl()
        ########################################################################################
        ########################################################################################
        ########################################################################################
        def drag_command(event):
            print(167)
            for selected_item in self.trigger_audio_table2.selection():
                item = self.trigger_audio_table2.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "{"+record[0]+"}"

        self.audio_language2 = LabelFrame(self.audio_mess_upper_frame, relief=RIDGE, text='Keywords (variable Part)', font=('times new roman', 13, "bold"),
                                          fg="red", bd=4)
        self.audio_language2.place(x=300, y=0, height=290, width=290)
        self.scroll_audio2 = Scrollbar(self.audio_language2, orient=VERTICAL)
        self.trigger_audio_table2 = tkinter.ttk.Treeview(self.audio_language2, columns="trigg",
                                                         yscrollcommand=self.scroll_audio2.set)
        self.scroll_audio2.pack(side=RIGHT, fill=Y)
        self.scroll_audio2.config(command=self.trigger_audio_table2.yview)
        self.trigger_audio_table2.heading("trigg", text="Keywords")
        self.trigger_audio_table2.pack(fill=BOTH, expand=1)
        self.trigger_audio_table2.register_drag_source("*")
        self.trigger_audio_table2.bind("<<DragInitCmd>>", drag_command)
        self.trigger_audio_table2["show"] = "headings"
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("stationCode"):
            it = i.find("name").text
            self.trigger_audio_table2.insert("", END, values=it)


        ##################################################################################################
        ##################################################################################################
        ##################################################################################################
        def drag_command(event):
            print(197)
            for selected_item in self.action_markup_table3.selection():
                item = self.action_markup_table3.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "<"+record[0]+">"+",</"+record[0]+">"


        self.audio_language3 = LabelFrame(self.audio_mess_upper_frame, relief=RIDGE, text='Markup Code', font=('times new roman', 13, "bold"),
                                          fg="red", bd=4)
        self.audio_language3.place(x=600, y=0, height=290, width=290)

        self.scroll_markup = Scrollbar(self.audio_language3, orient=VERTICAL)
        self.action_markup_table3 = tkinter.ttk.Treeview(self.audio_language3, columns="trigg",
                                                         yscrollcommand=self.scroll_markup.set)
        self.scroll_markup.pack(side=RIGHT, fill=Y)
        self.scroll_markup.config(command=self.action_markup_table3.yview)
        self.action_markup_table3.heading("trigg", text="Markup Code")
        self.action_markup_table3.pack(fill=BOTH, expand=1)
        self.action_markup_table3.register_drag_source("*")
        self.action_markup_table3.bind("<<DragInitCmd>>", drag_command)
        self.action_markup_table3["show"] = "headings"
        xml_data_audio = ET.parse("projectinfo.xml")
        root = xml_data_audio.getroot()
        for i in root.findall("markupCode"):
            # self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
            it1 = i.find("group").text
            if int(it1) == 3:
                it = i.find("name").text
                self.action_markup_table3.insert("", END, values=it)

        ################################################################################################
        ################################################################################################
        ################################################################################################

        self.audio_message_new = Button(self.audio_mess_upper_frame, text="New", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top)
        self.audio_message_new.place(x=10, y=293)

        self.audio_message_edit = Button(self.audio_mess_upper_frame, text="Edit", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top_update)
        self.audio_message_edit.place(x=110, y=293)

        self.audio_message_delete = Button(self.audio_mess_upper_frame, text="Delete", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.delete_all_message_tbl_sql)
        self.audio_message_delete.place(x=210, y=293)

        # self.audio_mess_upper_frame1 = LabelFrame(self.universal_mess_main_frame, relief=RIDGE)
        # self.audio_mess_upper_frame1.place(x=2, y=2, height=168, width=892)
        #
        # self.audio_message_label = Label(self.audio_mess_upper_frame1, text='Audio Message', font=('times new roman', 13, "bold"),
        #                                  fg="red", bd=4)
        # self.audio_message_label.place(x=0, y=0)
        #
        # self.audio_message_ok = Button(self.audio_mess_upper_frame1, text="Ok", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.save_data_in_sql)
        # self.audio_message_ok.place(x=700, y=134)
        #
        # self.audio_message_cancel = Button(self.audio_mess_upper_frame1, text="Cancel", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.on_exit)
        # self.audio_message_cancel.place(x=800, y=134)
        self.message()

    def text_radio_button_select(self):
        print(255)
        if not self.var_video:
            self.audio_mess.configure(state=DISABLED)
            self.video_mess.configure(state=DISABLED)
            self.banner_mess.configure(state=DISABLED)
            # self.logo_mess.configure(state=DISABLED)
        self.text_mess_upper_frame = LabelFrame(self.universal_main_frame, relief=RIDGE)
        self.text_mess_upper_frame.place(x=2, y=2, height=327, width=892)

        def drag_command(event):
            print(264)
            for selected_item in self.trigger_text_table.selection():
                item = self.trigger_text_table.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "["+record[0]+"]"

        self.fixed_msg_part = LabelFrame(self.text_mess_upper_frame, relief=RIDGE, text='Fixed Message Part', font=('times new roman', 13, "bold"),
                                         fg="red", bd=4)
        self.fixed_msg_part.place(x=0, y=0, height=290, width=290)
        self.scroll_y_text = Scrollbar(self.fixed_msg_part, orient=VERTICAL)
        self.trigger_text_table = tkinter.ttk.Treeview(self.fixed_msg_part, columns="trigg",
                                                       yscrollcommand=self.scroll_y_text.set)
        self.scroll_y_text.pack(side=RIGHT, fill=Y)
        self.scroll_y_text.config(command=self.trigger_text_table.yview)
        self.trigger_text_table.heading("trigg", text="Fixed Message Part")
        self.trigger_text_table.pack(fill=BOTH, expand=1)
        self.trigger_text_table.register_drag_source("*")
        self.trigger_text_table.bind("<<DragInitCmd>>", drag_command)
        self.trigger_text_table["show"] = "headings"

        def focus_fix_treeview(event=""):
            self.cursor_row = self.trigger_text_table.focus()
            self.content = self.trigger_text_table.item(self.cursor_row)
            self.data_fix_mess = self.content["values"]
        self.trigger_text_table.bind("<ButtonRelease>", focus_fix_treeview)

        def treeview_data_tbl():
            print(291)
            data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MT%'")

            if len(data) != 0:
                self.trigger_text_table.delete(*self.trigger_text_table.get_children())
                for i in data:
                    self.trigger_text_table.insert("", END, values=list(i))
            else:
                self.trigger_text_table.delete(*self.trigger_text_table.get_children())
        treeview_data_tbl()

        ################################################################################################
        ################################################################################################
        def drag_command(event):
            cursor_row = self.trigger_text_table2.focus()
            item = self.trigger_text_table2.item(cursor_row)
            record = item["values"]
            return tkinterDnD.COPY, "DND_Text", "{"+record[0]+"}"


        self.key_var_part = LabelFrame(self.text_mess_upper_frame, relief=RIDGE, text='Keywords Variable Parts', font=('times new roman', 13, "bold"),
                                       fg="red", bd=4)
        self.key_var_part.place(x=300, y=0, height=290, width=290)

        self.scroll_text2 = Scrollbar(self.key_var_part, orient=VERTICAL)
        self.trigger_text_table2 = tkinter.ttk.Treeview(self.key_var_part, columns="trigg",
                                                        yscrollcommand=self.scroll_text2.set)
        self.scroll_text2.pack(side=RIGHT, fill=Y)
        self.scroll_text2.config(command=self.trigger_text_table2.yview)
        self.trigger_text_table2.heading("trigg", text="Keywords")
        self.trigger_text_table2.pack(fill=BOTH, expand=1)
        self.trigger_text_table2.register_drag_source("*")
        self.trigger_text_table2.bind("<<DragInitCmd>>", drag_command)
        self.trigger_text_table2["show"] = "headings"
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("stationCode"):
            it = i.find("name").text
            self.trigger_text_table2.insert("", END, values=it)

        ################################################################################################
        ################################################################################################

        def drag_command(event):
            for selected_item in self.trigger_text_table3.selection():
                item = self.trigger_text_table3.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "<"+record[0]+">"+",</"+record[0]+">"

        self.markup_code_frmt = LabelFrame(self.text_mess_upper_frame, relief=RIDGE, text='Markup Codes (Formatting)', font=('times new roman', 13, "bold"),
                                           fg="red", bd=4)
        self.markup_code_frmt.place(x=600, y=0, height=290, width=290)

        self.scroll_text = Scrollbar(self.markup_code_frmt, orient=VERTICAL)
        self.trigger_text_table3 = tkinter.ttk.Treeview(self.markup_code_frmt, columns="trigg",
                                                        yscrollcommand=self.scroll_text.set)
        self.scroll_text.pack(side=RIGHT, fill=Y)
        self.scroll_text.config(command=self.trigger_text_table3.yview)
        self.trigger_text_table3.heading("trigg", text="Markup Code")
        self.trigger_text_table3.pack(fill=BOTH, expand=1)
        self.trigger_text_table3.register_drag_source("*")
        self.trigger_text_table3.bind("<<DragInitCmd>>", drag_command)
        self.trigger_text_table3["show"] = "headings"
        xml_data_text = ET.parse("projectinfo.xml")
        root = xml_data_text.getroot()
        for i in root.findall("markupCode"):
            it = i.find("name").text
            self.trigger_text_table3.insert("", END, values=it)

        ################################################################################################
        ################################################################################################

        self.text_message_new = Button(self.text_mess_upper_frame, text="New", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top)
        self.text_message_new.place(x=10, y=293)

        self.text_message_edit = Button(self.text_mess_upper_frame, text="Edit", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top_update)
        self.text_message_edit.place(x=110, y=293)

        self.text_message_delete = Button(self.text_mess_upper_frame, text="Delete", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.delete_all_message_tbl_sql)
        self.text_message_delete.place(x=210, y=293)

        # self.full_mess_upper_frame = LabelFrame(self.universal_mess_main_frame, relief=RIDGE)
        # self.full_mess_upper_frame.place(x=2, y=2, height=168, width=892)
        #
        # self.full_message_label = Label(self.full_mess_upper_frame, text='Text Message', font=('times new roman', 13, "bold"),
        #                                 fg="red", bd=4)
        # self.full_message_label.place(x=0, y=0)
        #
        # # self.full_message_frame = Frame(self.full_mess_upper_frame, relief=RIDGE, bd=4)
        # # self.full_message_frame.place(x=0, y=26, height=105, width=888)
        #
        # self.full_message_ok = Button(self.full_mess_upper_frame, text="Ok", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.save_data_in_sql)
        # self.full_message_ok.place(x=700, y=134)
        #
        # self.full_message_cancel = Button(self.full_mess_upper_frame, text="Cancel", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.on_exit)
        # self.full_message_cancel.place(x=800, y=134)
        self.message()
    def video_radio_button_select(self):
        print(389)
        self.audio_mess.configure(state=DISABLED)
        # self.text_mess.configure(state=DISABLED)
        # self.banner_mess.configure(state=DISABLED)
        # self.logo_mess.configure(state=DISABLED)
        self.video_mess_upper_frame = LabelFrame(self.universal_main_frame, relief=RIDGE)
        self.video_mess_upper_frame.place(x=2, y=2, height=327, width=892)
        ##################################################################################################
        ##################################################################################################
        def drag_command(event):
            for selected_item in self.trigger_left_table.selection():
                item = self.trigger_left_table.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "["+record[0]+"]"

        self.video_language1 = LabelFrame(self.video_mess_upper_frame, relief=RIDGE, text='Fixed Message Part', font=('times new roman', 13, "bold"),
                                          fg="red", bd=4)
        self.video_language1.place(x=0, y=0, height=290, width=290)
        self.scroll_y = Scrollbar(self.video_language1, orient=VERTICAL)
        self.trigger_left_table = tkinter.ttk.Treeview(self.video_language1, columns="trigg",
                                                       yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.scroll_y.config(command=self.trigger_left_table.yview)
        self.trigger_left_table.heading("trigg", text="Fixed Message Part")
        self.trigger_left_table.pack(fill=BOTH, expand=1)
        self.trigger_left_table.register_drag_source("*")
        self.trigger_left_table.bind("<<DragInitCmd>>", drag_command)
        self.trigger_left_table["show"] = "headings"

        def focus_fix_treeview(event=""):
            self.cursor_row = self.trigger_left_table.focus()
            self.content = self.trigger_left_table.item(self.cursor_row)
            self.data_fix_mess = self.content["values"]
        self.trigger_left_table.bind("<ButtonRelease>", focus_fix_treeview)

        def treeview_data_tbl():
            data = self.sql_data(f"SELECT description,[name] from messageA where name like'%MV%'")

            if len(data) != 0:
                self.trigger_left_table.delete(*self.trigger_left_table.get_children())
                for i in data:
                    self.trigger_left_table.insert("", END, values=list(i))
            else:
                self.trigger_left_table.delete(*self.trigger_left_table.get_children())
        treeview_data_tbl()

        ##################################################################################################
        ##################################################################################################
        def drag_command(event):
            for selected_item in self.trigger_video_table2.selection():
                item = self.trigger_video_table2.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "{"+record[0]+"}"

        self.video_language2 = LabelFrame(self.video_mess_upper_frame, relief=RIDGE, text='Keywords (variable Part)', font=('times new roman', 13, "bold"),
                                          fg="red", bd=4)
        self.video_language2.place(x=300, y=0, height=290, width=290)
        self.scroll_video = Scrollbar(self.video_language2, orient=VERTICAL)
        self.trigger_video_table2 = tkinter.ttk.Treeview(self.video_language2, columns="trigg",
                                                         yscrollcommand=self.scroll_video.set)
        self.scroll_video.pack(side=RIGHT, fill=Y)
        self.scroll_video.config(command=self.trigger_video_table2.yview)
        self.trigger_video_table2.heading("trigg", text="Keywords")
        self.trigger_video_table2.pack(fill=BOTH, expand=1)
        self.trigger_video_table2.register_drag_source("*")
        self.trigger_video_table2.bind("<<DragInitCmd>>", drag_command)
        self.trigger_video_table2["show"] = "headings"
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("stationCode"):
            it = i.find("name").text
            self.trigger_video_table2.insert("", END, values=it)

        ##################################################################################################
        ##################################################################################################
        def drag_command(event):
            for selected_item in self.trigger_left_table3.selection():
                item = self.trigger_left_table3.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "<"+record[0]+">"+",</"+record[0]+">"


        self.video_language3 = LabelFrame(self.video_mess_upper_frame, relief=RIDGE, text='Markup Code (Formatting)', font=('times new roman', 13, "bold"),
                                          fg="red", bd=4)
        self.video_language3.place(x=600, y=0, height=290, width=290)
        self.scroll_y3 = Scrollbar(self.video_language3, orient=VERTICAL)
        self.trigger_left_table3 = tkinter.ttk.Treeview(self.video_language3, columns="trigg",
                                                        yscrollcommand=self.scroll_y3.set)
        self.scroll_y3.pack(side=RIGHT, fill=Y)
        self.scroll_y3.config(command=self.trigger_left_table3.yview)
        self.trigger_left_table3.heading("trigg", text="Markup Code")
        self.trigger_left_table3.pack(fill=BOTH, expand=1)
        self.trigger_left_table3.register_drag_source("*")
        self.trigger_left_table3.bind("<<DragInitCmd>>", drag_command)
        self.trigger_left_table3["show"] = "headings"
        xml_data_text = ET.parse("projectinfo.xml")
        root = xml_data_text.getroot()
        for i in root.findall("markupCode"):
            # self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
            it1 = i.find("group").text
            if int(it1) == 3:
                it = i.find("name").text
                self.trigger_left_table3.insert("", END, values=it)

        ##################################################################################################
        ##################################################################################################

        self.video_message_new = Button(self.video_mess_upper_frame, text="New", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top)
        self.video_message_new.place(x=10, y=293)

        self.video_message_edit = Button(self.video_mess_upper_frame, text="Edit", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top_update)
        self.video_message_edit.place(x=110, y=293)

        self.video_message_delete = Button(self.video_mess_upper_frame, text="Delete", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.delete_all_message_tbl_sql)
        self.video_message_delete.place(x=210, y=293)

        # self.video_mess_upper_frame1 = LabelFrame(self.universal_mess_main_frame, relief=RIDGE)
        # self.video_mess_upper_frame1.place(x=2, y=2, height=168, width=892)
        #
        # self.video_message_label = Label(self.video_mess_upper_frame1, text='Video Message', font=('times new roman', 13, "bold"),
        #                                  fg="red", bd=4)
        # self.video_message_label.place(x=0, y=0)
        #################################################################################################################
        #################################################################################################################
        #################################################################################################################

        self.message()


        #################################################################################################################
        #################################################################################################################
        #################################################################################################################


#         self.video_message_ok = Button(self.video_mess_upper_frame1, text="Ok", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.save_data_in_sql)
#         self.video_message_ok.place(x=700, y=134)
#
#         self.video_message_cancel = Button(self.video_mess_upper_frame1, text="Cancel", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.on_exit)
#         self.video_message_cancel.place(x=800, y=134)

    def banner_radio_button_select(self):
        print(530)
        if not self.var_video:
            self.audio_mess.configure(state=DISABLED)
            self.text_mess.configure(state=DISABLED)
            self.video_mess.configure(state=DISABLED)
            # self.logo_mess.configure(state=DISABLED)
        self.banner_mess_upper_frame = LabelFrame(self.universal_main_frame, relief=RIDGE)
        self.banner_mess_upper_frame.place(x=2, y=2, height=327, width=892)


        ################################################################################################
        ################################################################################################
        def drag_command(event):
            for selected_item in self.trigger_banner_table.selection():
                item = self.trigger_banner_table.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "["+record[0]+"]"

        self.banner_language1 = LabelFrame(self.banner_mess_upper_frame, relief=RIDGE, text='Fixed Message Part', font=('times new roman', 13, "bold"),
                                           fg="red", bd=4)
        self.banner_language1.place(x=0, y=0, height=290, width=290)

        self.scroll_y_banner = Scrollbar(self.banner_language1, orient=VERTICAL)
        self.trigger_banner_table = tkinter.ttk.Treeview(self.banner_language1, columns="trigg",
                                                         yscrollcommand=self.scroll_y_banner.set)
        self.scroll_y_banner.pack(side=RIGHT, fill=Y)
        self.scroll_y_banner.config(command=self.trigger_banner_table.yview)
        self.trigger_banner_table.heading("trigg", text="Fixed Message Part")
        self.trigger_banner_table.pack(fill=BOTH, expand=1)
        self.trigger_banner_table.register_drag_source("*")
        self.trigger_banner_table.bind("<<DragInitCmd>>", drag_command)
        self.trigger_banner_table["show"] = "headings"

        def focus_fix_treeview(event=""):
            self.cursor_row = self.trigger_banner_table.focus()
            self.content = self.trigger_banner_table.item(self.cursor_row)
            self.data_fix_mess = self.content["values"]
        self.trigger_banner_table.bind("<ButtonRelease>", focus_fix_treeview)
        def treeview_data_tbl():
            data = self.sql_data(f"SELECT description,[name] from messageA where name like'%MB%'")

            if len(data) != 0:
                self.trigger_banner_table.delete(*self.trigger_banner_table.get_children())
                for i in data:
                    self.trigger_banner_table.insert("", END, values=list(i))
            else:
                self.trigger_banner_table.delete(*self.trigger_banner_table.get_children())

        treeview_data_tbl()


        ################################################################################################
        ################################################################################################
        def drag_command(event):
            for selected_item in self.trigger_banner_table2.selection():
                item = self.trigger_banner_table2.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "{"+record[0]+"}"


        self.banner_language2 = LabelFrame(self.banner_mess_upper_frame, relief=RIDGE, text='Keywords (variable Part)', font=('times new roman', 13, "bold"),
                                           fg="red", bd=4)
        self.banner_language2.place(x=300, y=0, height=290, width=290)

        self.scroll_banner = Scrollbar(self.banner_language2, orient=VERTICAL)
        self.trigger_banner_table2 = tkinter.ttk.Treeview(self.banner_language2, columns="trigg",
                                                          yscrollcommand=self.scroll_banner.set)
        self.scroll_banner.pack(side=RIGHT, fill=Y)
        self.scroll_banner.config(command=self.trigger_banner_table2.yview)
        self.trigger_banner_table2.heading("trigg", text="Keywords")
        self.trigger_banner_table2.pack(fill=BOTH, expand=1)
        self.trigger_banner_table2.register_drag_source("*")
        self.trigger_banner_table2.bind("<<DragInitCmd>>", drag_command)
        self.trigger_banner_table2["show"] = "headings"
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("stationCode"):
            it = i.find("name").text
            self.trigger_banner_table2.insert("", END, values=it)

        ################################################################################################
        ################################################################################################
        def drag_command(event):
            for selected_item in self.trigger_banner_table3.selection():
                item = self.trigger_banner_table3.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "<"+record[0]+">"+",</"+record[0]+">"


        self.banner_language3 = LabelFrame(self.banner_mess_upper_frame, relief=RIDGE, text='Markup Code', font=('times new roman', 13, "bold"),
                                           fg="red", bd=4)
        self.banner_language3.place(x=600, y=0, height=290, width=290)

        self.scroll_banner = Scrollbar(self.banner_language3, orient=VERTICAL)
        self.trigger_banner_table3 = tkinter.ttk.Treeview(self.banner_language3, columns="trigg",
                                                          yscrollcommand=self.scroll_banner.set)
        self.scroll_banner.pack(side=RIGHT, fill=Y)
        self.scroll_banner.config(command=self.trigger_banner_table3.yview)
        self.trigger_banner_table3.heading("trigg", text="Markup Code")
        self.trigger_banner_table3.pack(fill=BOTH, expand=1)
        self.trigger_banner_table3.register_drag_source("*")
        self.trigger_banner_table3.bind("<<DragInitCmd>>", drag_command)
        self.trigger_banner_table3["show"] = "headings"
        xml_data_text = ET.parse("projectinfo.xml")
        root = xml_data_text.getroot()
        for i in root.findall("markupCode"):
            it = i.find("name").text
            self.trigger_banner_table3.insert("", END, values=it)
        ################################################################################################
        ################################################################################################
        self.banner_message_new = Button(self.banner_mess_upper_frame, text="New", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top)
        self.banner_message_new.place(x=10, y=293)

        self.banner_message_edit = Button(self.banner_mess_upper_frame, text="Edit", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top_update)
        self.banner_message_edit.place(x=110, y=293)

        self.banner_message_delete = Button(self.banner_mess_upper_frame, text="Delete", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.delete_all_message_tbl_sql)
        self.banner_message_delete.place(x=210, y=293)

        # self.banner_mess_upper_frame1 = LabelFrame(self.universal_mess_main_frame, relief=RIDGE)
        # self.banner_mess_upper_frame1.place(x=2, y=2, height=168, width=892)
        #
        # self.banner_message_label = Label(self.banner_mess_upper_frame1, text='Banner Message', font=('times new roman', 13, "bold"),
        #                                   fg="red", bd=4)
        # self.banner_message_label.place(x=0, y=0)
        #
        # self.banner_message_ok = Button(self.banner_mess_upper_frame1, text="Ok", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.save_data_in_sql)
        # self.banner_message_ok.place(x=700, y=134)
        #
        # self.banner_message_cancel = Button(self.banner_mess_upper_frame1, text="Cancel", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.on_exit)
        # self.banner_message_cancel.place(x=800, y=134)
        self.message()

    def delete_all_message_tbl_sql(self):
        print(663)
        if len(self.data_fix_mess) > 0:
            data_type = self.data_fix_mess[1]
            text_format = data_type[0:2]
            data_type = self.data_fix_mess[1]
            data = self.sql_data(
                f"SELECT name from messageA where name like'%{data_type[0:2]}%' order by name desc limit 1")
            if data:
                if data[0][0] == data_type:
                    conn = sqlite3.connect("triggers_abhay.db")
                    my_cursor = conn.cursor()
                    my_cursor.execute(
                        f"delete from messageA where description='{self.data_fix_mess[0]}' and name='{self.data_fix_mess[1]}'")
                    my_cursor.execute(
                        f"delete from tbl_file where fileDescription='{self.data_fix_mess[0]}' and fileName='{self.data_fix_mess[1]}'")
                    conn.commit()
                    conn.close()
                else:
                    conn = sqlite3.connect("triggers_abhay.db")
                    my_cursor = conn.cursor()
                    my_cursor.execute(f"update messageA set description='Empty_data' where name='{self.data_fix_mess[1]}'")
                    my_cursor.execute(f"update tbl_file set fileDescription='Empty_data' where fileName='{self.data_fix_mess[1]}'")
                    conn.commit()
                    conn.close()

            if text_format == "MA":
                data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MA%'")
                if len(data) != 0:
                    self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
                    for i in data:
                        self.trigger_audio_table.insert("", END, values=list(i))
                else:
                    self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
            elif text_format == "MT":
                data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MT%'")

                if len(data) != 0:
                    self.trigger_text_table.delete(*self.trigger_text_table.get_children())
                    for i in data:
                        self.trigger_text_table.insert("", END, values=list(i))
                else:
                    self.trigger_text_table.delete(*self.trigger_text_table.get_children())
            elif text_format == "MV":
                data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MV%'")

                if len(data) != 0:
                    self.trigger_left_table.delete(*self.trigger_left_table.get_children())
                    for i in data:
                        self.trigger_left_table.insert("", END, values=list(i))
                else:
                    self.trigger_left_table.delete(*self.trigger_left_table.get_children())
            elif text_format == "ML":
                data = self.sql_data(f"SELECT description, [name] from messageA where name like'%ML%'")
                if len(data) != 0:
                    self.trigger_logo_table.delete(*self.trigger_logo_table.get_children())
                    for i in data:
                        self.trigger_logo_table.insert("", END, values=list(i))
                else:
                    self.trigger_logo_table.delete(*self.trigger_logo_table.get_children())
            elif text_format == "MB":
                data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MB%'")

                if len(data) != 0:
                    self.trigger_banner_table.delete(*self.trigger_banner_table.get_children())
                    for i in data:
                        self.trigger_banner_table.insert("", END, values=list(i))
                else:
                    self.trigger_banner_table.delete(*self.trigger_banner_table.get_children())


    def logo_radio_button_select(self):
        print(777)
        self.audio_mess.configure(state=DISABLED)
        self.text_mess.configure(state=DISABLED)
        self.video_mess.configure(state=DISABLED)
        self.banner_mess.configure(state=DISABLED)
        self.logo_mess_upper_frame = LabelFrame(self.universal_main_frame, relief=RIDGE)
        self.logo_mess_upper_frame.place(x=2, y=2, height=327, width=892)

        ################################################################################################
        ################################################################################################

        def drag_command(event):
            for selected_item in self.trigger_logo_table.selection():
                item = self.trigger_logo_table.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "["+record[0]+"]"

        self.logo_language1 = LabelFrame(self.logo_mess_upper_frame, relief=RIDGE, text='Fixed Message Part', font=('times new roman', 13, "bold"),
                                         fg="red", bd=4)
        self.logo_language1.place(x=0, y=0, height=290, width=290)

        self.scroll_y_logo = Scrollbar(self.logo_language1, orient=VERTICAL)
        self.trigger_logo_table = tkinter.ttk.Treeview(self.logo_language1, columns="trigg",
                                                       yscrollcommand=self.scroll_y_logo.set)
        self.scroll_y_logo.pack(side=RIGHT, fill=Y)
        self.scroll_y_logo.config(command=self.trigger_logo_table.yview)
        self.trigger_logo_table.heading("trigg", text="Fixed Message Part")
        self.trigger_logo_table.pack(fill=BOTH, expand=1)
        self.trigger_logo_table.register_drag_source("*")
        self.trigger_logo_table.bind("<<DragInitCmd>>", drag_command)
        self.trigger_logo_table["show"] = "headings"
        def treeview_data_tbl():
            data = self.sql_data(f"SELECT description, [name] from messageA where name like'%ML%'")
            if len(data) != 0:
                self.trigger_logo_table.delete(*self.trigger_logo_table.get_children())
                for i in data:
                    self.trigger_logo_table.insert("", END, values=list(i))
            else:
                self.trigger_logo_table.delete(*self.trigger_logo_table.get_children())

        treeview_data_tbl()

        def focus_fix_treeview(event=""):
            self.cursor_row = self.trigger_logo_table.focus()
            self.content = self.trigger_logo_table.item(self.cursor_row)
            self.data_fix_mess = self.content["values"]
        self.trigger_logo_table.bind("<ButtonRelease>", focus_fix_treeview)

        ################################################################################################
        ################################################################################################
        def drag_command(event):
            for selected_item in self.trigger_logo_table2.selection():
                item = self.trigger_logo_table2.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "{"+record[0]+"}"

        self.logo_language2 = LabelFrame(self.logo_mess_upper_frame, relief=RIDGE, text='Keywords (variable Part)', font=('times new roman', 13, "bold"),
                                         fg="red", bd=4)
        self.logo_language2.place(x=300, y=0, height=290, width=290)
        self.scroll_logo = Scrollbar(self.logo_language2, orient=VERTICAL)
        self.trigger_logo_table2 = tkinter.ttk.Treeview(self.logo_language2, columns="trigg",
                                                        yscrollcommand=self.scroll_logo.set)
        self.scroll_logo.pack(side=RIGHT, fill=Y)
        self.scroll_logo.config(command=self.trigger_logo_table2.yview)
        self.trigger_logo_table2.heading("trigg", text="Keywords")
        self.trigger_logo_table2.pack(fill=BOTH, expand=1)
        self.trigger_logo_table2.register_drag_source("*")
        self.trigger_logo_table2.bind("<<DragInitCmd>>", drag_command)
        self.trigger_logo_table2["show"] = "headings"
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("stationCode"):
            it = i.find("name").text
            self.trigger_logo_table2.insert("", END, values=it)

        ################################################################################################
        ################################################################################################

        def drag_command(event):
            for selected_item in self.trigger_logo_table3.selection():
                item = self.trigger_logo_table3.item(selected_item)
                record = item['values']
            return tkinterDnD.COPY, "DND_Text", "<"+record[0]+">"+",</"+record[0]+">"

        self.logo_language3 = LabelFrame(self.logo_mess_upper_frame, relief=RIDGE, text='Markup Code', font=('times new roman', 13, "bold"),
                                         fg="red", bd=4)
        self.logo_language3.place(x=600, y=0, height=290, width=290)

        self.scroll_logo = Scrollbar(self.logo_language3, orient=VERTICAL)
        self.trigger_logo_table3 = tkinter.ttk.Treeview(self.logo_language3, columns="trigg",
                                                        yscrollcommand=self.scroll_logo.set)
        self.scroll_logo.pack(side=RIGHT, fill=Y)
        self.scroll_logo.config(command=self.trigger_logo_table3.yview)
        self.trigger_logo_table3.heading("trigg", text="Markup Code")
        self.trigger_logo_table3.pack(fill=BOTH, expand=1)
        self.trigger_logo_table3.register_drag_source("*")
        self.trigger_logo_table3.bind("<<DragInitCmd>>", drag_command)
        self.trigger_logo_table3["show"] = "headings"
        xml_data_text = ET.parse("projectinfo.xml")
        root = xml_data_text.getroot()
        for i in root.findall("markupCode"):
            # self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
            it1 = i.find("group").text
            if int(it1) == 3:
                it = i.find("name").text
                self.trigger_logo_table3.insert("", END, values=it)

        ################################################################################################
        ################################################################################################

        self.logo_message_new = Button(self.logo_mess_upper_frame, text="New", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top)
        self.logo_message_new.place(x=10, y=293)

        self.logo_message_edit = Button(self.logo_mess_upper_frame, text="Edit", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.import_message_top_update)
        self.logo_message_edit.place(x=110, y=293)

        self.logo_message_delete = Button(self.logo_mess_upper_frame, text="Delete", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.delete_all_message_tbl_sql)
        self.logo_message_delete.place(x=210, y=293)

        # self.logo_mess_upper_frame1 = LabelFrame(self.universal_mess_main_frame, relief=RIDGE)
        # self.logo_mess_upper_frame1.place(x=2, y=2, height=168, width=892)
        #
        # self.logo_message_label = Label(self.logo_mess_upper_frame1, text='Logo Message', font=('times new roman', 13, "bold"),
        #                                 fg="red", bd=4)
        # self.logo_message_label.place(x=0, y=0)
        #
        # self.logo_message_ok = Button(self.logo_mess_upper_frame1, text="Ok", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.save_data_in_sql)
        # self.logo_message_ok.place(x=700, y=134)
        #
        # self.logo_message_cancel = Button(self.logo_mess_upper_frame1, text="Cancel", font=('arial', 10, 'bold'), width=9, height=1, bg="#7C7CFC", fg="white", command=self.on_exit)
        # self.logo_message_cancel.place(x=800, y=134)
        self.message()

    def drop_all_event(self):
        self.video_mess_upper_frame1 = LabelFrame(self.universal_mess_main_frame, relief=RIDGE)
        self.video_mess_upper_frame1.place(x=2, y=2, height=168, width=892)

        self.video_message_label = Label(self.video_mess_upper_frame1, text='Video Message',
                                         font=('times new roman', 13, "bold"),
                                         fg="red", bd=4)
        self.video_message_label.place(x=0, y=0)

        self.video_message_ok = Button(self.video_mess_upper_frame1, text="Ok", font=('arial', 10, 'bold'), width=9,
                                   height=1, bg="#7C7CFC", fg="white", command=self.save_data_in_sql)
        self.video_message_ok.place(x=700, y=134)

        self.video_message_cancel = Button(self.video_mess_upper_frame1, text="Cancel", font=('arial', 10, 'bold'), width=9,
                                       height=1, bg="#7C7CFC", fg="white", command=self.on_exit)
        self.video_message_cancel.place(x=800, y=134)
        def drop(event):
            print(966)
            text = event.data
            if len(self.selected_text) > 0:
                if text.find("<") == 0:
                    self.selected_text.sort()
                    split_text = text.split(",")
                    self.split_message_list.insert(self.selected_text[0], split_text[0])
                    self.split_message_list.insert(self.selected_text[-1] + 2, split_text[1])
                    self.create_mess()
                elif text.find("[") == 0 or text.find("{") == 0:
                    self.split_message_list.insert(self.selected_text[0], text)
                    self.create_mess()
            elif text.find("[") == 0 or text.find("{") == 0:
                self.split_message_list.append(event.data)
                self.create_mess()
            # text_box.insert(tk.END, event.data)

        self.all_message_frame = Frame(self.video_mess_upper_frame1, relief=RIDGE, bd=4) # store drag and drop message
        self.all_message_frame.place(x=0, y=26, height=105, width=888)
        self.all_message_frame.register_drop_target("*")
        self.all_message_frame.bind("<<Drop>>", drop)

    def message(self):
        print(911)
        lenth_of_message = len(self.message_dis)
        index_open_bracket_list = []
        index_close_bracket_list = []
        self.split_message_list = []
        self.delete_value1 = []
        self.delete_value2 = []
        delete_one_item = []
        # add_data_in_split_message_list = []

        for i in range(0, lenth_of_message):
            try:
                if self.message_dis[i] == "{":
                    index_open_bracket_list.append(self.message_dis.find("{", i))
                elif self.message_dis[i] == "}":
                    index_close_bracket_list.append(self.message_dis.find("}", i))

                elif self.message_dis[i] == "[":
                    index_open_bracket_list.append(self.message_dis.find("[", i))
                elif self.message_dis[i] == "]":
                    index_close_bracket_list.append(self.message_dis.find("]", i))

                elif self.message_dis[i] == "<":
                    index_open_bracket_list.append(self.message_dis.find("<", i))
                elif self.message_dis[i] == ">":
                    index_close_bracket_list.append(self.message_dis.find(">", i))
            except IndexError:
                j = None
        for j in range(len(index_open_bracket_list)):
            try:
                a = index_open_bracket_list[j]
                b = index_close_bracket_list[j]+1
                self.split_message_list.append(self.message_dis[a: b])
            except IndexError:
                m = None

        # list_for_message_description = self.split_message_list
        for item in self.split_message_list:
            if item[0] == "[":
                item_name = item[1:-1:]
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute(f"SELECT [description] FROM [messageA] where [name]='{item_name}'")
                description_name = my_cursor.fetchall()
                if len(description_name) != 0:
                    self.split_message_list[
                        self.split_message_list.index(item)] = f"[{description_name[0][0]}]"
                # conn.commit()
                conn.close()

        # def create_mess():
        #     print(962)
        #     self.selected_text = []
        #     # if self.aa == "front display right" or self.aa == "front display left":
        #     if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":
        #
        #         if self.True_var:
        #            self.drop_all_event()
        #            self.True_var = 0
        #         # def drop(event):
        #         #     print(966)
        #         #     text = event.data
        #         #     if len(self.selected_text) > 0:
        #         #         if text.find("<") == 0:
        #         #             self.selected_text.sort()
        #         #             split_text = text.split(",")
        #         #             self.split_message_list.insert(self.selected_text[0], split_text[0])
        #         #             self.split_message_list.insert(self.selected_text[-1] + 2, split_text[1])
        #         #             self.create_mess()
        #         #         elif text.find("[") == 0 or text.find("{") == 0:
        #         #             self.split_message_list.insert(self.selected_text[0], text)
        #         #             self.create_mess()
        #         #     elif text.find("[") == 0 or text.find("{") == 0:
        #         #         self.split_message_list.append(event.data)
        #         #         self.create_mess()
        #         #     # text_box.insert(tk.END, event.data)
        #         # self.video_message_frame = Frame(self.video_mess_upper_frame1, relief=RIDGE, bd=4)
        #         # self.video_message_frame.place(x=0, y=26, height=105, width=888)
        #         # self.video_message_frame.register_drop_target("*")
        #         # self.video_message_frame.bind("<<Drop>>", drop)
        #     ## elif self.aa == "interior display":
        #     elif self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left"\
        #             or self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or self.aa == "32":
        #         if self.True_var:
        #             self.drop_all_event()
        #         # def drop(event):
        #         #     print(991)
        #         #     text = event.data
        #         #     if len(self.selected_text) > 0:
        #         #         if text.find("<") == 0:
        #         #             self.selected_text.sort()
        #         #             split_text = text.split(",")
        #         #             self.split_message_list.insert(self.selected_text[0], split_text[0])
        #         #             self.split_message_list.insert(self.selected_text[-1] + 2, split_text[1])
        #         #             self.create_mess()
        #         #         elif text.find("[") == 0 or text.find("{") == 0:
        #         #             self.split_message_list.insert(self.selected_text[0], text)
        #         #             self.create_mess()
        #         #     elif text.find("[") == 0 or text.find("{") == 0:
        #         #         self.split_message_list.append(event.data)
        #         #         self.create_mess()
        #         #
        #         #     # text_box.insert(tk.END, event.data)
        #         # self.full_message_frame = Frame(self.full_mess_upper_frame, relief=RIDGE, bd=4)
        #         # self.full_message_frame.place(x=0, y=26, height=105, width=888)
        #         # self.full_message_frame.register_drop_target("*")
        #         # self.full_message_frame.bind("<<Drop>>", drop)
        #         # # self.full_message_frame.bind("<Button-1>", drop)
        #     elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
        #         self.drop_all_event()
        #         # def drop(event):
        #         #     print(1015)
        #         #     text = event.data
        #         #     if len(self.selected_text) > 0:
        #         #         if text.find("<") == 0:
        #         #             self.selected_text.sort()
        #         #             split_text = text.split(",")
        #         #             self.split_message_list.insert(self.selected_text[0], split_text[0])
        #         #             self.split_message_list.insert(self.selected_text[-1] + 2, split_text[1])
        #         #             self.create_mess()
        #         #         elif text.find("[") == 0 or text.find("{") == 0:
        #         #             self.split_message_list.insert(self.selected_text[0], text)
        #         #             self.create_mess()
        #         #     elif text.find("[") == 0 or text.find("{") == 0:
        #         #         self.split_message_list.append(event.data)
        #         #         self.create_mess()
        #         #     # text_box.insert(tk.END, event.data)
        #         # self.audio_message_frame = Frame(self.audio_mess_upper_frame1, relief=RIDGE, bd=4)
        #         # self.audio_message_frame.place(x=0, y=26, height=105, width=888)
        #         # self.audio_message_frame.register_drop_target("*")
        #         # self.audio_message_frame.bind("<<Drop>>", drop)
        #
        #     elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
        #         if self.True_var:
        #             self.drop_all_event()
        #         # def drop(event):
        #         #     print(1037)
        #         #     text = event.data
        #         #     if len(self.selected_text) > 0:
        #         #         if text.find("<") == 0:
        #         #             self.selected_text.sort()
        #         #             split_text = text.split(",")
        #         #             self.split_message_list.insert(self.selected_text[0], split_text[0])
        #         #             self.split_message_list.insert(self.selected_text[-1] + 2, split_text[1])
        #         #             self.create_mess()
        #         #         elif text.find("[") == 0 or text.find("{") == 0:
        #         #             self.split_message_list.insert(self.selected_text[0], text)
        #         #             self.create_mess()
        #         #     elif text.find("[") == 0 or text.find("{") == 0:
        #         #         self.split_message_list.append(event.data)
        #         #         self.create_mess()
        #         #     # text_box.insert(tk.END, event.data)
        #         # self.logo_message_frame = Frame(self.logo_mess_upper_frame1, relief=RIDGE, bd=4)
        #         # self.logo_message_frame.place(x=0, y=26, height=105, width=888)
        #         # self.logo_message_frame.register_drop_target("*")
        #         # self.logo_message_frame.bind("<<Drop>>", drop)
        #
        #     elif self.aa == "Interior Banner" or self.aa == "interior Banner":
        #         if self.True_var:
        #             self.drop_all_event()
        #
        #         # def drop(event):
        #         #     print(1059)
        #         #     text = event.data
        #         #     if len(self.selected_text) > 0:
        #         #         if text.find("<") == 0:
        #         #             self.selected_text.sort()
        #         #             split_text = text.split(",")
        #         #             self.split_message_list.insert(self.selected_text[0], split_text[0])
        #         #             self.split_message_list.insert(self.selected_text[-1] + 2, split_text[1])
        #         #             self.create_mess()
        #         #         elif text.find("[") == 0 or text.find("{") == 0:
        #         #             self.split_message_list.insert(self.selected_text[0], text)
        #         #             self.create_mess()
        #         #     elif text.find("[") == 0 or text.find("{") == 0:
        #         #         self.split_message_list.append(event.data)
        #         #         self.create_mess()
        #         #     # text_box.insert(tk.END, event.data)
        #         # self.banner_message_frame = Frame(self.banner_mess_upper_frame1, relief=RIDGE, bd=4)
        #         # self.banner_message_frame.place(x=0, y=26, height=105, width=888)
        #         # self.banner_message_frame.register_drop_target("*")
        #         # self.banner_message_frame.bind("<<Drop>>", drop)
        #
        #     self.split_message_dic = {}
        #     button_dic = {}
        #     for j in range(len(self.split_message_list)):
        #         try:
        #             self.split_message_dic[j] = self.split_message_list[j]
        #         except IndexError:
        #             m = None
        #     print(self.split_message_dic)
        #
        #     def do_popup(event):
        #         # display the popup menu
        #         try:
        #             popup.tk_popup(event.x_root, event.y_root, 0)
        #         finally:
        #             # make sure to release the grab (Tk 8.0a1 only)
        #             popup.grab_release()
        #     ##################################################
        #     ###################################################
        #     x_position = 0  # Initial x-coordinate          #####
        #     y_position = 0  # y-coordinate for all labels  #######  create position for button_dic[dic_key]
        #     space = 2                                       #####
        #     ###################################################
        #     ##################################################
        #     for dic_key in self.split_message_dic:
        #         x = dic_key
        #
        #         def on_enter(e, r=x):
        #             print(1106)
        #             find_tag = self.split_message_dic[r]
        #             lenth_dis = len(self.split_message_dic)
        #             if find_tag.find("/") == 1:
        #                 for i in range(r, -1, -1):
        #                     if self.split_message_dic[i].find("{") == 0 or self.split_message_dic[i].find("[") == 0:
        #                         self.delete_value1.clear()
        #                         self.delete_value2.clear()
        #                         value1 = r - i
        #                         value2 = i - value1
        #                         button_dic[r].config(bg="red")
        #                         self.delete_value1.insert(0, r)
        #                         new_name = self.split_message_dic[r].replace("/", "")
        #                         while True:
        #                             # if self.split_message_dic[value2].find("<") == 0:
        #                             if self.split_message_dic[value2] == new_name:
        #                                 break
        #                             if value2 == -1:
        #                                 break
        #                             value2 -= 1
        #                         button_dic[value2].config(bg="red")
        #                         self.delete_value2.insert(0, value2)
        #                         break
        #
        #
        #             elif find_tag.find("<") == 0:
        #                 for i in range(r, lenth_dis):
        #                     if self.split_message_dic[i].find("{") == 0 or self.split_message_dic[i].find("[") == 0:
        #                         self.delete_value1.clear()
        #                         self.delete_value2.clear()
        #                         value1 = i - r
        #                         value2 = i + value1
        #                         button_dic[r].config(bg="red")
        #                         self.delete_value1.insert(0, r)
        #                         new_name = self.split_message_dic[r].replace("<", "</")
        #                         while True:
        #                             # if self.split_message_dic[value2].find("<") == 0:
        #                             if self.split_message_dic[value2] == new_name:
        #                                 break
        #                             if value2 == -1:
        #                                 break
        #                             value2 += 1
        #                         button_dic[value2].config(bg="red")
        #                         self.delete_value2.insert(0, value2 - 1)
        #                         break
        #                     elif self.split_message_dic[i].find("</") == 0:
        #                         self.delete_value1.clear()
        #                         self.delete_value2.clear()
        #                         value1 = r + 1
        #                         value2 = i - value1
        #                         value3 = i + value2
        #                         button_dic[r].config(bg="red")
        #                         self.delete_value1.insert(0, r)
        #                         button_dic[abs(value3)].config(bg="red")
        #                         self.delete_value2.insert(0, value3 - 1)
        #                         break
        #             else:
        #                 self.delete_value1.clear()
        #                 # button_dic[r].config(bg="red")
        #                 self.delete_value1.insert(0, r)
        #
        #
        #         def on_leave(e, r=x):
        #             print(1169)
        #             find_tag = self.split_message_dic[r]
        #             lenth_dis = len(self.split_message_dic)
        #             if find_tag.find("/") == 1:
        #                 for i in range(r, -1, -1):
        #                     if self.split_message_dic[i].find("{") == 0 or self.split_message_dic[i].find("[") == 0:
        #                         value1 = r - i
        #                         value2 = i - value1
        #                         button_dic[r].config(bg="light green")
        #                         new_name = self.split_message_dic[r].replace("/", "")
        #                         while True:
        #                             # if self.split_message_dic[value2].find("<") == 0:
        #                             if self.split_message_dic[value2] == new_name:
        #                                 break
        #                             if value2 == -1:
        #                                 break
        #                             value2 -= 1
        #                         button_dic[value2].config(bg="light green")
        #                         break
        #                     elif self.split_message_dic[i].find("</") != 0:
        #                         value1 = r - i
        #                         value2 = i - value1
        #                         value3 = value2 + 1
        #                         button_dic[r].config(bg="light green")
        #                         button_dic[abs(value3)].config(bg="light green")
        #             elif find_tag.find("<") == 0:
        #                 for i in range(r, lenth_dis):
        #                     if self.split_message_dic[i].find("</") == 0:
        #                         value1 = r + 1
        #                         value2 = i - value1
        #                         value3 = i + value2
        #                         button_dic[r].config(bg="light green")
        #                         button_dic[value3].config(bg="light green")
        #                         break
        #                     elif self.split_message_dic[i].find("{") == 0 or self.split_message_dic[i].find("[") == 0:
        #                         value1 = i - r
        #                         value2 = i + value1
        #                         new_name = self.split_message_dic[r].replace("<", "</")
        #                         while True:
        #                             if self.split_message_dic[value2] == new_name:
        #                                 break
        #                             if value2 == -1:
        #                                 break
        #                             value2 += 1
        #                         button_dic[r].config(bg="light green")
        #                         button_dic[value2].config(bg="light green")
        #                         break
        #
        #         def func(index_but=x):
        #             print(1218)
        #             if self.split_message_dic[self.delete_value1[0]].find("<") == 0:
        #                 g = self.delete_value1[0]
        #                 m = self.delete_value2[0]
        #                 self.split_message_list.remove(self.split_message_list[g])
        #                 self.split_message_list.remove(self.split_message_list[m])
        #                 # if self.aa == "front display right" or self.aa == "front display left":
        #
        #                 self.all_message_frame.destroy()
        #                 # if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":
        #                 #     self.video_message_frame.destroy()
        #                 # elif self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left" \
        #                 #         or self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or self.aa == "32":
        #                 #     self.full_message_frame.destroy()
        #                 # elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
        #                 #     self.audio_message_frame.destroy()
        #                 # elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
        #                 #     self.logo_message_frame.destroy()
        #                 # elif self.aa == "Interior Banner" or self.aa == "interior Banner":
        #                 #     self.banner_message_frame.destroy()
        #                 self.create_mess()
        #             else:
        #                 g = self.delete_value1[0]
        #                 self.split_message_list.remove(self.split_message_list[g])
        #                 # if self.aa == "front display right" or self.aa == "front display left":
        #                 self.all_message_frame_message_frame.destroy()
        #                 # if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":
        #                 #     self.video_message_frame.destroy()
        #                 # elif self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left" \
        #                 #         or self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or self.aa == "32":
        #                 #     self.full_message_frame.destroy()
        #                 # elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
        #                 #     self.audio_message_frame.destroy()
        #                 # elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
        #                 #     self.logo_message_frame.destroy()
        #                 # elif self.aa == "Interior Banner" or self.aa == "interior Banner":
        #                 #     self.banner_message_frame.destroy()
        #                 self.create_mess()
        #
        #         def add_item(index_but=x):
        #             print(1255)
        #             if self.split_message_list[index_but].find("[") == 0:
        #                 if button_dic[index_but]["bg"] == "cyan":
        #                     button_dic[index_but].config(bg="yellow")
        #                     # self.selected_text.clear()
        #                     self.selected_text.append(index_but)
        #
        #                 elif button_dic[index_but]["bg"] == "yellow":
        #                     button_dic[index_but].config(bg="cyan")
        #                     self.selected_text.remove(index_but)
        #                     # self.selected_text.clear()
        #
        #             elif self.split_message_list[index_but].find("{") == 0:
        #                 if button_dic[index_but]["bg"] == "pink":
        #                     button_dic[index_but].config(bg="yellow")
        #                     # self.selected_text.clear()
        #                     self.selected_text.append(index_but)
        #
        #                 elif button_dic[index_but]["bg"] == "yellow":
        #                     button_dic[index_but].config(bg="pink")
        #                     self.selected_text.remove(index_but)
        #                     # self.selected_text.clear()
        #         if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":
        #             # button_dic[dic_key] = Button(self.video_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             if 750 < x_position < (x_position+button_dic[dic_key].winfo_reqwidth()):
        #                 y_position += 22
        #                 x_position = 0
        #             button_dic[dic_key].place(x=x_position, y=y_position)
        #             x_position += button_dic[dic_key].winfo_reqwidth() + space
        #             # popup = Menu(self.video_message_frame, tearoff=0)
        #             popup = Menu(self.all_message_frame, tearoff=0)
        #             popup.add_command(label="  Delete ", command=func)
        #             button_dic[dic_key].bind('<Enter>', on_enter)
        #             button_dic[dic_key].bind("<Button-3>", do_popup)
        #             button_dic[dic_key].bind('<Leave>', on_leave)
        #         # elif self.aa == "interior display":
        #         elif self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left"\
        #                 or self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or self.aa == "32":
        #             # button_dic[dic_key] = Button(self.full_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             if 750 < x_position < (x_position+button_dic[dic_key].winfo_reqwidth()):
        #                 y_position += 22
        #                 x_position = 0
        #             button_dic[dic_key].place(x=x_position, y=y_position)
        #             x_position += button_dic[dic_key].winfo_reqwidth() + space  # place with 3 space
        #             # popup = Menu(self.full_message_frame, tearoff=0)
        #             popup = Menu(self.all_message_frame, tearoff=0)
        #             popup.add_command(label="  Delete ", command=func)
        #             button_dic[dic_key].bind('<Enter>', on_enter)
        #             button_dic[dic_key].bind("<Button-3>", do_popup)
        #             button_dic[dic_key].bind('<Leave>', on_leave)
        #         elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
        #             # button_dic[dic_key] = Button(self.audio_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             if 750 < x_position < (x_position+button_dic[dic_key].winfo_reqwidth()):
        #                 y_position += 22
        #                 x_position = 0
        #             button_dic[dic_key].place(x=x_position, y=y_position)
        #             x_position += button_dic[dic_key].winfo_reqwidth() + space  # place with 3 space
        #             # popup = Menu(self.audio_message_frame, tearoff=0)
        #             popup = Menu(self.all_message_frame, tearoff=0)
        #             popup.add_command(label="  Delete ", command=func)
        #             button_dic[dic_key].bind('<Enter>', on_enter)
        #             button_dic[dic_key].bind("<Button-3>", do_popup)
        #             button_dic[dic_key].bind('<Leave>', on_leave)
        #         elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
        #             # button_dic[dic_key] = Button(self.logo_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             if 750 < x_position < (x_position+button_dic[dic_key].winfo_reqwidth()):
        #                 y_position += 22
        #                 x_position = 0
        #             button_dic[dic_key].place(x=x_position, y=y_position)
        #             x_position += button_dic[dic_key].winfo_reqwidth() + space
        #             popup = Menu(self.all_message_frame, tearoff=0)
        #             # popup = Menu(self.logo_message_frame, tearoff=0)
        #             popup.add_command(label="  Delete ", command=func)
        #             button_dic[dic_key].bind('<Enter>', on_enter)
        #             button_dic[dic_key].bind("<Button-3>", do_popup)
        #             button_dic[dic_key].bind('<Leave>', on_leave)
        #
        #         elif self.aa == "Interior Banner" or self.aa == "interior Banner":
        #             # button_dic[dic_key] = Button(self.banner_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
        #             if 750 < x_position < (x_position+button_dic[dic_key].winfo_reqwidth()):
        #                 y_position += 22
        #                 x_position = 0
        #             button_dic[dic_key].place(x=x_position, y=y_position)
        #             x_position += button_dic[dic_key].winfo_reqwidth() + space
        #             # popup = Menu(self.banner_message_frame, tearoff=0)
        #             popup = Menu(self.all_message_frame, tearoff=0)
        #             popup.add_command(label="  Delete ", command=func)
        #             button_dic[dic_key].bind('<Enter>', on_enter)
        #             button_dic[dic_key].bind("<Button-3>", do_popup)
        #             button_dic[dic_key].bind('<Leave>', on_leave)
        #
        #         color = self.split_message_dic[dic_key]
        #         if color.find("{") == 0:
        #             button_dic[dic_key].config(bg="pink")
        #         elif color.find("[") == 0:
        #             button_dic[dic_key].config(bg="cyan")
        #         elif color.find("<") == 0:
        #             button_dic[dic_key].config(bg="light green")
        #         # button_dic[dic_key].focus()

        self.create_mess()

    def create_mess(self):
        print(962)
        self.selected_text = []
        # if self.aa == "front display right" or self.aa == "front display left":
        if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":

            # self.drop_all_event()
            if self.True_var:
                self.drop_all_event()
                self.True_var = 0
        elif self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left" \
                or self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or self.aa == "32":
            if self.True_var:
                self.drop_all_event()

        elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
            self.drop_all_event()

        elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
            if self.True_var:
                self.drop_all_event()

        elif self.aa == "Interior Banner" or self.aa == "interior Banner":
            if self.True_var:
                self.drop_all_event()

        self.split_message_dic = {}
        button_dic = {}
        for j in range(len(self.split_message_list)):
            try:
                self.split_message_dic[j] = self.split_message_list[j]
            except IndexError:
                m = None
        print(self.split_message_dic)

        def do_popup(event):
            # display the popup menu
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                # make sure to release the grab (Tk 8.0a1 only)
                popup.grab_release()

        ##################################################
        ###################################################
        x_position = 0  # Initial x-coordinate          #####
        y_position = 0  # y-coordinate for all labels  #######  create position for button_dic[dic_key]
        space = 2  #####
        ###################################################
        ##################################################
        for dic_key in self.split_message_dic:
            x = dic_key

            def on_enter(e, r=x):
                print(1106)
                find_tag = self.split_message_dic[r]
                lenth_dis = len(self.split_message_dic)
                if find_tag.find("/") == 1:
                    for i in range(r, -1, -1):
                        if self.split_message_dic[i].find("{") == 0 or self.split_message_dic[i].find("[") == 0:
                            self.delete_value1.clear()
                            self.delete_value2.clear()
                            value1 = r - i
                            value2 = i - value1
                            button_dic[r].config(bg="red")
                            self.delete_value1.insert(0, r)
                            new_name = self.split_message_dic[r].replace("/", "")
                            while True:
                                # if self.split_message_dic[value2].find("<") == 0:
                                if self.split_message_dic[value2] == new_name:
                                    break
                                if value2 == -1:
                                    break
                                value2 -= 1
                            button_dic[value2].config(bg="red")
                            self.delete_value2.insert(0, value2)
                            break


                elif find_tag.find("<") == 0:
                    for i in range(r, lenth_dis):
                        if self.split_message_dic[i].find("{") == 0 or self.split_message_dic[i].find("[") == 0:
                            self.delete_value1.clear()
                            self.delete_value2.clear()
                            value1 = i - r
                            value2 = i + value1
                            button_dic[r].config(bg="red")
                            self.delete_value1.insert(0, r)
                            new_name = self.split_message_dic[r].replace("<", "</")
                            while True:
                                # if self.split_message_dic[value2].find("<") == 0:
                                if self.split_message_dic[value2] == new_name:
                                    break
                                if value2 == -1:
                                    break
                                value2 += 1
                            button_dic[value2].config(bg="red")
                            self.delete_value2.insert(0, value2 - 1)
                            break
                        elif self.split_message_dic[i].find("</") == 0:
                            self.delete_value1.clear()
                            self.delete_value2.clear()
                            value1 = r + 1
                            value2 = i - value1
                            value3 = i + value2
                            button_dic[r].config(bg="red")
                            self.delete_value1.insert(0, r)
                            button_dic[abs(value3)].config(bg="red")
                            self.delete_value2.insert(0, value3 - 1)
                            break
                else:
                    self.delete_value1.clear()
                    # button_dic[r].config(bg="red")
                    self.delete_value1.insert(0, r)

            def on_leave(e, r=x):
                print(1169)
                find_tag = self.split_message_dic[r]
                lenth_dis = len(self.split_message_dic)
                if find_tag.find("/") == 1:
                    for i in range(r, -1, -1):
                        if self.split_message_dic[i].find("{") == 0 or self.split_message_dic[i].find("[") == 0:
                            value1 = r - i
                            value2 = i - value1
                            button_dic[r].config(bg="light green")
                            new_name = self.split_message_dic[r].replace("/", "")
                            while True:
                                # if self.split_message_dic[value2].find("<") == 0:
                                if self.split_message_dic[value2] == new_name:
                                    break
                                if value2 == -1:
                                    break
                                value2 -= 1
                            button_dic[value2].config(bg="light green")
                            break
                        elif self.split_message_dic[i].find("</") != 0:
                            value1 = r - i
                            value2 = i - value1
                            value3 = value2 + 1
                            button_dic[r].config(bg="light green")
                            button_dic[abs(value3)].config(bg="light green")
                elif find_tag.find("<") == 0:
                    for i in range(r, lenth_dis):
                        if self.split_message_dic[i].find("</") == 0:
                            value1 = r + 1
                            value2 = i - value1
                            value3 = i + value2
                            button_dic[r].config(bg="light green")
                            button_dic[value3].config(bg="light green")
                            break
                        elif self.split_message_dic[i].find("{") == 0 or self.split_message_dic[i].find("[") == 0:
                            value1 = i - r
                            value2 = i + value1
                            new_name = self.split_message_dic[r].replace("<", "</")
                            while True:
                                if self.split_message_dic[value2] == new_name:
                                    break
                                if value2 == -1:
                                    break
                                value2 += 1
                            button_dic[r].config(bg="light green")
                            button_dic[value2].config(bg="light green")
                            break

            def func(index_but=x):
                print(1218)
                if self.split_message_dic[self.delete_value1[0]].find("<") == 0:
                    g = self.delete_value1[0]
                    m = self.delete_value2[0]
                    self.split_message_list.remove(self.split_message_list[g])
                    self.split_message_list.remove(self.split_message_list[m])
                    # if self.aa == "front display right" or self.aa == "front display left":

                    self.all_message_frame.destroy()
                    # if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":
                    #     self.video_message_frame.destroy()
                    # elif self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left" \
                    #         or self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or self.aa == "32":
                    #     self.full_message_frame.destroy()
                    # elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
                    #     self.audio_message_frame.destroy()
                    # elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
                    #     self.logo_message_frame.destroy()
                    # elif self.aa == "Interior Banner" or self.aa == "interior Banner":
                    #     self.banner_message_frame.destroy()
                    self.create_mess()
                else:
                    g = self.delete_value1[0]
                    self.split_message_list.remove(self.split_message_list[g])
                    # if self.aa == "front display right" or self.aa == "front display left":
                    self.all_message_frame.destroy()
                    # if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":
                    #     self.video_message_frame.destroy()
                    # elif self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left" \
                    #         or self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or self.aa == "32":
                    #     self.full_message_frame.destroy()
                    # elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
                    #     self.audio_message_frame.destroy()
                    # elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
                    #     self.logo_message_frame.destroy()
                    # elif self.aa == "Interior Banner" or self.aa == "interior Banner":
                    #     self.banner_message_frame.destroy()
                    self.create_mess()

            def add_item(index_but=x):
                print(1255)
                if self.split_message_list[index_but].find("[") == 0:
                    if button_dic[index_but]["bg"] == "cyan":
                        button_dic[index_but].config(bg="yellow")
                        # self.selected_text.clear()
                        self.selected_text.append(index_but)

                    elif button_dic[index_but]["bg"] == "yellow":
                        button_dic[index_but].config(bg="cyan")
                        self.selected_text.remove(index_but)
                        # self.selected_text.clear()

                elif self.split_message_list[index_but].find("{") == 0:
                    if button_dic[index_but]["bg"] == "pink":
                        button_dic[index_but].config(bg="yellow")
                        # self.selected_text.clear()
                        self.selected_text.append(index_but)

                    elif button_dic[index_but]["bg"] == "yellow":
                        button_dic[index_but].config(bg="pink")
                        self.selected_text.remove(index_but)
                        # self.selected_text.clear()


            # if self.aa.upper() == "Interior Video".upper() or self.aa == "interior Video":
            #     # button_dic[dic_key] = Button(self.video_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
            #     button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key],
            #                                  command=add_item, font=('arial', 7, 'bold'))
            #     if 750 < x_position < (x_position + button_dic[dic_key].winfo_reqwidth()):
            #         y_position += 22
            #         x_position = 0
            #     button_dic[dic_key].place(x=x_position, y=y_position)
            #     x_position += button_dic[dic_key].winfo_reqwidth() + space
            #     # popup = Menu(self.video_message_frame, tearoff=0)
            #     popup = Menu(self.all_message_frame, tearoff=0)
            #     popup.add_command(label="  Delete ", command=func)
            #     button_dic[dic_key].bind('<Enter>', on_enter)
            #     button_dic[dic_key].bind("<Button-3>", do_popup)
            #     button_dic[dic_key].bind('<Leave>', on_leave)
            # # elif self.aa == "interior display":
            # elif self.aa == "interior display" or self.aa == "front display right" or self.aa == "front display left" \
            #         or self.aa == "Interior display" or self.aa == "Front display right" or self.aa == "Front display left" or self.aa == "32":
            #     # button_dic[dic_key] = Button(self.full_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
            #     button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key],
            #                                  command=add_item, font=('arial', 7, 'bold'))
            #     if 750 < x_position < (x_position + button_dic[dic_key].winfo_reqwidth()):
            #         y_position += 22
            #         x_position = 0
            #     button_dic[dic_key].place(x=x_position, y=y_position)
            #     x_position += button_dic[dic_key].winfo_reqwidth() + space  # place with 3 space
            #     # popup = Menu(self.full_message_frame, tearoff=0)
            #     popup = Menu(self.all_message_frame, tearoff=0)
            #     popup.add_command(label="  Delete ", command=func)
            #     button_dic[dic_key].bind('<Enter>', on_enter)
            #     button_dic[dic_key].bind("<Button-3>", do_popup)
            #     button_dic[dic_key].bind('<Leave>', on_leave)
            # elif self.aa == "interior loudspeaker" or self.aa == "Interior Loudspeaker":
            #     # button_dic[dic_key] = Button(self.audio_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
            #     button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key],
            #                                  command=add_item, font=('arial', 7, 'bold'))
            #     if 750 < x_position < (x_position + button_dic[dic_key].winfo_reqwidth()):
            #         y_position += 22
            #         x_position = 0
            #     button_dic[dic_key].place(x=x_position, y=y_position)
            #     x_position += button_dic[dic_key].winfo_reqwidth() + space  # place with 3 space
            #     # popup = Menu(self.audio_message_frame, tearoff=0)
            #     popup = Menu(self.all_message_frame, tearoff=0)
            #     popup.add_command(label="  Delete ", command=func)
            #     button_dic[dic_key].bind('<Enter>', on_enter)
            #     button_dic[dic_key].bind("<Button-3>", do_popup)
            #     button_dic[dic_key].bind('<Leave>', on_leave)
            # elif self.aa == "Interior LOGO" or self.aa == "interior LOGO":
            #     # button_dic[dic_key] = Button(self.logo_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
            #     button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key],
            #                                  command=add_item, font=('arial', 7, 'bold'))
            #     if 750 < x_position < (x_position + button_dic[dic_key].winfo_reqwidth()):
            #         y_position += 22
            #         x_position = 0
            #     button_dic[dic_key].place(x=x_position, y=y_position)
            #     x_position += button_dic[dic_key].winfo_reqwidth() + space
            #     popup = Menu(self.all_message_frame, tearoff=0)
            #     # popup = Menu(self.logo_message_frame, tearoff=0)
            #     popup.add_command(label="  Delete ", command=func)
            #     button_dic[dic_key].bind('<Enter>', on_enter)
            #     button_dic[dic_key].bind("<Button-3>", do_popup)
            #     button_dic[dic_key].bind('<Leave>', on_leave)
            #
            # elif self.aa == "Interior Banner" or self.aa == "interior Banner":
            #     # button_dic[dic_key] = Button(self.banner_message_frame, text=self.split_message_dic[dic_key], command=add_item, font=('arial', 7, 'bold'))
            #     button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key],
            #                                  command=add_item, font=('arial', 7, 'bold'))
            #     if 750 < x_position < (x_position + button_dic[dic_key].winfo_reqwidth()):
            #         y_position += 22
            #         x_position = 0
            #     button_dic[dic_key].place(x=x_position, y=y_position)
            #     x_position += button_dic[dic_key].winfo_reqwidth() + space
            #     # popup = Menu(self.banner_message_frame, tearoff=0)
            #     popup = Menu(self.all_message_frame, tearoff=0)
            #     popup.add_command(label="  Delete ", command=func)
            #     button_dic[dic_key].bind('<Enter>', on_enter)
            #     button_dic[dic_key].bind("<Button-3>", do_popup)
            #     button_dic[dic_key].bind('<Leave>', on_leave)

            button_dic[dic_key] = Button(self.all_message_frame, text=self.split_message_dic[dic_key],
                                         command=add_item, font=('arial', 7, 'bold'))
            if 750 < x_position < (x_position + button_dic[dic_key].winfo_reqwidth()):
                y_position += 22
                x_position = 0
            button_dic[dic_key].place(x=x_position, y=y_position)
            x_position += button_dic[dic_key].winfo_reqwidth() + space
            # popup = Menu(self.video_message_frame, tearoff=0)
            popup = Menu(self.all_message_frame, tearoff=0)
            popup.add_command(label="  Delete ", command=func)
            button_dic[dic_key].bind('<Enter>', on_enter)
            button_dic[dic_key].bind("<Button-3>", do_popup)
            button_dic[dic_key].bind('<Leave>', on_leave)

            color = self.split_message_dic[dic_key]
            if color.find("{") == 0:
                button_dic[dic_key].config(bg="pink")
            elif color.find("[") == 0:
                button_dic[dic_key].config(bg="cyan")
            elif color.find("<") == 0:
                button_dic[dic_key].config(bg="light green")
            # button_dic[dic_key].focus()
    def save_data_in_sql(self):
        print(1351)
        list_for_message_description = list(self.split_message_dic.values())
        for item in list_for_message_description:
            if item[0] == "[":
                item_name = item[1:-1:]
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                my_cursor.execute(f"SELECT [name] FROM [messageA] where [description]='{item_name}'")
                description_name = my_cursor.fetchall()
                if len(description_name) != 0:
                    list_for_message_description[list_for_message_description.index(item)] = f"[{description_name[0][0]}]"
                # conn.commit()
                conn.close()
        message_Description_text = "".join(list_for_message_description)
        self.sql_data(f"UPDATE tbl_action SET message_Description = '{message_Description_text}' WHERE action_ID = {self.action_ID}")
        self.on_exit()

        ######################################### add new pop up import message ########################################
    def import_message_top_update(self):
        print(1370)
        if len(self.data_fix_mess) > 0:
            self.import_message_top()
            self.top1.title(self.data_fix_mess[0])
            self.message_name_entry.delete(0, END)
            data = self.sql_data(f"select fileName, fileDescription from tbl_file where fileDescription='{self.data_fix_mess[0]}' and fileExtention='{self.format_file}'")

            self.description_entry.insert(END, data[0][1])
            self.message_name_entry.insert(END, data[0][0])
            old_data = self.description_entry.get()
            # self.description_entry.configure(state=DISABLED)
            self.message_name_entry.configure(state=DISABLED)
            self.done_button.destroy()
            def close_top():
                if not self.description_entry.get() == old_data:
                    self.sql_data(
                        f"UPDATE tbl_file SET fileDescription='{self.description_entry.get()}' WHERE fileName='{self.message_name_entry.get()}'")
                    self.sql_data(
                        f"UPDATE messageA SET description='{self.description_entry.get()}' WHERE name='{self.message_name_entry.get()}'")
                name_data1 = self.message_name_entry.get()
                text_format = name_data1[0:2]
                if text_format == "MA":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MA%'")
                    if len(data) != 0:
                        self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
                        for i in data:
                            self.trigger_audio_table.insert("", END, values=list(i))
                    else:
                        self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
                elif text_format == "MT":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MT%'")
                    if len(data) != 0:
                        self.trigger_text_table.delete(*self.trigger_text_table.get_children())
                        for i in data:
                            self.trigger_text_table.insert("", END, values=list(i))
                    else:
                        self.trigger_text_table.delete(*self.trigger_text_table.get_children())
                elif text_format == "MV":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MV%'")
                    if len(data) != 0:
                        self.trigger_left_table.delete(*self.trigger_left_table.get_children())
                        for i in data:
                            self.trigger_left_table.insert("", END, values=list(i))
                    else:
                        self.trigger_left_table.delete(*self.trigger_left_table.get_children())
                elif text_format == "ML":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%ML%'")
                    if len(data) != 0:
                        self.trigger_logo_table.delete(*self.trigger_logo_table.get_children())
                        for i in data:
                            self.trigger_logo_table.insert("", END, values=list(i))
                    else:
                        self.trigger_logo_table.delete(*self.trigger_logo_table.get_children())
                elif text_format == "MB":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MB%'")

                    if len(data) != 0:
                        self.trigger_banner_table.delete(*self.trigger_banner_table.get_children())
                        for i in data:
                            self.trigger_banner_table.insert("", END, values=list(i))
                    else:
                        self.trigger_banner_table.delete(*self.trigger_banner_table.get_children())
                self.top1.destroy()
            self.done_button = Button(self.import_message_main_frame, text="Done", font=('arial', 10, 'bold'), width=12,
                                      height=1, bg="#7C7CFC", fg="white", command=close_top)
            self.done_button.place(x=426, y=279)
            self.import_file_name_in_txt()
        else:
            messagebox.showerror("Error", f"Select", parent=self.top)



    def import_message_top(self):
        print(1443)
        self.top1 = Toplevel()
        self.top1.title("Import Message")
        self.top1.geometry("900x320+400+150")

        ############################## style for combobox ##################################
        z = tkinter.ttk.Style(self.top1)
        z.theme_use('clam')
        z.configure('Treeview.Heading', background="light gray")

        ################################ main frame ############################################
        self.import_message_main_frame = Frame(self.top1, relief=RIDGE, background='light gray', bd=4)
        self.import_message_main_frame.place(x=0, y=0, height=320, width=900)

        import_message_top_frame = Frame(self.import_message_main_frame, relief=RIDGE, background='light gray', bd=4)
        import_message_top_frame.place(x=10, y=10, height=100, width=530)

        message_name_label = Label(import_message_top_frame, text='Message Name',
                                   font=('times new roman', 13, "bold"), background='light gray', fg="Black", bd=4)
        message_name_label.place(x=10, y=10)

        self.message_name_entry = Entry(import_message_top_frame, font=('times new roman', 15, 'bold'))
        self.message_name_entry.place(x=150, y=10, width=350)

        description_label = Label(import_message_top_frame, text='Description',
                                  font=('times new roman', 13, "bold"), background='light gray', fg="Black", bd=4)
        description_label.place(x=10, y=50)

        self.description_entry = Entry(import_message_top_frame, font=('times new roman', 15, 'bold'))
        self.description_entry.place(x=150, y=50, width=350)

        import_message_bottom_frame = Frame(self.import_message_main_frame, relief=RIDGE, background='light gray', bd=4)
        import_message_bottom_frame.place(x=10, y=115, height=160, width=530)

        source_file_label = Label(import_message_bottom_frame, text='Source File',
                                  font=('times new roman', 13, "bold"), background='light gray', fg="Black", bd=4)
        source_file_label.place(x=10, y=10)

        self.source_file_entry = Entry(import_message_bottom_frame, font=('times new roman', 15, 'bold'))

        self.source_file_entry1 = Entry(import_message_bottom_frame, font=('times new roman', 15, 'bold'))
        self.source_file_entry1.place(x=150, y=10, width=300)

        language_label = Label(import_message_bottom_frame, text='Language', font=('times new roman', 13, "bold"),
                               background='light gray', fg="Black", bd=4)
        language_label.place(x=10, y=80)
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        self.list_language_combo = []
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            self.list_language_combo.append(it)
        self.language_combobox = tkinter.ttk.Combobox(import_message_bottom_frame, font=("arial", 9, 'bold'),
                                                      height=15, width=30)
        self.language_combobox.set("")
        self.language_combobox["values"] = self.list_language_combo
        self.language_combobox.place(x=150, y=85)

        self.edit_content_button = Button(import_message_bottom_frame, text="Edit Contents",
                                          font=('arial', 10, 'bold'), width=12, height=1, bg="#7C7CFC", fg="white")
        self.edit_content_button.place(x=150, y=120)

        self.view_log_button = Button(import_message_bottom_frame, text="View Log", font=('arial', 10, 'bold'),
                                      width=12, height=1, bg="#7C7CFC", fg="white")
        self.view_log_button.place(x=410, y=120)

        self.import_message_right_frame = Frame(self.import_message_main_frame, relief=RIDGE, background='light gray', bd=4)
        self.import_message_right_frame.place(x=550, y=10, height=291, width=331)

        Import_log_label = Label(self.import_message_right_frame, text='Import Log :',
                                 font=('times new roman', 17, "bold"), background='light gray', fg="Black", bd=4)
        Import_log_label.place(x=10, y=10)


        self.import_log_main_frame = Frame(self.import_message_right_frame)
        self.import_log_main_frame.place(x=20, y=45, height=220, width=290)


        ################################### play audio trigger table #############################
        self.play_audio_trreview_frame = Frame(self.import_log_main_frame)
        self.play_audio_trreview_frame.place(x=0, y=0, height=220, width=290)
        self.scroll_y = Scrollbar(self.play_audio_trreview_frame, orient=VERTICAL)
        self.import_message_play_treeview = tkinter.ttk.Treeview(self.play_audio_trreview_frame, columns="trigg",
                                                                 yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.scroll_y.config(command=self.import_message_play_treeview.yview)
        self.import_message_play_treeview.heading("trigg", text="Combined Trigger")
        self.import_message_play_treeview.pack(fill=BOTH, expand=1)
        self.import_message_play_treeview["show"] = ""
        # self.import_message_play_treeview.bind("<ButtonRelease>", import_play_audio_focus_data)

        def import_play_audio_focus_data(event=''):
            print(1535)
            self.import_log_main_frame.pack_forget()

            self.cursor_row4 = self.import_message_play_treeview.focus()
            self.content4 = self.import_message_play_treeview.item(self.cursor_row4)
            self.data4 = self.content4["values"]

            self.import_log_main_frame = Frame(self.import_message_right_frame)
            self.import_log_main_frame.place(x=20, y=45, height=220, width=290)

            if self.text_radio:
                self.import_log_text_frame = tk.Text(self.import_log_main_frame, height=14, width=36)
                self.import_log_text_frame.place(x=0, y=0)
                file1 = open(f"sqlData\\txt\\{self.data4[0]}", encoding="utf-8")
                self.import_log_text_frame.insert('1.0', f"\n\n{file1.read()}")

                self.cancel_button_text = tk.Button(self.import_log_text_frame, text="X",
                                                    command=lambda: cancel(self.import_log_main_frame), bg="red",
                                                    cursor="arrow")
                self.cancel_button_text.place(x=268, y=0)

                def cancel(frame):
                    self.import_log_main_frame.destroy()
                    # tree_frame.pack()


            elif self.audio_radio:
                play_audio_in_logo = Label(self.import_log_main_frame, font=('arial', 28, "bold"), fg='black', text="🔈",
                                           bg='light gray')
                play_audio_in_logo.place(x=40, y=50)

                play_audio_in_logo1 = Label(self.import_log_main_frame, font=('arial', 12, "bold"), fg='black',
                                            text=f":- {self.data4[0]}", bg='light gray')
                play_audio_in_logo1.place(x=90, y=60)

                def play_import_audio():
                    playsound(f"sqlData\\audio\\{self.data4[0]}")

                self.view_log_button = Button(self.import_log_main_frame, text="♫", font=('arial', 9, 'bold'),
                                              width=8, height=1, bg="#7C7CFC", fg="white", command=play_import_audio)
                self.view_log_button.place(x=90, y=140)

                self.cancel_button_audio = tk.Button(self.import_log_main_frame, text="X",
                                                     command=lambda: cancel(self.import_log_main_frame), bg="red",
                                                     cursor="arrow")
                self.cancel_button_audio.place(x=270, y=1)

                def cancel(frame):
                    self.import_log_main_frame.destroy()
                    # tree_frame.pack()


            elif self.logo_radio:
                self.img_logo_open = (Image.open(f"sqlData\\logo\\{self.data4[0]}"))
                self.resized_image_logo = self.img_logo_open.resize((284, 185), Image.ADAPTIVE)
                self.new_image_logo = ImageTk.PhotoImage(self.resized_image_logo, master=self.import_log_main_frame)

                images_logo_show = tkinter.ttk.Label(self.import_log_main_frame, image=self.new_image_logo)
                images_logo_show.place(x=1, y=30)

                self.cancel_button_logo = tk.Button(self.import_log_main_frame, text="X",
                                                    command=lambda: cancel(self.import_log_main_frame), bg="red",
                                                    cursor="arrow")
                self.cancel_button_logo.place(x=270, y=1)

                def cancel(frame):
                    self.import_log_main_frame.destroy()

            elif self.banner_radio:
                self.img_banner_open = (Image.open(f"sqlData\\banner\\{self.data4[0]}"))
                self.resized_image_banner = self.img_banner_open.resize((284, 185), Image.ADAPTIVE)
                self.new_image_banner = ImageTk.PhotoImage(self.resized_image_banner, master=self.import_log_main_frame)

                images_banner_show = tkinter.ttk.Label(self.import_log_main_frame, image=self.new_image_banner)
                images_banner_show.place(x=1, y=30)

                self.cancel_button_logo = tk.Button(self.import_log_main_frame, text="X",
                                                    command=lambda: cancel(self.import_log_main_frame), bg="red",
                                                    cursor="arrow")
                self.cancel_button_logo.place(x=270, y=1)

                def cancel(frame):
                    self.import_log_main_frame.destroy()

            elif self.video_radio:

                self.label_frame_video = LabelFrame(self.import_log_main_frame, text="Video Play")
                self.label_frame_video.place(x=0, y=20, height=200, width=290)

                self.vid = TkinterVideo(master=self.label_frame_video)
                self.vid.load(f"sqlData\\video\\{self.data4[0]}")
                self.vid.pack(expand=True, fill="both")
                self.vid.play()

                self.cancel_button_video = tk.Button(self.import_log_main_frame, text="X",
                                                     command=lambda: cancel(self.import_log_main_frame), bg="red",
                                                     cursor="arrow")
                self.cancel_button_video.place(x=270, y=1)

                def cancel(frame):
                    self.import_log_main_frame.destroy()

        self.import_message_play_treeview.bind("<ButtonRelease>", import_play_audio_focus_data)
        self.var_2 = IntVar(self.import_message_main_frame)
        self.import_audio_mess = Radiobutton(import_message_bottom_frame, variable=self.var_2, text='Audio',
                                             font=('arial', 11, 'bold'), value=1, background='light gray')
        self.import_audio_mess.place(x=150, y=50)

        self.import_text_mess = Radiobutton(import_message_bottom_frame, variable=self.var_2, text='Text',
                                            font=('arial', 11, 'bold'), value=2, background='light gray')
        self.import_text_mess.place(x=226, y=50)

        self.import_video_mess = Radiobutton(import_message_bottom_frame, variable=self.var_2, text='Video',
                                             font=('arial', 11, 'bold'), value=3, background='light gray')
        self.import_video_mess.place(x=295, y=50)

        self.import_banner_mess = Radiobutton(import_message_bottom_frame, variable=self.var_2, text='Banner',
                                              font=('arial', 11, 'bold'), value=4, background='light gray')
        self.import_banner_mess.place(x=372, y=50)

        self.import_logo_mess = Radiobutton(import_message_bottom_frame, variable=self.var_2, text='Logo',
                                            font=('arial', 11, 'bold'), value=5, background='light gray')
        self.import_logo_mess.place(x=455, y=50)
        if self.video_radio:
            self.var_2.set(value=3)
            data = self.sql_data(f"SELECT name from messageA where name like'%MV%' order by name desc limit 1")
            if not data:
                data = [("MV0000", )]
            self.format_file = "MP4"
            self.import_audio_mess.configure(state=DISABLED)
            self.import_text_mess.configure(state=DISABLED)
            self.import_banner_mess.configure(state=DISABLED)
            self.import_logo_mess.configure(state=DISABLED)
        elif self.text_radio:
            self.var_2.set(value=2)
            data = self.sql_data(f"SELECT name from messageA where name like'%MT%' order by name desc limit 1")
            self.format_file = "TXT"
            if not data:
                data = [("MT0000", )]
            self.import_audio_mess.configure(state=DISABLED)
            self.import_video_mess.configure(state=DISABLED)
            self.import_banner_mess.configure(state=DISABLED)
            self.import_logo_mess.configure(state=DISABLED)
        elif self.audio_radio:
            self.var_2.set(value=1)
            data = self.sql_data(f"SELECT name from messageA where name like'%MA%' order by name desc limit 1")
            if not data:
                data = [("MA0000", )]
            self.format_file = "MP3"
            self.import_video_mess.configure(state=DISABLED)
            self.import_text_mess.configure(state=DISABLED)
            self.import_banner_mess.configure(state=DISABLED)
            self.import_logo_mess.configure(state=DISABLED)
        elif self.logo_radio:
            self.var_2.set(value=5)
            data = self.sql_data(f"SELECT name from messageA where name like'%ML%' order by name desc limit 1")
            if not data:
                data = [("ML0000", )]
            self.format_file = "ICO"
            self.import_audio_mess.configure(state=DISABLED)
            self.import_text_mess.configure(state=DISABLED)
            self.import_banner_mess.configure(state=DISABLED)
            self.import_video_mess.configure(state=DISABLED)
        elif self.banner_radio:
            self.var_2.set(value=4)
            data = self.sql_data(f"SELECT name from messageA where name like'%MB%' order by name desc limit 1")
            if not data:
                data = [("MB0000", )]
            self.format_file = "PNG"
            self.import_audio_mess.configure(state=DISABLED)
            self.import_text_mess.configure(state=DISABLED)
            self.import_video_mess.configure(state=DISABLED)
            self.import_logo_mess.configure(state=DISABLED)
        name_data = data[0][0]
        text_format = name_data[0:2]
        text_number = int(name_data[2:7])
        if text_number < 9:
            self.message_name_entry.insert(0, f"{text_format}000{text_number+1}")
        elif text_number < 99:
            self.message_name_entry.insert(0, f"{text_format}00{text_number+1}")
        elif text_number < 999:
            self.message_name_entry.insert(0, f"{text_format}0{text_number+1}")
        elif text_number < 9999:
            self.message_name_entry.insert(0, f"{text_format}{text_number+1}")

        def insert_data_tbl_file():
            print(1721)
            if self.message_name_entry.get() == "" or self.description_entry.get() == "" or self.language_combobox.get() == "" or self.source_file_entry.get() == "":
                messagebox.showerror("Error", f"All filed are required", parent=self.top1)
            else:
                src = self.source_file_entry.get()
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                if text_format == "MA":
                    my_cursor.execute("insert into tbl_file values(?,?,?)",
                                      ("MP3", self.message_name_entry.get(), self.description_entry.get()))
                elif text_format == "MT":
                    my_cursor.execute("insert into tbl_file values(?,?,?)",
                                      ("TEXT", self.message_name_entry.get(), self.description_entry.get()))
                elif text_format == "MV":
                    my_cursor.execute("insert into tbl_file values(?,?,?)",
                                      ("MP4", self.message_name_entry.get(), self.description_entry.get()))
                elif text_format == "MB":
                    my_cursor.execute("insert into tbl_file values(?,?,?)",
                                      ("PNG", self.message_name_entry.get(), self.description_entry.get()))
                elif text_format == "ML":
                    my_cursor.execute("insert into tbl_file values(?,?,?)",
                                      ("ICO", self.message_name_entry.get(), self.description_entry.get()))
                my_cursor.execute("insert into [messageA] values(?,?)",
                                  (self.message_name_entry.get(), self.description_entry.get()))
                conn.commit()
                conn.close()
                if text_format == "MA":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MA%'")
                    if len(data) != 0:
                        self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
                        for i in data:
                            self.trigger_audio_table.insert("", END, values=list(i))
                    else:
                        self.trigger_audio_table.delete(*self.trigger_audio_table.get_children())
                elif text_format == "MT":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MT%'")
                    if len(data) != 0:
                        self.trigger_text_table.delete(*self.trigger_text_table.get_children())
                        for i in data:
                            self.trigger_text_table.insert("", END, values=list(i))
                    else:
                        self.trigger_text_table.delete(*self.trigger_text_table.get_children())
                elif text_format == "MV":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MV%'")
                    if len(data) != 0:
                        self.trigger_left_table.delete(*self.trigger_left_table.get_children())
                        for i in data:
                            self.trigger_left_table.insert("", END, values=list(i))
                    else:
                        self.trigger_left_table.delete(*self.trigger_left_table.get_children())
                elif text_format == "ML":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%ML%'")
                    if len(data) != 0:
                        self.trigger_logo_table.delete(*self.trigger_logo_table.get_children())
                        for i in data:
                            self.trigger_logo_table.insert("", END, values=list(i))
                    else:
                        self.trigger_logo_table.delete(*self.trigger_logo_table.get_children())
                elif text_format == "MB":
                    data = self.sql_data(f"SELECT description, [name] from messageA where name like'%MB%'")

                    if len(data) != 0:
                        self.trigger_banner_table.delete(*self.trigger_banner_table.get_children())
                        for i in data:
                            self.trigger_banner_table.insert("", END, values=list(i))
                    else:
                        self.trigger_banner_table.delete(*self.trigger_banner_table.get_children())
                self.top1.destroy()
                # self.top.update()


        def import_button_copy_past():
            print(1793)
            if self.message_name_entry.get() == "" or self.description_entry.get() == "" or self.language_combobox.get() == "" or self.source_file_entry.get() == "":
                messagebox.showerror("Error", f"All filed are required", parent=self.top1)
            else:
                src = self.source_file_entry.get()
                conn = sqlite3.connect("triggers_abhay.db")
                my_cursor = conn.cursor()
                if text_format == "MA":
                    format_file = "MP3"
                    dst = f"sqlData/audio/{self.message_name_entry.get()}{self.language_combobox.get()}.MP3"
                    shutil.copy(src, dst)
                elif text_format == "MT":
                    format_file = "TXT"
                    dst = f"sqlData/txt/{self.message_name_entry.get()}{self.language_combobox.get()}.TXT"
                    shutil.copy(src, dst)
                elif text_format == "MV":
                    format_file = "MP4"
                    dst = f"sqlData/video/{self.message_name_entry.get()}{self.language_combobox.get()}.MP4"
                    shutil.copy(src, dst)
                elif text_format == "MB":
                    format_file = "png"
                    dst = f"sqlData/banner/{self.message_name_entry.get()}{self.language_combobox.get()}.png"
                    shutil.copy(src, dst)
                elif text_format == "ML":
                    format_file = "ico"
                    dst = f"sqlData/logo/{self.message_name_entry.get()}{self.language_combobox.get()}.ico"
                    shutil.copy(src, dst)

                my_cursor.execute(f"SELECT messageName FROM fileImport WHERE messageName = '{self.message_name_entry.get()}{self.language_combobox.get()}.{format_file}'")
                find_file_in_fileImport = my_cursor.fetchall()
                if not find_file_in_fileImport:
                    my_cursor.execute(f"insert into fileImport values(?,?)",
                                      (self.message_name_entry.get(), f'{self.message_name_entry.get()}{self.language_combobox.get()}.{format_file}'))
                conn.commit()
                conn.close()
                self.import_message_play_treeview.delete(*self.import_message_play_treeview.get_children())
                # self.import_log_text_frame.delete("1.0", "end")
                self.import_file_name_in_txt()

        self.import_button = Button(import_message_bottom_frame, text="Import", font=('arial', 10, 'bold'),
                                    width=12, height=1, bg="#7C7CFC", fg="white", command=import_button_copy_past)
        self.import_button.place(x=280, y=120)

        def select_file_hindi():
            print(1837)
            self.source_file_entry.delete(0, END)
            self.source_file_entry1.delete(0, END)
            if self.video_radio:
                filetypes = (('mp4 files', '*.mp4'), ('All files', '*.*'))
                filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top1)

            elif self.text_radio:
                filetypes = (('TXT files', '*.TXT'), ('All files', '*.*'))
                filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top1)

            elif self.audio_radio:
                filetypes = (('mp3 files', '*.mp3'), ('All files', '*.*'))
                filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top1)
            elif self.logo_radio:
                filetypes = (('ico files', '*.ico'), ('All files', '*.*'))
                filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top1)

            elif self.banner_radio:
                filetypes = (('png files', '*.png'), ('All files', '*.*'))
                filename = fd.askopenfilename(title='Open a file', initialdir='/', filetypes=filetypes, parent=self.top1)

            self.source_file_entry.insert(END, filename)
            file_name = os.path.basename(filename)
            self.source_file_entry1.insert(END, file_name)

        def copy_other_folder():
            src = self.source_file_entry.get()
            dst = f"D:\\abhay\\ab\\sir soft\\New folder\\{self.message_name_entry.get()}{self.language_combobox.get()}.MP3"

            shutil.copy(src, dst)


        select_file_button = tk.Button(import_message_bottom_frame, text="Select", font=('arial', 10, 'bold'),
                                       bg="#7C7CFC", fg="white", command=select_file_hindi)
        select_file_button.place(x=460, y=10)

        self.done_button = Button(self.import_message_main_frame, text="Done", font=('arial', 10, 'bold'), width=12,
                                  height=1, bg="#7C7CFC", fg="white", command=insert_data_tbl_file)
        self.done_button.place(x=426, y=279)

    def import_file_name_in_txt(self):
        data = self.sql_data(
            f"SELECT messageName from fileImport where FullFileName like'%{self.message_name_entry.get()}%'")

        for i in data:
            self.import_message_play_treeview.insert("", END, values=i[0])

    def on_exit(self):
        self.top.destroy()
        trigger1.MainApplication5()

class MainApplication_trigger(tk.Frame):
    def __init__(self, parent3):
        tk.Frame.__init__(self)

    @staticmethod
    def num_of_combo_available_global_actionMess_data():
        global num_of_combo_available_global_actionMess
        return num_of_combo_available_global_actionMess

if __name__ == "__main__":
    MainApplication6()
