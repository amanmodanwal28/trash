import main
import tkinter as tk
from tkinter import *
import tkinter.ttk
from tkinter import messagebox
# import pyodbc
import simulation
import xml.etree.ElementTree as ET
import sqlite3
from file_dir import GUI_ICON, SQL_QUERY
data_list_route = ""

class MainApplication3:
    def __init__(self):
        self.journey = tk.Tk()
        self.journey.geometry("1200x615+70+40")
        self.journey.title("Journey")
        # self.journey.iconbitmap("UIFILES/logo2.ico")
        self.journey.iconbitmap(GUI_ICON().gui_icon_file)
        self.journey.configure(bg="light gray")
        self.journey.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.journey.resizable(False, False)
        self.journey.maxsize(1200, 615)
        self.journey.minsize(1200, 615)
        ############################## style for combobox ##################################
        self.z = tkinter.ttk.Style(self.journey)
        self.z.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        self.z.configure('Treeview.Heading', background="light gray")

        self.combi_trigger_id = {} # for triggerID
        
        ################################### left main frame ##############################
        self.journey_left_frame1 = Frame(self.journey, relief=RIDGE, background='light gray', bd=4)
        self.journey_left_frame1.place(x=0, y=30, height=530, width=450)
        
        ################################### right main frame ##############################
        self.journey_right_frame2 = Frame(self.journey, relief=RIDGE, background='light gray', bd=4)
        self.journey_right_frame2.place(x=451, y=30, height=530, width=748)


        #################################### journey route label box ##########################
        self.journey_route1 = Label(self.journey, bd=4, bg='light gray', padx=2, font=('arial', 10, 'bold'), text='Journeys of route :-')
        self.journey_route1.place(x=10, y=0)

        #################################### combobox list ####################################
        self.combobox_journey_list = tkinter.ttk.Combobox(self.journey, font=("arial", 13, 'bold'), width=20)
        self.combobox_journey_list.place(x=150, y=2)
        self.combobox_journey_list.bind("<<ComboboxSelected>>", self.Insert_data_left_journey_treeview)
        self.tbl_journeys_dist_sql = {}
        
        ################################### Button New Delete #############################################
        journey_button_new = Button(self.journey, text=" New ", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.add_new_data)
        journey_button_new.place(x=70, y=565)

        journey_button_delete = Button(self.journey, text=" Delete", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.delete_data_left)
        journey_button_delete.place(x=140, y=565)
        
        journey_button_simulate = Button(self.journey, text="Simulate", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.simulate_top)
        journey_button_simulate.place(x=800, y=565)
        

        ########################################### scroll bar in (left journey frame) ############################################
        self.left_journey_scroll_y = tk.Scrollbar(self.journey_left_frame1, orient=VERTICAL)
        self.left_journey_treeview = tkinter.ttk.Treeview(self.journey_left_frame1, columns=("name", "condition", "departure", "service", "totalcars", "handicars"),
                                                          yscrollcommand=self.left_journey_scroll_y.set, show="headings")
        self.left_journey_scroll_y.pack(side=RIGHT, fill=Y)
        self.left_journey_scroll_y.config(command=self.left_journey_treeview.yview)
        self.left_journey_treeview.heading("name", text="Name")
        self.left_journey_treeview.column("name", width=5, anchor='c')
        self.left_journey_treeview.heading("condition", text="Condition")
        self.left_journey_treeview.column("condition", width=50, anchor='c')
        self.left_journey_treeview.heading("departure", text="Departure")
        self.left_journey_treeview.column("departure", width=5, anchor='c')
        self.left_journey_treeview.heading("service", text="Service")
        self.left_journey_treeview.column("service", width=5, anchor='c')
        self.left_journey_treeview.heading("totalcars", text="Totalcars")
        self.left_journey_treeview.column("totalcars", width=5, anchor='c')
        self.left_journey_treeview.heading("handicars", text="Handicars")
        self.left_journey_treeview.column("handicars", width=5, anchor='c')
        self.left_journey_treeview.pack(fill=BOTH, expand=1)
        self.left_journey_treeview.bind("<ButtonRelease>", self.get_left_treeview)
        self.cursor_row3_old = None
        self.event_combo_box_left = None
        self.all_change_data_left = {}

        ############################### scroll bar in (right journey frame) #################################
        self.right_journey_scroll_y = tk.Scrollbar(self.journey_right_frame2, orient=VERTICAL)
        self.right_journey_treeview = tkinter.ttk.Treeview(self.journey_right_frame2, columns=(
                                                          "stnno", "stn", "arriv", "depar", "cond", "plat", "trigg", "lng"),
                                                            yscrollcommand=self.right_journey_scroll_y.set, show="headings")
        self.right_journey_scroll_y.pack(side=RIGHT, fill=Y)
        self.right_journey_scroll_y.config(command=self.right_journey_treeview.yview)
        self.right_journey_treeview.heading("stnno", text="StationNo")
        self.right_journey_treeview.column("stnno", width=0, anchor='c')
        self.right_journey_treeview.heading("stn", text="Station")
        self.right_journey_treeview.column("stn", width=60, anchor='c')
        self.right_journey_treeview.heading("arriv", text="Arrival")
        self.right_journey_treeview.column("arriv", width=0, anchor='c')
        self.right_journey_treeview.heading("depar", text="Departure")
        self.right_journey_treeview.column("depar", width=0, anchor='c')
        self.right_journey_treeview.heading("cond", text="Condition")
        self.right_journey_treeview.column("cond", width=1, anchor='c')
        self.right_journey_treeview.heading("plat", text="Platform")
        self.right_journey_treeview.column("plat", width=1, anchor='c')
        self.right_journey_treeview.heading("trigg", text="Trigger")
        self.right_journey_treeview.column("trigg", width=45, anchor='c')
        self.right_journey_treeview.heading("lng", text="Language")
        self.right_journey_treeview.column("lng", width=80, anchor='c')
        self.right_journey_treeview.pack(fill=BOTH, expand=1)
        self.event_combo_box = None
        self.right_journey_treeview.bind("<ButtonRelease>", self.get_right_treeview)
        # self.right_journey_treeview.bind("<Double-1>", self.edit_data_right_treeview)
        self.save_button = None
        self.all_change_data = {}

        ######################################## Menu bar #################################################
        self.menu = tk.Menu(self.journey)
        self.Edit = tk.Menu(self.menu, tearoff=0)
        self.Edit.add_command(label="New")
        self.Edit.add_command(label="Delete")

        self.menu.add_cascade(label="Menu", menu=self.Edit)
        self.journey.config(menu=self.menu)
        ###########################################################
        popup = Menu(self.journey_left_frame1, tearoff=0)
        popup.add_command(label="new")
        popup.add_command(label="Edit")
        self.show_journey_in_combobox()
        self.journey.mainloop()

    ####### show table in combobox function in previous route ########
    def combobox_routeID(self):
        self.routeID = dict(self.table_name)
        for i in self.routeID:
            if self.routeID[i] == self.combobox_journey_list.get():
                self.routeID_variable = i
                return self.routeID_variable
    def show_journey_in_combobox(self):
        print(125)
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute("SELECT routeID,routeName FROM tbl_routes")
        # self.table_name = my_cursor.fetchall()
        self.table_name = SQL_QUERY("SELECT routeID,routeName FROM tbl_routes").QUERY_COMMAND()
        m = []
        for j in self.table_name:
            p = list(j)
            m.append(p[1])
        self.combobox_journey_list["value"] = m
        if m:
           self.combobox_journey_list.set(m[0])
           self.Insert_data_left_journey_treeview()

    ################## treeview data insert in left frame #########################################
    def Insert_data_left_journey_treeview(self, event=""):
        print(140)
        self.destroy_data()
        self.change_save_message()
        self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
        self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute(
        #     f'''select journeyName,condition,departure,serviceType,totalCars,handicapCar,journeyID from tbl_journeys where routeID={self.combobox_routeID()}''')
        # stn_left_table = my_cursor.fetchall()
        stn_left_table = SQL_QUERY(f'''select journeyName,condition,departure,serviceType,totalCars,handicapCar,journeyID from tbl_journeys where routeID={self.combobox_routeID()}''').QUERY_COMMAND()
        if len(stn_left_table) != 0:
            self.tbl_journeys_dist_sql.clear()
            self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
            for journeyName_sql, condition_sql, departure_sql, serviceType_sql, totalCars_sql, handicapCar_sql,journeyID_sql in stn_left_table:
                self.left_journey_treeview.insert("", END, values=(journeyName_sql, condition_sql,departure_sql,serviceType_sql,totalCars_sql,handicapCar_sql,journeyID_sql))
                self.tbl_journeys_dist_sql[journeyID_sql] = (journeyName_sql, condition_sql,departure_sql,serviceType_sql,totalCars_sql,handicapCar_sql,journeyID_sql)
            self.journey_id = stn_left_table[0][6]
            self.Insert_data_right_journey_treeview()
        else:
            self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
        # conn.commit()
        # conn.close()
        if self.left_journey_treeview.get_children():
            children = self.left_journey_treeview.get_children()
            # print("children", children)
            self.left_journey_treeview.selection_set(children[0])
            self.left_journey_treeview.focus(children[0])

        ########################################### right journey treeview #########################
    def Insert_data_right_journey_treeview(self, event=""):
        self.all_change_data.clear()
        if self.event_combo_box:
            self.event_combo_box.destroy()
            self.event_combo_box = None
        if self.save_button:
            self.save_button.destroy()
            self.cancel_button.destroy()
            self.save_button = None
        global data_list_route
        print(172)
        try:
            # conn = sqlite3.connect("triggers_abhay.db")
            # my_cursor = conn.cursor()
            # my_cursor.execute(f"select * from tbl_journeys where journeyID={self.journey_id}")
            # data_tbl_journeys = my_cursor.fetchall()
            data_tbl_journeys = SQL_QUERY(f"select * from tbl_journeys where journeyID={self.journey_id}").QUERY_COMMAND()
            data_list_route = data_tbl_journeys
            data_list_route.append(self.combobox_journey_list.get())
            # my_cursor.execute(f'''select stationNo, stationName, arrivalTime, depactureTime, conditional, platformNum, combiTriggerID,languageArea, journeyID, routeStopID from tbl_journeyStops where journeyID={self.journey_id} order by routeStopID''')
            # data2 = my_cursor.fetchall()
            data2 = SQL_QUERY(f'''select stationNo, stationName, arrivalTime, depactureTime, conditional, platformNum, combiTriggerID,languageArea, journeyID, routeStopID from tbl_journeyStops where journeyID={self.journey_id} order by routeStopID''').QUERY_COMMAND()
            if len(data2) != 0:
                self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
                for i in data2:
                    self.right_journey_treeview.insert("", END, values=list(i))
            else:
                self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
            # conn.commit()
            # conn.close()
        except Exception as es:
            print("not saved", f"due to:{str(es)}")

    ########################## delete function left treeview data  #########################
    def delete_data_left(self):
        print(196)
        if self.left_journey_treeview.focus() == "":
            messagebox.showerror("Error", "Select the file ", parent=self.journey)
        else:
            try:
                Delete = messagebox.askyesno("Delete", "Are you sure delete the data", parent=self.journey)
                if Delete > 0:
                    # conn = sqlite3.connect("triggers_abhay.db")
                    # my_cursor = conn.cursor()
                    # sql_data1 = f"delete from tbl_journeys where journeyID=? and routeID=?"
                    # value1 = (self.journey_id, self.combobox_routeID(),)
                    # my_cursor.execute(sql_data1, value1)
                    SQL_QUERY(f"delete from tbl_journeys where journeyID={self.journey_id} and routeID={self.combobox_routeID()}").QUERY_COMMAND()
                    # sql_data = f"delete from tbl_journeyStops where journeyID=?"
                    # value = (self.journey_id,)
                    # my_cursor.execute(sql_data, value)
                    SQL_QUERY(f"delete from tbl_journeyStops where journeyID={self.journey_id}").QUERY_COMMAND()
                else:
                    if not Delete:
                        return
                # conn.commit()
                # conn.close()
                self.Insert_data_left_journey_treeview()
                messagebox.showinfo("Delete", "your train data has been deleted", parent=self.journey)
            except Exception as es:
                messagebox.showerror("Error", f"Due To:{str(es)}", parent=self.journey)

    def change_save_message(self):
        # self.Insert_data_right_journey_treeview()
        print(self.all_change_data_left, "kkkkk")
        if self.all_change_data_left or self.all_change_data:
            def message_fun():
                update_question = messagebox.askyesno("Unsaved Changes", "Do you want to save changed journey",
                                                      parent=self.journey)
                if update_question:
                    print("update save")
                    self.save_insert_right_data_list()
                    self.all_change_data_left.clear()
                    self.all_change_data.clear()
                    self.Insert_data_right_journey_treeview()
                else:
                    self.all_change_data_left.clear()
                    self.all_change_data.clear()
                    self.Insert_data_left_journey_treeview()
                    self.Insert_data_right_journey_treeview()
                    print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
            print("self.all_change_data_left.keys()", self.all_change_data_left.keys())
            if self.all_change_data_left.keys():
                print("self.all_change_data_left.values()",self.all_change_data_left.keys(), self.all_change_data_left.values())
                if list(self.all_change_data_left.keys())[0] != list(self.all_change_data_left.values())[0][0]:
                    journey_name_ = list(self.all_change_data_left.values())[0][0]
                    # conn = sqlite3.connect("triggers_abhay.db")
                    # my_cursor = conn.cursor()
                    # sql_data1 = f"select journeyName from tbl_journeys where journeyName={journey_name_}"
                    # my_cursor.execute(sql_data1)
                    # data_j_Name = my_cursor.fetchall()
                    data_j_Name = SQL_QUERY(f"select journeyName from tbl_journeys where journeyName={journey_name_}").QUERY_COMMAND()
                    print("data_j_Name", data_j_Name)
                    if data_j_Name:
                        update_question = messagebox.showwarning("Unsaved Changes",
                                                                 f"{journey_name_} Journey name already in use",
                                                                 parent=self.journey)
                        # print("journey_name_", journey_name_)
                        self.all_change_data_left.clear()
                        self.all_change_data.clear()
                        self.Insert_data_left_journey_treeview()
                        self.Insert_data_right_journey_treeview()
                    else:
                        message_fun()
                else:
                    message_fun()



            else:
                message_fun()
                # update_question = messagebox.askyesno("Unsaved Changes", "Do you want to save changed journey",
                #                                       parent=self.journey)
                # if update_question:
                #     print("update save")
                #     self.save_insert_right_data_list()
                #     self.all_change_data_left.clear()
                #     self.all_change_data.clear()
                #     self.Insert_data_right_journey_treeview()
                # else:
                #     self.all_change_data_left.clear()
                #     self.all_change_data.clear()
                #     self.Insert_data_left_journey_treeview()
                #     self.Insert_data_right_journey_treeview()
                #     print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")



        # if self.all_change_data_left or self.all_change_data:
        #     update_question = messagebox.askyesno("Unsaved Changes", "Do you want to save changed journey", parent=self.journey)
        #     if update_question:
        #         pass
        #         print("update save")
        #         self.save_insert_right_data_list()
        #         self.all_change_data_left.clear()
        #         self.all_change_data.clear()
        #         self.Insert_data_right_journey_treeview()
        #     else:
        #         self.all_change_data_left.clear()
        #         self.all_change_data.clear()
        #         self.Insert_data_left_journey_treeview()
        #         self.Insert_data_right_journey_treeview()
        #         print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")

    def get_left_treeview(self, event=""):
        print(219)
        self.destroy_data()
        self.cursor_row3 = self.left_journey_treeview.focus()
        # print("self.cursor_row3", self.cursor_row3)
        self.content3 = self.left_journey_treeview.item(self.cursor_row3)
        self.data3 = self.content3["values"]
        self.journey_id = self.data3[6]
        # print("self.all_change_data_left", self.all_change_data_left)
        if self.cursor_row3 != self.cursor_row3_old:
            print("yooo 22")
            self.change_save_message()
            self.Insert_data_right_journey_treeview()
        self.cursor_row3_old = self.cursor_row3


        self.column_left = self.left_journey_treeview.identify_column(event.x)  # #1, #2
        self.row_ID_left = self.left_journey_treeview.focus()    # I001, I002
        item_data = self.left_journey_treeview.item(self.row_ID_left)
        # self.row_item_data = item_data.get("values")
        self.row_item_data = item_data.get("values")
        # print(self.row_item_data)
        column_num = int(self.column_left[1]) - 1
        bbox_size = self.left_journey_treeview.bbox(self.row_ID_left, self.column_left)

        if not self.row_item_data:
            pass
        elif self.column_left == "#1":
            entry_box = tkinter.ttk.Entry(self.journey_left_frame1, width=bbox_size[2], justify="center")
            entry_box.insert(END, self.tbl_journeys_dist_sql[self.row_item_data[-1]][column_num])
            # print(type(self.row_item_data[column_num]), str(self.row_item_data[column_num]), self.tbl_journeys_dist_sql[self.row_item_data[-1]][column_num])
            entry_box.place(x=bbox_size[0], y=bbox_size[1], w=bbox_size[2], h=bbox_size[3])
            entry_box.focus()
            self.event_combo_box_left = entry_box
        elif self.column_left == "#2":
            entry_box = tkinter.ttk.Combobox(self.journey_left_frame1, font=("arial", 9, 'bold'), width=10,
                                             justify="center")
            entry_box.set(self.row_item_data[column_num])
            entry_box.bind("<<ComboboxSelected>>", self.destroy_data)
            entry_box.place(x=bbox_size[0], y=bbox_size[1], w=bbox_size[2], h=bbox_size[3])
            self.event_combo_box_left = entry_box
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            days = []
            for i in root.findall("timeConditional"):
                it = i.find("name").text
                days.append(it)
            entry_box["values"] = days
        elif self.column_left == "#3":
            def show_arrival_entry(event=""):
                if len(entry_box.get()) == 2:
                    entry_box.insert(2, ":")
                if not event.char.isdigit():
                    return "break"
                elif len(entry_box.get()) > 3:
                    entry_box.delete(4, tk.END)
                elif not event.char.isdigit():
                    return "break"

            def do_backspace(event=""):
                pass

            entry_box = tkinter.ttk.Entry(self.journey_left_frame1, justify="center")
            entry_box.insert(END, self.row_item_data[column_num])
            entry_box.place(x=bbox_size[0], y=bbox_size[1], w=bbox_size[2], h=bbox_size[3])
            self.event_combo_box_left = entry_box
            old_data = entry_box.get()

            def remove(event):
                entry_box.delete(0, END)

            def insert_data(event):
                now_data = entry_box.get()
                if old_data == now_data or now_data == "":
                    entry_box.delete(0, END)
                    entry_box.insert(END, self.row_item_data[column_num])
                else:
                    pass
            entry_box.bind("<Key>", show_arrival_entry)
            entry_box.bind("<BackSpace>", do_backspace)
            entry_box.bind("<ButtonRelease>", remove)
            entry_box.focus()
            entry_box.bind("<FocusOut>", insert_data)
        elif self.column_left == "#4":
            entry_box = tkinter.ttk.Combobox(self.journey_left_frame1, font=("arial", 9, 'bold'), width=10,
                                             justify="center")
            entry_box.set(self.row_item_data[column_num])
            entry_box.place(x=bbox_size[0], y=bbox_size[1], w=bbox_size[2], h=bbox_size[3])
            entry_box.bind("<<ComboboxSelected>>", self.destroy_data)
            entry_box["values"] = ("Fast", "Slow")
            self.event_combo_box_left = entry_box
        elif self.column_left == "#5":
            entry_box = tkinter.ttk.Entry(self.journey_left_frame1, width=bbox_size[2], justify="center")
            entry_box.insert(END, self.row_item_data[column_num])
            entry_box.place(x=bbox_size[0], y=bbox_size[1], w=bbox_size[2], h=bbox_size[3])
            self.event_combo_box_left = entry_box
        elif self.column_left == "#6":
            entry_box = tkinter.ttk.Combobox(self.journey_left_frame1, font=("arial", 9, 'bold'), width=10,
                                             justify="center")
            entry_box.set(self.row_item_data[column_num])
            entry_box.bind("<<ComboboxSelected>>", self.destroy_data)
            entry_box.place(x=bbox_size[0], y=bbox_size[1], w=bbox_size[2], h=bbox_size[3])
            entry_box["values"] = ("0", "3", "6", "9", "12", "15")
            self.event_combo_box_left = entry_box




    def destroy_data(self, event=""):
        if self.event_combo_box:
            if type(self.journey_left_frame1) == type(self.event_combo_box):
                self.all_change_data[self.ev_value[0]] = self.right_journey_treeview.item(self.row_ID).get("values")
                self.event_combo_box.destroy()
                self.event_combo_box = None
                # print("self.all_change_data: ", self.all_change_data)
            else:
                self.right_journey_treeview.set(self.row_ID, column=self.column,
                                                value=f"{self.event_combo_box.get()}")
                if self.ev_value != self.right_journey_treeview.item(self.row_ID).get("values"):
                    self.all_change_data[self.ev_value[0]] = self.right_journey_treeview.item(self.row_ID).get("values")
                self.event_combo_box.destroy()
                self.event_combo_box = None
                # print("self.all_change_data: ", self.all_change_data)

        if self.event_combo_box_left:
            self.left_journey_treeview.set(self.row_ID_left, column=self.column_left,
                                           value=f"{self.event_combo_box_left.get()}")
            if self.row_item_data != self.left_journey_treeview.item(self.row_ID_left).get("values"):
                self.all_change_data_left[self.row_item_data[0]] = self.left_journey_treeview.item(self.row_ID_left).get("values")
            self.event_combo_box_left.destroy()
            self.event_combo_box_left = None
            # print(self.all_change_data_left, "all_change_data_left")

    ############## bind function call right treeview data ############################
    def get_right_treeview(self, event=""):
        print(219)
        self.destroy_data()
        self.column = self.right_journey_treeview.identify_column(event.x)  # #1, #2
        self.row_ID = self.right_journey_treeview.focus()    # I001, I002
        ev1_text = self.right_journey_treeview.item(self.row_ID)
        self.ev_value = ev1_text.get("values")
        new_ev = int(self.column[1]) - 1
        colum_box = self.right_journey_treeview.bbox(self.row_ID, self.column)

        if self.ev_value:
            if not self.save_button:
                self.save_button = Button(self.journey, text="Save", font=('arial', 9, 'bold'), bg="#7C7CFC",
                                          fg="white",
                                          command=self.save_insert_right_data_list)
                self.save_button.place(x=1090, y=565)
                self.cancel_button = Button(self.journey, text="Cancel", font=('arial', 9, 'bold'), bg="#7C7CFC",
                                            fg="white",
                                            command=self.Insert_data_right_journey_treeview)
                self.cancel_button.place(x=1140, y=565)


        if not self.ev_value:
            pass
        elif self.column == "#3" or self.column == "#4":
            def show_arrival_entry(event=""):
                if len(entry_box.get()) == 2:
                    entry_box.insert(2, ":")
                if not event.char.isdigit():
                    return "break"
                elif len(entry_box.get()) > 3:
                    entry_box.delete(4, tk.END)
                elif not event.char.isdigit():
                    return "break"
            def do_backspace(event=""):
                pass

            entry_box = tkinter.ttk.Entry(self.journey_right_frame2, width=colum_box[2], justify="center")
            entry_box.insert(END, self.ev_value[new_ev])
            entry_box.place(x=colum_box[0], y=colum_box[1], w=colum_box[2], h=colum_box[3])
            self.event_combo_box = entry_box
            old_data = entry_box.get()
            def remove(event):
                entry_box.delete(0, END)
            def insert_data(event):
                now_data = entry_box.get()
                if old_data == now_data or now_data == "":
                    entry_box.delete(0, END)
                    entry_box.insert(END, self.ev_value[new_ev])
                else:
                    pass
            entry_box.bind("<Key>", show_arrival_entry)
            entry_box.bind("<BackSpace>", do_backspace)
            entry_box.bind("<ButtonRelease>", remove)
            entry_box.focus()
            entry_box.bind("<FocusOut>", insert_data)

        elif self.column == "#5":
            entry_box = tkinter.ttk.Combobox(self.journey_right_frame2, font=("arial", 9, 'bold'), width=10,
                                             justify="center")
            entry_box.set(self.ev_value[new_ev])
            entry_box.place(x=colum_box[0], y=colum_box[1], w=colum_box[2], h=colum_box[3])
            entry_box.bind("<<ComboboxSelected>>", self.destroy_data)
            self.event_combo_box = entry_box
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            days = []
            for i in root.findall("timeConditional"):
                it = i.find("name").text
                days.append(it)
            entry_box["values"] = days
        elif self.column == "#6":
            entry_box = tkinter.ttk.Combobox(self.journey_right_frame2, font=("arial", 9, 'bold'), width=10,
                                             justify="center")
            entry_box.set(self.ev_value[new_ev])
            entry_box.place(x=colum_box[0], y=colum_box[1], w=colum_box[2], h=colum_box[3])
            entry_box["values"] = ("", "Left", "Right", "Both")
            entry_box.bind("<<ComboboxSelected>>", self.destroy_data)
            self.event_combo_box = entry_box
        elif self.column == "#7":
            entry_box = tkinter.ttk.Combobox(self.journey_right_frame2, font=("arial", 9, 'bold'), width=10,
                                             justify="center")
            entry_box.set(self.ev_value[new_ev])
            entry_box.bind("<<ComboboxSelected>>", self.destroy_data)
            entry_box.place(x=colum_box[0], y=colum_box[1], w=colum_box[2], h=colum_box[3])
            self.event_combo_box = entry_box
            def show_trigger_in_combobox_journey():
                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute("SELECT combiTriggerName, combiTriggerID from tbl_combiTrigger")
                # table_name = my_cursor.fetchall()
                table_name = SQL_QUERY("SELECT combiTriggerName, combiTriggerID from tbl_combiTrigger").QUERY_COMMAND()
                self.combi_trigger_id = dict(table_name)
                n = []
                for j in table_name:
                    q = list(j)
                    n.append(q[0])
                entry_box["values"] = n
                # conn.commit()
                # conn.close()
            show_trigger_in_combobox_journey()
        elif self.column == "#8":
            # self.stop_location_table.set(self.row_ID, column=self.column, value=f"{self.destroy_all_list_2.get()}")
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            self.list_language_combo = []
            for i in root.findall("ImsLanguages"):
                it = i.find("Code").text
                self.list_language_combo.append(it)
            # print(self.list_language_combo)
            num = 0
            entry_box = Frame(self.journey_right_frame2)
            entry_box.place(x=colum_box[0], y=colum_box[1], w=colum_box[2], h=colum_box[3])
            list_language = {}
            entry_box1 = {}
            index_num = 0
            for i in self.list_language_combo:
                def add_list_data(event="", name=i, number=index_num):
                    list_language[number] = entry_box1[name].get()
                    save_table_language = [list_language[num] for num in range(len(list_language)) if num in list_language.keys()]
                    # self.all_change_data[self.ev_value[0]] = ",".join(list_language.values())
                    self.right_journey_treeview.set(self.row_ID, column=self.column,
                                                    value=",".join(save_table_language))
                entry_box1[i] = tkinter.ttk.Combobox(entry_box, font=("arial", 7, 'bold'), justify="center")
                entry_box1[i].bind("<<ComboboxSelected>>", add_list_data)
                # entry_box.set(self.ev_value[new_ev])
                entry_box1[i].place(x=num, y=0, w=colum_box[2]/len(self.list_language_combo), h=colum_box[3])
                entry_box1[i]["values"] = self.list_language_combo
                num = num+(colum_box[2]/len(self.list_language_combo))
                index_num += 1
            self.event_combo_box = entry_box

    def save_insert_right_data_list(self):
        print(298)
        self.destroy_data()
        for stationNO, stationName, arriv_time, deparch_time, condition, platform_num, combi_trigger_name, language_area, journey_id, route_id in self.all_change_data.values():
            # print("stationNO = ", stationNO, " || stationName = ", stationName, " || ArrivalTime = ", arriv_time, "  || DepactureTime = ", deparch_time, " || conditon = ", condition, " || platform = ", platform_num, " || combitriggerID = ", combi_trigger_name, " || language_area = ", language_area, " || journey_id = ", journey_id, " || route_id = ", route_id)
            try:
                combi_trigger_id_new = self.combi_trigger_id[combi_trigger_name]
            except KeyError:
                combi_trigger_id_new = 0
            # conn = sqlite3.connect("triggers_abhay.db")
            # my_cursor = conn.cursor()
            # my_cursor.execute(
            #     f"UPDATE tbl_journeyStops SET arrivalTime=?, depactureTime=?, conditional=?, platformNum=?, combiTriggerID=?, languageArea=?, combiTriggerIDn=? WHERE journeyID = {journey_id} and routeStopID = {route_id}",
            #     (arriv_time, deparch_time, condition, platform_num, combi_trigger_name, language_area, combi_trigger_id_new))
            SQL_QUERY(f"UPDATE tbl_journeyStops SET arrivalTime='{arriv_time}', depactureTime='{deparch_time}', conditional='{condition}', platformNum='{platform_num}', combiTriggerID='{combi_trigger_name}', languageArea='{language_area}', combiTriggerIDn={combi_trigger_id_new} WHERE journeyID = {journey_id} and routeStopID = {route_id}").QUERY_COMMAND()
            # conn.commit()
            ## self.Insert_data_right_journey_treeview()
            # conn.close()

        for journey_name_left, condition_left, departure_left, service_type_left, total_cars_left, handicap_left, journey_id_left in self.all_change_data_left.values():

            conn = sqlite3.connect("triggers_abhay.db")
            my_cursor = conn.cursor()
            print("self.tbl_journeys_dist_sql[journey_id_left][0]", journey_name_left)
            # my_cursor.execute(
            #     f"UPDATE tbl_journeys SET journeyName=?, condition=?, departure=?, serviceType=?, totalCars=?, handicapCar=? WHERE journeyID = {journey_id_left}",
            #     (journey_name_left, condition_left, departure_left, service_type_left, total_cars_left, handicap_left))
            SQL_QUERY(f"UPDATE tbl_journeys SET journeyName='{journey_name_left}', condition='{condition_left}', departure='{departure_left}', serviceType='{service_type_left}', totalCars={total_cars_left}, handicapCar={handicap_left} WHERE journeyID = {journey_id_left}").QUERY_COMMAND()
            # conn.commit()
            ## self.Insert_data_right_journey_treeview()
            # conn.close()
        if self.save_button:
            self.all_change_data_left.clear()
            self.all_change_data.clear()
            # print(self.combi_trigger_id)
            self.save_button.destroy()
            self.cancel_button.destroy()
            self.save_button = None



    ################################### combobox #################################
    def edit_data_right_treeview(self, event=""):
        print(287)
        self.cursor_row4 = self.right_journey_treeview.focus()
        self.content4 = self.right_journey_treeview.item(self.cursor_row4)
        self.data4 = self.content4["values"]
        if not self.data4:
            pass
        else:
            self.Edit_Route = tk.Tk()
            self.Edit_Route.geometry("700x130+550+400")
            self.Edit_Route.title(f"Edit Route :{self.data4[1]}")

            ################################### Arrival #######################################
            def show_arrival_entry(event=""):
                if len(arrival_entry.get()) == 2:
                    arrival_entry.insert(2, ":")
                if not event.char.isdigit():
                    return "break"
                elif len(arrival_entry.get()) > 3:
                    arrival_entry.delete(4, tk.END)
                elif not event.char.isdigit():
                    return "break"
            def do_backspace(event=""):
                pass

            arrival_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Arrival ↓")
            arrival_label.place(x=20, y=17)
            arrival_entry = tkinter.ttk.Entry(self.Edit_Route, font=('arial', 9, 'bold'), width=10)
            arrival_entry.insert(END, self.data4[2])
            arrival_entry.place(x=10, y=40)
            old_data = arrival_entry.get()
            def remove(event):
                arrival_entry.delete(0, END)
            def insert_data(event):
                now_data = arrival_entry.get()
                if old_data == now_data or now_data == "":
                    arrival_entry.delete(0, END)
                    arrival_entry.insert(END, self.data4[2])
                else:
                    pass
            arrival_entry.bind("<Key>", show_arrival_entry)
            arrival_entry.bind("<BackSpace>", do_backspace)
            arrival_entry.bind("<ButtonRelease>", remove)
            arrival_entry.focus()
            arrival_entry.bind("<FocusOut>", insert_data)

            ################################# Departure ########################################

            def show_departure_entry(event=""):
                if len(departure_entry.get()) == 2:
                    departure_entry.insert(2, ":")
                if not event.char.isdigit():
                    return "break"
                elif len(departure_entry.get()) > 3:
                    departure_entry.delete(4, tk.END)
                elif not event.char.isdigit():
                    return "break"

            def do_backspace(event=""):
                pass

            departure_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Departure ↓")
            departure_label.place(x=110, y=17)
            departure_entry = tkinter.ttk.Entry(self.Edit_Route, font=('arial', 9, 'bold'), width=10)
            departure_entry.insert(END, self.data4[3])
            departure_entry.place(x=110, y=40)
            old_data = arrival_entry.get()
            def remove1(event):
                departure_entry.delete(0, END)
            def insert_data1(event):
                now_data = arrival_entry.get()
                if old_data == now_data or now_data == "":
                    departure_entry.delete(0, END)
                    departure_entry.insert(END, self.data4[3])
                else:
                    pass
            departure_entry.bind("<Key>", show_departure_entry)
            departure_entry.bind("<BackSpace>", do_backspace)
            departure_entry.bind("<ButtonRelease>", remove1)
            departure_entry.focus()
            departure_entry.bind("<FocusOut>", insert_data1)

            ################################# Condition #########################################
            condition_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Condition ↓")
            condition_label.place(x=210, y=17)
            combobox_condition = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10)
            combobox_condition.set(self.data4[4])
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            date_condition_right = ["-None-"]
            for i in root.findall("timeConditional"):
                name = i.find("name").text
                date_condition_right.append(name)
            combobox_condition["values"] = date_condition_right
            combobox_condition.place(x=210, y=40)
            ################################# Platform #########################################
            Platform_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Platform ↓")
            Platform_label.place(x=330, y=17)
            combobox_platform = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10)
            combobox_platform.set(self.data4[5])
            combobox_platform["values"] = ("Left", "Right", "Both")
            combobox_platform.place(x=330, y=40)
            ################################# Trigger  ##########################################
            trigger_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Trigger ↓")
            trigger_label.place(x=450, y=17)
            combobox_trigger = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10, )
            combobox_trigger.place(x=450, y=40)
            self.combi_trigger_id = {}

            def show_trigger_in_combobox_journey():
                print(264)
                self.combi_trigger_id.copy()
                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute("SELECT combiTriggerName, combiTriggerID from tbl_combiTrigger")
                # table_name = my_cursor.fetchall()
                table_name = SQL_QUERY("SELECT combiTriggerName, combiTriggerID from tbl_combiTrigger").QUERY_COMMAND()
                self.combi_trigger_id = dict(table_name)
                n = []
                for j in table_name:
                    q = list(j)
                    n.append(q[0])
                combobox_trigger["value"] = n
                combobox_trigger.set(self.data4[6])
                # conn.commit()
                # conn.close()

            show_trigger_in_combobox_journey()

            ################################ Language ############################################
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            self.list_language_combo = []
            for i in root.findall("ImsLanguages"):
                it = i.find("Code").text
                self.list_language_combo.append(it)
            Language_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Language ↓")
            Language_label.place(x=560, y=17)
            combobox_english = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
            combobox_english.set("EN")
            combobox_english["values"] = self.list_language_combo
            combobox_english.place(x=558, y=40)

            combobox_hindi = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
            combobox_hindi.set("HI")
            combobox_hindi["values"] = self.list_language_combo
            combobox_hindi.place(x=605, y=40)

            combobox_regional = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
            combobox_regional.set("MR")
            combobox_regional["values"] = self.list_language_combo
            combobox_regional.place(x=653, y=40)

            ################################# save data edit in right treeview ##########################
            def save_insert_right_data():
                print(298)
                try:
                  combi_trigger_id_new = self.combi_trigger_id[combobox_trigger.get()]
                except KeyError:
                    combi_trigger_id_new = 0
                combobox_language = combobox_english.get() + ',' + combobox_hindi.get() + ',' + combobox_regional.get()
                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                ## my_cursor.execute(f"UPDATE {self.combobox_journey_list.get()} SET arrival='{arrival_entry.get()}', departure='{departure_entry.get()}', conditions='{combobox_condition.get()}', platform='{combobox_platform.get()}', triggers='{combobox_trigger.get()}', language='{combobox_language}' WHERE orders={self.data4[0]}")
                # my_cursor.execute(
                #     f"UPDATE tbl_journeyStops SET arrivalTime=?, depactureTime=?, conditional=?, platformNum=?, combiTriggerID=?, languageArea=?, combiTriggerIDn=? WHERE journeyID = {self.data4[8]} and routeStopID = {self.data4[9]}",
                #     (arrival_entry.get(), departure_entry.get(), combobox_condition.get(), combobox_platform.get(),
                #      combobox_trigger.get(), combobox_language, combi_trigger_id_new))
                SQL_QUERY(f"UPDATE tbl_journeyStops SET arrivalTime='{arrival_entry.get()}', depactureTime='{departure_entry.get()}', conditional='{combobox_condition.get()}', platformNum='{combobox_platform.get()}', combiTriggerID='{combobox_trigger.get()}', languageArea='{combobox_language}', combiTriggerIDn={combi_trigger_id_new} WHERE journeyID = {self.data4[8]} and routeStopID = {self.data4[9]}").QUERY_COMMAND()
                # conn.commit()
                self.Insert_data_right_journey_treeview()
                # conn.close()
                self.Edit_Route.destroy()

            distance_button_add = Button(self.Edit_Route, text=" Submit ", font=('arial', 9, 'bold'), bg="#7C7CFC",
                                         fg="white", command=save_insert_right_data)
            distance_button_add.place(x=300, y=80)
            self.Edit_Route.mainloop()


    ########################################### Add New data in left frame ############################
    def add_new_data(self):
        print(361)
        # print(self.journey.winfo_x(), self.journey.winfo_y())
        self.Add_New = Toplevel()
        self.Add_New.grab_set()
        # self.Add_New.geometry(f"400x300+80+300")
        self.Add_New.geometry(f"400x300+{self.journey.winfo_x()+10}+{self.journey.winfo_y()+270}")
        self.Add_New.title("Add New")
        
        def show_column_entry(event=""):
            if len(self.Entry3.get()) == 2:
                self.Entry3.insert(2, ":")
            if not event.char.isdigit():
                return "break"
            elif len(self.Entry3.get()) > 3:
                self.Entry3.delete(4, tk.END)
            elif not event.char.isdigit():
                return "break"
        def do_backspace(event=""):
            pass

        ################################### Name ######################################################
        self.label1 = Label(self.Add_New, text="Name", width=12, font=('Times', 11, "bold"))
        self.Entry1 = Entry(self.Add_New, width=25,)
        self.label1.place(x=10, y=10)
        self.Entry1.place(x=200, y=10)
        ################################## Condition #################################################
        self.label2 = Label(self.Add_New, text="Condition", width=12, font=('Times', 11, "bold"))
        self.label2.place(x=10, y=50)
        self.combobox_left_condition = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_left_condition.set("none")
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        date_condition = ["-None-"]
        for i in root.findall("timeConditional"):
            name = i.find("name").text
            date_condition.append(name)
        self.combobox_left_condition.set("-None-")
        self.combobox_left_condition["values"] = date_condition
        self.combobox_left_condition.place(x=200, y=50)
        ##################################### Departure ###############################################

        self.label3 = Label(self.Add_New, text="Departure", width=12, font=('Times', 11, "bold"))
        self.Entry3 = Entry(self.Add_New, width=25)
        self.label3.place(x=10, y=90)
        self.Entry3.place(x=200, y=90)
        self.Entry3.bind("<Key>", show_column_entry)
        self.Entry3.bind("<BackSpace>", do_backspace)
        ############################### Service #######################################################
        self.label4 = Label(self.Add_New, text="Service", width=12, font=('Times', 11, "bold"))
        self.label4.place(x=10, y=130)
        self.combobox_service = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_service.set("none")
        self.combobox_service["values"] = ("Fast", "Slow")
        self.combobox_service.place(x=200, y=130)
        ############################# Total cars #######################################################
        self.label5 = Label(self.Add_New, text="Total cars", width=12, font=('Times', 11, "bold"))
        self.Entry5 = Entry(self.Add_New, width=25)
        self.label5.place(x=10, y=170)
        self.Entry5.place(x=200, y=170)
        ############################# Handicars ######################################################
        self.label6 = Label(self.Add_New, text="Handicars", width=12, font=('Times', 11, "bold"))
        self.label6.place(x=10, y=210)
        self.combobox_handicars = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_handicars.set("0")
        self.combobox_handicars["values"] = ("0", "3", "6", "9", "12", "15")
        self.combobox_handicars.place(x=200, y=210)

                
        ################################# insert data in new frame #####################################
        def insert_data_left():
            print(373)
            # conn = sqlite3.connect("triggers_abhay.db")
            # my_cursor = conn.cursor()
            # my_cursor.execute(f"select journeyName from tbl_journeys where journeyName='{self.Entry1.get()}'")
            # data_journeyName = my_cursor.fetchall()
            data_journeyName = SQL_QUERY(f"select journeyName from tbl_journeys where journeyName='{self.Entry1.get()}'").QUERY_COMMAND()
            # print(data_journeyName)
            if data_journeyName:
                messagebox.showinfo("Submit", "already save", parent=self.Add_New)
            else:
                n = self.Entry1.get()
                # sql_journey_id = self.Entry1.get()
                c = self.combobox_left_condition.get()
                # sql_condition = self.combobox_left_condition.get()
                d = self.Entry3.get()
                # sql_departure = self.Entry3.get()
                s = self.combobox_service.get()
                # sql_service_Type = self.combobox_service.get()
                t = self.Entry5.get()
                # sql_total_cars = self.Entry5.get()
                h = self.combobox_handicars.get()
                # sql_handicapCar = self.combobox_handicars.get()
                route_ID = self.combobox_routeID()
                # print(f"n={n} c={c} d={d} s={s} t={t} h={h} route_ID={route_ID}")

                # conn = sqlite3.connect("triggers_abhay.db")
                # my_cursor = conn.cursor()
                # my_cursor.execute("select journeyID from tbl_journeys")
                # data_journeyID = my_cursor.fetchall()
                data_journeyID = SQL_QUERY("select journeyID from tbl_journeys").QUERY_COMMAND()
                # my_cursor.execute("select journeyID from tbl_journeys order by journeyID desc limit 1")
                # data_journey_last_ID = my_cursor.fetchall()
                data_journey_last_ID = SQL_QUERY("select journeyID from tbl_journeys order by journeyID desc limit 1").QUERY_COMMAND()
                if len(data_journeyID) == 0:
                    # my_cursor.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)',
                    #                   (1, route_ID, n, c, d, s, t, h))
                    SQL_QUERY(f"INSERT INTO tbl_journeys VALUES(1,{route_ID},'{n}','{c}','{d}','{s}',{t},{h})").QUERY_COMMAND()
                    sql_query = f'''select r.stopOrder,s.shortName, r.stationID, s.stationNr from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={route_ID} order by r.stopOrder'''
                    # my_cursor.execute(sql_query)
                    # data_tree = my_cursor.fetchall()
                    data_tree = SQL_QUERY(sql_query).QUERY_COMMAND()
                    for i in range(len(data_tree)):
                        journey_name = data_tree[i][3].replace(" ", "")
                        # my_cursor.execute(f'INSERT INTO tbl_journeyStops VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                        #                   (1, data_tree[i][0], journey_name.replace(" ", ""), data_tree[i][1], "00:00", "00:00", "-None-", "", "-None-", "-None-", 0))
                        SQL_QUERY(f"INSERT INTO tbl_journeyStops VALUES(1,{data_tree[i][0]},'{journey_name}','{data_tree[i][1]}','00:00','00:00','-None-','','-None-','-None-',0)").QUERY_COMMAND()

                else:
                    sql_qu = '''SELECT CASE WHEN MAX([journeyID]) = COUNT(*)
                THEN CAST(NULL AS INTEGER)
                -- THEN MAX(column_name) + 1 as other option
                WHEN MIN([journeyID]) > 1
                THEN 1
                WHEN MAX([journeyID]) <> COUNT(*)
                THEN (SELECT MIN([journeyID])+1
                FROM [tbl_journeys]
                WHERE ([journeyID]+ 1)
                NOT IN (SELECT [journeyID] FROM [tbl_journeys]))
                ELSE NULL END
                FROM [tbl_journeys]'''
                #     my_cursor.execute('''SELECT CASE WHEN MAX([journeyID]) = COUNT(*)
                # THEN CAST(NULL AS INTEGER)
                # -- THEN MAX(column_name) + 1 as other option
                # WHEN MIN([journeyID]) > 1
                # THEN 1
                # WHEN MAX([journeyID]) <> COUNT(*)
                # THEN (SELECT MIN([journeyID])+1
                # FROM [tbl_journeys]
                # WHERE ([journeyID]+ 1)
                # NOT IN (SELECT [journeyID] FROM [tbl_journeys]))
                # ELSE NULL END
                # FROM [tbl_journeys]''')
                #     left_number = my_cursor.fetchall()
                    left_number = SQL_QUERY(sql_qu).QUERY_COMMAND()
                    if not left_number[0][0]:
                        # my_cursor.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)',
                        #                   (data_journey_last_ID[0][0] + 1, route_ID, n, c, d, s, t, h))
                        SQL_QUERY(f"INSERT INTO tbl_journeys VALUES({data_journey_last_ID[0][0]+1},{route_ID},'{n}','{c}','{d}','{s}',{t},{h})").QUERY_COMMAND()
                        sql_query = f'''select r.stopOrder,s.shortName, r.stationID, s.stationNr from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={route_ID} order by r.stopOrder'''
                        # my_cursor.execute(sql_query)
                        # data_tree = my_cursor.fetchall()
                        data_tree = SQL_QUERY(sql_query).QUERY_COMMAND()
                        for i in range(len(data_tree)):
                            journey_name = data_tree[i][3].replace(" ", "")
                            # my_cursor.execute(f'INSERT INTO tbl_journeyStops VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                            #                   (data_journey_last_ID[0][0] + 1, data_tree[i][0],
                            #                    journey_name.replace(" ", ""), data_tree[i][1], "00:00",
                            #                    "00:00", "-None-", "", "-None-", "-None-", 0))
                            SQL_QUERY(f"INSERT INTO tbl_journeyStops VALUES({data_journey_last_ID[0][0] + 1},{data_tree[i][0]},'{journey_name}','{data_tree[i][1]}','00:00','00:00','-None-','','-None-','-None-',0)").QUERY_COMMAND()
                    else:
                        # my_cursor.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)',
                        #                   (left_number[0][0], route_ID, n, c, d, s, t, h))
                        SQL_QUERY(f"INSERT INTO tbl_journeys VALUES({left_number[0][0]},{route_ID},'{n}','{c}','{d}','{s}',{t},{h})").QUERY_COMMAND()
                        sql_query = f'''select r.stopOrder,s.shortName, r.stationID, s.stationNr from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={route_ID} order by r.stopOrder'''
                        # my_cursor.execute(sql_query)
                        # data_tree = my_cursor.fetchall()
                        data_tree = SQL_QUERY(sql_query).QUERY_COMMAND()
                        for i in range(len(data_tree)):
                            journey_name = data_tree[i][3].replace(" ", "")
                            # my_cursor.execute(f'INSERT INTO tbl_journeyStops VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                            #                   (left_number[0][0], data_tree[i][0],
                            #                    journey_name.replace(" ", ""), data_tree[i][1], "00:00",
                            #                    "00:00", "-None-", " ", "-None-", "-None-", 0))
                            SQL_QUERY(f"INSERT INTO tbl_journeyStops VALUES({left_number[0][0]},{data_tree[i][0]},'{journey_name}','{data_tree[i][1]}','00:00','00:00','-None-',' ','-None-','-None-',0)").QUERY_COMMAND()

                # conn.commit()
                # conn.close()
                self.Insert_data_left_journey_treeview()
                # messagebox.showinfo("Submit", "your data has been saved", parent=self.Add_New)
                self.Add_New.destroy()
            # conn.close()

        self.submitbutton = Button(self.Add_New, text="Submit", command=insert_data_left)
        self.submitbutton.configure(font=('Times', 11, 'bold'), bg="#7C7CFC", fg="white")
        self.submitbutton.place(x=160, y=250)
        

    def simulate_top(self):
        self.journey.destroy()
        simulation.MainApplicationSimulate()
        print(395)
    def on_exit(self):
        self.change_save_message()
        self.journey.destroy()
        main.MainApplication()


class data_from_route_list(tk.Frame):
    def __init__(self, parent):
        tk.Frame.__init__(self)
    @staticmethod
    def journey_list():
        global data_list_route
        return data_list_route

if __name__ == "__main__":
    MainApplication3()
