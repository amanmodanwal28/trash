
l1 = [9, 9, 9, 12, 9, 9, 110]
l2 = [9, 9, 9, 9]
# print("Need output = [0, 1, 1, 6, 5]")

max_len = len(l1) if l1 > l2 else len(l2)
min_len = len(l1) if l1 < l2 else len(l2)
# print(max_len, min_len)
new_list = []
baro = 0
for num in range(max_len):
    add_num_1 = 0
    add_num_2 = 0
    if num < len(l1):
        add_num_1 = l1[num]
    if num < len(l2):
        add_num_2 = l2[num]
    total = add_num_1 + add_num_2 + baro

    if len(str(total)) < 2:
        new_list.append(total)
        baro = 0
    else:
        new_list.append(int(str(total)[1:]))
        baro = int(str(total)[0])

    if max_len-1 == num and baro != 0:
        new_list.append(baro)


    # print(total)
print(new_list)


# a = "1003333"
# print(int(a[1:]))