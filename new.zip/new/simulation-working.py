import journey
import tkinter as tk
from tkinter import ttk
from tkinter import *
import tkinter.ttk
from tkinter import messagebox
# import pyodbc
import pyautogui
from PIL import Image, ImageTk
import xml.etree.ElementTree as ET
import os
from tkVideoPlayer import TkinterVideo
from ffpyplayer.player import MediaPlayer
import time
# import pygame
from playsound import playsound
from threading import *
import sqlite3
from file_dir import File_Path, SQL_QUERY



# children_index1 = 0
class MainApplicationSimulate:
    def __init__(self):
        # global children_index1
        # children_index1 = 0
        self.simulate = tk.Tk()
        self.simulate.title("Simulate")
        self.simulate.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.simulate.geometry("1200x600+70+40")
        # self.data_from_journey_tbl = journey.data_from_route_list(tk.Frame)
        self.data_from_journey_tbl = journey.data_from_route_list(tk.Frame)
        # print("self.data_from_journey_tbl", self.data_from_journey_tbl)
        # self.data_from_journey_tbl2 = self.data_from_journey_tbl.journey_list()
        self.data_from_journey_tbl2 = [(1, 1, '12904', '-None-', '00:00', 'Fast', 3, 5), 'Golden Temple Mail']
        # print("self.data_from_journey_tbl2", self.data_from_journey_tbl2)

        self.treeET = ET.parse('projectinfo.xml')
        self.rootET = self.treeET.getroot()

        ############################## help ###########################
        menu = tk.Menu(self.simulate)
        Edit = tk.Menu(menu, tearoff=0)
        Edit.add_command(label="Help now")
        menu.add_cascade(label="Help", menu=Edit)
        self.simulate.config(menu=menu)
        ############################## style for combobox ##################################
        z = tkinter.ttk.Style(self.simulate)
        z.theme_use('clam')
        z.configure('Treeview.Heading', background="light gray")

        ################################ main frame ############################################
        simulate_main_frame = Frame(self.simulate, relief=RIDGE, background='light gray', bd=4)
        simulate_main_frame.place(x=0, y=0, height=600, width=1200)

        ##################################### Up frame #####################################
        up_frame = Frame(self.simulate, simulate_main_frame, width=1190, height=40, relief=RIDGE, background='light gray', bd=4)
        up_frame.place(x=5, y=4)

        journey_label = Label(up_frame, text="Journey :- ", font=('times new roman', 12, "bold"), fg='black',
                              bg='light gray')
        journey_label.place(x=0, y=3)

        journey_entry = Entry(up_frame, font=('arial', 8, 'bold'))
        journey_entry.place(x=100, y=6)
        # if self.data_from_journey_tbl2:
        #    journey_entry.insert(END, self.data_from_journey_tbl2[1])
        # journey_entry.configure(state=DISABLED)
        journey_entry.bind("<Key>", DISABLED)

        #################################### route ##################################

        route_label = Label(up_frame, text="Route :- ", font=('times new roman', 12, "bold"), fg='black',
                            bg='light gray')
        route_label.place(x=250, y=3)

        route_entry = Entry(up_frame, font=('arial', 8, 'bold'))
        route_entry.place(x=330, y=6)
        route_entry.bind("<Key>", DISABLED)

        #################################### condition ##################################

        condition_label = Label(up_frame, text="Condition :- ", font=('times new roman', 12, "bold"), fg='black',
                                bg='light gray')
        condition_label.place(x=490, y=3)

        condition_entry = Entry(up_frame, font=('arial', 8, 'bold'))
        condition_entry.place(x=600, y=6)
        condition_entry.bind("<Key>", DISABLED)

        if self.data_from_journey_tbl2:
            journey_entry.insert(END, self.data_from_journey_tbl2[1])
            route_entry.insert(END, self.data_from_journey_tbl2[0][2])
            condition_entry.insert(END, self.data_from_journey_tbl2[0][3])

        ##################################### Up frame 1 #####################################
        up_frame1 = Frame(self.simulate, simulate_main_frame, bd=10, width=1190, height=150, relief=RIDGE, bg='light gray')
        up_frame1.place(x=5, y=45)

        self.img = (Image.open("UIFILES/sta.png"))
        self.resized_image = self.img.resize((60, 55), Image.ADAPTIVE)
        self.new_image = ImageTk.PhotoImage(self.resized_image)
        # Label(win, image=new_image).pack()

        frame1 = Frame(self.simulate, highlightbackground="black", highlightthickness=1, height=110, width=120, bg='light gray')
        frame1.place(x=20, y=60)
        frame2 = Frame(self.simulate, highlightbackground="black", highlightthickness=1, height=110, width=120,
                       bg='light gray')
        frame2.place(x=340, y=60)
        frame3 = Frame(self.simulate, highlightbackground="black", highlightthickness=1, height=110, width=120,
                       bg='light gray')
        frame3.place(x=660, y=60)

        old_station_image = Label(frame1, image=self.new_image)
        old_station_image.place(x=25, y=17)
        self.old_station_name = Label(frame1, font=('times new roman', 7, "bold"), fg='black',
                                      bg='light gray')
        self.old_station_name.place(x=5, y=75)
        old_station_sep = tkinter.ttk.Separator(self.simulate, orient='horizontal')
        old_station_sep.place(x=141, y=110, relwidth=.165, relheight=0.01)

        current_station_image = Label(frame2, image=self.new_image)
        current_station_image.place(x=25, y=17)
        #  n, ne, e, se, s, sw, w, nw, or center
        self.current_station_name = Label(frame2, font=('times new roman', 7, "bold"), fg='black', bg='light gray', anchor="se")
        self.current_station_name.place(x=5, y=75)

        current_station_sep = tkinter.ttk.Separator(self.simulate, orient='horizontal')
        current_station_sep.place(x=461, y=110, relwidth=.165, relheight=0.01)

        next_station_image = Label(frame3, image=self.new_image)
        next_station_image.place(x=25, y=17)

        self.next_station_name = Label(frame3, font=('times new roman', 7, "bold"), fg='black',
                                       bg='light gray', anchor="se")
        self.next_station_name.place(x=5, y=75)
#####################################################################################################
#####################################################################################################
#####################################################################################################

        self.station_language_1 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_1.place(x=10, y=91)
        self.station_language_2 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_2.place(x=29, y=91)
        self.station_language_3 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_3.place(x=48, y=91)
        self.station_language_4 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_4.place(x=67, y=91)
        self.station_language_5 = Label(frame2, font=('arial', 8, "bold"), fg='black',
                                        text="", bg='light gray', borderwidth=1, relief="solid", width=2)
        self.station_language_5.place(x=86, y=91)

#####################################################################################################
#####################################################################################################
#####################################################################################################

        Front_Left = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text="Front Left :", bg='light gray')
        Front_Left.place(x=240, y=275)
        Front_right = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text="Front Right :", bg='light gray')
        Front_right.place(x=240, y=317)
        Interior_Display = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text="Interior Display :", bg='light gray')
        Interior_Display.place(x=240, y=359)
        Interior_Display = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text="Bitmap :", bg='light gray')
        Interior_Display.place(x=240, y=414)

        self.Front_Left_entry = Entry(self.simulate, font=('times new roman', 11, 'bold'), bd=3)
        self.Front_Left_entry.place(x=390, y=270, height=35, width=800)
        self.Front_Left_entry.bind("<Key>", "break")

        self.Front_Right_entry = Entry(self.simulate, font=('times new roman', 11, 'bold'), bd=3)
        self.Front_Right_entry.place(x=390, y=312, height=35, width=800)
        self.Front_Right_entry.bind("<Key>", "break")

        self.Interior_Display_entry = Entry(self.simulate, font=('times new roman', 11, 'bold'), bd=3)
        self.Interior_Display_entry.place(x=390, y=354, height=35, width=800)
        self.Interior_Display_entry.bind("<Key>", "break")

        self.Bit_IMG_BANNER_VIDEO_frame = Frame(self.simulate, height=120, width=800, relief=RIDGE, background='gray52', bd=4)
        self.Bit_IMG_BANNER_VIDEO_frame.place(x=390, y=414)

        # arrival_train = Label(up_frame1, text="ARRIVAL", font=('times new roman', 15, "bold"), fg='black',
        #                       bg='light gray')
        # arrival_train.place(x=500, y=13)

        # screen_entry2 = Entry(up_frame1, font=('times new roman', 15, 'bold'))
        # screen_entry2.place(x=650, y=12, height=40, width=200)
        self.station_list = []
        self.station_list2 = []
        self.station_list2_iid = []
        self.station_list_3_iid = []
        self.station_list3 = {}
        self.station_num_and_name = {}
        self.action_iid_name = {}
        # self.location_side = ""

        self.final_next = 0 # for function (send_dawn_arrow_key)
        self.final_data = 0 # for function (send_dawn_arrow_key)
        self.lan_index = 0 # for function (send_dawn_arrow_key)
        self.lan_index2 = 1 # for function (send_dawn_arrow_key)

        # def send_down_arrow_key():
        #     if self.station_table.focus() == "":
        #         messagebox.showinfo("Submit", "select data from Station ListBox", parent=self.simulate)
        #     else:
        #         self.simulate.update()
        #         pyautogui.press("down")
        #         self.simulate.update()
        #         cursor_row3 = self.station_table.focus()
        #         content3 = self.station_table.item(cursor_row3)
        #         data3 = content3["text"]
        #         if self.lan_index < self.lan_index2:
        #             if int(cursor_row3) == self.final_next or self.station_list.count(data3):
        #                 if not self.lan_index2 == self.lan_index:
        #                     self.station_table.focus(self.final_data + 1)  #############################################
        #                     self.station_table.selection_set(self.final_data + 1)
        #                     self.lan_index += 1
        #             elif int(cursor_row3) == self.station_list_3_iid[-1]:
        #                 language_name = self.language_from_sql()
        #                 language_name_value = language_name[self.lan_index]
        #                 self.action_tbl_data(item_name_find=data3, languageArea=language_name_value)
        #                 if not self.lan_index2 == self.lan_index:
        #                     self.station_table.focus(
        #                         self.final_data + 1)  #############################################
        #                     self.station_table.selection_set(self.final_data + 1)
        #                     self.lan_index += 1
        #         elif not self.lan_index < self.lan_index2:
        #             if int(cursor_row3) == self.final_next or self.station_list.count(data3):
        #                 self.lan_index = 0
        #         self.simulate.update()
        #         cursor_row3 = self.station_table.focus()
        #         content3 = self.station_table.item(cursor_row3)
        #         data3 = content3["text"]
        #         self.next_and_old_action()
        #         language_name = self.language_from_sql()
        #         language_name_value = language_name[self.lan_index]
        #
        #         self.action_tbl_data(item_name_find=data3, languageArea=language_name_value)
        #         self.lan_index2 = len(language_name) - 1
        #         self.get_old_new_current_data()

        self.Forward_button_add = Button(simulate_main_frame, text="Forward", font=('arial', 11, 'bold'), bg="#7C7CFC",
                                         fg="white", command=self.send_down_arrow_key)
        self.Forward_button_add.place(x=240, y=555)
        self.var_value = IntVar()
        def threading():
            # Call work function
            if self.var_value.get() == 1:
                self.Forward_button_add.configure(state=DISABLED, bg="white", fg="black")
                # self.simulate.configure(cursor="circle")
                t1 = Thread(target=self.auto_run)
                t1.start()
            elif self.var_value.get() == 0:
                self.Forward_button_add.configure(state=NORMAL, bg="#7C7CFC", fg="white")
                # self.simulate.configure(cursor="arrow")
                self.a_run = 0

        self.check_box = Checkbutton(simulate_main_frame, text="run", command=threading, offvalue=0, onvalue=1, variable=self.var_value, bg="light gray")
        self.check_box.place(x=370, y=555)

        self.combobox_time_sec = tkinter.ttk.Combobox(simulate_main_frame, font=("arial", 8, 'bold'), width=2, background="light gray",
                                                      values=(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
        self.combobox_time_sec.set(1)
        self.combobox_time_sec.place(x=430, y=557)
        # self.Forward_button_autorun = Button(simulate_main_frame, text="run", font=('arial', 11, 'bold'), bg="#7C7CFC",
        #                                      fg="white", command=threading)
        # self.Forward_button_autorun.place(x=370, y=555)
        # self.Forward_button_autorun = Button(simulate_main_frame, text="Stop", font=('arial', 11, 'bold'), bg="#7C7CFC",
        #                                      fg="white", command=self.auto_run_stop)
        # self.Forward_button_autorun.place(x=470, y=555)

        #################################### station table ###################################
        table_station = Frame(simulate_main_frame)
        table_station.place(x=0, y=193, height=397, width=230)
        scroll_y = Scrollbar(table_station, orient=VERTICAL)
        self.station_table = tkinter.ttk.Treeview(table_station, yscrollcommand=scroll_y.set)
        scroll_y.pack(side=RIGHT, fill=Y)
        scroll_y.config(command=self.station_table.yview)
        self.station_table.heading('#0', text='Station')
        self.station_table.pack(fill=BOTH, expand=1)
        self.simulate_data_sql_tbl_tree()
        self.station_table.bind("<ButtonRelease>", self.get_left_treeview)
        self.video_button = {}
        self.a_run = 1
        self.simulate.mainloop()
    # def auto_run_stop(self):
    #     self.a_run = 0

    def sql_data(self, sql_query):
        return SQL_QUERY(sql_query).QUERY_COMMAND()
        # conn = sqlite3.connect("triggers_abhay.db")
        # my_cursor = conn.cursor()
        # my_cursor.execute(sql_query)
        # if sql_query.find("Select") > -1 or sql_query.find("SELECT") > -1 or sql_query.find("select") > -1:
        #     data = my_cursor.fetchall()
        #     # conn.commit()
        #     conn.close()
        #     return data
        # else:
        #     conn.commit()
        #     conn.close()
    def auto_run(self):
        while True:
            if self.a_run == 1:
                self.send_down_arrow_key()
                time.sleep(int(self.combobox_time_sec.get()))
            elif self.a_run == 0:
                self.a_run = 1
                break
    def send_down_arrow_key(self):
        if self.station_table.focus() == "":
            messagebox.showinfo("Submit", "select data from Station ListBox", parent=self.simulate)
            self.var_value.set(0)
            self.a_run = 0
            self.Forward_button_add.configure(state=NORMAL, bg="#7C7CFC", fg="white")
        else:
            self.simulate.update()
            cursor_row3 = self.station_table.focus()
            # pyautogui.press("down")
            try:
                self.station_table.focus(int(cursor_row3) + 1)  #############################################
                self.station_table.selection_set(int(cursor_row3) + 1)
            except TclError:
                self.station_table.focus(0)  #############################################
                self.station_table.selection_set(0)
            self.simulate.update()
            cursor_row3 = self.station_table.focus()
            content3 = self.station_table.item(cursor_row3)
            data3 = content3["text"]
            if self.lan_index < self.lan_index2:
                if int(cursor_row3) == self.final_next or self.station_list.count(data3):
                    if not self.lan_index2 == self.lan_index:
                        self.station_table.focus(self.final_data + 1)  #############################################
                        self.station_table.selection_set(self.final_data + 1)
                        self.lan_index += 1
                elif int(cursor_row3) == self.station_list_3_iid[-1]:
                    language_name = self.language_from_sql()
                    language_name_value = language_name[self.lan_index]
                    self.action_tbl_data(item_name_find=data3, languageArea=language_name_value)
                    if not self.lan_index2 == self.lan_index:
                        self.station_table.focus(
                            self.final_data + 1)  #############################################
                        self.station_table.selection_set(self.final_data + 1)
                        self.lan_index += 1
            elif not self.lan_index < self.lan_index2:
                if int(cursor_row3) == self.final_next or self.station_list.count(data3):
                    self.lan_index = 0
            self.simulate.update()
            cursor_row3 = self.station_table.focus()
            content3 = self.station_table.item(cursor_row3)
            data3 = content3["text"]
            self.next_and_old_action()
            language_name = self.language_from_sql()
            language_name_value = language_name[self.lan_index]

            self.action_tbl_data(item_name_find=data3, languageArea=language_name_value)
            self.lan_index2 = len(language_name) - 1
            self.get_old_new_current_data()
    def next_and_old_action(self):
        print(309)
        language_name = self.language_from_sql()
        language_name_value = language_name[self.lan_index]
        if language_name:
            a = 0
            for lan_sort_name in language_name:
                if a == 0:
                    self.station_language_1.configure(text=lan_sort_name)
                elif a == 1:
                    self.station_language_2.configure(text=lan_sort_name)
                elif a == 2:
                    self.station_language_3.configure(text=lan_sort_name)
                elif a == 3:
                    self.station_language_4.configure(text=lan_sort_name)
                elif a == 4:
                    self.station_language_5.configure(text=lan_sort_name)
                a += 1
            self.station_language_1.configure(bg="light gray")
            self.station_language_2.configure(bg="light gray")
            self.station_language_3.configure(bg="light gray")
            self.station_language_4.configure(bg="light gray")
            self.station_language_5.configure(bg="light gray")
            if self.station_language_1.cget("text") == language_name_value:
                self.station_language_1.configure(bg="red")
            elif self.station_language_2.cget("text") == language_name_value:
                self.station_language_2.configure(bg="red")
            elif self.station_language_3.cget("text") == language_name_value:
                self.station_language_3.configure(bg="red")
            elif self.station_language_4.cget("text") == language_name_value:
                self.station_language_4.configure(bg="red")
            elif self.station_language_5.cget("text") == language_name_value:
                self.station_language_5.configure(bg="red")
        cursor_row3 = self.station_table.focus()
        content3 = self.station_table.item(cursor_row3)
        data3 = content3["text"]
        try:
            for trigger in self.station_list2_iid:
                if trigger > int(cursor_row3):
                    self.final_next = trigger
                    if self.station_list.count(data3):
                        self.final_next = 0
                if trigger <= int(cursor_row3):
                    self.final_data = trigger
                else:
                    break

        except IndexError:
            pass
        self.simulate.update()
        if self.action_iid_name.get(self.final_data):
            # conn = pyodbc.connect(
            #     'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
            # my_cursor = conn.cursor()
            # my_cursor.execute(
            #     f"select eventValue from tbl_trigger where triggerName='{self.action_iid_name[self.final_data]}'")
            # data6 = my_cursor.fetchall()
            data6 = self.sql_data(sql_query=f"select eventValue from tbl_trigger where triggerName='{self.action_iid_name[self.final_data]}'")
            try:
                self.location_side.destroy()
            except AttributeError:
                pass
            if data6:
                eventValue = data6[0][0]
                if eventValue.find("after the station") > -1:
                    self.location_side = Label(self.simulate, font=('arial', 8), fg='black', text="after the station",
                                               bg='red')
                    # self.location_side.place(x=189, y=100)
                    self.location_side.place(x=498, y=100)
                elif eventValue.find("before the station") > -1:
                    self.location_side = Label(self.simulate, font=('arial', 8), fg='black', text="before the station",
                                               bg='red')
                    # self.location_side.place(x=498, y=100)
                    self.location_side.place(x=189, y=100)
                elif eventValue.find("in the station") > -1:
                    self.location_side = Label(self.simulate, font=('arial', 8), fg='black', text="in the station",
                                               bg='red')
                    self.location_side.place(x=363, y=171)
                else:
                    self.location_side.destroy()

            # conn.commit()
            # conn.close()
    def clear_frame(self):
        for widgets in self.Bit_IMG_BANNER_VIDEO_frame.winfo_children():
            widgets.destroy()
    def action_tbl_data(self, item_name_find, languageArea):
        print(219)
        self.clear_frame()
        try:
            self.video_button.clear()
        except AttributeError:
            pass
        # conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        # my_cursor = conn.cursor()
        # my_cursor.execute(f"select * from tbl_action where action_Name='{item_name_find}'")
        # self.tbl_data = my_cursor.fetchall()
        self.tbl_data = self.sql_data(sql_query=f"select * from tbl_action where action_Name='{item_name_find}'")
        self.tbl_data2 = ""
        self.tbl_data3 = ""
        self.tbl_data_true_false = False
        self.tbl_data_true_false2 = False
        resource_display_value = ""
        if self.tbl_data:
            my_tr = ET.parse("projectinfo.xml")
            root = my_tr.getroot()
            for i in root.findall("resource"):
                resource_name = i.find("name").text
                if resource_name.upper() == self.tbl_data[0][3].upper():
                    resource_display_value = i.find("value").text
        if self.tbl_data:
            for items in self.tbl_data[0][2]:
                if self.tbl_data_true_false:
                    self.tbl_data2 = self.tbl_data2 + items
                if self.tbl_data_true_false2:
                    self.tbl_data2 = self.tbl_data2 + items
                if items == "{":
                    self.tbl_data_true_false = True
                elif items == "}":
                    self.tbl_data_true_false = False
                if items == "[":
                    self.tbl_data_true_false2 = True
                elif items == "]":
                    self.tbl_data_true_false2 = False
            self.items_tbl_action_dictionary = self.tbl_data2.replace("]", ",")
            self.items_tbl_action_list = self.items_tbl_action_dictionary.replace("}", ",")
            self.items_tbl_action_list_dictionary = self.items_tbl_action_list.split(",")
            self.items_tbl_action_data = ""
            self.items_tbl_action_data_list = []
            self.items_tbl_action_list_dictionary.remove("")
            print(self.items_tbl_action_list_dictionary, "disnorrririririr")
            for data_items in self.items_tbl_action_list_dictionary:
                # print(data_items, "461 #######################################")
                # my_cursor.execute(f"select * from messageA where [name]='{data_items}'")
                # name_data = my_cursor.fetchall()
                name_data = self.sql_data(sql_query=f"select * from messageA where [name]='{data_items}'")
                print(name_data, "audioooooooooooooooooooooadiooooooooo")
                # split_tup = os.path.splitext('my_file.txt')
                if name_data:
                    new_name_data = name_data[0][0]
                    if new_name_data[0:2] == "MT":
                        # my_cursor.execute(f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        # messageName_data = my_cursor.fetchall()
                        messageName_data = self.sql_data(sql_query=f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        for name_order in messageName_data:
                            name_order_2 = name_order[0]
                            if name_order_2.find(languageArea) > 0:
                                file = name_order_2
                                # print(self.current_data, "audioooooooooooooooooooooadiooooooooo")
                                # file1 = open(f"sqlData\\txt\\{file}", encoding="utf-8")
                                file1 = open(f"{File_Path().TEXT_Path}{file}", encoding="utf-8")
                        self.items_tbl_action_data = self.items_tbl_action_data + " " + file1.read()
                        self.items_tbl_action_data_list.append(file1.read())
                    elif new_name_data[0:2] == "MV":
                        # my_cursor.execute(f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        # messageName_data = my_cursor.fetchall()
                        messageName_data = self.sql_data(sql_query=f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        for lang_messageName in messageName_data:
                            lang_messageName_2 = lang_messageName[0]
                            if lang_messageName_2.find(languageArea) > 0:
                                file_data = lang_messageName_2

                        # def video_play(x=messageName_data[0][0]):
                        def video_play(x=file_data):
                            Path_video = File_Path().VIDEO_Path
                            self.vid = TkinterVideo(self.Bit_IMG_BANNER_VIDEO_frame)
                            # self.vid.load(f"sqlData\\video\\{x}")
                            self.vid.load(f"{Path_video}{x}")
                            # self.player = MediaPlayer(f"sqlData\\video\\{x}")
                            self.player = MediaPlayer(f"{Path_video}{x}")
                            self.vid.place(relx=0, rely=0.19, relwidth=1, relheight=.8)
                            self.vid .play()
                        num_place = len(self.video_button)
                        # self.video_button[f"{messageName_data[0][0]},{num_place}"] = Button(self.Bit_IMG_BANNER_VIDEO_frame, text=messageName_data[0][0], font=('arial', 7, 'bold'), bg="#7C7CFC",
                        self.video_button[f"{file_data},{num_place}"] = Button(self.Bit_IMG_BANNER_VIDEO_frame, text=file_data, font=('arial', 7, 'bold'), bg="#7C7CFC",
                                                                               fg="white", command=video_play)
                        self.video_button[f"{file_data},{num_place}"].place(x=77*num_place, y=1)
                    elif new_name_data[0:2] == "MA" or new_name_data[0:2] == "ST":
                        self.simulate.configure(cursor="none")
                        if self.var_value.get() == 0:
                            self.Forward_button_add.configure(state=DISABLED, bg="white", fg="black")
                        # my_cursor.execute(f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        # messageName_data = my_cursor.fetchall()
                        messageName_data = self.sql_data(sql_query=f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        for audio_lang in messageName_data:
                            audio_lang_2 = audio_lang[0]
                            if audio_lang_2.find(languageArea) > 0:
                                audio_lang_name = audio_lang_2
                        play_audio = Label(self.simulate, font=('arial', 28, "bold"), fg='black', text="🔈", bg='light gray')
                        play_audio.place(x=1000, y=545)
                        play_audio_1 = Label(self.simulate, font=('arial', 12, "bold"), fg='black', text=f":- {audio_lang_name}", bg='light gray')
                        play_audio_1.place(x=1035, y=558)
                        self.simulate.update()
                        # self.audio_play(audio_lang_name)
                        # t1 = threading.Thread(target=self.audio_play, args=audio_lang_name)
                        # t1.start()
                        # playsound(f"sqlData\\audio\\{audio_lang_name}")
                        playsound(f"{File_Path().Audio_Path}{audio_lang_name}")
                        self.simulate.update()
                        play_audio_1.configure(text="")
                        self.simulate.configure(cursor="arrow")
                        if self.var_value.get() == 0:
                            self.Forward_button_add.configure(state=NORMAL, bg="#7C7CFC", fg="white")

                    elif new_name_data[0:2] == "MB":
                        # my_cursor.execute(f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        # messageName_data = my_cursor.fetchall()
                        messageName_data = self.sql_data(sql_query=f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        for banner_lang in messageName_data:
                            banner_lang_2 = banner_lang[0]
                            if banner_lang_2.find(languageArea) > 0:
                                banner_lang_3 = banner_lang_2

                        # def video_play(x=messageName_data[0][0]):
                        def video_play(x=banner_lang_3):
                            # self.img_banner = (Image.open(f"sqlData\\banner\\{x}"))
                            self.img_banner = (Image.open(f"{File_Path().IMAGE_Path}{x}"))
                            self.resized_image_banner = self.img_banner.resize((786, 88), Image.ADAPTIVE)
                            self.new_image_banner = ImageTk.PhotoImage(self.resized_image_banner)
                            images_banner_show = Label(self.Bit_IMG_BANNER_VIDEO_frame, image=self.new_image_banner)
                            images_banner_show.place(x=1, y=21)
                        num_place = len(self.video_button)
                        # self.video_button[f"{messageName_data[0][0]},{num_place}"] = Button(self.Bit_IMG_BANNER_VIDEO_frame, text=messageName_data[0][0], font=('arial', 7, 'bold'), bg="#7C7CFC",
                        self.video_button[f"{banner_lang_3},{num_place}"] = Button(self.Bit_IMG_BANNER_VIDEO_frame, text=banner_lang_3, font=('arial', 7, 'bold'), bg="#7C7CFC",
                                                                                   fg="white", command=video_play)
                        self.video_button[f"{banner_lang_3},{num_place}"].place(x=77*num_place, y=1)


                    elif new_name_data[0:2] == "ML":
                        # my_cursor.execute(f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        # messageName_data = my_cursor.fetchall()
                        messageName_data = self.sql_data(f"select messageName from fileImport where FullFileName='{name_data[0][0]}'")
                        for logo_lang in messageName_data:
                            logo_lang_2 = logo_lang[0]
                            if logo_lang_2.find(languageArea) > 0:
                                logo_lang_3 = logo_lang_2

                        # def video_play(x=messageName_data[0][0]):
                        def video_play(x=logo_lang_3):
                            # self.img_logo = (Image.open(f"sqlData\\logo\\{x}"))
                            self.img_logo = (Image.open(f"{File_Path().IMAGE_Path}{x}"))
                            self.resized_image_logo = self.img_logo.resize((786, 88), Image.ADAPTIVE)
                            self.new_image_logo = ImageTk.PhotoImage(self.resized_image_logo)
                            images_logo_show = Label(self.Bit_IMG_BANNER_VIDEO_frame, image=self.new_image_logo)
                            images_logo_show.place(x=1, y=21)
                        num_place = len(self.video_button)
                        # self.video_button[f"{messageName_data[0][0]},{num_place}"] = Button(self.Bit_IMG_BANNER_VIDEO_frame, text=messageName_data[0][0], font=('arial', 7, 'bold'), bg="#7C7CFC",
                        self.video_button[f"{logo_lang_3},{num_place}"] = Button(self.Bit_IMG_BANNER_VIDEO_frame, text=logo_lang_3, font=('arial', 7, 'bold'), bg="#7C7CFC",
                                                                                 fg="white", command=video_play)
                        self.video_button[f"{logo_lang_3},{num_place}"].place(x=70*num_place, y=1)

                else:
                    if data_items:
                        # my_cursor.execute(f"select * from messageA where description='{data_items}'")
                        # name_data1 = my_cursor.fetchall()
                        # print(name_data1, "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
                        for country in self.rootET.findall('stationCode'):
                            name = country.find('name').text
                            if name.upper() == data_items.upper():
                                rank = country.find('code').text
                        try:
                            # if rank == "3799": # current_station
                            if rank == "37187" or rank == "37186":  # current_station
                                station_num_id = self.station_num_and_name[self.current_data]
                                languageArea_data_1 = self.xml_EN_HI_OTHER(station_num_id, languageArea)
                                # if self.tbl_data[0][3] == "Interior Loudspeaker":
                                if resource_display_value == "8":
                                    st_audio = f"{station_num_id}{languageArea}.MP3"
                                if languageArea_data_1:
                                    self.items_tbl_action_data = self.items_tbl_action_data + languageArea_data_1[0][0]
                                    self.items_tbl_action_data_list.append(languageArea_data_1[0][0])
                                # self.items_tbl_action_data = self.items_tbl_action_data + ", " + self.current_data # current station name
                            # elif rank == "3798": # previous_station
                            elif rank == "37185" or rank == "37184": # previous_station
                                station_num_id = self.station_num_and_name[self.old_data]
                                languageArea_data_1 = self.xml_EN_HI_OTHER(station_num_id, languageArea)
                                # if self.tbl_data[0][3] == "Interior Loudspeaker":
                                if resource_display_value == "8":
                                    st_audio = f"{station_num_id}{languageArea}.MP3"
                                if languageArea_data_1:
                                    self.items_tbl_action_data = self.items_tbl_action_data + languageArea_data_1[0][0]
                                    self.items_tbl_action_data_list.append(languageArea_data_1[0][0])
                                # self.items_tbl_action_data = self.items_tbl_action_data + ", " + self.old_data  # old station name
                            # elif rank == "3797": # Next_Station
                            elif rank == "37189" or rank == "37188": # Next_Station
                                try:
                                    next_data = self.next_data
                                except AttributeError:
                                    next_data = self.current_data

                                if self.station_num_and_name.get(next_data):
                                    station_num_id = self.station_num_and_name[next_data]
                                    languageArea_data_1 = self.xml_EN_HI_OTHER(station_num_id, languageArea)
                                    # if self.tbl_data[0][3] == "Interior Loudspeaker":
                                    if resource_display_value == "8":
                                        st_audio = f"{station_num_id}{languageArea}.MP3"
                                    if languageArea_data_1:
                                        self.items_tbl_action_data = self.items_tbl_action_data + languageArea_data_1[0][0]
                                        self.items_tbl_action_data_list.append(languageArea_data_1[0][0])
                                    # self.items_tbl_action_data = self.items_tbl_action_data + ", " + self.next_data  # next station name
                            # elif rank == "3796": # allNextStations
                            elif rank == "37191" or rank == "37190": # allNextStations
                                for all_station_name1 in self.all_next_station_data:
                                    station_num_id = self.station_num_and_name[all_station_name1]
                                    languageArea_data_1 = self.xml_EN_HI_OTHER(station_num_id, languageArea)
                                    if languageArea_data_1:
                                        self.items_tbl_action_data = self.items_tbl_action_data + languageArea_data_1[0][0]  # next all station name
                                        self.items_tbl_action_data_list.append(languageArea_data_1[0][0])
                                    # self.items_tbl_action_data = self.items_tbl_action_data + ", " + all_station_name1  # next all station name
                            # elif rank == "3795": # start_station
                            elif rank == "37193" or rank == "37192": # start_station
                                station_num_id = self.station_num_and_name[self.start_station]
                                languageArea_data_1 = self.xml_EN_HI_OTHER(station_num_id, languageArea)
                                # if self.tbl_data[0][3] == "Interior Loudspeaker":
                                if resource_display_value == "8":
                                    st_audio = f"{station_num_id}{languageArea}.MP3"
                                    play_audio_1.configure(text=" ")
                                if languageArea_data_1:
                                    self.items_tbl_action_data = self.items_tbl_action_data + languageArea_data_1[0][0]  # start station
                                    self.items_tbl_action_data_list.append(languageArea_data_1[0][0])
                                # self.items_tbl_action_data = self.items_tbl_action_data + ", " + self.start_station  # start station
                            # elif rank == "3794": # End_Station
                            elif rank == "37195" or rank == "37194": # End_Station
                                station_num_id = self.station_num_and_name[self.End_station]
                                languageArea_data_1 = self.xml_EN_HI_OTHER(station_num_id, languageArea)
                                # if self.tbl_data[0][3] == "Interior Loudspeaker":
                                if resource_display_value == "8":
                                    st_audio = f"{station_num_id}{languageArea}.MP3"
                                if languageArea_data_1:
                                    self.items_tbl_action_data = self.items_tbl_action_data + languageArea_data_1[0][0]
                                    self.items_tbl_action_data_list.append(languageArea_data_1[0][0])
                                # self.items_tbl_action_data = self.items_tbl_action_data + ", " + self.End_station # End station
                            elif rank == "37261": # Carcount, 37261
                                if self.data_from_journey_tbl2:
                                    self.items_tbl_action_data = self.items_tbl_action_data + str(self.data_from_journey_tbl2[0][6])
                                # self.items_tbl_action_data = self.items_tbl_action_data + ", " + self.End_station # End station
                            elif rank == "37263": # serviceType , 37263
                                if self.data_from_journey_tbl2:
                                    self.items_tbl_action_data = self.items_tbl_action_data + self.data_from_journey_tbl2[0][5]
                                    # self.items_tbl_action_data_list.append(languageArea_data_1[0][0])
                                # self.items_tbl_action_data = self.items_tbl_action_data + ", " + self.End_station # End station
                            # if self.tbl_data[0][3] == "Interior Loudspeaker":
                            if resource_display_value == "8":
                                play_audio_2 = Label(self.simulate, font=('arial', 12, "bold"), fg='black',
                                                     text=f":- {station_num_id}", bg='light gray')
                                play_audio_2.place(x=1035, y=558)
                                # self.simulate.update()
                                # playsound(f"sqlData\\audio\\{st_audio}")
                                playsound(f"{File_Path().Audio_Path}{st_audio}")
                                # self.simulate.update()
                                play_audio_2.configure(text=" ")
                        except UnboundLocalError:
                            pass

        if self.tbl_data:
            # resource_display_value = ""
            # my_tr = ET.parse("projectinfo.xml")
            # root = my_tr.getroot()
            # for i in root.findall("resource"):
            #     resource_name = i.find("name").text
            #     if resource_name.upper() == self.tbl_data[0][3].upper():
            #         resource_display_value = i.find("value").text
            # if self.items_tbl_action_data[0] == ",":
            #     self.items_tbl_action_data = self.items_tbl_action_data[1:]
            # if self.tbl_data[0][3] == "front display left" or self.tbl_data[0][3] == "Front display left":
            if resource_display_value == "32":
                self.Front_Left_entry.delete(0, END)
                self.Front_Left_entry.insert(END, self.items_tbl_action_data)
                # self.Front_Left_entry.insert(END, ", ".join(self.items_tbl_action_data_list))
            # elif self.tbl_data[0][3] == "front display right" or self.tbl_data[0][3] == "Front display right":
            elif resource_display_value == "64":
                self.Front_Right_entry.delete(0, END)
                self.Front_Right_entry.insert(END, self.items_tbl_action_data)
                # self.Front_Left_entry.insert(END, ", ".join(self.items_tbl_action_data_list))
            # elif self.tbl_data[0][3] == "interior display" or self.tbl_data[0][3] == "Interior display":
            elif resource_display_value == "4":
                self.Interior_Display_entry.delete(0, END)
                self.Interior_Display_entry.insert(END, self.items_tbl_action_data)
                # self.Front_Left_entry.insert(END, ", ".join(self.items_tbl_action_data_list))
            elif resource_display_value == "16":
                pass
    def language_from_sql(self):
        if self.data_from_journey_tbl2:
            # conn = pyodbc.connect(
            #     'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
            # my_cursor = conn.cursor()
            # my_cursor.execute(
            #     f'''select languageArea from tbl_journeyStops where journeyID={self.data_from_journey_tbl2[0][0]} and stationName='{self.current_data}' ''')
            # languageArea_sql = my_cursor.fetchall()
            languageArea_sql = self.sql_data(sql_query=f'''select languageArea from tbl_journeyStops where journeyID={self.data_from_journey_tbl2[0][0]} and stationName='{self.current_data}' ''')
            for lan_item in languageArea_sql:
                lan_data = lan_item[0]
                lan_final = lan_data.split(",")
            return lan_final

    # @staticmethod
    def xml_EN_HI_OTHER(self, value_1, language_value):
        # conn = pyodbc.connect(
        #     'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        # my_cursor = conn.cursor()
        # my_cursor.execute(
        #     f'''select stationName from tbl_stationNames where stationNameAudio='{value_1}{language_value}.MP3' ''')
        # languageArea_data = my_cursor.fetchall()
        languageArea_data = self.sql_data(sql_query=f'''select stationName from tbl_stationNames where stationNameAudio='{value_1}{language_value}.MP3' ''')
        return languageArea_data

    def get_old_new_current_data(self):
        station_id = self.station_table.get_children()
        self.cursor_row3 = self.station_table.focus()
        self.cursor_row3_new = 0
        try:
            for index_station in list(station_id):
                if int(index_station) <= int(self.cursor_row3):
                    self.cursor_row3_new = index_station
                else:
                    break
        except ValueError:
            pass
        try:
            index = station_id.index(self.cursor_row3_new)
            if index > 0:
                old = self.station_table.item(station_id[index - 1])
                self.old_data = old["text"]
                self.old_station_name.configure(text=self.old_data)
            else:
                self.old_station_name.configure(text="")
            if index < len(station_id) - 1:
                next1 = self.station_table.item(station_id[index + 1])
                self.next_data = next1["text"]
                self.next_station_name.configure(text=self.next_data)
            else:
                self.next_station_name.configure(text="")

            current = self.station_table.item(station_id[index])
            current_start = self.station_table.item(0)
            current_End = self.station_table.item(station_id[-1])
            self.current_data = current["text"]
            self.start_station = current_start["text"]
            self.End_station = current_End["text"]
            self.current_station_name.configure(text=self.current_data)
            self.all_next_station_data = []

            for station_name in range(index, len(station_id)):
                current = self.station_table.item(station_id[station_name])
                all_data = current["text"]
                self.all_next_station_data.append(all_data)


        except ValueError:
            pass
    def get_left_treeview(self, event=""):
        print(190)
        self.get_old_new_current_data()
        self.lan_index = 0
        self.next_and_old_action()
        current1 = self.station_table.item(self.cursor_row3)
        self.current_data1 = current1["text"]
        languageArea_sql = self.language_from_sql()
        languageArea_sql_2 = languageArea_sql[0]
        if languageArea_sql:
            self.action_tbl_data(item_name_find=self.current_data1, languageArea=languageArea_sql_2)
        try:
            print(self.station_list3[int(self.cursor_row3)], "sub sub tree")

        except KeyError:
            print("not found")

    def simulate_data_sql_tbl_tree(self):
        print(468)
        self.station_list.clear()
        if self.data_from_journey_tbl2:
            data6 = self.sql_data(sql_query=f'''select combiTriggerID, stationName, languageArea, stationNo from tbl_journeyStops where journeyID={self.data_from_journey_tbl2[0][0]}''')
            self.num = 0
            if data6:
                self.station_table.delete(*self.station_table.get_children())
                for i in data6:
                    self.station_num_and_name[i[1]] = i[3]
                    self.station_table.insert("", 'end', text=i[1], iid=self.num, open=True)
                    self.station_list.append(i[1])
                    # my_cursor.execute(f"select combiTriggerID from tbl_combiTrigger where combiTriggerName='{i[0]}'")
                    # data8 = my_cursor.fetchall()
                    data8 = self.sql_data(sql_query=f"select combiTriggerID from tbl_combiTrigger where combiTriggerName='{i[0]}'")
                    fix_num = self.num
                    self.num += 1
                    if data8:
                        data7 = self.sql_data(sql_query=f'''select triggerName from tbl_combiTriggerItems where combiTriggerID={data8[0][0]}''')
                        self.station_list2.append(data7)
                        for j in data7:
                            self.action_iid_name[self.num] = j[0]
                            self.station_list2_iid.append(self.num)
                            self.station_table.insert("", 'end', text=j[0], iid=self.num, open=True)
                            self.station_table.move(self.num, fix_num, self.num)
                            # my_cursor.execute(f"select do_this_combi_ID from  tbl_trigger where triggerName='{j[0]}'")
                            # data9 = my_cursor.fetchall()
                            data9 = self.sql_data(sql_query=f"select do_this_combi_ID from  tbl_trigger where triggerName='{j[0]}'")
                            if data9:
                                # my_cursor.execute(
                                #     f"select actionId from do_this_combi_item where do_this_combi_ID='{data9[0][0]}'")
                                # data10 = my_cursor.fetchall()
                                data10 = self.sql_data(sql_query=f"select actionId from do_this_combi_item where do_this_combi_ID='{data9[0][0]}'")
                                add_dic = []
                                for ij in data10:
                                    add_dic.append(ij)
                                self.station_list3[self.num] = tuple(add_dic)
                                fix_num2 = self.num
                                self.num += 1
                                for k in data10:
                                    self.station_table.insert("", 'end', text=k[0], iid=self.num, open=True)
                                    self.station_table.move(self.num, fix_num2, self.num)
                                    self.station_list_3_iid.append(self.num)
                                    self.num += 1

            else:
                self.station_table.delete(*self.station_table.get_children())
            # conn.commit()
            # conn.close()
            if data8:
                self.station_table.focus(0)
                self.station_table.selection_set(0)
                self.get_left_treeview()

    def on_exit(self):
        try:
            self.player.close_player()
        except AttributeError:
            pass
        self.simulate.destroy()
        # journey.MainApplication3()


MainApplicationSimulate()