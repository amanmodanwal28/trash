import shutil, pyodbc, main, os, sqlite3, tkinter.ttk
from tkinter import *
from tkinter import messagebox
import tkinter as tk
from pathlib import Path
from tkinter import filedialog as fd
import xml.etree.ElementTree as ET
from ttkwidgets import TickScale
from file_dir import File_Path, GUI_ICON


# Define the class the application
class MainApplication1:
    # init method or constructor that call by instance variable
    def __init__(self):
        # tk.Tk is crate a window
        self.field = tk.Tk()
        # write a field title name line
        self.field.title('Station')
        # self.size_width = 1920
        # self.size_height = 360
        # print(for_loop)
        # window frame geometry size (width,height,x-place,y-place)
        self.field.geometry("1230x600+30+20")
        # self.field.iconbitmap("logo2.ico")
        self.field.iconbitmap(GUI_ICON().gui_icon_file)
        # the background colour change by config
        self.field.configure(bg="lightsteelblue2")
        self.field.protocol("WM_DELETE_WINDOW", self.on_exit)
        # self.field.grab_set()
        # Allowing root window to not change it's size according to user's need
        # self.field.resizable(False, False)
        # Fixing the size of the root window No one can now expand the size of the root window than the specified one.
        # self.field.maxsize(1100, 600)
        # self.field.minsize(1100, 600)
        self.var_station_name = StringVar()
        self.s = tkinter.ttk.Style(self.field)
        self.s.theme_use('clam')
        self.s.configure('custom.Horizontal.TScale', background='lightsteelblue2', foreground='black',
                         troughcolor='gray')
        self.s.configure('custom.Vertical.TScale', background='lightsteelblue2', foreground='black',
                         troughcolor='gray')

        self.size_width = 0
        self.size_height = 0
        self.size_width_frame = 1001
        self.size_height_frame = 383


        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("display_resolution"):
            it = i.find("size").text
            value_h_w = it.split("x")
            if value_h_w:
                self.size_width = int(value_h_w[0])
                self.size_height = int(value_h_w[1])

        # def size_width_height(w=1920, h=1200):
        #     self.size_width = w
        #     self.size_height = h
        #     range_loop = self.size_width
        #     if self.size_height > self.size_width:
        #         range_loop = self.size_height

        plus = 140
        screen_size_display = Label(self.field, bg="lightsteelblue2", font=("Courier", 14), text="Display Resolution :")
        screen_size_display.place(x=60+plus, y=5)

        screen_size_display1 = Label(self.field, bg="lightsteelblue2", font=("Courier", 14), text=f"{self.size_width}x{self.size_height}")
        screen_size_display1.place(x=285+plus, y=5)

        self.upper_field_frame = LabelFrame(self.field, relief=SUNKEN, height=self.size_height_frame-1, width=self.size_width_frame+1)
        self.upper_field_frame.place(x=60+plus, y=60)

        self.var_width_x = DoubleVar()
        self.var_height_y = DoubleVar()
        self.var_place_x = DoubleVar()
        self.var_place_y = DoubleVar()

        # spin = tkinter.ttk.Spinbox(self.field, textvariable=self.var_width_x, wrap=True, width=10, from_=1001, to=0, increment=1)
        # self.width_scale_x = tkinter.ttk.Scale(self.field, variable=self.var_width_x, from_=0, to=1001, orient=HORIZONTAL, length=1002, style='custom.Horizontal.TScale')
        self.width_scale_x = tkinter.ttk.Scale(self.field, variable=self.var_width_x, from_=0, to=self.size_width_frame, orient=HORIZONTAL, length=self.size_width_frame, command=lambda a: self.show1(side_s="bottom")) # bottom
        # self.width_scale_x = TickScale(self.field, variable=self.var_width_x, from_=0, to=1001, orient=HORIZONTAL, length=990, labelpos="s", style='custom.Horizontal.TScale')
        self.width_scale_x.place(x=60+plus, y=445)
        # spin.place(x=60 + plus, y=465)
        self.height_scale_y = tkinter.ttk.Scale(self.field, variable=self.var_height_y, from_=0, to=self.size_height_frame, orient=VERTICAL, length=self.size_height_frame, command=lambda a: self.show1(side_s="left")) # left
        # self.height_scale_y = TickScale(self.field, variable=self.var_height_y, from_=0, to=383, orient=VERTICAL, length=383, labelpos="w", style='custom.Vertical.TScale')
        self.height_scale_y.place(x=45+plus, y=60)

        self.x_place = tkinter.ttk.Scale(self.field, variable=self.var_place_x, from_=0, to=self.size_width_frame, orient=HORIZONTAL, length=self.size_width_frame, command=lambda a: self.show1(side_s="upper")) # upper
        # self.x_place = TickScale(self.field, variable=self.var_place_x, from_=0, to=1001, orient=HORIZONTAL, length=1002, labelpos="n", style='custom.Horizontal.TScale')
        self.x_place.place(x=60+plus, y=45)

        self.y_place = tkinter.ttk.Scale(self.field, variable=self.var_place_y, from_=0, to=self.size_height_frame, orient=VERTICAL, length=self.size_height_frame, command=lambda a: self.show1(side_s="right")) # right
        # self.y_place = TickScale(self.field, variable=self.var_place_y, from_=0, to=383, orient=VERTICAL, length=382, labelpos="e", style='custom.Vertical.TScale')
        self.y_place.place(x=1065+plus, y=60)


        self.l1 = Label(self.field, bg="lightsteelblue2", font=("Courier", 14))
        self.l1.place(x=10, y=500)
        self.l2 = Label(self.field, bg="lightsteelblue2", font=("Courier", 14))
        self.l2.place(x=10, y=530)

        self.l3 = Label(self.field, bg="lightsteelblue2", font=("Courier", 14))
        self.l3.place(x=10, y=560)

        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()

        self.field_size_frame = LabelFrame(self.upper_field_frame, background="yellow", bd=4, relief=RAISED)
        self.field_size_frame.place(x=0, y=40)

        self.field_table_frame = tk.Frame(self.field)
        self.field_table_frame.place(x=10, y=45, height=415, width=160)

        self.display_type_xml = tkinter.ttk.Combobox(self.field, font=("arial", 9, 'bold'), width=20)
        self.display_type_xml.place(x=10, y=23)
        self.display_type_xml.set("Select Display Type")
        dist_for_combo = {}
        for i in root.findall("resource"):
            it = i.find("group").text
            if it == "1" or it == "3":
                field_name = i.find("name").text
                field_value = i.find("value").text
                dist_for_combo[field_name] = field_value
        self.display_type_xml["value"] = [lis_name for lis_name in dist_for_combo.keys()]
        self.display_type_xml.set("interior display")
        self.add_in_database = ""
        self.list_destroy_all_button = []
        # self.list_destroy_all_button = []
        def add_entry_box():
            self.add_in_database = Entry(self.field_table_frame, font=('times new roman', 10, 'bold'), relief=RIDGE, bd=2, fg="black")
            self.add_in_database.place(x=3, y=3, height=23, width=137)
            self.add_in_database.focus()
            self.add_in_database.bind("<Return>", self.database)
            self.list_destroy_all_button.append(self.add_in_database)
            self.save.configure(bg="#22DCEC")
            # def destroy_all():
            #     for item in self.list_destroy_all_button:
            #         item.destroy()
            #     self.save.configure(bg="#7C7CFC")
            #     n.destroy()
            #     destroy_all_button.destroy()
            #     self.add_in_database = ""
            destroy_all_button = Button(self.field_table_frame, text="X", font=('arial', 8, 'bold'), bg="red", fg="white", command=self.destroy_all)
            destroy_all_button.place(x=122, y=6, height=18, width=15)
            self.list_destroy_all_button.append(destroy_all_button)

        self.scroll_y = tk.Scrollbar(self.field_table_frame, orient=VERTICAL)
        self.field_table = tkinter.ttk.Treeview(self.field_table_frame, columns="Stat", yscrollcommand=self.scroll_y.set)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.field_table.heading("Stat", text="ADD Field", command=add_entry_box)
        self.field_table.column("Stat", width=130)
        self.field_table.pack(fill=BOTH, expand=1)
        self.field_table["show"] = "headings"
        self.scroll_y.configure(command=self.field_table.yview)
        self.field_table.bind("<ButtonRelease>", self.get_database)

        popup = Menu(self.field_table, tearoff=0)

        # Adding Menu Items
        popup.add_command(label="delete", command=self.delete_field)
        # popup.add_command(label="Edit")
        # popup.add_separator()
        # popup.add_command(label="Save")

        def menu_popup(event):
            # display the popup menu
            if self.field_table.focus():
                try:
                    popup.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    # Release the grab
                    popup.grab_release()


        self.field_table.bind("<Button-3>", menu_popup)

        self.tree_data_insert()
        self.display_type_xml.bind("<<ComboboxSelected>>", self.tree_data_insert)
        self.save = Button(self.field, text="SAVE", font=('arial', 8, 'bold'), bg="#7C7CFC", fg="white",
                           command=self.database)
        self.save.place(x=990 + plus, y=10)
        # self.save.place(x=950 + plus, y=565)
        self.field.mainloop()

    def destroy_all(self):
        for item in self.list_destroy_all_button:
            item.destroy()
        self.save.configure(bg="#7C7CFC")
        self.add_in_database = ""
    def tree_data_insert(self, e=""):
        self.field_table.delete(*self.field_table.get_children())
        data = self.sql_data(
            sql_query=f"select field_name from tbl_field where Resource='{self.display_type_xml.get()}'")
        if data:
            for item in data:
                self.field_table.insert("", END, values=item)
            # self.field_size_frame.place_forget()
            self.var_width_x.set(0)
            self.var_place_x.set(0)
            self.var_place_y.set(0)
            self.var_height_y.set(0)
            self.show1()

    def add_field_database(self):
        pass

    def delete_field(self):
        if self.field_table.focus():
            self.sql_data(sql_query=f"delete from tbl_field where field_name ='{self.field_name_tbl[0]}' and  Resource='{self.display_type_xml.get()}'")
            self.tree_data_insert()
        else:
            print("nooooo")



    def sql_data(self, sql_query):
        conn = sqlite3.connect("triggers_abhay.db")
        my_cursor = conn.cursor()
        my_cursor.execute(sql_query)
        if sql_query.find("Select") > -1 or sql_query.find("SELECT") > -1 or sql_query.find("select") > -1:
            data = my_cursor.fetchall()
            # conn.commit()
            conn.close()
            return data
        else:
            conn.commit()
            conn.close()

    def show1(self, side_s=""):
        # print(side_s, "eeeeeeee")
        if side_s == "upper":
            if int(self.var_place_x.get())+int(self.var_width_x.get()) > self.size_width_frame:
                self.var_width_x.set(self.size_width_frame-self.var_place_x.get())
        elif side_s == "bottom":
            if int(self.var_place_x.get())+int(self.var_width_x.get()) > self.size_width_frame:
                self.var_place_x.set(self.size_width_frame-self.var_width_x.get())
        elif side_s == "left":
            if int(self.var_place_y.get())+int(self.var_height_y.get()) > self.size_height_frame:
                self.var_place_y.set(self.size_height_frame-self.var_height_y.get())
        elif side_s == "right":
            if int(self.var_place_y.get())+int(self.var_height_y.get()) > self.size_height_frame:
                self.var_height_y.set(self.size_height_frame-self.var_place_y.get())

        # print(self.var_place_x.get(), self.var_width_x.get())
        print(self.var_place_y.get(), self.var_height_y.get())
        parcent_a = self.var_place_x.get() / 10
        self.value_x = (self.size_width / 100) * parcent_a

        parcent_b = self.var_place_y.get() / 3.83
        self.value_Y = (self.size_height / 100) * parcent_b

        frame_x = self.var_width_x.get() / 10
        self.frame_x1 = (self.size_width / 100) * frame_x

        frame_y = self.var_height_y.get() / 3.83
        self.frame_y1 = (self.size_height / 100) * frame_y
        self.field_size_frame.place(y=int(self.var_place_y.get()) - 5, x=int(self.var_place_x.get()),
                                    height=int(self.var_height_y.get()), width=int(self.var_width_x.get()))
        # print(int(self.var_height_y.get()), int(self.var_width_x.get()), "hhhhhhh")
        # self.field_size_frame.config(height=int(self.var_height_y.get()), width=int(self.var_width_x.get()))

        sel = "X Height Scale Value = " + str(int(self.frame_x1))
        sel1 = "Y Wight Scale Value = " + str(int(self.frame_y1))
        sel3 = "  X Scale Value = " + str(int(self.value_x))
        sel4 = "  Y Scale Value = " + str(int(self.value_Y))
        self.l1.config(text=f"{sel}, {sel3}")
        self.l2.config(text=f"{sel1}, {sel4}")
        self.l3.config(text=f"(x={int(self.value_x)},    y={int(self.value_Y)},     x'={int(self.value_x) + int(self.frame_x1)}    y'={int(self.value_Y) + int(self.frame_y1)})")

    def database(self, even=""):
        self.cursor_row = self.field_table.focus()
        self.content = self.field_table.item(self.cursor_row)
        self.field_name_tbl = self.content["values"]


        if self.add_in_database:
            if self.add_in_database.get().upper() == "FIELD00":
                print("yoooooooonooon")
                return
            if self.add_in_database.get():
                data = self.sql_data(sql_query=f"select * from tbl_field where field_name ='{self.add_in_database.get()}' and  Resource='{self.display_type_xml.get()}'")
                if not data:
                    self.sql_data(sql_query=f"insert into tbl_field values('{self.add_in_database.get()}','{self.display_type_xml.get()}',0,0,0,0)")
                    self.tree_data_insert()
        else:
            if self.field_name_tbl:
                data = self.sql_data(sql_query=f"select * from tbl_field where field_name ='{self.field_name_tbl[0]}' and  Resource='{self.display_type_xml.get()}'")
                if data:
                    self.sql_data(sql_query=f'''UPDATE [tbl_field] SET [height_x] = {int(self.frame_x1)}
                                    ,[Resource] = '{self.display_type_xml.get()}'
                                    ,[width_y] = {str(int(self.frame_y1))}
                                    ,[value_x] = {int(self.value_x)}
                                    ,[value_y] = {int(self.value_Y)}
                                    ,[field_name] = '{self.field_name_tbl[0]}'
                                 where field_name ='{self.field_name_tbl[0]}' and  Resource='{self.display_type_xml.get()}' ''')
        if self.list_destroy_all_button:
            self.destroy_all()

    def get_database(self, event=""):
        self.cursor_row = self.field_table.focus()
        self.content = self.field_table.item(self.cursor_row)
        self.field_name_tbl = self.content["values"]
        if self.field_name_tbl:
            data = self.sql_data(sql_query=f"select * from tbl_field where field_name ='{self.field_name_tbl[0]}' and  Resource='{self.display_type_xml.get()}'")
            # print(data)
            if data:
                scale_x_width = (int(data[0][2]) * 100 / self.size_width) * (self.size_width_frame / 100)
                scale_x_height = (int(data[0][3]) * 100 / self.size_height) * (self.size_height_frame / 100)

                scale_x_place = (int(data[0][4]) * 100 / self.size_width) * (self.size_width_frame / 100)
                scale_y_place = (int(data[0][5]) * 100 / self.size_height) * (self.size_height_frame / 100)

                self.width_scale_x.set(value=int(scale_x_width)+1)
                self.height_scale_y.set(value=int(scale_x_height)+1)
                self.x_place.set(value=int(scale_x_place)+1)
                self.y_place.set(value=int(scale_y_place)+1)
                # self.show1()
            else:
                self.width_scale_x.set(value=0)
                self.height_scale_y.set(value=0)
                self.x_place.set(value=0)
                self.y_place.set(value=0)
            self.show1()
            # conn.close()



    def on_exit(self):
        self.field.destroy()
        # main.MainApplication()


if __name__ == "__main__":
    MainApplication1()
