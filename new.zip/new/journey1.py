import main
import tkinter as tk
from tkinter import *
import tkinter.ttk
from tkinter import messagebox
import pyodbc
import simulation

class MainApplication3:
    def __init__(self):
        self.journey = tk.Tk()
        self.journey.geometry("1200x615+70+40")
        self.journey.title("Journey")
        self.journey.iconbitmap("logo2.ico")
        self.journey.configure(bg="light gray")
        self.journey.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.journey.resizable(False, False)
        self.journey.maxsize(1200, 615)
        self.journey.minsize(1200, 615)
        ############################## style for combobox ##################################
        self.z = tkinter.ttk.Style(self.journey)
        self.z.theme_use('clam')
        # Configure the style of Heading in Treeview widget
        self.z.configure('Treeview.Heading', background="light gray")
        
        ################################### left main frame ##############################
        self.journey_left_frame1 = Frame(self.journey, relief=RIDGE, background='light gray', bd=4)
        self.journey_left_frame1.place(x=0, y=30, height=530, width=450)
        
        ################################### right main frame ##############################
        self.journey_right_frame2 = Frame(self.journey, relief=RIDGE, background='light gray', bd=4)
        self.journey_right_frame2.place(x=451, y=30, height=530, width=748)


        #################################### journey route label box ##########################
        self.journey_route1 = Label(self.journey, bd=4, bg='light gray', padx=2, font=('arial', 10, 'bold'), text='Journeys of route :-')
        self.journey_route1.place(x=10, y=0)

        #################################### combobox list ####################################
        self.combobox_journey_list = tkinter.ttk.Combobox(self.journey, font=("arial", 13, 'bold'), width=20)
        self.combobox_journey_list.place(x=150, y=2)
        self.combobox_journey_list.bind("<<ComboboxSelected>>", self.Insert_data_left_journey_treeview)
        
        ################################### Button New Delete #############################################
        journey_button_new = Button(self.journey, text=" New ", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.add_new_data)
        journey_button_new.place(x=70, y=565)

        journey_button_delete = Button(self.journey, text=" Delete", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.delete_data_left)
        journey_button_delete.place(x=140, y=565)
        
        journey_button_simulate = Button(self.journey, text="Simulate", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=self.simulate_top)
        journey_button_simulate.place(x=800, y=565)
        

        ########################################### scroll bar in (left journey frame) ############################################
        self.left_journey_scroll_y = tk.Scrollbar(self.journey_left_frame1, orient=VERTICAL)
        self.left_journey_treeview = tkinter.ttk.Treeview(self.journey_left_frame1, columns=("name", "condition", "departure", "service", "totalcars", "handicars"),
                                                          yscrollcommand=self.left_journey_scroll_y.set, show="headings")
        self.left_journey_scroll_y.pack(side=RIGHT, fill=Y)
        self.left_journey_scroll_y.config(command=self.left_journey_treeview.yview)
        self.left_journey_treeview.heading("name", text="Name")
        self.left_journey_treeview.column("name", width=25, anchor='c')
        self.left_journey_treeview.heading("condition", text="Condition")
        self.left_journey_treeview.column("condition", width=25, anchor='c')
        self.left_journey_treeview.heading("departure", text="Departure")
        self.left_journey_treeview.column("departure", width=25, anchor='c')
        self.left_journey_treeview.heading("service", text="Service")
        self.left_journey_treeview.column("service", width=25, anchor='c')
        self.left_journey_treeview.heading("totalcars", text="Totalcars")
        self.left_journey_treeview.column("totalcars", width=25, anchor='c')
        self.left_journey_treeview.heading("handicars", text="Handicars")
        self.left_journey_treeview.column("handicars", width=25, anchor='c')
        self.left_journey_treeview.pack(fill=BOTH, expand=1)
        self.left_journey_treeview.bind("<ButtonRelease>", self.get_left_treeview)

        ############################### scroll bar in (right journey frame) #################################
        self.right_journey_scroll_y = tk.Scrollbar(self.journey_right_frame2, orient=VERTICAL)
        self.right_journey_treeview = tkinter.ttk.Treeview(self.journey_right_frame2, columns=(
                                                          "stnno", "stn", "arriv", "depar", "cond", "plat", "trigg", "lng"),
                                                            yscrollcommand=self.right_journey_scroll_y.set, show="headings")
        self.right_journey_scroll_y.pack(side=RIGHT, fill=Y)
        self.right_journey_scroll_y.config(command=self.right_journey_treeview.yview)
        self.right_journey_treeview.heading("stnno", text="StationNo")
        self.right_journey_treeview.column("stnno", width=25, anchor='c')
        self.right_journey_treeview.heading("stn", text="Station")
        self.right_journey_treeview.column("stn", width=25, anchor='c')
        self.right_journey_treeview.heading("arriv", text="Arrival")
        self.right_journey_treeview.column("arriv", width=25, anchor='c')
        self.right_journey_treeview.heading("depar", text="Departure")
        self.right_journey_treeview.column("depar", width=25, anchor='c')
        self.right_journey_treeview.heading("cond", text="Condition")
        self.right_journey_treeview.column("cond", width=25, anchor='c')
        self.right_journey_treeview.heading("plat", text="Platform")
        self.right_journey_treeview.column("plat", width=25, anchor='c')
        self.right_journey_treeview.heading("trigg", text="Trigger")
        self.right_journey_treeview.column("trigg", width=25, anchor='c')
        self.right_journey_treeview.heading("lng", text="Language")
        self.right_journey_treeview.column("lng", width=25, anchor='c')
        self.right_journey_treeview.pack(fill=BOTH, expand=1)
        self.right_journey_treeview.bind("<ButtonRelease>", self.get_right_treeview)
        self.right_journey_treeview.bind("<Double-1>", self.edit_data_right_treeview)

        ######################################## Menu bar #################################################
        self.menu = tk.Menu(self.journey)
        self.Edit = tk.Menu(self.menu, tearoff=0)
        self.Edit.add_command(label="New")
        self.Edit.add_command(label="Delete")

        self.menu.add_cascade(label="Menu", menu=self.Edit)
        self.journey.config(menu=self.menu)
        ###########################################################
        popup = Menu(self.journey_left_frame1, tearoff=0)
        popup.add_command(label="new")
        popup.add_command(label="Edit")
        self.show_journey_in_combobox()
        self.journey.mainloop()

    ####### show table in combobox function in previous route ########
    def combobox_routeID(self):
        self.routeID = dict(self.table_name)
        for i in self.routeID:
            if self.routeID[i] == self.combobox_journey_list.get():
                self.routeID_variable = i
                return self.routeID_variable
    def show_journey_in_combobox(self):
        print(125)
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT routeID,routeName FROM tbl_routes")
        self.table_name = my_cursor.fetchall()
        m = []
        for j in self.table_name:
            p = list(j)
            m.append(p[1])
        self.combobox_journey_list["value"] = m
        self.combobox_journey_list.set("service")

    ################## treeview data insert in left frame #########################################
    def Insert_data_left_journey_treeview(self, event=""):
        print(140)
        self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
        self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(
            f'''select journeyName,condition,departure,serviceType,totalCars,handicapCar,journeyID from tbl_journeys where routeID={self.combobox_routeID()}''')
        stn_left_table = my_cursor.fetchall()
        print(stn_left_table, 567876545678754567)
        if len(stn_left_table) != 0:
            self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
            for i in stn_left_table:
                self.left_journey_treeview.insert("", END, values=list(i))
            self.journey_id = stn_left_table[0][6]
            self.Insert_data_right_journey_treeview()
        else:
            self.left_journey_treeview.delete(*self.left_journey_treeview.get_children())
        conn.commit()
        conn.close()

       ############################# fetchone value name call in combobox ##############################
    def left_treeview_data_insert(self):

        print(160)
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f'''select journeyID from tbl_journeys where routeID={self.combobox_routeID()}''')
        self.data2 = my_cursor.fetchone()
        self.data23 = str(self.data2)
        # self.left_treeview_data_insert()
        print(self.combobox_routeID(), 444444444444444444444)

        ########################################### right journey treeview #########################
    def Insert_data_right_journey_treeview(self, event=""):
        print(172)
        try:
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute(f'''select stationNo, stationName, arrivalTime,depactureTime, conditional, platformNum, combiTriggerID,languageArea, journeyID, routeStopID from tbl_journeyStops where journeyID={self.journey_id} order by routeStopID''')
            data2 = my_cursor.fetchall()
            if len(data2) != 0:
                self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
                for i in data2:
                    self.right_journey_treeview.insert("", END, values=list(i))
            else:
                self.right_journey_treeview.delete(*self.right_journey_treeview.get_children())
            conn.commit()
            conn.close()
        except Exception as es:
            print("not saved", f"due to:{str(es)}")
    ############## bind function call left treeview click ###############################
    def get_left_treeview(self, event=""):
        print(190)
        self.cursor_row3 = self.left_journey_treeview.focus()
        self.content3 = self.left_journey_treeview.item(self.cursor_row3)
        self.data3 = self.content3["values"]
        self.journey_id = self.data3[6]
        self.Insert_data_right_journey_treeview()
    ########################## delete function left treeview data  #########################
    def delete_data_left(self):
        print(196)
        if self.left_journey_treeview.focus() == "":
            messagebox.showerror("Error", "Select the file ", parent=self.journey)
        else:
            try:
                Delete = messagebox.askyesno("Delete", "Are you sure delete the data", parent=self.journey)
                if Delete > 0:
                    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
                    my_cursor = conn.cursor()
                    sql_data1 = f"delete from tbl_journeys where journeyID=? and routeID=?"
                    value1 = (self.journey_id, self.combobox_routeID(),)
                    my_cursor.execute(sql_data1, value1)
                    sql_data = f"delete from tbl_journeyStops where journeyID=?"
                    value = (self.journey_id,)
                    my_cursor.execute(sql_data, value)
                else:
                    if not Delete:
                        return
                conn.commit()
                conn.close()
                self.Insert_data_left_journey_treeview()
                messagebox.showinfo("Delete", "your train data has been deleted", parent=self.journey)
            except Exception as es:
                messagebox.showerror("Error", f"Due To:{str(es)}", parent=self.journey)
    ############## bind function call right treeview data ############################
    def get_right_treeview(self, event=""):
        print(219)
        self.cursor_row4 = self.right_journey_treeview.focus()
        self.content4 = self.right_journey_treeview.item(self.cursor_row4)
        self.data4 = self.content4["values"]
        mg = self.right_journey_treeview.get_children()
        # # self.total_lenth_journey_treeview = len(mg) + 1
        # self.count_journey_treeview = mg.index(self.cursor_row4) + 1
    ################################### combobox #################################
    def edit_data_right_treeview(self, event=""):
        print(228)
        self.Edit_Route = tk.Tk()
        self.Edit_Route.geometry("700x130+550+400")
        self.Edit_Route.title(f"Edit Route :{self.data4[1]}")
        ################################### Arrival #######################################
        arrival_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Arrival ↓")
        arrival_label.place(x=20, y=17)
        arrival_entry = tkinter.ttk.Entry(self.Edit_Route, font=('arial', 9, 'bold'), width=10)
        arrival_entry.place(x=10, y=40)

        ################################# Departure ########################################
        departure_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Departure ↓")
        departure_label.place(x=110, y=17)
        departure_entry = tkinter.ttk.Entry(self.Edit_Route, font=('arial', 9, 'bold'), width=10)
        departure_entry.place(x=110, y=40)
        ################################# Condition #########################################
        condition_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Condition ↓")
        condition_label.place(x=210, y=17)
        combobox_condition = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10)
        combobox_condition.set("none")
        combobox_condition["values"] = ("Mon to Fri", "Not on Mon", "Not on Tues", "Not on Wed", "Not on Thurs", "Not on Fri", "Not on Sat", "Wekends")
        combobox_condition.place(x=210, y=40)
        ################################# Platform #########################################
        Platform_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Platform ↓")
        Platform_label.place(x=330, y=17)
        combobox_platform = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10)
        combobox_platform.set("none")
        combobox_platform["values"] = ("Left", "Right", "Both")
        combobox_platform.place(x=330, y=40)
        ################################# Trigger  ##########################################
        trigger_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Trigger ↓")
        trigger_label.place(x=450, y=17)
        combobox_trigger = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=10,)
        combobox_trigger.place(x=450, y=40)

        def show_trigger_in_combobox_journey():
            print(264)
            conn = pyodbc.connect(
                'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute("SELECT * from tbl_combiTrigger")
            table_name = my_cursor.fetchall()
            n = []
            for j in table_name:
                q = list(j)
                n.append(q[1])
            combobox_trigger["value"] = n
            combobox_trigger.set("none")
            conn.commit()
            conn.close()
        show_trigger_in_combobox_journey()
        ################################ Language ############################################
        Language_label = Label(self.Edit_Route, font=('arial', 10, 'bold'), text="Language ↓")
        Language_label.place(x=560, y=17)
        combobox_english = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
        combobox_english.set("")
        combobox_english["values"] = ("EN", "HI", "MR")
        combobox_english.place(x=558, y=40)

        combobox_hindi = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
        combobox_hindi.set("")
        combobox_hindi["values"] = ("EN", "HI", "MR")
        combobox_hindi.place(x=605, y=40)

        combobox_regional = tkinter.ttk.Combobox(self.Edit_Route, font=("arial", 9, 'bold'), width=3)
        combobox_regional.set("")
        combobox_regional["values"] = ("EN", "HI", "MR")
        combobox_regional.place(x=653, y=40)
       ################################# save data edit in right treeview ##########################
        def save_insert_right_data():
            print(298)
            print(self.data4[8], self.data4[9], 234567890)
            combobox_language = combobox_english.get()+'  '+combobox_hindi.get()+'  '+combobox_regional.get()
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            # my_cursor.execute(f"UPDATE {self.combobox_journey_list.get()} SET arrival='{arrival_entry.get()}', departure='{departure_entry.get()}', conditions='{combobox_condition.get()}', platform='{combobox_platform.get()}', triggers='{combobox_trigger.get()}', language='{combobox_language}' WHERE orders={self.data4[0]}")
            my_cursor.execute(
                f"UPDATE tbl_journeyStops SET arrivalTime=?, depactureTime=?, conditional=?, platformNum=?, combiTriggerID=?, languageArea=? WHERE journeyID = {self.data4[8]} and routeStopID = {self.data4[9]}",
                (arrival_entry.get(), departure_entry.get(), combobox_condition.get(), combobox_platform.get(), combobox_trigger.get(), combobox_language))
            conn.commit()
            conn.close()
            self.Insert_data_right_journey_treeview()
            self.Edit_Route.destroy()
        distance_button_add = Button(self.Edit_Route, text=" Submit ", font=('arial', 9, 'bold'), bg="#7C7CFC", fg="white", command=save_insert_right_data)
        distance_button_add.place(x=300, y=80)
        self.Edit_Route.mainloop()
    ########################################### Add New data in left frame ############################
    def add_new_data(self):
        print(361)
        self.Add_New = Tk()
        self.Add_New.geometry("400x300+80+300")
        self.Add_New.title("Add New")

        def show_column_entry(event=""):
            print(322)
            if len(self.Entry3.get()) == 2:
                self.Entry3.insert(2, ":")
            elif len(self.Entry3.get()) > 4:
                self.Entry3.delete(4, END)
        def do_backspace(event=""):
            d = None

        ################################### Name ######################################################
        self.label1 = Label(self.Add_New, text="Name", width=12, font=('Times', 11, "bold"))
        self.Entry1 = Entry(self.Add_New, width=25,)
        self.label1.place(x=10, y=10)
        self.Entry1.place(x=200, y=10)
        ################################## Condition #################################################
        self.label2 = Label(self.Add_New, text="Condition", width=12, font=('Times', 11, "bold"))
        self.label2.place(x=10, y=50)
        self.combobox_left_condition = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_left_condition.set("none")
        self.combobox_left_condition["values"] = ("Mon to Fri", "Not on Mon", "Not on Tues", "Not on Wed", "Not on Thurs", "Not on Fri", "Not on Sat", "Wekends")
        self.combobox_left_condition.place(x=200, y=50)
        ################################ Departure ###################################################

        self.label3 = Label(self.Add_New, text="Departure", width=12, font=('Times', 11, "bold"))
        self.Entry3 = Entry(self.Add_New, width=25)
        self.label3.place(x=10, y=90)
        self.Entry3.place(x=200, y=90)
        self.Entry3.bind("<Key>", show_column_entry)
        self.Entry3.bind("<BackSpace>", do_backspace)
        ############################### Service #######################################################
        self.label4 = Label(self.Add_New, text="Service", width=12, font=('Times', 11, "bold"))
        self.label4.place(x=10, y=130)
        self.combobox_service = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_service.set("none")
        self.combobox_service["values"] = ("Fast", "Slow")
        self.combobox_service.place(x=200, y=130)
        ############################# Total cars #######################################################
        self.label5 = Label(self.Add_New, text="Total cars", width=12, font=('Times', 11, "bold"))
        self.Entry5 = Entry(self.Add_New, width=25)
        self.label5.place(x=10, y=170)
        self.Entry5.place(x=200, y=170)
        ############################# Handicars ######################################################
        self.label6 = Label(self.Add_New, text="Handicars", width=12, font=('Times', 11, "bold"))
        self.label6.place(x=10, y=210)
        self.combobox_handicars = tkinter.ttk.Combobox(self.Add_New, font=("arial", 9, 'bold'), width=19)
        self.combobox_handicars.set("none")
        self.combobox_handicars["values"] = ("3", "6", "9", "12", "15")
        self.combobox_handicars.place(x=200, y=210)

                
        ################################# insert data in new frame #####################################
        def insert_data_left():
            print(373)
            n = self.Entry1.get()
            c = self.combobox_left_condition.get()
            d = self.Entry3.get()
            s = self.combobox_service.get()
            t = self.Entry5.get()
            h = self.combobox_handicars.get()
            route_ID = self.combobox_routeID()
            print(n, 1)
            print(c, 2)
            print(d, 3)
            print(s, 4)
            print(t, 5)
            print(h, 6)

            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
            my_cursor = conn.cursor()
            my_cursor.execute("select journeyID from tbl_journeys")
            data_journeyID = my_cursor.fetchall()
            my_cursor.execute("select top(1) journeyID from tbl_journeys order by journeyID desc")
            data_journey_last_ID = my_cursor.fetchall()
            print(data_journey_last_ID, 22222222222222222)
            if len(data_journeyID) == 0:
                my_cursor.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)',
                                  (1, route_ID, n, c, d, s, t, h))
                sql_query = f'''select r.stopOrder,s.shortName, r.stationID, s.stationNr from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={route_ID} order by r.stopOrder'''
                my_cursor.execute(sql_query)
                data_tree = my_cursor.fetchall()
                # print(data_tree, 555555555555555555)
                for i in range(len(data_tree)):
                    journey_name = data_tree[i][3]
                    my_cursor.execute(f'INSERT INTO tbl_journeyStops VALUES(?,?,?,?,?,?,?,?,?,?)',
                                      (1, data_tree[i][0], journey_name.replace(" ", ""), data_tree[i][1], "--:--", "--:--", "-None-", " ", "-None-", "-None-"))

            else:
                my_cursor.execute(f'INSERT INTO tbl_journeys VALUES(?,?,?,?,?,?,?,?)',
                                  (data_journey_last_ID[0][0]+1, route_ID, n, c, d, s, t, h))
                sql_query = f'''select r.stopOrder,s.shortName, r.stationID, s.stationNr from tbl_routeStops as r inner join tbl_station as s on s.stationID=r.stationID where r.routeID={route_ID} order by r.stopOrder'''
                my_cursor.execute(sql_query)
                data_tree = my_cursor.fetchall()
                # print(data_tree, 555555555555555555)
                for i in range(len(data_tree)):
                    journey_name = data_tree[i][3]
                    my_cursor.execute(f'INSERT INTO tbl_journeyStops VALUES(?,?,?,?,?,?,?,?,?,?)',
                                      (data_journey_last_ID[0][0]+1, data_tree[i][0], journey_name.replace(" ", ""), data_tree[i][1], "--:--",
                                       "--:--", "-None-", " ", "-None-", "-None-"))


            conn.commit()
            conn.close()
            self.Insert_data_left_journey_treeview()
            # messagebox.showinfo("Submit", "your data has been saved", parent=self.Add_New)
            self.Add_New.destroy()
        self.submitbutton = Button(self.Add_New, text="Submit", command=insert_data_left)
        self.submitbutton.configure(font=('Times', 11, 'bold'), bg="#7C7CFC", fg="white")
        self.submitbutton.place(x=160, y=250)
        
    ############################################# simulate ################################################################
    
    def simulate_top(self):
        self.journey.destroy()
        simulation.MainApplicationSimulate()
        print(395)
    #     top7 = tk.Tk()
    #     top7.title("Simulate")
    #     top7.geometry("1200x500+70+40")
    # ############################## help ###########################
    #     menu = tk.Menu(top7)
    #     Edit = tk.Menu(menu, tearoff=0)
    #     Edit.add_command(label="Help now")
    #     menu.add_cascade(label="Help", menu=Edit)
    #     top7.config(menu=menu)
    #     ############################## style for combobox ##################################
    #     z = tkinter.ttk.Style(top7)
    #     z.theme_use('clam')
    #     z.configure('Treeview.Heading', background="light gray")
    #
    #     ################################ main frame ############################################
    #     simulate_main_frame = Frame(top7, relief=RIDGE, background='light gray', bd=4)
    #     simulate_main_frame.place(x=0, y=0, height=500, width=1200)
    #
    #     ##################################### Up frame #####################################
    #     up_frame = Frame(top7, simulate_main_frame, width=1190, height=40, relief=RIDGE, background='light gray', bd=4)
    #     up_frame.place(x=5, y=4)
    #
    #     journey_label = Label(up_frame, text="Journey :- ", font=('times new roman', 12, "bold"), fg='black', bg='light gray')
    #     journey_label.place(x=0, y=3)
    #
    #     journey_entry = Entry(up_frame, font=('arial', 8, 'bold'))
    #     journey_entry.place(x=100, y=6)
    #
    #     #################################### route ##################################
    #
    #     route_label = Label(up_frame, text="Route :- ", font=('times new roman', 12, "bold"), fg='black', bg='light gray')
    #     route_label.place(x=250, y=3)
    #
    #     route_entry = Entry(up_frame, font=('arial', 8, 'bold'))
    #     route_entry.place(x=330, y=6)
    #
    #     #################################### condition ##################################
    #
    #     condition_label = Label(up_frame, text="Condition :- ", font=('times new roman', 12, "bold"), fg='black', bg='light gray')
    #     condition_label.place(x=490, y=3)
    #
    #     condition_entry = Entry(up_frame, font=('arial', 8, 'bold'))
    #     condition_entry.place(x=600, y=6)
    #
    #     ##################################### Up frame 1 #####################################
    #     up_frame1 = Frame(top7, simulate_main_frame, bd=10, width=1190, height=70, relief=RIDGE, bg='light gray')
    #     up_frame1.place(x=5, y=45)
    #
    #     departure_train = Label(up_frame1, text="DEPARTURE", font=('times new roman', 15, "bold"), fg='black', bg='light gray')
    #     departure_train.place(x=10, y=13)
    #
    #     screen_entry1 = Entry(up_frame1, font=('times new roman', 15, 'bold'))
    #     screen_entry1.place(x=200, y=12, height=40, width=200)
    #
    #     arrival_train = Label(up_frame1, text="ARRIVAL", font=('times new roman', 15, "bold"), fg='black', bg='light gray')
    #     arrival_train.place(x=500, y=13)
    #
    #     screen_entry2 = Entry(up_frame1, font=('times new roman', 15, 'bold'))
    #     screen_entry2.place(x=650, y=12, height=40, width=200)
    #
    #     #################################### station table ###################################
    #     table_station = Frame(simulate_main_frame)
    #     table_station.place(x=0, y=113, height=380, width=230)
    #     scroll_y = Scrollbar(table_station, orient=VERTICAL)
    #     station_table = tkinter.ttk.Treeview(table_station, columns="Stat", yscrollcommand=scroll_y.set)
    #     scroll_y.pack(side=RIGHT, fill=Y)
    #     scroll_y.config(command=station_table.yview)
    #     station_table.heading("Stat", text="Station")
    #     station_table.pack(fill=BOTH, expand=1)
    #     station_table["show"] = "headings"
    #
    #     def show_data_in_tigger_table():
    #         print(468)
    #         conn = pyodbc.connect(
    #             'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=abhay;Trusted_Connection=yes;')
    #         my_cursor = conn.cursor()
    #         my_cursor.execute(f'''select station from {self.combobox_journey_list.get()}''')
    #         data6 = my_cursor.fetchall()
    #         if len(data6) != 0:
    #             station_table.delete(*station_table.get_children())
    #             for i in data6:
    #                 station_table.insert("", END, values=list(i))
    #         else:
    #             station_table.delete(*station_table.get_children())
    #         conn.commit()
    #         conn.close()
    #     show_data_in_tigger_table()
    def on_exit(self):
        self.journey.destroy()
        main.MainApplication()

if __name__ == "__main__":
    MainApplication3()
