class one:
    def test(self):
        print('A+B')
