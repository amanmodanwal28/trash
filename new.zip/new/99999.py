# import pyodbc
#
#
# conn = pyodbc.connect(
#     'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
# my_cursor = conn.cursor()
# my_cursor.execute(
#     f'''UPDATE [dbo].[tbl_stationNames]
#    SET stationName('राम')
#  WHERE stationNameAudio='ST009HI.MP3' ''')
# my_cursor.execute(
#     f'''select stationName from tbl_stationNames''')
# languageArea_data = my_cursor.fetchall()
# print(languageArea_data, "ghjhgfghgfvgggytghygv")
# conn.commit()
# conn.close()

# l = []
# print(bool(l))

# from mutagen.mp3 import MP3
# import time
# import miniaudio
#
# file = f"sqlData\\audio\\ST035EN.MP3"
# audio = MP3(file)
# length = audio.info.length
# stream = miniaudio.stream_file(file)
# def a():
#     with miniaudio.PlaybackDevice() as device:
#         device.start(stream)
#         print('playing')
#         time.sleep(length)
#
# a()
# a()
# a()
# a()
from playsound import playsound
for i in range(4):
    playsound(f"sqlData\\audio\\ST035EN.MP3")
    playsound(f"sqlData\\audio\\ST035EN.MP3")

