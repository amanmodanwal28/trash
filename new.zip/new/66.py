# import pyodbc
#
# # creating a new db to load Iris sample in
# new_db_name = "irissql"
# connection_string = "Driver=SQL Server;Server=LP-ABHAY-PTC;Trusted_Connection=Yes;"
#                         # you can also swap Trusted_Connection for UID={your username};PWD={your password}
# cnxn = pyodbc.connect(connection_string.format("master"), autocommit=True)
# # cnxn.cursor().execute("IF EXISTS(SELECT * FROM sys.databases WHERE [name] = '{0}') DROP DATABASE {0}".format(new_db_name))
# cnxn.cursor().execute('''CREATE DATABASE [AdventureWorks] ON  PRIMARY
#     (NAME = N'AdventureWorks_Data', FILENAME = N'D:\SQLRecovery\AdventureWorks_Data.mdf' , SIZE = 167872KB , MAXSIZE = UNLIMITED, FILEGROWTH = 16384KB )
#      LOG ON
#     ( NAME = N'AdventureWorks_Log', FILENAME = N'D:\SQLRecovery\AdventureWorks_Log.ldf' , SIZE = 2048KB , MAXSIZE = 2048GB , FILEGROWTH = 16384KB )''')
# cnxn.close()
#
# import tkinter as tk
# import random
#
#
# def label_click(label):
#     if label["fg"] == "blue":
#         label["fg"] = random.choice(["red", "green", "blue"])
#     else:
#         if label in selected_labels:
#             selected_labels.remove(label)
#         else:
#             mm = selected_labels1.index(label)
#             jj = selected_labels1[mm+2]
#             selected_labels.append(label)
#             selected_labels.append(jj)
#             label["fg"] = "black"
#             # print(selected_labels)
#
#
# def delete_selected():
#     for label in selected_labels:
#         print(label, 222)
#         label.destroy()
#     print(selected_labels)
#     selected_labels.clear()
#     print("Selected labels deleted!")
#
#
# root = tk.Tk()
# root.title("Auto Create Clickable Labels Example")
#
# num_labels = 10
# selected_labels = []
# selected_labels1 = []
#
# for label_num in range(1, num_labels + 1):
#     label_text = f"Label {label_num}"
#     label = tk.Label(root, text=label_text, fg="blue", cursor="hand2")
#     label.pack()
#
#     label.bind("<Button-1>", lambda event, lbl=label: label_click(lbl))
#     selected_labels1.append(label)
# print(selected_labels1)
# # print(type(label))
# delete_button = tk.Button(root, text="Delete Selected", command=delete_selected)
# delete_button.pack()
#
# root.mainloop()

# from tkinter import *
# #Create an instance of tkinter frame
# win= Tk()
# #Define the geometry of the window
# win.geometry("750x250")
# #Define functions
# def on_enter(e):
#    button.config(background='OrangeRed3', foreground= "white")
#
# def on_leave(e):
#    button.config(background= 'SystemButtonFace', foreground= 'black')
# #Create a Button
# button= Button(win, text= "Click Me", font= ('Helvetica 13 bold'))
# button.pack(pady= 20)
#
# #Bind the Enter and Leave Events to the Button
# button.bind('<Enter>', on_enter)
# button.bind('<Leave>', on_leave)
# win.mainloop()
# a = { 1: '<field05>', 2: '<field05>', 3: '[platformright]', 4: '</field05>', 5: '</field05>', 6: '</field05>', 7: '<field01>', 8: '{MT000A}', 9: '</field01>', 10: '<field04>', 11: '[platformleft]', 12: '</field04>'}
# a = ['<field05>', '<field05>', '<field05>', '[platformright]', '</field05>', '</field05>', '</field05>', '<field01>', '{MT000A}', '</field01>', '<field04>', '[platformleft]', '</field04>']
# a.remove(a[10])
# a.remove(a[11])
# a = "<sfjkf"
# b = 1 - 2
# print(abs(b))
# a = -1+1
# print(a)

# import tkinter as tk
#
#
# def place_labels_with_gap(label_data):
#     x_position = 0  # Initial x-coordinate
#     y_position = 50  # y-coordinate for all labels
#     gap = 0  # Gap between labels
#
#     for text in label_data:
#         label = tk.Label(root, text=text, bg="yellow")
#         label.pack()  # Just for visibility, not used in the place method
#
#         text_length = len(text)-1
#         label_width = text_length * 7  # Adjust the multiplier as needed
#
#         label.place(x=x_position, y=y_position)
#         x_position += label_width + gap-1
#
#
# root = tk.Tk()
#
# label_texts = ["Label 1 Text", "Another Label", "Short Text"]
# place_labels_with_gap(label_texts)
#
# root.mainloop()

# import tkinter as tk
#
#
# def place_labels_with_fixed_space(label_data):
#     # Fixed space between labels
#     x_position = 10  # Initial x-coordinate
#     y_position = 50  # y-coordinate for all labels
#     space = 10
#
#     for text in label_data:
#         label = tk.Label(root, text=text, bg="yellow")
#         label.place(x=x_position, y=y_position)
#         y_position = y_position + 10
#         print(label.winfo_reqwidth(), space, x_position)
#         x_position += label.winfo_reqwidth() + space
#
#
# root = tk.Tk()
#
# label_texts = ["a2R", "Anothrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrer Label", "Short Text"]
# place_labels_with_fixed_space(label_texts)
#
# root.mainloop()

# x_position = 810
# print(780 < x_position < 811)
#
#
# v = {0: '<field05>', 1: '<field05>', 2: '<tag05>', 3: '[platformright]', 4: '</tag05>', 5: '</field05>', 6: '</field05>', 7: '<field01>', 8: '{MT000A}', 9: '</field01>', 10: '<field04>', 11: '[platformleft]', 12: '</field04>'}
# print("".join(list(v.values())))


# import tkinter as tk
# from tkinter import ttk
#
# class windows(tk.Tk):
#     def __init__(self, *args, **kwargs):
#         tk.Tk.__init__(self, *args, **kwargs)
#         # Adding a title to the window
#         self.wm_title("Test Application")
#
#         # creating a frame and assigning it to container
#         container = tk.Frame(self, height=400, width=600)
#         # specifying the region where the frame is packed in root
#         container.pack(side="top", fill="both", expand=True)
#
#         # configuring the location of the container using grid
#         container.grid_rowconfigure(0, weight=1)
#         container.grid_columnconfigure(0, weight=1)
#
#         # We will now create a dictionary of frames
#         self.frames = {}
#         # we'll create the frames themselves later but let's add the components to the dictionary.
#         for F in (MainPage, SidePage, CompletionScreen):
#             frame = F(container, self)
#
#             # the windows class acts as the root window for the frames.
#             self.frames[F] = frame
#             frame.grid(row=0, column=0, sticky="nsew")
#
#         # Using a method to switch frames
#         self.show_frame(MainPage)
#
#     def show_frame(self, cont):
#         frame = self.frames[cont]
#         # raises the current frame to the top
#         frame.tkraise()
# class MainPage(tk.Frame):
#     def __init__(self, parent, controller):
#         tk.Frame.__init__(self, parent)
#         label = tk.Label(self, text="Main Page")
#         label.pack(padx=10, pady=10)
#
#         # We use the switch_window_button in order to call the show_frame() method as a lambda function
#         switch_window_button = tk.Button(
#             self,
#             text="Go to the Side Page",
#             command=lambda: controller.show_frame(SidePage),
#         )
#         switch_window_button.pack(side="bottom", fill=tk.X)
#
#
# class SidePage(tk.Frame):
#     def __init__(self, parent, controller):
#         tk.Frame.__init__(self, parent)
#         label = tk.Label(self, text="This is the Side Page")
#         label.pack(padx=10, pady=10)
#
#         switch_window_button = tk.Button(
#             self,
#             text="Go to the Completion Screen",
#             command=lambda: controller.show_frame(CompletionScreen),
#         )
#         switch_window_button.pack(side="bottom", fill=tk.X)
#
#
# class CompletionScreen(tk.Frame):
#     def __init__(self, parent, controller):
#         tk.Frame.__init__(self, parent)
#         label = tk.Label(self, text="Completion Screen, we did it!")
#         label.pack(padx=10, pady=10)
#         switch_window_button = ttk.Button(
#             self, text="Return to menu", command=lambda: controller.show_frame(MainPage)
#         )
#         switch_window_button.pack(side="bottom", fill=tk.X)
#
# if __name__ == "__main__":
#     testObj = windows()
#     testObj.mainloop()



# print(1+1+2+1+2+1+1+1+2+1+1+1+1+2+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+2+1+2+1+2+1+2+1+2+1+2+1+2+1+2+1+1+1+1+1+1+1+1+1+1+1+1+1)