# import shutil
#
# # Copy file example.txt into a new file called example_copy.txt
#
# shutil.copy('D:\\abhay\\ab\\abhay\\4 Creating Input Fields With Tkinter - Python Tkinter GUI Course in Hindi #5.mp4', 'sqlData/audio/example_copy11.MP4')
#
# # Copy file example.txt into directory test/
#
# # shutil.copy2('example.txt', 'test/')
# import pyodbc
#
# def sql_data(sql_query="", sql_query2=""):
#     # conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=message;Trusted_Connection=yes;')
#     conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers;Trusted_Connection=yes;')
#     my_cursor = conn.cursor()
#
#     if sql_query and sql_query2:
#         if sql_query.find("Select") > -1 or sql_query.find("SELECT") > -1 or sql_query.find("select") > -1:
#             my_cursor.execute(sql_query)
#             data = my_cursor.fetchall()
#             my_cursor.execute(sql_query2)
#             data1 = my_cursor.fetchall()
#             conn.commit()
#             conn.close()
#             return data, data1
#     if sql_query:
#         my_cursor.execute(sql_query)
#         if sql_query.find("Select") > -1 or sql_query.find("SELECT") > -1 or sql_query.find("select") > -1:
#             data = my_cursor.fetchall()
#             conn.commit()
#             conn.close()
#             return data
#
#
#
#
# # sql_data("insert into display_message values('abhay','ram')")
# print(sql_data(sql_query="SELECT top(1) name from messageA where name like'%ML%' order by name desc"))

# my_cursor.execute("insert into tbl_file values(?,?,?)", ("PNG", self.message_name_entry.get(), self.description_entry.get()))

# sr = "abhay ankit rw"
# sr = "rjo"
# if sr:
#     print(sr)
#     print("done")


# Importing the modules and classes
import tkinter as t
from tkinter import ttk
from tkinter.messagebox import showinfo

# Root window creation
root_window = t.Tk()
root_window.title('Hierarchical representation')
root_window.geometry('600x370')

# grid layout
# root_window.rowconfigure(0, weight=1)
# root_window.columnconfigure(0, weight=1)

# Tree view
tree = ttk.Treeview(root_window, columns=("s", "g"))
tree.heading('#0', text='Courses')
tree.heading('g', text='Courses1')
tree.insert("", 'end', text="L1", iid="fj")
tree.insert('', 'end', text='Engineering', iid=0, open=True)
tree.insert('', 'end', text='Mechanical engineering', iid=1, open=True)
tree.insert('', 'end', text='Electrical engineering', iid=2, open=False)
tree.insert('', 'end', text='Electronic and computer engineering', iid=3, open=False)
tree.insert('', 'end', text='Information Technology', iid=4, open=False)
tree.insert('', 'end', text='Computer science and engineering', iid=5, open=False)
tree.insert('', 'end', text='Artificial Intelligence and Machine Learning', iid=6, open=False)
tree.insert('', 'end', text='Data Science', iid=7, open=False)
tree.insert('', 'end', text='Cyber Security', iid=8, open=False)
tree.insert('', 'end', text='Internet Of Things', iid=9, open=False)

# Assinging the sub-data into Engineering
tree.move(1, 0, 0)
tree.move(1, "fj", 0)
tree.move(2, 0, 1)
tree.move(3, 0, 2)
tree.move(4, 0, 3)
# tree.move(5, 0, 4)

# Assigning the sub-data to Computer science and engineering
tree.move(9, 5, 0)
tree.move(7, 5, 1)
tree.move(8, 5, 2)
tree.move(6, 5, 3)

# Positioning
tree.grid(row=0, column=0, sticky=t.NSEW)

# Execution
root_window.mainloop()

# # Importing the modules and the classes
# from tkinter import ttk
# import tkinter as t
#
# # Creating a window
# root_window = t.Tk()
# root_window.resizable(width=2, height=2)
#
# # Treeview widget
# tree = ttk.Treeview(root_window, selectmode='browse')
# tree.pack(side='left')
#
# # scrollbar
# scrollbar = ttk.Scrollbar(root_window, orient="vertical", command=tree.yview)
# scrollbar.pack(side='left', fill='x')
# tree.configure(xscrollcommand=scrollbar.set)
#
# # Number of columns
# tree["columns"] = ("1", "2")
#
# # Headings
# tree['show'] = 'headings'
#
# # Columns configuration
# tree.column("1", width=90, anchor='c')
# tree.column("2", width=90, anchor='se')
#
# # Headings
# tree.heading("1", text="Name")
# tree.heading("2", text="Age")
#
# # Data
# tree.insert("", 'end', text="L1",
#             values=("Harry Styles", "28"))
# tree.insert("", 'end', text="L2",
#             values=("Zayn Malik", "29"))
# tree.insert("", 'end', text="L3",
#             values=("Liam Payne", "29"))
# tree.insert("", 'end', text="L4",
#             values=("Louis Tomlinson", "30"))
# tree.insert("", 'end', text="L5",
#             values=("Niall Horan", "29"))
# tree.insert("", 'end', text="L6",
#             values=("Adam Levine", "43"))
# tree.insert("", 'end', text="L7",
#             values=("Selena Gomez", "30"))
# tree.insert("", 'end', text="L8",
#             values=("Shawn Mendes", "24"))
# tree.insert("", 'end', text="L10",
#             values=("Taylor Swift", "32"))
# tree.insert("", 'end', text="L11",
#             values=("Justin Beiber", "28"))
# tree.insert("", 'end', text="L12",
#             values=("Demi Lovato", "30"))
# tree.insert("", 'end', text="L13",
#             values=("Conan Gray", "23"))
#
# # Calling main loop
# root_window.mainloop()