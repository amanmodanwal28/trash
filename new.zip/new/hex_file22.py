# from tkinter import *
# tkk = Tk()
# tkk.geometry()
# Label(tkk, text="\u092f\u093e\u0924\u094d\u0930\u093e").pack()
# tkk.mainloop()
# import tkinter as tk
# from tkinter import font
#
# # Create the tkinter application window
# root = tk.Tk()
# root.title("Custom Font Example")
#
# # Specify the path to your custom font file
# font_path = "path_to_your_font_file.ttf"
#
# # Load the custom font
# custom_font = font.Font(family="MyCustomFont", size=12, weight="bold")
# custom_font.actual()
#
# # Example usage: Label with custom font
# label = tk.Label(root, text="Hello, Custom Font!", font=custom_font)
# label.pack(pady=20)
#
# root.mainloop()

import fontstyle

# format text
text = fontstyle.apply('GEEKSFORGEEKS', 'bold/Italic/red/GREEN_BG')

# display text
print(text)