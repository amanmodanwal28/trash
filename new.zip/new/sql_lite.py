import sqlite3
# connection=sqlite3.connect("student.db")
# cursor = connection.cursor()
# cursor.execute("CREATE TABLE student_data (st_name text, number integer, id integer)")
#
# st_data_lis = [("Abhay", 34000, 1),
#                ("Ankit", 24000, 2),
#                ("अम्बत्तुर", 24000, 3),
#                ("Ravi", 14000, 4)]
# cursor.executemany("insert into student_data values (?,?,?)", st_data_lis)
# connection.commit()
# for row in cursor.execute("select * from student_data"):
#     print(row)
# cursor.execute("select * from student_data order by id desc LIMIT 1")
conn = sqlite3.connect("triggers_abhay.db")
my_cursor = conn.cursor()
# my_cursor.execute("select * from messageA where [name]='TA0002'")
my_cursor.execute("select fileName, fileDescription from tbl_file where fileDescription='Next station :' and fileExtention='TXT       '")
# my_cursor.execute("select * from tbl_trigger")
data_get = my_cursor.fetchall()
# if not data_get:
#     print("yess")
print(data_get)

# connection.close()
