import tkinter.ttk
from tkinter import *
import tkinter as tk
from customtkinter import CTkButton, CTkCheckBox
from time import gmtime, strftime
import pyodbc
import main
last_key_press = None
class dts_time_class:

    def __init__(self):
        self.project = tk.Tk()
        self.project.title('Daylights')
        self.project.geometry("400x400+500+200")
        self.project.iconbitmap("logo2.ico")
        self.project.configure(bg="lightsteelblue2", borderwidth="1")
        self.project.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.project.resizable(False, False)
        popup = Menu(self.project, tearoff=0)
        popup.add_command(label="Delete", command=self.delete_table_in_sql_tbl)
        popup.add_command(label="Add New", command=self.insert_table_in_sql_tbl)
        self.project.maxsize(400, 405)
        self.project.minsize(400, 405)

        self.var_station_name = StringVar()
        self.s = tkinter.ttk.Style(self.project)
        self.s.theme_use('clam')

        self.general_frame = Frame(self.project, relief=SUNKEN, bg='lightsteelblue1', bd=4)
        self.general_frame.place(x=0,y=0, height=350, width=397)

        self.language_scroll_y = tk.Scrollbar(self.general_frame, orient=VERTICAL)
        self.dts_date_time_table = tkinter.ttk.Treeview(self.general_frame, columns=("Stat", "StatN"), yscrollcommand=self.language_scroll_y.set)
        self.language_scroll_y.pack(side=RIGHT, fill=Y)
        self.dts_date_time_table.heading("Stat", text="Date(DD/MM/YY-HH:MM:SS)")
        self.dts_date_time_table.column("Stat", width=150, anchor='c')

        self.dts_date_time_table.heading("StatN", text="Offset")
        self.dts_date_time_table.column("StatN", width=10, anchor='c')


        self.dts_date_time_table.pack(fill=BOTH, expand=1)
        self.dts_date_time_table["show"] = "headings"
        self.dts_date_time_table.bind("<Double-1>", self.txt_entry_on_treeview)
        self.description_treeview = Entry(self.general_frame)
        # self.old_data = ""
        # def place_forget(event):
        #     self.row_ID = self.dts_date_time_table.focus()
        #     if self.row_ID != self.old_data:
        #         self.description_treeview.place_forget()
        #     else:
        #         self.old_data = self.row_ID
        # self.dts_date_time_table.bind("<ButtonRelease>", place_forget)

        select_Import_file = CTkButton(self.project, text="SAVE", font=('arial', 13, 'bold'), text_color="black", width=50, height=10, command=self.update_table_in_sql_tbl)
        select_Import_file.place(x=330, y=370)

        select_New_file = CTkButton(self.project, text="NEW", font=('arial', 13, 'bold'), text_color="black", width=50, height=10, command=self.insert_table_in_sql_tbl)
        select_New_file.place(x=15, y=370)

        def menu_popup(event):
            try:
                popup.tk_popup(event.x_root, event.y_root, 0)
            finally:
                popup.grab_release()

        self.dts_date_time_table.bind("<Button-3>", menu_popup)
        # self.dts_date_time_table.insert("", END, values=("", ""))
        self.insert_table_in_treeview()
        self.project.mainloop()

    def txt_entry_on_treeview(self, event=""):

        self.column_number = self.dts_date_time_table.identify_column(event.x) ### with #1,#2,#3,....
        self.row_ID = self.dts_date_time_table.focus() ### I001, I002, I003, ........
        self.item_data = self.dts_date_time_table.item(self.row_ID)
        self.item_text_value = self.item_data.get("values")
        self.second_column_number = int(self.column_number[1]) - 1
        self.colum_box = self.dts_date_time_table.bbox(self.row_ID, self.column_number)

        self.description_treeview.destroy()

        def place_forget(event):
            self.description_treeview.destroy()
        if int(self.column_number[1:]) == 1:
            def is_type_int(*args):
                item = self.description_treeview.get()
                print(*args, '#####')
                try:
                    if last_key_press == "BackSpace":
                        pass
                    else:
                        if item[-1] == "/" or item[-1] == "-" or item[-1] == ":":
                            # pass
                            if len(item) > 18:
                                self.description_treeview.delete(19, 20)
                        elif type(int(item[-1])) == type(1):
                            if len(item) > 18:
                                self.description_treeview.delete(19, 20)
                            elif len(item) == 2 and item[-1] != '/':
                                self.description_treeview.insert(tk.END, '/')
                            elif len(item) == 5 and item[-1] != '/':
                                self.description_treeview.insert(tk.END, '/')
                            elif len(item) == 10 and item[-1] != '-':
                                self.description_treeview.insert(tk.END, '-')
                            elif len(item) == 13 and item[-1] != ':':
                                self.description_treeview.insert(tk.END, ':')
                            elif len(item) == 16 and item[-1] != ':':
                                self.description_treeview.insert(tk.END, ':')
                except:
                    self.description_treeview.delete(len(self.description_treeview.get()) - 1, tk.END)

                self.dts_date_time_table.set(self.row_ID, column=self.column_number, value=item)

            def on_key_press(event):
                global last_key_press
                last_key_press = event.keysym

            self.description_treeview_var = tk.StringVar()
            self.description_treeview = Entry(self.general_frame, justify="center", width=self.colum_box[2], textvariable=self.description_treeview_var)
            if self.item_text_value[self.second_column_number] == "":
                self.description_treeview.insert(0, strftime("%d/%m/%Y-%H:%M:%S", gmtime()))
                self.dts_date_time_table.set(self.row_ID, column=self.column_number, value=strftime("%d/%m/%Y-%H:%M:%S", gmtime()))
            else:
                self.description_treeview.insert(0, self.item_text_value[self.second_column_number]) # ev_value[new_ev]
            self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1], w=self.colum_box[2], h=self.colum_box[3])
            self.description_treeview.bind("<KeyPress>", on_key_press)
            self.description_treeview_var.trace("w", is_type_int)
            self.description_treeview.focus()
            # def on_focus_out(event):
            #     event.widget.destroy()
            self.description_treeview.bind("<FocusOut>", place_forget)
            self.scroll_true_and_false = True
        elif int(self.column_number[1:]) == 2:
            self.description_treeview.destroy()
            self.description_treeview = tkinter.ttk.Combobox(self.general_frame, font=("arial", 9, 'bold'), width=3)
            self.description_treeview["values"] = ("0", "15", "30", "45", "60")
            self.description_treeview.place(x=self.colum_box[0], y=self.colum_box[1], w=self.colum_box[2], h=self.colum_box[3])
            if self.item_text_value[self.second_column_number] == "":
                self.description_treeview.set("0")
                self.dts_date_time_table.set(self.row_ID, column=self.column_number, value="0")
            else:
                self.description_treeview.set(self.item_text_value[self.second_column_number])
                # print(self.item_text_value[self.second_column_number])
                self.dts_date_time_table.set(self.row_ID, column=self.column_number, value=self.item_text_value[self.second_column_number])
            def set_combo_in_treeview(event):
                self.dts_date_time_table.set(self.row_ID, column=self.column_number, value=self.description_treeview.get())
            self.description_treeview.bind("<<ComboboxSelected>>", set_combo_in_treeview)
            self.description_treeview.bind("<Return>", place_forget)
            # print("yooo")
            # self.text_toplevel(self.item_text_value[0], int(self.column_number[1:]))
    def insert_table_in_treeview(self):
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute("select [day],[offset] from [tbl_dts] order by dts_id")
        data_dts = my_cursor.fetchall()
        if len(data_dts) != 0:
            self.dts_date_time_table.delete(*self.dts_date_time_table.get_children())
            for i in data_dts:
                self.dts_date_time_table.insert("", END, values=list(i))
            conn.commit()
        else:
            self.dts_date_time_table.delete(*self.dts_date_time_table.get_children())
        conn.close()
    def insert_table_in_sql_tbl(self):
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute("select top(1) dts_id from [tbl_dts] order by dts_id desc")
        data_dts_id = my_cursor.fetchall()
        if len(data_dts_id) != 0:
            num = int(data_dts_id[0][0])+1
            my_cursor.execute(f'INSERT INTO [tbl_dts] VALUES(?,?,?)', (num, "", ""))
            self.dts_date_time_table.insert("", END, values=("", ""))
        else:
            my_cursor.execute(f'INSERT INTO [tbl_dts] VALUES(?,?,?)', (1, "", ""))
            self.dts_date_time_table.insert("", END, values=("", ""))
        conn.commit()
        conn.close()

    def update_table_in_sql_tbl(self):
        # self.column_number = self.dts_date_time_table.identify_column(event.x)  ### with #1,#2,#3,....
        # print(self.column_number)
        self.row_ID = self.dts_date_time_table.focus()  ### I001, I002, I003, ........
        print(self.row_ID)
        dts_id = int(self.row_ID[1::])
        self.item_data = self.dts_date_time_table.item(self.row_ID)
        self.item_text_value = self.item_data.get("values")
        print(self.item_text_value)

        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f"UPDATE [tbl_dts] SET [day]='{self.item_text_value[0]}', [offset]={self.item_text_value[1]} WHERE [dts_id]={dts_id}")
        conn.commit()
        conn.close()

    def delete_table_in_sql_tbl(self):
        # self.column_number = self.dts_date_time_table.identify_column(event.x)  ### with #1,#2,#3,....
        # print(self.column_number)
        self.row_ID = self.dts_date_time_table.focus()  ### I001, I002, I003, ........
        print(self.row_ID)
        dts_id = int(self.row_ID[1::])

        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=LP-ABHAY-PTC;DATABASE=triggers_ankit;Trusted_Connection=yes;')
        my_cursor = conn.cursor()
        my_cursor.execute(f"delete from [tbl_dts] WHERE [dts_id]={dts_id}")
        selected_item = self.dts_date_time_table.selection()[0]
        self.dts_date_time_table.delete(selected_item)
        conn.commit()
        conn.close()

    def on_exit(self):
        self.project.destroy()
        main.MainApplication()


if __name__ == "__main__":
    dts_time_class()
