# a = '414130303031'
# decoded_string = bytes.fromhex(a).decode('utf-8')
# print(decoded_string)

# a= '<;100;m/s'
# a = 'AND;speed;<;200;m/s'
# a = ';10;m;before the station'
# a = 'AND;lacationindexed;;300;m;afterthe station'

# split_elements = a.split(';')
# print(split_elements)
# if split_elements == 3:
#     specific_elements = [split_elements[0], split_elements[1]]
# elif split_elements:
#     specific_elements = [split_elements[2], split_elements[3]]
# elif split_elements:
#     specific_elements = [split_elements[2], split_elements[4]]
# else:
#     specific_elements = [split_elements[3], split_elements[5]]
    
# print(specific_elements)

# hex_number = "65F38F8003"
# decimal_number = int(hex_number, 16)
# print(decimal_number)



# language_data = '0927'
# language_data_hex = language_data.upper().encode('utf-8').hex().upper()
# print(language_data_hex)
 
# print('6666666666C64B40')

# decimal_number = 55.55
# hex_number = float.hex(decimal_number).upper()
# print(hex_number)


# value = 55.55
# hex_value = hex(int(value))
# print(hex_value)



# import tkinter as tk
# from tkinter import ttk
# from customtkinter import CTkButton, CTkCheckBox

# class CustomGUI:
#     def __init__(self):
#         self.root = tk.Tk()
#         self.root.title('Custom GUI')
#         self.root.geometry("600x400")

#         # Create a treeview
#         tree_frame = ttk.Frame(self.root)
#         tree_frame.pack(pady=10)
#         self.tree = ttk.Treeview(tree_frame, columns=('date', 'off'), show='headings')
#         self.tree.column("date", width=200)
#         self.tree.column("off", width=100)
#         self.tree.heading("date", text="Date")
#         self.tree.heading("off", text="Offset")
#         self.tree.pack()

#         # Create a custom button
#         custom_button = CTkButton(self.root, text="SAVE", font=('Arial', 12, 'bold'), text_color="black", width=10, height=2)
#         custom_button.pack(pady=10)

#         # Create a custom checkbox
#         custom_checkbox = CTkCheckBox(self.root, text="Enable Feature")
#         custom_checkbox.pack(pady=10)

#         self.root.mainloop()

# if __name__ == "__main__":
#     CustomGUI()


# print('48E1  7A14AEC74B40')
# decimal_number = 55.56
# hex_number = float.hex(decimal_number).upper()
# print(hex_number)




# import tkinter.ttk
# from tkinter import *
# import tkinter as tk
# from customtkinter import CTkButton, CTkCheckBox
# import xml.etree.ElementTree as ET

# class dts_time_class:

#     def __init__(self):
#         self.project = tk.Tk()
#         self.project.title('Daylights')
#         self.project.geometry("400x400+500+200")
#         self.project.iconbitmap("logo2.ico")
#         self.project.configure(bg="lightsteelblue2", borderwidth="1")
#         # self.project.protocol("WM_DELETE_WINDOW", self.on_exit)
#         # self.project.grab_set()
#         # Allowing root window to not change it's size according to user's need
#         self.project.resizable(False, False)

#         self.project.maxsize(400, 405)
#         self.project.minsize(400, 405)
        
#         self.var_station_name = StringVar()
#         self.s = tkinter.ttk.Style(self.project)
#         self.s.theme_use('clam')
        
    

#         general_frame = Frame(self.project, relief=SUNKEN, bg='lightsteelblue1', bd=4)
#         general_frame.place(x=0,y=0, height=350, width=397)
        
#         self.display_line_entry_propaganda = tk.Entry(general_frame, font=('arial', 10, 'bold'), width=9, relief=SUNKEN, bd=2)
#         self.display_line_entry_propaganda.place(x=215, y=110)
        
#         my_tr = ET.parse("projectinfo.xml")
#         root = my_tr.getroot()
#         for i in root.findall("Configuration"):
            
#             self.PropagandaDisplayLine = i.find("PropagandaDisplayLine").text
#             self.display_line_entry_propaganda.insert(0,self.PropagandaDisplayLine)
        
        
        
#         def update_xml():
#             display_line_entry_propaganda = self.display_line_entry_propaganda.get()
            
#             my_tr = ET.parse("projectinfo.xml")
#             root = my_tr.getroot()
#             for i in root.findall("Configuration"):
#                 i.find("PropagandaDisplayLine").text = display_line_entry_propaganda
#             my_tr.write("projectinfo.xml")

                
                
#         # Create a button to trigger the update
#         select_Import_file = tk.Button(general_frame, text="SAVE", font=('arial', 13, 'bold'), width=10, height=3, command=update_xml)
#         select_Import_file.place(x=30, y=200)

#         self.project.mainloop()



# if __name__ == "__main__":
#     dts_time_class()


# import datetime
# import calendar

# t = datetime.datetime(2024, 3, 1, 1, 0, 0)
# print(f"1 =  {calendar.timegm(t.timetuple())}")

# t = datetime.datetime(2024, 3, 2, 2, 0, 0)
# print(f"2 =  {calendar.timegm(t.timetuple())}")

# t = datetime.datetime(2024, 3, 3, 3, 0, 0)
# print(f"3 =  {calendar.timegm(t.timetuple())}")

# t = datetime.datetime(2024, 3, 4, 4, 0, 0)
# print(f"4 =  {calendar.timegm(t.timetuple())}")

# t = datetime.datetime(2024, 3, 5, 5, 0, 0)
# print(f"5 =  {calendar.timegm(t.timetuple())}")



# import datetime
# import calendar
# a = '2024,03,05,05,00,00'
# date_and_time_percentage = datetime.datetime.strptime(a, '%Y,%m,%d,%H,%M,%S')
# change_dec_value = calendar.timegm(date_and_time_percentage.timetuple())
# hex_dec_and_time = format(int(change_dec_value), '02X')
# print(hex_dec_and_time)



# import datetime
# import calendar

# a = '02/03/2024-02:00:00'
# date, time = a.split('-')
# date_parts = date.split('/')
# time_parts = time.split(':')
# result = ','.join(date_parts + time_parts)
# date_and_time_percentage = datetime.datetime.strptime(result, '%d,%m,%Y,%H,%M,%S')
# change_dec_value = calendar.timegm(date_and_time_percentage.timetuple())
# hex_dec_and_time = format(int(change_dec_value), '02X')
# print(hex_dec_and_time)



# from tkinter import *
# from tkinter import ttk
# import shutil
# import pyodbc
# import main
# import tkinter as tk
# from tkinter import filedialog
# import tkinter.ttk
# import os
# import glob
# import crcmod.predefined
# import struct
# import binascii
# import xml.etree.ElementTree as ET
# import datetime
# import calendar
# from customtkinter import CTkButton, CTkCheckBox

# class MainApplication5:
#     def __init__(self): 
#         self.add_new = tk.Tk()
#         self.add_new.geometry("250x200+300+300")
#         self.add_new.title("Export Data")
#       #   self.add_new.protocol("WM_DELETE_WINDOW", self.on_exit)
        
#         self.e = tkinter.ttk.Style(self.add_new)
#         self.e.theme_use('clam')
        
#         general_frame = Frame(self.add_new, relief=SUNKEN, bg='lightsteelblue1', bd=4)
#         general_frame.place(x=0,y=0, height=200, width=250)
        
#         # Create the version Combobox
#         self.version_combobox = ttk.Combobox(general_frame , values=[str(i) for i in range(11)], width=5)
#         self.version_combobox.place(x=10, y=10)
        
#         self.version_combobox1 = ttk.Combobox(general_frame , values=[str(i) for i in range(11)], width=5)
#         self.version_combobox1.place(x=80, y=10)

#         self.version_combobox2 = ttk.Combobox(general_frame , values=[str(i) for i in range(11)], width=5)
#         self.version_combobox2.place(x=150, y=10)
        
        
#         self.export_data = CTkButton(general_frame, text="SAVE", font=('arial', 13, 'bold'), text_color="black", width=50, height=10, command=self.export_data_all)
#         self.export_data.place(x=100, y=150)
        
#         self.length_of_jstops = {1: 0}
#         self.length_of_rstops = {1: 0}

    # version = 0.0
    # def comboselect_version(self):
        # self.selected_version = self.version_combobox.get()
      
#     def export_data_all(self):
#         global version

#         self.selected_version = self.version_combobox.get()
#         self.selected_version1 = self.version_combobox1.get()
#         self.selected_version2 = self.version_combobox2.get()


#         export_folder = filedialog.askdirectory(title='Select Export Folder')

#         if not os.path.exists(export_folder):
#             os.makedirs(export_folder)

#         # Create the version folder
#         self.version_folder = os.path.join(export_folder, f'EXPORT {self.selected_version}{self.selected_version1}{self.selected_version2}')
#         if not os.path.exists(self.version_folder):
#             os.makedirs(self.version_folder)

#         # Create the subfolders for audio, video, banner, logo, and text
#         self.audio_folder = os.path.join(self.version_folder, 'AUDIO')
#         self.video_folder = os.path.join(self.version_folder, 'VIDEOS')
#         self.banner_folder = os.path.join(self.version_folder, 'BANNER')
#         self.logo_folder = os.path.join(self.version_folder, 'LOGO')
#         self.text_folder = os.path.join(self.version_folder, 'TEXT')
#         self.data_folder = os.path.join(self.version_folder, 'DATA')

#         # Create the subfolders if they don't exist
#         if not os.path.exists(self.audio_folder):
#             os.makedirs(self.audio_folder)
#         if not os.path.exists(self.video_folder):
#             os.makedirs(self.video_folder)
#         if not os.path.exists(self.banner_folder):
#             os.makedirs(self.banner_folder)
#         if not os.path.exists(self.logo_folder):
#             os.makedirs(self.logo_folder)
#         if not os.path.exists(self.text_folder):
#             os.makedirs(self.text_folder)
#         if not os.path.exists(self.data_folder):
#             os.makedirs(self.data_folder)
            
#         # Create the index.txt file heading
#         index_file_path = os.path.join(self.version_folder, 'INDEX.SYS')
#         with open(index_file_path, 'w', encoding='utf-8') as index_file:
#             index_file.write("  CRC     \tFILESIZE     \tFILENAME\n")

#         # Export audio files
#         path = "sqlData\\audio"
#         audio_files = glob.glob(os.path.join(path, '*MA*.mp3')) + glob.glob(os.path.join(path, '*ST*.mp3'))
#         print(audio_files)

#         for file in audio_files:
#             file_name = os.path.basename(file)
#             source_path = os.path.join(path, file_name)

#             if "MA" in file_name:
#                 destination_folder = os.path.join(self.audio_folder, "MESSAGE")
#             elif 'ST' in file_name:
#                 destination_folder = os.path.join(self.audio_folder, "STATIONS")
#             else:
#                 destination_folder = self.audio_folder

#             if not os.path.exists(destination_folder):
#                 os.makedirs(destination_folder)

#             destination_path = os.path.join(destination_folder, file_name)
#             print(destination_path,'9999999999999999999')
#             if os.path.exists(source_path):
#                 shutil.copyfile(source_path, destination_path)

#             # Calculate CRC and file size
#             crc_func = crcmod.predefined.mkCrcFun('crc-32')
#             with open(destination_path, 'rb') as file:
#                 crc_value = crc_func(file.read())

#             # Format the CRC value as crc_value:08X
#             crc_formatted = f"{crc_value:08X}"
#             file_size = os.path.getsize(destination_path)

#             # Append CRC, file size, and filename to index.txt
#             with open(index_file_path, 'a', encoding='utf-8') as index_file:
#                 index_file.write(f"{crc_formatted }     \t{file_size}     \t{destination_path}\n")




# if __name__ == "__main__":
#     MainApplication5()



# from tkinter import *
# from tkinter.ttk import *
# from sqlite3 import *
# from tkinter import messagebox
# import sign_up_1
# import Home_page


# class SafetyQuestion(Tk):
#     def __init__(self, *args, **kwargs):
#         Tk.__init__(self, *args, **kwargs)

#         self.title("Contact Book")
#         self.geometry('500x400')

#         self.style = Style()
#         self.style.configure('Head.TFrame', background='Blue')

#         self.head_frame = Frame(self, style='Head.TFrame')
#         self.head_frame.pack(side=TOP, fill=X)

#         self.style.configure('Head.TLabel', foreground='White', background='Blue', font=(NONE, 15))

#         self.head_label = Label(self.head_frame, text='Select one of the following Question:',
#                                 style='Head.TLabel')
#         self.head_label.pack(pady=3)

#         val = StringVar()
#         # val.set('Empty')

#         self.r1 = Radiobutton(self, text='What is your nickname?', variable=val, value='What?')                
#         self.r1.pack(anchor=W, pady=10, padx=10)
#         self.r2 = Radiobutton(self, text='What is the name of your pet?', variable=val,
#                               value='What is the name of your pet?')
#         self.r2.pack(anchor=W, pady=10, padx=10)
#         self.r3 = Radiobutton(self, text='What is your favourite food?', variable=val,
#                               value='What is your favourite food?')
#         self.r3.pack(anchor=W, pady=10, padx=10)
#         self.r4 = Radiobutton(self, text='What ia your favourite Bike?', variable=val,
#                               value='What ia your favourite Bike?')
#         self.r4.pack(anchor=W, pady=10, padx=10)

#         self.answer_frame = Frame(self, style='Head.TFrame')
#         self.answer_frame.pack(side=BOTTOM, fill=X)

#         self.style.configure('Ans.TLabel', foreground='White', background='Blue', font=(NONE, 12))

#         self.ans_label = Label(self.answer_frame, text='Answer:', style='Ans.TLabel')
#         self.ans_label.grid(row=0, column=0, pady=2)

#         self.style.configure('Ans.TEntry', foreground='Red', font=(NONE, 12))

#         self.ans_entry = Entry(self.answer_frame, style='Ans.TEntry', width=25)
#         self.ans_entry.grid(row=0, column=1, pady=2)

#         self.style.configure('Ans.TButton', forefround='Blue', font=(NONE, 12))

#        self.ans_sub_button = Button(self.answer_frame, text='Sign Up', style='Ans.TButton',
#                                     command=self.signup_button_click)
#        self.ans_sub_button.grid(row=0, column=2, pady=10, padx=150)

#     def signup_button_click(self):
#         signup_con = connect('AppDatabase.db')
#         signup_cur = signup_con.cursor()
#         signup_cur.execute("""update LoginData 
#                             set Question='{0}', Answer='{1}'
#                              where Email='{1}'""".format(self.val.get(),
#                                                          self.ans_entry.get(),
#                                                         sign_up_1.SignUp.send_email()))
#         signup_con.commit()
#         signup_con.close()
#         messagebox.showinfo('Successful', 'Successfully Signed Up')
#         self.destroy()
#         Home_page.HomePage()


# if __name__ == "__main__":
#     safety_question = SafetyQuestion()
#     safety_question.mainloop()


# import tkinter as tk
# from tkinter import filedialog
# import os
# import pyodbc
# import binascii
# import xml.etree.ElementTree as ET

# def export_gps_data():
    
#     # Connect to the SQL Server database
#     conn_str = ('DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
#     conn = pyodbc.connect(conn_str)
#     cursor = conn.cursor()

#     # Select the required columns from the table
#     query = 'SELECT [routeID],[routeStopID],[stationID],[distanceFromPrev] FROM [tbl_routeStops] order by routeID, routeStopID'
#     cursor.execute(query)
#     rows = cursor.fetchall()

#     # Create the GPS.DAT file in the DATA folder
#     export_folder = filedialog.askdirectory(title='Select Export Folder')
#     if not export_folder:
#         # User canceled the folder selection
#         return
    
#     data_folder = os.path.join(export_folder, 'DATA')
#     os.makedirs(data_folder, exist_ok=True)  # Create the folder if it doesn't exist

#     station_path = os.path.join(data_folder, 'COMBTRIG.DAT')
#     try:
#         with open(station_path, 'w', encoding='utf-8') as station_file:
#             for row in rows:
#                 routestops_id = row[0]
#                 routestopsorder_id = row[1]
#                 routestops_station_id = row[2]
#                 routestops_distance_preview = row[3]
                
#                 hex_value_routestops_id = format(int(routestops_id), '04X')

#                 hex_value_routestopsorder_id = format(int(routestopsorder_id), '04X')

#                 hex_value_routestops_station_id = format(int(routestops_station_id), '04X')
                
#                 if routestops_distance_preview and routestops_distance_preview != 'Empty':
#                     hex_value_routestops_distance_preview = hex(int(routestops_distance_preview))[2:].upper().zfill(8)
#                 else:
#                     hex_value_routestops_distance_preview = '0000'



#                 station_file.write(f"{hex_value_routestops_id},{hex_value_routestopsorder_id},{hex_value_routestops_station_id},{hex_value_routestops_distance_preview}\n")
#     except Exception as e:
#         print(f"An error occurred while exporting GPS data111000: {e}")
#     finally:
#         cursor.close()
#         conn.close()

# window = tk.Tk()
# window.geometry('200x200')

# frame = tk.Frame(window)
# frame.pack()

# button = tk.Button(frame, text="Export GPS Data", command=export_gps_data)
# button.pack()

# window.mainloop()



import tkinter as tk
from tkinter import filedialog
import os
import pyodbc
import binascii
import xml.etree.ElementTree as ET

def export_gps_data():
    
    conn_str = (
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=DP-ANKIT-PTC\MSSQLSERVER01;DATABASE=triggers;Trusted_Connection=yes;')
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()

                
    # Select the required columns from the table
    query = "SELECT [ISOlang], [stationNameAudio], [stationName], [stationNameShort] FROM [triggers].[dbo].[tbl_stationNames] order by stationID, numLanguage"
    cursor.execute(query)
    rows = cursor.fetchall()

    # Create the GPS.DAT file in the DATA folder
    export_folder = filedialog.askdirectory(title='Select Export Folder')
    if not export_folder:
        # User canceled the folder selection
        return
    
    data_folder = os.path.join(export_folder, 'DATA')
    os.makedirs(data_folder, exist_ok=True)  # Create the folder if it doesn't exist

    station_path = os.path.join(data_folder, 'COMBTRIG.DAT')
    
        # print(self.length_of_jstops, "jjjjjjjjjjj stop")
    with open(station_path, 'w', encoding='utf-8') as station_file:
        list_language_data = {}
        my_tr = ET.parse("projectinfo.xml")
        root = my_tr.getroot()
        for i in root.findall("ImsLanguages"):
            it = i.find("Code").text
            it1 = i.find("uni_sub").text
            it2 = i.find("add").text
            it3 = i.find("graphics").text
            list_language_data[it] = (it1, it2)
        for row in rows:
            if list_language_data.get(row[0]):
                station_num_en = row
                station_num1_en = station_num_en[1]

                station_value_get_en = station_num1_en.replace('ST', '').replace('.MP3', '')
                digits1_en = ''.join(char1 for char1 in station_value_get_en if char1.isdigit())
                hex_value_station_en = format(int(digits1_en), '04X')
                digits2_en = ''.join(char2 for char2 in station_value_get_en if char2.isalpha())
                name_lang_station_en = binascii.hexlify(''.join(digits2_en).encode()).decode().upper()
                station_data_get_en = hex_value_station_en + name_lang_station_en

                unicode_text = row[2]
                unicode_text_short = row[3]
                add_and_subtract = list_language_data.get(row[0])
                subtract = add_and_subtract[0]
                add = add_and_subtract[1]

                result = []
                for character in unicode_text:
                    print(character,'yyyy')
                    code_point = ord(character)
                    # print(code_point,'uuuuuuuuuuuu')
                    if code_point == 32:
                        hex_code = "20"
                    else:
                        if subtract == "00":
                            hex_1_add = code_point - int(subtract, 16)
                            if len(str(hex_1_add)) >= 2:
                                print('111111111')
                                hex_2 = hex_1_add + int(add, 16)
                                print('22222222222')
                                hex_code = hex(hex_2)[2:].upper().zfill(4)
                                print('33333333')
                            else:
                                hex_2 = hex_1_add + int(add, 16)
                                print('55555')
                                hex_code = hex(hex_2)[2:].upper()
                                print('6666')
                        elif subtract == "01":
                            print('888888')
                            hex_1_add = code_point - int(subtract, 16)+1
                            print(hex_1_add,'99999')
                            hex_2 = hex_1_add + int(add, 16)
                            print(hex_2,'101010101')
                            hex_code = hex(hex_2)[2:].upper().zfill(4)[-2:]
                        else:
                            hex_code = hex(code_point - int(subtract, 16) + int(add, 16))[2:].upper()
                    result.append(hex_code)
                output = ''.join(result)
                print(output)

                pairs_output = [output[i:i+2] for i in range(0, len(output), 2)]
                count_output = len(pairs_output)
                hex_value_len = format(int(count_output), '02X')

        

                station_file.write(f"{station_data_get_en},{it3},{hex_value_len},{output}\n")


window = tk.Tk()
window.geometry('200x200')

frame = tk.Frame(window)
frame.pack()

button = tk.Button(frame, text="Export GPS Data", command=export_gps_data)
button.pack()

window.mainloop()