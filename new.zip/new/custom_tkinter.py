# import tkinter
# from customtkinter import CTkButton # <- import the CustomTkinter module
#
# root_tk = tkinter.Tk()  # create the Tk window like you normally do
# root_tk.geometry("400x240")
# root_tk.title("CustomTkinter Test")
#
# window_bg_color = "#DDD0C8"
# fg_color_button = "#323232"
# text_color_button = "#ffffff"
# hover_color_button = "black"
# fontstyle_for_button = ("dubai medium", 15)
#
#
# root_tk.configure(bg=window_bg_color)
# def button_function():
#     print("button pressed")
#
# # Use CTkButton instead of tkinter Button
# button = CTkButton(master=root_tk, corner_radius=50, command=button_function, bg_color=window_bg_color, fg_color=fg_color_button,
#                    font=fontstyle_for_button, text="SHOP NOW", text_color=text_color_button, hover_color=hover_color_button)
# button.place(relx=0.5, rely=0.5, anchor=tkinter.CENTER)
#
# root_tk.mainloop()


import tkinter as tk

def button_clicked():
    print("Button clicked!")

root = tk.Tk()

# Creating a button with specified options
button = tk.Button(root,
                   text="Click Me",
                   command=button_clicked,
                   activebackground="blue",
                   activeforeground="white",
                   anchor="center",
                   bd=3,
                   bg="lightgray",
                   cursor="hand2",
                   disabledforeground="gray",
                   fg="black",
                   font=("Arial", 12),
                   height=2,
                   highlightbackground="black",
                   highlightcolor="green",
                   highlightthickness=2,
                   justify="center",
                   overrelief="raised",
                   padx=10,
                   pady=5,
                   width=15,
                   wraplength=100)

button.pack(padx=20, pady=20)

root.mainloop()