

# new = {"Mumbai CSMT to Dadar": 32, "Dadar to Vikhroli": 27, "Vikhroli to Bhandup": 19, "Bhandup to Mulund": 21,
#        "Ghatkopar to Bhandup": 23, "Bhandup to Thane": 21, "Vikhroli to Mulund": 19,"Kurla to Bhandup": 21, "Kurla to Vikhroli":21,
#        "Dadar to Ghatkopar": 23, "Thane to Diva": 19, "Diva to Dombivli": 29, "Dadar to Thane": 27, "Matunga to Kurla":19
#        ,"Dombivli to Diva": 23, "Diva to Thane": 21, "Thane to Bhandup":23, "Bhandup to Ghatkopar": 20, "Mulund to Vikhroli":29, "Vikhroli to Kurla": 23
#        , "Mulund to Bhandup":22, "Bhandup to Vikhroli": 20, "Kurla to Matunga":27, "Matunga to Parel": 23, "Parel to Byculla": 21,
#        "Thane to Mulund": 23,"Vikhroli to Thane":19, "Kurla to Mulund": 28, "Thane to Vikhroli": 23, "Thane to Dolavali":31, "Dolavali to Kalyan": 27,
#        "Byculla to Parel": 31,"Mumbra to Dombivli":21 , "Kurla to Thane": 28
#
#        }
# print(new["Thane to Bhandup"])

print("123456789".replace("2", "S").replace("5", "F"))
